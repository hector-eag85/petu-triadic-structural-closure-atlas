# Code Availability

All available analysis code in this release-candidate package is organized under `06_code_repository/`.

The final public release should include one executable pipeline for each discovery-domain analysis, one executable pipeline for each independent tier-1 validation analysis, shared utility functions, table-generation scripts and figure-generation scripts.

The final release should be archived with a persistent DOI through Zenodo, Figshare, OSF, an institutional repository or equivalent archive.

Internal LETU, Calx Mariae, Perichoresis-related conceptual materials or philosophical/theological companion texts are excluded from the empirical code release.

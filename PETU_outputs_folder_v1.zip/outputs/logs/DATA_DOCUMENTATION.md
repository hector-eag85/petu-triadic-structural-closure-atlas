# Data Documentation

Each domain must provide the source dataset, access date, raw format, processed sample size, number of natural observations/windows, number of auxiliary perturbative/null rows, operational definitions of H/S/L/Φ, perturbation/null model descriptions and final output filenames.

The independent tier-1 validation block must additionally report what was preserved from the primary pipeline, what dataset/substrate changed, whether H_raw and H_structured were separated, and what group-cross-validation or external endpoint strategy was used.

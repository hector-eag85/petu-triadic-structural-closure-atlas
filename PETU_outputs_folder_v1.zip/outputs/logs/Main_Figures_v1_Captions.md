# PETU/LETU Main Figures v1 — Captions

Figure 1 | Cross-scale empirical atlas for triadic structural closure.
Introduces the H-S-L-Phi architecture, Atlas 4-4-4 and discovery-to-replication workflow.

Figure 2 | Triadic models reconstruct coherence Phi and functional unity.
Shows HSL->Phi R2 and HSL->Unity R2 across twelve domains.

Figure 3 | Linkage prediction from structured support H+S.
Shows H+S->L R2 where directly reported in the reduced source table. Missing values are marked as not reported.

Figure 4 | Perturbations reduce coherence and triadic integration.
Shows percent increase of Phi or Phi_HSL in natural/integrated conditions over perturbed variants where summary contrasts were available.

Figure 5 | Fragility emerges as triadic disproportion.
Compares HSL->Fragility R2 and full/disproportion classification performance.

Figure 6 | Cross-scale evidence map and flagship anchor domains.
Summarizes evidence grade across the twelve-domain Atlas 4-4-4.

# Preregistration Roadmap

Each future replication should freeze H/S/L/Φ definitions, dataset inclusion rules, primary endpoint, secondary endpoints, null models, perturbative contrasts, group-cross-validation strategy, success criteria and falsification criteria.

Core falsification criteria:
1. HSL does not reconstruct Φ or Unity above prespecified null thresholds.
2. HSL does not outperform H-only where H_raw is properly isolated.
3. Predicted perturbations do not reduce coherence or increase fragility.
4. Triadic disproportion is unrelated to pathology, instability or loss of resilience.
5. Cross-domain convergence disappears under harmonized independent replication.

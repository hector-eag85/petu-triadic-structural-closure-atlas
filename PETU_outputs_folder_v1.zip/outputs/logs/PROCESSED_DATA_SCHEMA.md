# Processed Data Schema

Recommended shared fields:
domain, scale, sample_id, group_id, variant, is_natural, H_raw, H_structured, H, S, L, Phi_obs, Phi_HSL, Unity_HSL, Balance_HSL, Dominance_HSL, Fragility, scale_parameter, notes.

If H_raw and H_structured are not both available, the domain-specific Methods section must state whether H is minimally structured or already structure-bearing.

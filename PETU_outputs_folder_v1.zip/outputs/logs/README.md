# PETU/LETU Atlas 4–4–4 — Release Candidate v1

This package is a local release-candidate assembly of the empirical PETU/LETU Atlas 4–4–4 publication package.

## Included
- Base English and Spanish manuscript files.
- Publication skeleton.
- Figure/table source document.
- Independent replication document.
- Main Figures v1 package and files.
- Extended Data Figure prototypes 1–8.
- Available domain pipeline scripts.
- Available logs and pasted run outputs.
- Data and Code Availability final text.
- Reproducibility audit final text.
- Raw data source table.
- Tier-1 independent validation table.
- Preregistration roadmap.
- Reviewer response reserve.
- SHA256 checksums.

## Empirical language policy
The empirical paper uses naturalistic scientific language only. LETU, Calx Mariae, Perichoresis and theological interpretation are excluded from the empirical submission package.

## Remaining external actions
This local package becomes a public release only after upload to a public repository/archive, DOI creation and replacement of repository/DOI placeholders.

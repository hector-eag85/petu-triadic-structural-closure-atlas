# Run Order

1. Install environment from requirements.txt or environment.yml.
2. Run discovery-domain pipelines.
3. Run tier-1 validation pipelines.
4. Export statistical outputs.
5. Generate Supplementary Tables.
6. Generate Main Figures and Extended Data Figures from audited source tables.
7. Run generate_checksums.py.
8. Freeze release and archive externally with DOI.

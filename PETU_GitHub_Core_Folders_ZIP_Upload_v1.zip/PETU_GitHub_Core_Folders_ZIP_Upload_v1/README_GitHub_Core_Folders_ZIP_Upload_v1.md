# PETU GitHub Core Folders ZIP Upload v1

Generated: 2026-06-23

These ZIP files package the requested core folders for upload to GitHub without uploading hundreds of loose files:

- manuscript/
- supplementary_tables/
- main_figures/
- extended_data_figures/

Recommended use:

1. Upload each ZIP as a GitHub Release asset under release `v1.0.0`, or upload the ZIPs into the repository root if you prefer.
2. In the release description, state that these ZIPs contain the core manuscript, supplementary tables, main figures and extended data figures.
3. Keep the package status as: PASS_STRUCTURAL / PENDING_FINAL_LOG_AUDIT.

Suggested release note:

`The folders manuscript/, supplementary_tables/, main_figures/ and extended_data_figures/ are provided as compressed release assets to preserve the full reproducibility package while avoiding web-interface upload limits.`

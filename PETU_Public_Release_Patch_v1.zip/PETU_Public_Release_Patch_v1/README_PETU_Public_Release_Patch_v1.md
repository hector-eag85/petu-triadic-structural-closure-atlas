# PETU Public Release Patch v1

Generated: 2026-06-23

Repository: https://github.com/hector-eag85/petu-triadic-structural-closure-atlas

Archived DOI: https://doi.org/10.5281/zenodo.20820252

Preprint DOI: pending

Status: PASS_METADATA_PATCH / PENDING_FINAL_LOG_AUDIT.

This patch resolves repository and archived DOI placeholders in GitHub root patch files and patched journal-facing DOCX/PDF documents. It does not close the final numerical/log audit.

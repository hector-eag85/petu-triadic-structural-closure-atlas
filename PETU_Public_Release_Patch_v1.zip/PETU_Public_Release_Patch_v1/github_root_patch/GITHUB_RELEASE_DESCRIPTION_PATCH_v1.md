# GitHub Release Description Patch v1

This release contains the PETU reproducibility package for **Triadic structural closure across twelve natural domains**.

Repository: https://github.com/hector-eag85/petu-triadic-structural-closure-atlas

Archived DOI: https://doi.org/10.5281/zenodo.20820252

The package includes manuscript materials, supplementary information, supplementary tables, main figures, extended data figures, source tables, scripts, logs, audit files and reproducibility documentation.

Release status: **PASS_STRUCTURAL / PENDING_FINAL_LOG_AUDIT**.

Before public preprint or journal submission, the ST9 Independent Validation final log audit, final script-to-output mapping and preprint DOI replacement remain pending.

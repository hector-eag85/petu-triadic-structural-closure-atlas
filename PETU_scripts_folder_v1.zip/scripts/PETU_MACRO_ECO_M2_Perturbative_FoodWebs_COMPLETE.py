# ============================================================
# PETU-MACRO-ECO M2 - Perturbative Food-Web Audit
# ============================================================
# Tests PETU macro-ecology perturbatively:
#   H = eco-material support
#   S = ecological structure/form
#   L = ecological linkage/cohesion
#   Phi = resilience / functional ecosystem unity
#
# M2 adds targeted perturbations:
#   random attack, H-support attack, S-bridge attack, L-hub attack
# ============================================================

!pip -q install requests numpy scipy pandas scikit-learn networkx matplotlib tqdm

import os, json, random, warnings, shutil
warnings.filterwarnings('ignore')
import requests
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

OUTDIR = '/content/PETU_MACRO_ECO_M2_Perturbative_FoodWebs'
os.makedirs(OUTDIR, exist_ok=True)
BASE = 'https://mangal.io/api/v2'
MAX_NETWORKS_REQUESTED = 120
TARGET_OK_NETWORKS = 50
MIN_NODES, MAX_NODES, MIN_EDGES = 8, 250, 8
EPSILON = 0.05
ROBUSTNESS_REPS = 20
ATTACK_FRACTIONS = np.linspace(0.05, 0.50, 10)
random.seed(42); np.random.seed(42)

def normalize01(x):
    x=np.asarray(x,dtype=float); mn=np.nanmin(x); mx=np.nanmax(x)
    return np.zeros_like(x) if mx-mn<1e-12 else (x-mn)/(mx-mn)

def safe_spearman(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        m=np.isfinite(a)&np.isfinite(b)
        if m.sum()<3: return None,None
        r,p=spearmanr(a[m],b[m]); return float(r),float(p)
    except Exception: return None,None

def safe_mw(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        a=a[np.isfinite(a)]; b=b[np.isfinite(b)]
        if len(a)<3 or len(b)<3: return None,None
        s,p=mannwhitneyu(a,b,alternative='two-sided'); return float(s),float(p)
    except Exception: return None,None

def triadic_balance(h,s,l): return float(max(0,1-np.std([h,s,l])))
def dominance_index(h,s,l): return float(max(h,s,l)-min(h,s,l))

def api_get(path, params=None):
    r=requests.get(BASE+path, params=params or {}, timeout=30); r.raise_for_status(); return r.json()

def list_networks(limit):
    nets=[]; page=0
    while len(nets)<limit and page<20:
        try: data=api_get('/network', {'page':page,'count':100})
        except Exception: break
        items=data.get('data',data) if isinstance(data,dict) else data
        if not items: break
        nets.extend(items); page+=1
    return nets[:limit]

def get_interactions(network_id):
    out=[]; page=0
    while page<50:
        try: data=api_get('/interaction', {'network_id':network_id,'page':page,'count':100})
        except Exception: break
        items=data.get('data',data) if isinstance(data,dict) else data
        if not items: break
        out.extend(items)
        if len(items)<100: break
        page+=1
    return out

def node_id(x):
    if isinstance(x,dict): return x.get('id') or x.get('_id') or x.get('name')
    return x

def interaction_nodes(it):
    a=b=None
    for k in ['node_from','node1','source','consumer','predator','from']:
        if k in it and it[k] is not None: a=node_id(it[k]); break
    for k in ['node_to','node2','target','resource','prey','to']:
        if k in it and it[k] is not None: b=node_id(it[k]); break
    return a,b

def build_graph(interactions):
    G=nx.DiGraph()
    for it in interactions:
        a,b=interaction_nodes(it)
        if a is None or b is None or a==b: continue
        G.add_edge(str(a),str(b))
    return G

def trophic_proxy(G):
    n=G.number_of_nodes()
    if n==0: return 0,0
    indeg=dict(G.in_degree()); outdeg=dict(G.out_degree())
    basal=[v for v in G.nodes() if min(indeg[v],outdeg[v])==0]
    top=[v for v in G.nodes() if max(indeg[v],outdeg[v])>0 and min(indeg[v],outdeg[v])==0]
    return len(basal)/n, len(top)/n

def graph_metrics(Gd):
    Gu=Gd.to_undirected(); n=Gu.number_of_nodes(); m=Gu.number_of_edges()
    if n==0: raise ValueError('empty graph')
    connectance=0 if n<2 else 2*m/(n*(n-1)); density=nx.density(Gu)
    deg=np.array([d for _,d in Gu.degree()],dtype=float)
    mean_degree=float(deg.mean()) if len(deg) else 0
    std_degree=float(deg.std()) if len(deg) else 0
    max_degree=float(deg.max()) if len(deg) else 0
    if deg.sum()>0:
        p=deg/deg.sum(); degree_entropy=float(-np.sum(p*np.log(p+1e-12))/np.log(len(p)+1e-12))
    else: degree_entropy=0
    clustering=float(nx.average_clustering(Gu)) if n else 0
    efficiency=float(nx.global_efficiency(Gu)) if n else 0
    comps=list(nx.connected_components(Gu)); lcc=max(len(c) for c in comps)/n if comps else 0
    try:
        assort=nx.degree_assortativity_coefficient(Gu)
        assort=0 if not np.isfinite(assort) else abs(float(assort))
    except Exception: assort=0
    modularity_proxy=len(comps)/n if n else 0
    basal,top=trophic_proxy(Gd)
    H_raw=np.mean([np.log1p(n),np.log1p(m),basal,1/(1+abs(connectance-0.10)),lcc])
    S_raw=np.mean([degree_entropy,1/(1+std_degree),clustering,assort,modularity_proxy,top])
    L_raw=np.mean([connectance,density,efficiency,clustering,lcc,mean_degree/(n+1e-12)])
    return dict(n_species=n,n_interactions=m,connectance_raw=connectance,density_raw=density,
                mean_degree=mean_degree,std_degree=std_degree,max_degree=max_degree,
                degree_entropy=degree_entropy,clustering=clustering,efficiency=efficiency,lcc_fraction=lcc,
                assortativity_abs=assort,modularity_proxy=modularity_proxy,basal_like_fraction=basal,
                top_like_fraction=top,H_raw=H_raw,S_raw=S_raw,L_raw=L_raw)

def remove_nodes_and_secondary_extinctions(Gd, initial_remove):
    G=Gd.copy(); n0=max(G.number_of_nodes(),1)
    G.remove_nodes_from([v for v in initial_remove if v in G])
    changed=True
    while changed and G.number_of_nodes()>0:
        changed=False; Gu=G.to_undirected(); isolated=list(nx.isolates(Gu))
        if isolated: G.remove_nodes_from(isolated); changed=True
    return G.number_of_nodes()/n0

def attack_order(Gd, attack_type):
    Gu=Gd.to_undirected(); nodes=list(Gu.nodes())
    if attack_type=='random':
        z=nodes[:]; random.shuffle(z); return z
    deg=dict(Gu.degree())
    if attack_type=='L_attack_hubs': return sorted(nodes,key=lambda v:deg.get(v,0),reverse=True)
    if attack_type=='S_attack_bridges':
        try: btw=nx.betweenness_centrality(Gu,normalized=True)
        except Exception: btw={v:0 for v in nodes}
        return sorted(nodes,key=lambda v:(btw.get(v,0),deg.get(v,0)),reverse=True)
    if attack_type=='H_attack_basal':
        indeg=dict(Gd.in_degree()); outdeg=dict(Gd.out_degree())
        return sorted(nodes,key=lambda v:(min(indeg.get(v,0),outdeg.get(v,0)),-deg.get(v,0)))
    if attack_type=='balanced_attack':
        try: btw=nx.betweenness_centrality(Gu,normalized=True)
        except Exception: btw={v:0 for v in nodes}
        cl=nx.clustering(Gu)
        return sorted(nodes,key=lambda v:deg.get(v,0)+5*btw.get(v,0)+cl.get(v,0),reverse=True)
    return nodes

def robustness_curve(Gd, attack_type):
    n=Gd.number_of_nodes(); rows=[]
    reps=ROBUSTNESS_REPS if attack_type=='random' else 1
    for rep in range(reps):
        order=attack_order(Gd,attack_type)
        for f in ATTACK_FRACTIONS:
            k=max(1,int(round(f*n))); surv=remove_nodes_and_secondary_extinctions(Gd,order[:k])
            rows.append(dict(attack_type=attack_type,rep=rep,fraction_removed=float(f),survival=surv))
    return rows

def auc_resilience(cdf):
    d=cdf.groupby('fraction_removed')['survival'].mean().reset_index()
    return float(np.trapz(d.survival,d.fraction_removed)/(d.fraction_removed.max()-d.fraction_removed.min()+1e-12))

def regression(data,X_cols,y_col,label):
    d=data[X_cols+[y_col]].dropna()
    X=d[X_cols].values.astype(float); y=d[y_col].values.astype(float)
    model=Ridge(alpha=1.0).fit(X,y); pred=model.predict(X)
    r,p=safe_spearman(y,pred)
    return dict(test=label,n=int(len(d)),r2=float(r2_score(y,pred)),mae=float(mean_absolute_error(y,pred)),spearman_true_pred=r,p_value=p)

def auc_model(data,features,target,label):
    d=data[features+[target]].dropna()
    if len(d)<20 or len(d[target].unique())<2: return None
    X=d[features].values.astype(float); y=d[target].astype(int).values
    try:
        clf=LogisticRegression(max_iter=1000,class_weight='balanced').fit(X,y)
        auc=float(roc_auc_score(y,clf.predict_proba(X)[:,1]))
    except Exception: auc=np.nan
    return dict(feature_set=label,target=target,n=int(len(d)),auc=auc)

print('='*60); print('PETU-MACRO-ECO M2 PERTURBATIVE FOOD-WEB AUDIT'); print('='*60)
print('Fetching public Mangal networks...')
networks=list_networks(MAX_NETWORKS_REQUESTED)
print('Networks discovered:',len(networks))

rows=[]; curve_rows=[]; failures=[]
for net in tqdm(networks,desc='Processing networks'):
    if len(rows)>=TARGET_OK_NETWORKS: break
    try:
        net_id=net.get('id') or net.get('_id')
        if net_id is None: continue
        Gd=build_graph(get_interactions(net_id))
        n=Gd.number_of_nodes(); m=Gd.number_of_edges()
        if n<MIN_NODES or n>MAX_NODES or m<MIN_EDGES: continue
        feats=graph_metrics(Gd)
        aucs={}
        for at in ['random','H_attack_basal','S_attack_bridges','L_attack_hubs','balanced_attack']:
            c=robustness_curve(Gd,at); cdf=pd.DataFrame(c); aucs['resilience_'+at]=auc_resilience(cdf)
            for rr in c:
                rr.update(network_id=net_id,network_name=net.get('name','')); curve_rows.append(rr)
        random_res=aucs['resilience_random']; H_res=aucs['resilience_H_attack_basal']; S_res=aucs['resilience_S_attack_bridges']; L_res=aucs['resilience_L_attack_hubs']; B_res=aucs['resilience_balanced_attack']
        frag=np.mean([1-H_res,1-S_res,1-L_res,1-B_res])
        rows.append(dict(network_id=net_id,network_name=net.get('name',''),**feats,**aucs,
                         Phi_resilience=random_res,H_attack_resilience=H_res,S_attack_resilience=S_res,
                         L_attack_resilience=L_res,balanced_attack_resilience=B_res,
                         Pathological_fragility_index=frag))
        if len(rows)%10==0: print('  OK networks:',len(rows))
    except Exception as e:
        failures.append(dict(network=str(net.get('id','NA')),error=str(e)))

metrics=pd.DataFrame(rows); curves=pd.DataFrame(curve_rows)
if len(metrics)<10: raise RuntimeError('Too few networks processed')
for col in ['H_raw','S_raw','L_raw']:
    metrics[col.replace('_raw','')]=normalize01(metrics[col].values)
metrics['Phi_HSL_epsilon']=(metrics.H+EPSILON)*(metrics.S+EPSILON)*(metrics.L+EPSILON)
metrics['Triadic_balance']=[triadic_balance(h,s,l) for h,s,l in zip(metrics.H,metrics.S,metrics.L)]
metrics['Functional_unity_HSL']=metrics.Phi_HSL_epsilon*metrics.Triadic_balance
metrics['Dominance_index']=[dominance_index(h,s,l) for h,s,l in zip(metrics.H,metrics.S,metrics.L)]
metrics['robust_high_flag']=metrics.Phi_resilience>=metrics.Phi_resilience.median()
metrics['fragile_high_flag']=metrics.Pathological_fragility_index>=metrics.Pathological_fragility_index.median()
metrics['L_hyperconnectivity_flag']=(metrics.L>=metrics.L.quantile(.75))&(metrics.Phi_resilience<=metrics.Phi_resilience.median())
metrics['triadic_disproportion_flag']=(metrics.Dominance_index>=metrics.Dominance_index.quantile(.75))|(metrics.Triadic_balance<=metrics.Triadic_balance.quantile(.25))|metrics.L_hyperconnectivity_flag

genesis_summary=pd.DataFrame([
    regression(metrics,['H'],'S','M2_H_to_S'),
    regression(metrics,['H'],'L','M2_H_to_L'),
    regression(metrics,['S'],'L','M2_S_to_L'),
    regression(metrics,['H','S'],'L','M2_H_plus_S_to_L'),
    regression(metrics,['H','S','L'],'Phi_resilience','M2_HSL_to_RandomResilience'),
    regression(metrics,['H','S','L'],'H_attack_resilience','M2_HSL_to_HAttackResilience'),
    regression(metrics,['H','S','L'],'S_attack_resilience','M2_HSL_to_SAttackResilience'),
    regression(metrics,['H','S','L'],'L_attack_resilience','M2_HSL_to_LAttackResilience'),
    regression(metrics,['H','S','L'],'Functional_unity_HSL','M2_HSL_to_FunctionalUnity'),
    regression(metrics,['H','S','L','Triadic_balance','Dominance_index'],'Pathological_fragility_index','M2_Full_to_PathologicalFragility')])

def get_mae(test): return float(genesis_summary.loc[genesis_summary.test==test,'mae'].iloc[0])
H_L,S_L,HS_L=get_mae('M2_H_to_L'),get_mae('M2_S_to_L'),get_mae('M2_H_plus_S_to_L')
emergence_contrast=pd.DataFrame([dict(level='macro_eco_perturbative',H_to_L_mae=H_L,S_to_L_mae=S_L,H_plus_S_to_L_mae=HS_L,HS_improves_over_H=H_L-HS_L,HS_improves_over_S=S_L-HS_L,PETU_prediction_supported=HS_L<H_L and HS_L<S_L)])

attack_cols=['Phi_resilience','H_attack_resilience','S_attack_resilience','L_attack_resilience','balanced_attack_resilience']
perturbation_summary=pd.DataFrame([dict(outcome=col,mean=float(metrics[col].mean()),std=float(metrics[col].std()),min=float(metrics[col].min()),median=float(metrics[col].median()),max=float(metrics[col].max()),spearman_with_H=safe_spearman(metrics.H,metrics[col])[0],spearman_with_S=safe_spearman(metrics.S,metrics[col])[0],spearman_with_L=safe_spearman(metrics.L,metrics[col])[0],spearman_with_PhiHSL=safe_spearman(metrics.Phi_HSL_epsilon,metrics[col])[0],spearman_with_balance=safe_spearman(metrics.Triadic_balance,metrics[col])[0],spearman_with_dominance=safe_spearman(metrics.Dominance_index,metrics[col])[0]) for col in attack_cols])
attack_contrast=pd.DataFrame([
    dict(attack='H_attack_basal',mean_resilience=float(metrics.H_attack_resilience.mean()),mean_loss_vs_random=float(metrics.Phi_resilience.mean()-metrics.H_attack_resilience.mean())),
    dict(attack='S_attack_bridges',mean_resilience=float(metrics.S_attack_resilience.mean()),mean_loss_vs_random=float(metrics.Phi_resilience.mean()-metrics.S_attack_resilience.mean())),
    dict(attack='L_attack_hubs',mean_resilience=float(metrics.L_attack_resilience.mean()),mean_loss_vs_random=float(metrics.Phi_resilience.mean()-metrics.L_attack_resilience.mean())),
    dict(attack='balanced_attack',mean_resilience=float(metrics.balanced_attack_resilience.mean()),mean_loss_vs_random=float(metrics.Phi_resilience.mean()-metrics.balanced_attack_resilience.mean()))])

def contrast_table(flag_true,flag_false,name):
    A=metrics[flag_true]; B=metrics[flag_false]; rows=[]
    for col in ['H','S','L','Phi_HSL_epsilon','Triadic_balance','Functional_unity_HSL','Dominance_index','Phi_resilience','Pathological_fragility_index','H_attack_resilience','S_attack_resilience','L_attack_resilience','connectance_raw','n_species','n_interactions']:
        stat,p=safe_mw(A[col],B[col])
        rows.append(dict(metric=col,groupA_mean=float(A[col].mean()),groupB_mean=float(B[col].mean()),delta_A_minus_B=float(A[col].mean()-B[col].mean()),pct_delta=float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)),mannwhitney_stat=stat,p_value=p))
    df=pd.DataFrame(rows); df.insert(0,'contrast',name); return df
robust_fragile_contrast=contrast_table(metrics.robust_high_flag==True,metrics.robust_high_flag==False,'robust_vs_fragile')
triadic_pathology_summary=contrast_table(metrics.triadic_disproportion_flag==True,metrics.triadic_disproportion_flag==False,'disproportion_vs_proportion')

class_rows=[]
for target in ['robust_high_flag','fragile_high_flag','triadic_disproportion_flag','L_hyperconnectivity_flag']:
    for cols,label in [(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]:
        r=auc_model(metrics,cols,target,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)
gain=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x=d[d.feature_set==fs]; return None if len(x)==0 else float(x.auc.iloc[0])
    aH,aHS,aHSL,aFull=auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gain.append(dict(target=target,auc_H=aH,auc_HS=aHS,auc_HSL=aHSL,auc_full=aFull,gain_HSL_over_H=None if aH is None or aHSL is None else aHSL-aH,gain_HSL_over_HS=None if aHS is None or aHSL is None else aHSL-aHS,gain_full_over_HSL=None if aFull is None or aHSL is None else aFull-aHSL))
classification_gain_summary=pd.DataFrame(gain)

def phase(r):
    if r.L_hyperconnectivity_flag: return 'L_hyperlinked_fragile'
    if r.triadic_disproportion_flag: return 'triadic_disproportion'
    if r.Phi_resilience>=metrics.Phi_resilience.median() and r.Triadic_balance>=metrics.Triadic_balance.median(): return 'resilient_phi_integrated'
    if r.S>=metrics.S.median() and r.L<=metrics.L.quantile(.25): return 'S_structure_low_link'
    if r.H<=metrics.H.quantile(.25): return 'low_support_H'
    return 'transitional'
metrics['PETU_M2_phase']=metrics.apply(phase,axis=1)
phase_summary=metrics.groupby('PETU_M2_phase').agg(n_networks=('network_id','count'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi_HSL=('Phi_HSL_epsilon','mean'),mean_resilience=('Phi_resilience','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_fragility=('Pathological_fragility_index','mean'),mean_H_attack_res=('H_attack_resilience','mean'),mean_S_attack_res=('S_attack_resilience','mean'),mean_L_attack_res=('L_attack_resilience','mean')).reset_index().sort_values('n_networks',ascending=False)

paths={
'network_metrics':f'{OUTDIR}/PETU_MACRO_ECO_M2_network_metrics.csv','robustness_curves':f'{OUTDIR}/PETU_MACRO_ECO_M2_robustness_curves.csv','genesis_summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_genesis_summary.csv','emergence_contrast':f'{OUTDIR}/PETU_MACRO_ECO_M2_emergence_contrast.csv','perturbation_summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_perturbation_summary.csv','attack_contrast':f'{OUTDIR}/PETU_MACRO_ECO_M2_attack_contrast.csv','robust_fragile_contrast':f'{OUTDIR}/PETU_MACRO_ECO_M2_robust_fragile_contrast.csv','triadic_pathology_summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_triadic_pathology_summary.csv','classification_summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_classification_summary.csv','classification_gain_summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_classification_gain_summary.csv','phase_summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_phase_summary.csv','failures':f'{OUTDIR}/PETU_MACRO_ECO_M2_failures.csv','summary':f'{OUTDIR}/PETU_MACRO_ECO_M2_summary.json'}
metrics.to_csv(paths['network_metrics'],index=False); curves.to_csv(paths['robustness_curves'],index=False); genesis_summary.to_csv(paths['genesis_summary'],index=False); emergence_contrast.to_csv(paths['emergence_contrast'],index=False); perturbation_summary.to_csv(paths['perturbation_summary'],index=False); attack_contrast.to_csv(paths['attack_contrast'],index=False); robust_fragile_contrast.to_csv(paths['robust_fragile_contrast'],index=False); triadic_pathology_summary.to_csv(paths['triadic_pathology_summary'],index=False); classification_summary.to_csv(paths['classification_summary'],index=False); classification_gain_summary.to_csv(paths['classification_gain_summary'],index=False); phase_summary.to_csv(paths['phase_summary'],index=False); pd.DataFrame(failures).to_csv(paths['failures'],index=False)
summary=dict(pipeline='PETU-MACRO-ECO M2 Perturbative Food-Web Audit',domain='macro natural ecosystems / empirical food-web networks / Mangal API',n_networks_processed=int(len(metrics)),max_networks_requested=MAX_NETWORKS_REQUESTED,target_ok_networks=TARGET_OK_NETWORKS,robustness_reps=ROBUSTNESS_REPS,attack_fractions=[float(x) for x in ATTACK_FRACTIONS],epsilon=EPSILON,hypothesis='Macro-ecosystem resilience and fragility arise from triadic proportion/disproportion of H eco-support, S structure, and L ecological linkage.',next_step='M3: temporal ecosystems/climate-hydrology macro dynamics; or M2b: expanded networks plus Web-of-Life.')
with open(paths['summary'],'w') as f: json.dump(summary,f,indent=2)

for title,table in [('PETU-MACRO-ECO M2 GENESIS SUMMARY',genesis_summary),('PETU-MACRO-ECO M2 EMERGENCE CONTRAST',emergence_contrast),('PETU-MACRO-ECO M2 PERTURBATION SUMMARY',perturbation_summary),('PETU-MACRO-ECO M2 ATTACK CONTRAST',attack_contrast),('PETU-MACRO-ECO M2 ROBUST VS FRAGILE CONTRAST',robust_fragile_contrast),('PETU-MACRO-ECO M2 TRIADIC PATHOLOGY SUMMARY',triadic_pathology_summary),('PETU-MACRO-ECO M2 CLASSIFICATION GAIN SUMMARY',classification_gain_summary),('PETU-MACRO-ECO M2 PHASE SUMMARY',phase_summary)]:
    print('\n'+'='*60); print(title); print('='*60); print(table)
print('\n'+'='*60); print('PETU-MACRO-ECO M2 FINAL SUMMARY'); print('='*60); print(json.dumps(summary,indent=2))
if len(failures)>0: print('\nFAILURES'); print(pd.DataFrame(failures).head(20))

# Figures
plt.figure(figsize=(8,5)); plt.scatter(metrics.H+metrics.S,metrics.L,s=35,alpha=.7); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('M2: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M2_HS_to_L.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(metrics.Phi_HSL_epsilon,metrics.Phi_resilience,s=35,alpha=.7); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_resilience'); plt.title('M2: HSL unity vs resilience'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M2_PhiHSL_resilience.png',dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(attack_contrast.attack,attack_contrast.mean_resilience); plt.xticks(rotation=45); plt.ylabel('Mean resilience'); plt.title('M2: resilience by perturbation type'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M2_attack_resilience.png',dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(phase_summary.PETU_M2_phase,phase_summary.n_networks); plt.xticks(rotation=60); plt.ylabel('Networks'); plt.title('M2: macro phases'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M2_phase_counts.png',dpi=220); plt.show()

zip_base='/content/PETU_MACRO_ECO_M2_Perturbative_FoodWebs_results'; zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

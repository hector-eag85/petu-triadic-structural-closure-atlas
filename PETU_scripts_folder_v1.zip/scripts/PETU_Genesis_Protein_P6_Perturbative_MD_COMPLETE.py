# ============================================================
# PETU-GENESIS PROTEIN P6 PERTURBATIVE MD
# Native vs Disrupted / Falsification-Oriented Test
#
# Condiciones:
#   A) native_control
#   B) thermal_disrupted
#   C) coordinate_perturbed
# ============================================================

!pip -q install openmm biopython networkx numpy scipy pandas matplotlib scikit-learn

import os, json, shutil, time, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx

from Bio.PDB import PDBList, PDBParser, PDBIO, Select, is_aa
from scipy.spatial.distance import pdist, squareform
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error

from openmm import unit, LangevinIntegrator, Platform
from openmm.app import PDBFile, Modeller, ForceField, Simulation, HBonds, NoCutoff

OUTDIR = "/content/PETU_Genesis_Protein_P6_Perturbative_MD"
PDB_DIR = "/content/PETU_PDB_P6"
os.makedirs(OUTDIR, exist_ok=True)
os.makedirs(PDB_DIR, exist_ok=True)

PDB_IDS = ["1FSD", "1PGB", "1VII"]
CONDITIONS = ["native_control", "thermal_disrupted", "coordinate_perturbed"]

MD_STEPS = 1600
EQUIL_STEPS = 400
REPORT_INTERVAL = 100

TEMPERATURE_NATIVE_K = 300
TEMPERATURE_THERMAL_K = 500
THERMAL_PREHEAT_STEPS = 600
COORD_NOISE_ANGSTROM = 2.5

FRICTION = 1.0 / unit.picosecond
TIMESTEP = 2.0 * unit.femtoseconds
CONTACT_CUTOFF = 8.0
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

HYDROPATHY = {"ALA":1.8,"ARG":-4.5,"ASN":-3.5,"ASP":-3.5,"CYS":2.5,"GLN":-3.5,"GLU":-3.5,"GLY":-0.4,"HIS":-3.2,"ILE":4.5,"LEU":3.8,"LYS":-3.9,"MET":1.9,"PHE":2.8,"PRO":-1.6,"SER":-0.8,"THR":-0.7,"TRP":-0.9,"TYR":-1.3,"VAL":4.2}
MASS = {"ALA":89.09,"ARG":174.20,"ASN":132.12,"ASP":133.10,"CYS":121.16,"GLN":146.15,"GLU":147.13,"GLY":75.07,"HIS":155.16,"ILE":131.17,"LEU":131.17,"LYS":146.19,"MET":149.21,"PHE":165.19,"PRO":115.13,"SER":105.09,"THR":119.12,"TRP":204.23,"TYR":181.19,"VAL":117.15}
CHARGE = {"ARG":1,"LYS":1,"HIS":0.5,"ASP":-1,"GLU":-1,"ALA":0,"ASN":0,"CYS":0,"GLN":0,"GLY":0,"ILE":0,"LEU":0,"MET":0,"PHE":0,"PRO":0,"SER":0,"THR":0,"TRP":0,"TYR":0,"VAL":0}
POLAR = {"ARG":1,"ASN":1,"ASP":1,"GLN":1,"GLU":1,"HIS":1,"LYS":1,"SER":1,"THR":1,"TYR":1,"ALA":0,"CYS":0,"GLY":0,"ILE":0,"LEU":0,"MET":0,"PHE":0,"PRO":0,"TRP":0,"VAL":0}

def normalize01(x):
    x=np.asarray(x,dtype=float)
    if len(x)==0: return x
    mn,mx=np.nanmin(x),np.nanmax(x)
    if mx-mn<1e-12: return np.zeros_like(x)
    return (x-mn)/(mx-mn)

def normalize01_groupwise(df, cols, group_cols):
    out=df.copy()
    for col in cols:
        out[col+"_local_norm"] = out.groupby(group_cols)[col].transform(lambda x: normalize01(x.values))
    return out

def safe_mean(x):
    x=[v for v in x if np.isfinite(v)]
    return float(np.mean(x)) if x else 0.0

def safe_std(x):
    x=[v for v in x if np.isfinite(v)]
    return float(np.std(x)) if x else 0.0

def safe_spearman(a,b):
    try:
        a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
        mask=np.isfinite(a)&np.isfinite(b)
        if mask.sum()<3: return None,None
        r,p=spearmanr(a[mask],b[mask])
        return float(r),float(p)
    except Exception:
        return None,None

def safe_mannwhitney(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        a=a[np.isfinite(a)]; b=b[np.isfinite(b)]
        if len(a)<3 or len(b)<3: return None,None
        stat,p=mannwhitneyu(a,b,alternative="two-sided")
        return float(stat),float(p)
    except Exception:
        return None,None

def pairwise_distances(coords):
    if len(coords)<2: return np.zeros((len(coords),len(coords)))
    return squareform(pdist(coords))

def contact_matrix(coords, cutoff=8.0):
    D=pairwise_distances(coords)
    C=(D<=cutoff).astype(int)
    np.fill_diagonal(C,0)
    return C,D

def radius_of_gyration(coords):
    coords=np.asarray(coords,dtype=float)
    c=np.mean(coords,axis=0)
    return float(np.sqrt(np.mean(np.sum((coords-c)**2,axis=1))))

def graph_from_C(C):
    G=nx.Graph(); n=C.shape[0]
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i+1,n):
            if C[i,j]>0: G.add_edge(i,j)
    return G

def graph_efficiency(G):
    try: return float(nx.global_efficiency(G))
    except Exception: return 0.0

def graph_lcc_fraction(G):
    if G.number_of_nodes()==0: return 0.0
    comps=list(nx.connected_components(G))
    if not comps: return 0.0
    return float(max(len(c) for c in comps)/G.number_of_nodes())

def graph_degree_entropy(G):
    deg=np.array([d for _,d in G.degree()],dtype=float)
    if len(deg)==0 or deg.sum()<=0: return 0.0
    p=deg/deg.sum(); ent=-np.sum(p*np.log(p+1e-12))
    return float(ent/np.log(len(p)+1e-12))

def rmsd_no_align(A,B):
    A=np.asarray(A,dtype=float); B=np.asarray(B,dtype=float)
    n=min(len(A),len(B))
    if n==0: return np.nan
    A=A[:n]-np.mean(A[:n],axis=0); B=B[:n]-np.mean(B[:n],axis=0)
    return float(np.sqrt(np.mean(np.sum((A-B)**2,axis=1))))

def native_contact_fraction(C,C_native):
    total_native=np.sum(C_native)/2
    if total_native<=0: return 0.0
    recovered=np.sum((C>0)&(C_native>0))/2
    return float(recovered/total_native)

def triadic_balance_from_cols(df, cols):
    return (1-df[cols].std(axis=1)).clip(lower=0)

def dominance_from_cols(df, cols):
    return df[cols].max(axis=1)-df[cols].min(axis=1)

pdbl=PDBList(); parser=PDBParser(QUIET=True)

def download_pdb(pdb_id):
    return pdbl.retrieve_pdb_file(pdb_id.lower(),pdir=PDB_DIR,file_format="pdb",overwrite=False)

def get_best_chain_id(pdb_path,pdb_id):
    structure=parser.get_structure(pdb_id,pdb_path)
    best_chain_id=None; best_count=-1
    for model in structure:
        for chain in model:
            count=sum(1 for res in chain if is_aa(res,standard=True) and "CA" in res)
            if count>best_count:
                best_count=count; best_chain_id=chain.id
        break
    return best_chain_id,best_count

class SingleProteinChainSelect(Select):
    def __init__(self, chain_id): self.chain_id=chain_id
    def accept_chain(self, chain): return 1 if chain.id==self.chain_id else 0
    def accept_residue(self, residue): return 1 if is_aa(residue,standard=True) else 0

def clean_pdb_to_single_chain(pdb_path,pdb_id):
    chain_id,nres=get_best_chain_id(pdb_path,pdb_id)
    if chain_id is None or nres<=0: raise ValueError(f"No valid protein chain found for {pdb_id}")
    structure=parser.get_structure(pdb_id,pdb_path)
    io=PDBIO(); io.set_structure(structure)
    clean_path=os.path.join(PDB_DIR,f"{pdb_id}_clean_chain_{chain_id}.pdb")
    io.save(clean_path,SingleProteinChainSelect(chain_id))
    return clean_path,chain_id,nres

def load_openmm_model(clean_pdb_path):
    pdb=PDBFile(clean_pdb_path)
    forcefield=ForceField("amber14-all.xml","implicit/gbn2.xml")
    modeller=Modeller(pdb.topology,pdb.positions)
    modeller.addHydrogens(forcefield,pH=7.0)
    system=forcefield.createSystem(modeller.topology,nonbondedMethod=NoCutoff,constraints=HBonds,ignoreExternalBonds=True)
    return modeller,forcefield,system

def extract_ca_from_openmm(topology,positions):
    residues=[]; coords=[]
    pos_nm=positions.value_in_unit(unit.nanometer)
    for atom in topology.atoms():
        if atom.name=="CA" and atom.residue.name in HYDROPATHY:
            residues.append(atom.residue.name)
            p=pos_nm[atom.index]
            coords.append([p.x*10.0,p.y*10.0,p.z*10.0])
    return residues,np.array(coords,dtype=float)

def perturb_positions(positions, noise_angstrom):
    pos_nm=positions.value_in_unit(unit.nanometer)
    new_pos=[]; sigma_nm=noise_angstrom*0.1
    for p in pos_nm:
        new_pos.append([p.x+np.random.normal(0,sigma_nm),p.y+np.random.normal(0,sigma_nm),p.z+np.random.normal(0,sigma_nm)])
    return new_pos*unit.nanometer

def H_sequence_raw(residues,potential_energy_kj=None):
    hyd=[HYDROPATHY[r] for r in residues]; mass=[MASS[r] for r in residues]
    charge=[CHARGE[r] for r in residues]; polar=[POLAR[r] for r in residues]
    n=len(residues)
    vals={"H_mass_mean":safe_mean(mass),"H_hydro_abs_mean":safe_mean([abs(x) for x in hyd]),"H_hydro_std":safe_std(hyd),"H_charge_abs_mean":safe_mean([abs(x) for x in charge]),"H_net_charge_abs":abs(float(np.sum(charge)))/max(n,1),"H_polar_fraction":safe_mean(polar)}
    vals["H_energy_stability"]=0.0 if potential_energy_kj is None or not np.isfinite(potential_energy_kj) else -float(potential_energy_kj)/max(n,1)
    vals["H_raw"]=safe_mean(list(vals.values()))
    return vals

def S_structure_raw(coords,C,D,coords_native):
    n=len(coords)
    if n<2:
        return {"S_contact_density":0,"S_compactness":0,"S_local_contact_fraction":0,"S_distance_regularity":0,"S_native_similarity":0,"S_raw":0}
    rg=radius_of_gyration(coords)
    contact_density=float(np.sum(C)/(n*(n-1)+1e-12))
    compactness=1/((rg/(n**(1/3)+1e-12))+1e-12)
    total_contacts=np.sum(C)/2
    local_contacts=sum(1 for i in range(n) for j in range(i+1,n) if C[i,j]>0 and abs(i-j)<=6)
    local_frac=float(local_contacts/(total_contacts+1e-12))
    contact_distances=D[C>0]
    distance_regularity=1/(np.std(contact_distances)+1e-12) if len(contact_distances)>0 else 0.0
    r=rmsd_no_align(coords,coords_native)
    native_similarity=1/(1+r) if np.isfinite(r) else 0.0
    vals={"S_contact_density":contact_density,"S_compactness":compactness,"S_local_contact_fraction":local_frac,"S_distance_regularity":distance_regularity,"S_native_similarity":native_similarity}
    vals["S_raw"]=safe_mean(list(vals.values()))
    return vals

def L_network_raw(C,C_native):
    G=graph_from_C(C); n=G.number_of_nodes()
    if n==0:
        return {"L_avg_degree":0,"L_efficiency":0,"L_clustering":0,"L_lcc_fraction":0,"L_degree_entropy":0,"L_native_contact_fraction":0,"L_raw":0}
    vals={"L_avg_degree":float(np.mean([d for _,d in G.degree()])) if n else 0.0,"L_efficiency":graph_efficiency(G),"L_clustering":float(nx.average_clustering(G)) if n else 0.0,"L_lcc_fraction":graph_lcc_fraction(G),"L_degree_entropy":graph_degree_entropy(G),"L_native_contact_fraction":native_contact_fraction(C,C_native)}
    vals["L_raw"]=safe_mean(list(vals.values()))
    return vals

def create_simulation(modeller,system,temperature_k):
    integrator=LangevinIntegrator(temperature_k*unit.kelvin,FRICTION,TIMESTEP)
    integrator.setRandomNumberSeed(RANDOM_SEED)
    try:
        platform=Platform.getPlatformByName("CPU")
        sim=Simulation(modeller.topology,system,integrator,platform)
    except Exception:
        sim=Simulation(modeller.topology,system,integrator)
    return sim

def run_condition(pdb_id,modeller,system,coords_native,C_native,condition):
    print("  Condition:",condition)
    if condition=="native_control":
        temperature=TEMPERATURE_NATIVE_K; initial_positions=modeller.positions; preheat=False
    elif condition=="thermal_disrupted":
        temperature=TEMPERATURE_NATIVE_K; initial_positions=modeller.positions; preheat=True
    elif condition=="coordinate_perturbed":
        temperature=TEMPERATURE_NATIVE_K; initial_positions=perturb_positions(modeller.positions,COORD_NOISE_ANGSTROM); preheat=False
    else:
        raise ValueError("Unknown condition: "+condition)
    sim=create_simulation(modeller,system,temperature)
    sim.context.setPositions(initial_positions)
    print("    Minimizing...")
    sim.minimizeEnergy(maxIterations=400)
    sim.context.setVelocitiesToTemperature(temperature*unit.kelvin,RANDOM_SEED)
    if preheat:
        print("    Thermal preheat disruption...")
        hot_sim=create_simulation(modeller,system,TEMPERATURE_THERMAL_K)
        hot_sim.context.setPositions(initial_positions)
        hot_sim.minimizeEnergy(maxIterations=200)
        hot_sim.context.setVelocitiesToTemperature(TEMPERATURE_THERMAL_K*unit.kelvin,RANDOM_SEED)
        hot_sim.step(THERMAL_PREHEAT_STEPS)
        hot_positions=hot_sim.context.getState(getPositions=True).getPositions()
        sim=create_simulation(modeller,system,TEMPERATURE_NATIVE_K)
        sim.context.setPositions(hot_positions)
        sim.context.setVelocitiesToTemperature(TEMPERATURE_NATIVE_K*unit.kelvin,RANDOM_SEED)
    print("    Equilibrating...")
    sim.step(EQUIL_STEPS)
    n_reports=MD_STEPS//REPORT_INTERVAL
    print(f"    Production: {MD_STEPS} steps -> {n_reports+1} frames")
    rows=[]
    for rep in range(n_reports+1):
        state=sim.context.getState(getPositions=True,getEnergy=True)
        positions=state.getPositions(); energy=state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
        time_ps=rep*REPORT_INTERVAL*TIMESTEP.value_in_unit(unit.picoseconds)
        residues,coords=extract_ca_from_openmm(modeller.topology,positions)
        C,D=contact_matrix(coords,CONTACT_CUTOFF)
        rows.append({"pdb_id":pdb_id,"condition":condition,"frame":rep,"time_ps":time_ps,"potential_energy_kj_mol":float(energy),"n_residues":len(residues),"rmsd_to_native":rmsd_no_align(coords,coords_native),**H_sequence_raw(residues,energy),**S_structure_raw(coords,C,D,coords_native),**L_network_raw(C,C_native)})
        if rep<n_reports: sim.step(REPORT_INTERVAL)
    return pd.DataFrame(rows)

def run_p6_for_pdb(pdb_id):
    print("\n============================================================")
    print("Running P6 perturbative MD for:",pdb_id)
    print("============================================================")
    pdb_path=download_pdb(pdb_id)
    clean_path,chain_id,nres=clean_pdb_to_single_chain(pdb_path,pdb_id)
    print(f"  Cleaned to chain {chain_id} with approx {nres} CA residues")
    modeller,forcefield,system=load_openmm_model(clean_path)
    residues_native,coords_native=extract_ca_from_openmm(modeller.topology,modeller.positions)
    C_native,D_native=contact_matrix(coords_native,CONTACT_CUTOFF)
    dfs=[]
    for condition in CONDITIONS:
        dfs.append(run_condition(pdb_id,modeller,system,coords_native,C_native,condition))
    return pd.concat(dfs,ignore_index=True)

print("============================================================")
print("PETU-GENESIS PROTEIN P6 PERTURBATIVE MD")
print("============================================================")
all_frames=[]; failures=[]
for pdb_id in PDB_IDS:
    try:
        t0=time.time(); dfp=run_p6_for_pdb(pdb_id.upper()); all_frames.append(dfp)
        print(f"  OK: {pdb_id} elapsed_sec={time.time()-t0:.1f}")
        pd.concat(all_frames,ignore_index=True).to_csv(f"{OUTDIR}/PARTIAL_P6_frames.csv",index=False)
    except Exception as e:
        print("  FAIL:",pdb_id,e); failures.append({"pdb_id":pdb_id.upper(),"error":str(e)})
if len(all_frames)==0: raise RuntimeError("No simulations completed.")
md_df=pd.concat(all_frames,ignore_index=True)

H_BASE=["H_mass_mean","H_hydro_abs_mean","H_hydro_std","H_charge_abs_mean","H_net_charge_abs","H_polar_fraction","H_energy_stability"]
S_BASE=["S_contact_density","S_compactness","S_local_contact_fraction","S_distance_regularity","S_native_similarity"]
L_BASE=["L_avg_degree","L_efficiency","L_clustering","L_lcc_fraction","L_degree_entropy","L_native_contact_fraction"]
RAW_BASE=H_BASE+S_BASE+L_BASE
for col in RAW_BASE: md_df[col+"_global_norm"]=normalize01(md_df[col].values)
md_df["H_global"]=md_df[[c+"_global_norm" for c in H_BASE]].mean(axis=1)
md_df["S_global"]=md_df[[c+"_global_norm" for c in S_BASE]].mean(axis=1)
md_df["L_global"]=md_df[[c+"_global_norm" for c in L_BASE]].mean(axis=1)
md_df["Phi_global_epsilon"]=(md_df["H_global"]+EPSILON)*(md_df["S_global"]+EPSILON)*(md_df["L_global"]+EPSILON)
md_df["Triadic_balance_global"]=triadic_balance_from_cols(md_df,["H_global","S_global","L_global"])
md_df["Functional_unity_global"]=md_df["Phi_global_epsilon"]*md_df["Triadic_balance_global"]
md_df=normalize01_groupwise(md_df,RAW_BASE,group_cols=["pdb_id"])
md_df["H_local"]=md_df[[c+"_local_norm" for c in H_BASE]].mean(axis=1)
md_df["S_local"]=md_df[[c+"_local_norm" for c in S_BASE]].mean(axis=1)
md_df["L_local"]=md_df[[c+"_local_norm" for c in L_BASE]].mean(axis=1)
md_df["Phi_local_epsilon"]=(md_df["H_local"]+EPSILON)*(md_df["S_local"]+EPSILON)*(md_df["L_local"]+EPSILON)
md_df["Triadic_balance_local"]=triadic_balance_from_cols(md_df,["H_local","S_local","L_local"])
md_df["Functional_unity_local"]=md_df["Phi_local_epsilon"]*md_df["Triadic_balance_local"]
md_df["H"]=md_df["H_local"]; md_df["S"]=md_df["S_local"]; md_df["L"]=md_df["L_local"]
md_df["Phi_epsilon"]=md_df["Phi_local_epsilon"]; md_df["Triadic_balance"]=md_df["Triadic_balance_local"]; md_df["Functional_unity_score"]=md_df["Functional_unity_local"]
md_df["Dominance_index"]=dominance_from_cols(md_df,["H","S","L"])
md_df=md_df.sort_values(["pdb_id","condition","frame"]).reset_index(drop=True)
for metric in ["H","S","L","Phi_epsilon","Functional_unity_score","Triadic_balance"]:
    md_df["d_"+metric]=md_df.groupby(["pdb_id","condition"])[metric].diff().fillna(0)

def regression_dynamic(df,X_cols,y_col,label):
    d=df[X_cols+[y_col]].dropna().copy()
    if len(d)<20: return {"test":label,"n":int(len(d)),"r2":None,"mae":None,"spearman_true_pred":None,"p_value":None}
    X=d[X_cols].values.astype(float); y=d[y_col].values.astype(float)
    model=Ridge(alpha=1.0).fit(X,y); pred=model.predict(X)
    r,p=safe_spearman(y,pred)
    return {"test":label,"n":int(len(d)),"r2":float(r2_score(y,pred)),"mae":float(mean_absolute_error(y,pred)),"spearman_true_pred":r,"p_value":p}

genesis_summary=pd.DataFrame([
    regression_dynamic(md_df,["H"],"S","LOCAL_P6_H_to_S"),regression_dynamic(md_df,["H"],"L","LOCAL_P6_H_to_L"),regression_dynamic(md_df,["S"],"L","LOCAL_P6_S_to_L"),regression_dynamic(md_df,["H","S"],"L","LOCAL_P6_H_plus_S_to_L"),regression_dynamic(md_df,["H","S","L"],"Phi_epsilon","LOCAL_P6_HSL_to_Phi"),regression_dynamic(md_df,["H","S","L"],"Functional_unity_score","LOCAL_P6_HSL_to_Functional_Unity"),
    regression_dynamic(md_df,["H_global"],"S_global","GLOBAL_P6_H_to_S"),regression_dynamic(md_df,["H_global"],"L_global","GLOBAL_P6_H_to_L"),regression_dynamic(md_df,["S_global"],"L_global","GLOBAL_P6_S_to_L"),regression_dynamic(md_df,["H_global","S_global"],"L_global","GLOBAL_P6_H_plus_S_to_L"),regression_dynamic(md_df,["H_global","S_global","L_global"],"Phi_global_epsilon","GLOBAL_P6_HSL_to_Phi"),regression_dynamic(md_df,["H_global","S_global","L_global"],"Functional_unity_global","GLOBAL_P6_HSL_to_Functional_Unity")])

def get_mae(test):
    x=genesis_summary[genesis_summary["test"]==test]
    return None if len(x)==0 else x.iloc[0]["mae"]
def contrast_row(prefix):
    H_L=get_mae(f"{prefix}_P6_H_to_L"); S_L=get_mae(f"{prefix}_P6_S_to_L"); HS_L=get_mae(f"{prefix}_P6_H_plus_S_to_L")
    return {"level":prefix.lower(),"H_to_L_mae":H_L,"S_to_L_mae":S_L,"H_plus_S_to_L_mae":HS_L,"HS_improves_over_H":None if H_L is None or HS_L is None else H_L-HS_L,"HS_improves_over_S":None if S_L is None or HS_L is None else S_L-HS_L,"PETU_prediction_supported":H_L is not None and S_L is not None and HS_L is not None and HS_L<H_L and HS_L<S_L}
emergence_contrast_summary=pd.DataFrame([contrast_row("LOCAL"),contrast_row("GLOBAL")])
condition_summary=md_df.groupby(["pdb_id","condition"]).agg(n_frames=("frame","count"),mean_H=("H","mean"),mean_S=("S","mean"),mean_L=("L","mean"),mean_Phi=("Phi_epsilon","mean"),mean_unity=("Functional_unity_score","mean"),mean_balance=("Triadic_balance","mean"),mean_rmsd=("rmsd_to_native","mean"),mean_energy_stability=("H_energy_stability","mean"),final_H=("H","last"),final_S=("S","last"),final_L=("L","last"),final_Phi=("Phi_epsilon","last"),final_unity=("Functional_unity_score","last"),final_balance=("Triadic_balance","last")).reset_index()
delta_rows=[]
for pdb_id,d in condition_summary.groupby("pdb_id"):
    native=d[d["condition"]=="native_control"]
    if len(native)==0: continue
    native=native.iloc[0]
    for _,r in d.iterrows():
        if r["condition"]=="native_control": continue
        row={"pdb_id":pdb_id,"condition":r["condition"]}
        for metric in ["mean_H","mean_S","mean_L","mean_Phi","mean_unity","mean_balance","mean_rmsd","mean_energy_stability"]:
            base=native[metric]; val=r[metric]
            row["delta_"+metric]=float(val-base); row["pct_delta_"+metric]=float(100*(val-base)/(abs(base)+1e-12))
        delta_rows.append(row)
perturbation_delta_summary=pd.DataFrame(delta_rows)
stats_rows=[]
for pdb_id,d in md_df.groupby("pdb_id"):
    native=d[d["condition"]=="native_control"]
    for cond in ["thermal_disrupted","coordinate_perturbed"]:
        pert=d[d["condition"]==cond]
        for metric in ["H","S","L","Phi_epsilon","Functional_unity_score","Triadic_balance","rmsd_to_native"]:
            stat,p=safe_mannwhitney(native[metric].values,pert[metric].values)
            stats_rows.append({"pdb_id":pdb_id,"condition":cond,"metric":metric,"native_mean":float(native[metric].mean()),"perturbed_mean":float(pert[metric].mean()),"delta":float(pert[metric].mean()-native[metric].mean()),"pct_delta":float(100*(pert[metric].mean()-native[metric].mean())/(abs(native[metric].mean())+1e-12)),"mannwhitney_stat":stat,"p_value":p})
perturbation_stats=pd.DataFrame(stats_rows)
support_rows=[]
for _,r in perturbation_delta_summary.iterrows():
    disruption_index=0
    for key, direction in [("delta_mean_rmsd",1),("delta_mean_S",-1),("delta_mean_L",-1),("delta_mean_Phi",-1),("delta_mean_unity",-1),("delta_mean_balance",-1)]:
        if (direction==1 and r[key]>0) or (direction==-1 and r[key]<0): disruption_index+=1
    support_rows.append({"pdb_id":r["pdb_id"],"condition":r["condition"],"disruption_index_0_6":disruption_index,"PETU_perturbation_supported":disruption_index>=3,"rmsd_increased":bool(r["delta_mean_rmsd"]>0),"Phi_decreased":bool(r["delta_mean_Phi"]<0),"unity_decreased":bool(r["delta_mean_unity"]<0),"S_decreased":bool(r["delta_mean_S"]<0),"L_decreased":bool(r["delta_mean_L"]<0),"balance_decreased":bool(r["delta_mean_balance"]<0)})
perturbation_support_summary=pd.DataFrame(support_rows)

def classify_phase(row):
    s,l,phi,bal=row["S"],row["L"],row["Phi_epsilon"],row["Triadic_balance"]
    if s<0.25 and l<0.25: return "low_structure_low_link"
    if s>=0.35 and l<0.35: return "S_without_full_L"
    if l>=0.35 and phi<0.20: return "L_cohesion_subPhi"
    if phi>=0.20 and bal>=0.65: return "Phi_stable_co-inherence"
    if bal<0.55: return "unbalanced_disruption"
    return "transitional"
md_df["PETU_P6_phase"]=md_df.apply(classify_phase,axis=1)
phase_summary=md_df.groupby(["pdb_id","condition","PETU_P6_phase"]).size().reset_index(name="n_frames")
phase_totals=md_df.groupby(["condition","PETU_P6_phase"]).size().reset_index(name="n_frames_total").sort_values(["condition","n_frames_total"],ascending=[True,False])
paths={"features":f"{OUTDIR}/PETU_Genesis_Protein_P6_features.csv","genesis_summary":f"{OUTDIR}/PETU_Genesis_Protein_P6_genesis_summary.csv","emergence_contrast":f"{OUTDIR}/PETU_Genesis_Protein_P6_emergence_contrast_summary.csv","condition_summary":f"{OUTDIR}/PETU_Genesis_Protein_P6_condition_summary.csv","perturbation_delta":f"{OUTDIR}/PETU_Genesis_Protein_P6_perturbation_delta_summary.csv","perturbation_stats":f"{OUTDIR}/PETU_Genesis_Protein_P6_perturbation_stats.csv","perturbation_support":f"{OUTDIR}/PETU_Genesis_Protein_P6_perturbation_support_summary.csv","phase_summary":f"{OUTDIR}/PETU_Genesis_Protein_P6_phase_summary.csv","phase_totals":f"{OUTDIR}/PETU_Genesis_Protein_P6_phase_totals.csv","failures":f"{OUTDIR}/PETU_Genesis_Protein_P6_failures.csv","summary":f"{OUTDIR}/PETU_Genesis_Protein_P6_summary.json"}
md_df.to_csv(paths["features"],index=False); genesis_summary.to_csv(paths["genesis_summary"],index=False); emergence_contrast_summary.to_csv(paths["emergence_contrast"],index=False); condition_summary.to_csv(paths["condition_summary"],index=False); perturbation_delta_summary.to_csv(paths["perturbation_delta"],index=False); perturbation_stats.to_csv(paths["perturbation_stats"],index=False); perturbation_support_summary.to_csv(paths["perturbation_support"],index=False); phase_summary.to_csv(paths["phase_summary"],index=False); phase_totals.to_csv(paths["phase_totals"],index=False); pd.DataFrame(failures).to_csv(paths["failures"],index=False)
summary={"pipeline":"PETU-Genesis Protein P6 Perturbative MD","domain":"real-physics perturbative molecular dynamics of natural proteins","pdb_ids_requested":PDB_IDS,"pdb_ids_completed":sorted(list(md_df["pdb_id"].unique())),"n_proteins_completed":int(md_df["pdb_id"].nunique()),"conditions":CONDITIONS,"total_frames":int(len(md_df)),"md_steps":MD_STEPS,"equil_steps":EQUIL_STEPS,"report_interval":REPORT_INTERVAL,"temperature_native_K":TEMPERATURE_NATIVE_K,"temperature_thermal_K":TEMPERATURE_THERMAL_K,"thermal_preheat_steps":THERMAL_PREHEAT_STEPS,"coordinate_noise_angstrom":COORD_NOISE_ANGSTROM,"timestep_fs":TIMESTEP.value_in_unit(unit.femtoseconds),"contact_cutoff_angstrom":CONTACT_CUTOFF,"forcefield":["amber14-all.xml","implicit/gbn2.xml"],"epsilon":EPSILON,"methodological_note":"OpenMM real MD with native and perturbed conditions. Designed as falsification-oriented PETU test.","hypothesis":"Perturbations to physical/structural/link regimes should alter Phi and functional unity if PETU is capturing real co-inherence H-S-L.","next_step":"If P6 supports PETU, extend to explicit solvent, longer trajectories, and residue-level perturbation maps."}
open(paths["summary"],"w").write(json.dumps(summary,indent=2))
print("\n============================================================"); print("P6 GENESIS SUMMARY"); print("============================================================"); print(genesis_summary)
print("\n============================================================"); print("P6 EMERGENCE CONTRAST SUMMARY"); print("============================================================"); print(emergence_contrast_summary)
print("\n============================================================"); print("P6 CONDITION SUMMARY"); print("============================================================"); print(condition_summary)
print("\n============================================================"); print("P6 PERTURBATION DELTA SUMMARY"); print("============================================================"); print(perturbation_delta_summary)
print("\n============================================================"); print("P6 PERTURBATION STATS"); print("============================================================"); print(perturbation_stats)
print("\n============================================================"); print("P6 PERTURBATION SUPPORT SUMMARY"); print("============================================================"); print(perturbation_support_summary)
print("\n============================================================"); print("P6 PHASE TOTALS"); print("============================================================"); print(phase_totals)
print("\n============================================================"); print("P6 FINAL SUMMARY"); print("============================================================"); print(json.dumps(summary,indent=2))
if len(failures)>0:
    print("\n============================================================"); print("FAILURES"); print("============================================================"); print(pd.DataFrame(failures))
for pdb_id in sorted(md_df["pdb_id"].unique()):
    d0=md_df[md_df["pdb_id"]==pdb_id]
    plt.figure(figsize=(10,5))
    for cond in CONDITIONS:
        d=d0[d0["condition"]==cond]
        if len(d)>0: plt.plot(d["time_ps"],d["Phi_epsilon"],label=f"{cond} Phi")
    plt.xlabel("Time ps"); plt.ylabel("Phi epsilon"); plt.title(f"P6 Perturbative MD: Phi by condition — {pdb_id}"); plt.grid(True); plt.legend(); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_P6_Phi_conditions_{pdb_id}.png",dpi=220); plt.show()
    plt.figure(figsize=(10,5))
    for cond in CONDITIONS:
        d=d0[d0["condition"]==cond]
        if len(d)>0: plt.plot(d["time_ps"],d["Functional_unity_score"],label=f"{cond} unity")
    plt.xlabel("Time ps"); plt.ylabel("Functional unity"); plt.title(f"P6 Perturbative MD: Functional unity by condition — {pdb_id}"); plt.grid(True); plt.legend(); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_P6_Unity_conditions_{pdb_id}.png",dpi=220); plt.show()
plt.figure(figsize=(8,5))
for cond in CONDITIONS:
    d=md_df[md_df["condition"]==cond]
    if len(d)>0: plt.scatter(d["S"],d["L"],s=20,alpha=0.6,label=cond)
plt.xlabel("S"); plt.ylabel("L"); plt.title("P6 all frames: S-L by condition"); plt.grid(True); plt.legend(); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_P6_SL_by_condition.png",dpi=220); plt.show()
plt.figure(figsize=(8,5))
plt.bar(perturbation_support_summary["pdb_id"]+"_"+perturbation_support_summary["condition"],perturbation_support_summary["disruption_index_0_6"])
plt.xticks(rotation=75); plt.ylabel("PETU disruption index 0-6"); plt.title("P6 PETU perturbation disruption index"); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_P6_disruption_index.png",dpi=220); plt.show()
zip_base="/content/PETU_Genesis_Protein_P6_Perturbative_MD_results"; zip_path=zip_base+".zip"
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,"zip",OUTDIR)
print("\n============================================================"); print("PIPELINE COMPLETE")
for k,v in paths.items(): print(k+":",v)
print("ZIP:",zip_path); print("============================================================")

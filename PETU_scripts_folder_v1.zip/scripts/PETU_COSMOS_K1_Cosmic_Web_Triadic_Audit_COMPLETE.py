# ============================================================
# PETU-COSMOS K1
# Cosmic Web / Large-Scale Structure Triadic Audit
#
# Objetivo:
#   Primera prueba cosmológica de PETU/LETU sobre estructura a gran escala.
#
# Sistema natural:
#   Galaxias con espectro SDSS DR17, red cósmica aproximada mediante posiciones
#   comóviles 3D y grafo de vecinos próximos.
#
# Traducción PETU:
#   H = soporte cosmológico/material:
#       densidad local de galaxias, soporte luminoso/masa-proxy, contraste.
#
#   S = estructura geométrica:
#       anisotropía local, filamentariedad/sheetness, orden tensorial del entorno.
#
#   L = vínculo gravitacional/red:
#       conectividad kNN, clustering local, continuidad con vecinos, coherencia de grafo.
#
#   Phi = coherencia de red cósmica:
#       integración estructura-soporte-vínculo; pertenencia funcional a web.
#
# Hipótesis PETU-K1:
#   1. H + S -> L:
#      La conectividad cósmica L se predice mejor desde soporte + geometría
#      que desde H o S aislados.
#
#   2. H + S + L -> Phi:
#      La coherencia de la red cósmica se reconstruye desde HSL.
#
#   3. Patología/defecto estructural cósmico:
#      Voidness, desconexión, dominancia o desproporción local serán legibles como
#      desequilibrio pericorético H-S-L.
#
# Nota epistemológica:
#   Cosmología no permite perturbación experimental directa como proteínas/neuro/hidro.
#   K1 es una auditoría observacional y multiescala de estructura natural.
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install numpy pandas scipy scikit-learn matplotlib tqdm astropy astroquery networkx

import os, json, math, warnings, shutil, time
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm

from scipy.stats import spearmanr, mannwhitneyu
from sklearn.neighbors import NearestNeighbors
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.preprocessing import StandardScaler
import networkx as nx

from astropy.cosmology import Planck18 as cosmo
from astroquery.sdss import SDSS

# ============================================================
# CONFIG
# ============================================================

OUTDIR = '/content/PETU_COSMOS_K1_Cosmic_Web_Triadic_Audit'
os.makedirs(OUTDIR, exist_ok=True)

N_GALAXIES_TARGET = 6000
K_NEIGHBORS = 12
SCALE_KS = [8, 16, 32]
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# SQL region selected to keep query moderately fast but large enough for web structure.
SDSS_SQL = f"""
SELECT TOP {N_GALAXIES_TARGET}
    p.objID, p.ra, p.dec, s.z,
    p.petroMag_r, p.petroR50_r, p.petroR90_r
FROM PhotoObjAll AS p
JOIN SpecObjAll AS s ON p.objID = s.bestObjID
WHERE
    s.class = 'GALAXY'
    AND s.z BETWEEN 0.02 AND 0.20
    AND p.clean = 1
    AND p.petroMag_r BETWEEN 14.0 AND 17.77
    AND p.ra BETWEEN 120 AND 240
    AND p.dec BETWEEN 0 AND 60
"""

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        m = np.isfinite(a) & np.isfinite(b)
        if m.sum() < 4: return None, None
        r, p = spearmanr(a[m], b[m])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]; b = b[np.isfinite(b)]
        if len(a) < 4 or len(b) < 4: return None, None
        stat, p = mannwhitneyu(a, b, alternative='two-sided')
        return float(stat), float(p)
    except Exception:
        return None, None

def entropy_norm(v):
    v = np.asarray(v, dtype=float)
    v = v[np.isfinite(v)]
    s = np.sum(v)
    if len(v) == 0 or s <= 0: return 0.0
    p = v / s
    ent = -np.sum(p * np.log(p + 1e-12))
    return float(ent / np.log(len(p) + 1e-12))

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 30:
        return {'test': label, 'n': int(len(d)), 'r2': None, 'mae': None, 'spearman_true_pred': None, 'p_value': None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {'test': label, 'n': int(len(d)), 'r2': float(r2_score(y, pred)), 'mae': float(mean_absolute_error(y, pred)), 'spearman_true_pred': r, 'p_value': p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 40 or len(d[target].unique()) < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight='balanced')
        clf.fit(X, y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {'feature_set': label, 'target': target, 'n': int(len(d)), 'auc': float(auc)}

# ============================================================
# DATA FETCH
# ============================================================

print('='*60)
print('PETU-COSMOS K1 COSMIC WEB TRIADIC AUDIT')
print('='*60)
print('Querying SDSS DR17 spectroscopic galaxies...')

failures = []
try:
    q = SDSS.query_sql(SDSS_SQL, data_release=17, timeout=180)
    gal = q.to_pandas()
    print('  OK SDSS rows:', len(gal))
except Exception as e:
    failures.append({'dataset': 'SDSS_DR17', 'error': str(e)})
    raise RuntimeError('SDSS query failed. Re-run later or reduce N_GALAXIES_TARGET. Error: ' + str(e))

# Clean and convert columns.
gal.columns = [c.lower() for c in gal.columns]
gal = gal.rename(columns={'petromag_r':'petroMag_r'.lower(), 'petror50_r':'petroR50_r'.lower(), 'petror90_r':'petroR90_r'.lower()})
for col in ['ra','dec','z','petromag_r','petror50_r','petror90_r']:
    if col in gal.columns:
        gal[col] = pd.to_numeric(gal[col], errors='coerce')

gal = gal.dropna(subset=['ra','dec','z','petromag_r'])
gal = gal[(gal['z'] > 0.01) & (gal['z'] < 0.25)].copy()
if len(gal) < 500:
    raise RuntimeError('Too few galaxies after cleaning.')

# Approximate comoving coordinates.
ra = np.deg2rad(gal['ra'].values)
dec = np.deg2rad(gal['dec'].values)
dc = cosmo.comoving_distance(gal['z'].values).value  # Mpc
x = dc * np.cos(dec) * np.cos(ra)
y = dc * np.cos(dec) * np.sin(ra)
z3 = dc * np.sin(dec)
gal['x_mpc'] = x; gal['y_mpc'] = y; gal['z_mpc'] = z3; gal['dc_mpc'] = dc

# Luminosity proxy from apparent magnitude and distance modulus.
# Not exact k-corrected; adequate as observational support proxy.
d_l = cosmo.luminosity_distance(gal['z'].values).value * 1e6  # pc
M_r = gal['petromag_r'].values - 5*np.log10(d_l/10.0)
gal['M_r_proxy'] = M_r
gal['lum_proxy'] = 10 ** (-0.4 * (M_r - np.nanmedian(M_r)))
gal['lum_proxy'] = np.clip(gal['lum_proxy'], np.nanpercentile(gal['lum_proxy'], 1), np.nanpercentile(gal['lum_proxy'], 99))

coords = gal[['x_mpc','y_mpc','z_mpc']].values.astype(float)
N = len(gal)
print('Clean galaxies:', N)

# ============================================================
# LOCAL COSMIC WEB FEATURES
# ============================================================

print('Building kNN cosmic-web graph...')
max_k = max(SCALE_KS + [K_NEIGHBORS])
nn = NearestNeighbors(n_neighbors=max_k+1, algorithm='ball_tree')
nn.fit(coords)
dists, inds = nn.kneighbors(coords)
# Remove self neighbor at column 0
neighbor_dists = dists[:,1:]
neighbor_inds = inds[:,1:]

# Graph at main K.
main_inds = neighbor_inds[:, :K_NEIGHBORS]
G = nx.Graph()
G.add_nodes_from(range(N))
for i in range(N):
    for j in main_inds[i]:
        if i != int(j):
            G.add_edge(i, int(j))

clust = nx.clustering(G)
degree = dict(G.degree())
clust_arr = np.array([clust[i] for i in range(N)], dtype=float)
degree_arr = np.array([degree[i] for i in range(N)], dtype=float)

# Local features at main scale.
rows = []
for i in tqdm(range(N), desc='Cosmic local metrics'):
    neigh = main_inds[i]
    pts = coords[neigh]
    center = coords[i]
    rel = pts - center
    cov = np.cov(rel.T) if len(pts) > 3 else np.eye(3)
    eig = np.sort(np.linalg.eigvalsh(cov))[::-1]
    eig = np.maximum(eig, 1e-12)
    e1, e2, e3 = eig
    total = e1 + e2 + e3
    anisotropy = (e1 - e3) / total
    filamentarity = (e1 - e2) / total
    sheetness = (e2 - e3) / total
    isotropy = e3 / total
    eigen_entropy = entropy_norm(eig)

    kth_radius = neighbor_dists[i, K_NEIGHBORS-1]
    local_density = K_NEIGHBORS / ((4.0/3.0)*np.pi*(kth_radius**3) + 1e-12)
    mean_neighbor_lum = np.nanmean(gal['lum_proxy'].values[neigh])
    lum_local = gal['lum_proxy'].values[i]
    lum_coherence = 1.0 / (1.0 + abs(lum_local - mean_neighbor_lum)/(mean_neighbor_lum + 1e-12))

    neighbor_density_radius = np.mean(neighbor_dists[i, :K_NEIGHBORS])
    compactness = 1.0 / (1.0 + neighbor_density_radius)
    graph_linkage = np.mean([degree_arr[j] for j in neigh]) / (K_NEIGHBORS*2.0)
    graph_linkage = min(1.0, graph_linkage)

    # Raw PETU components.
    H_raw = np.mean([
        local_density,
        lum_local,
        mean_neighbor_lum,
        compactness
    ])

    S_raw = np.mean([
        anisotropy,
        filamentarity + sheetness,
        1.0 - eigen_entropy,
        1.0 - isotropy
    ])

    L_raw = np.mean([
        clust_arr[i],
        degree_arr[i] / (K_NEIGHBORS*2.0),
        graph_linkage,
        lum_coherence,
        1.0 / (1.0 + np.std(neighbor_dists[i,:K_NEIGHBORS])/(np.mean(neighbor_dists[i,:K_NEIGHBORS])+1e-12))
    ])

    # Independent cosmic-web coherence proxy: density + anisotropy + graph cohesion.
    Phi_web_raw = np.mean([
        np.log1p(local_density),
        anisotropy,
        filamentarity + 0.5*sheetness,
        clust_arr[i],
        graph_linkage,
        lum_coherence
    ])

    # Pathology/defect proxy: voidness/disconnection/isotropy/dominance of one aspect.
    Voidness_raw = np.mean([
        kth_radius,
        1.0/(1.0 + local_density),
        isotropy,
        1.0 - clust_arr[i]
    ])

    Cluster_core_raw = np.mean([
        np.log1p(local_density),
        clust_arr[i],
        degree_arr[i] / (K_NEIGHBORS*2.0),
        compactness
    ])

    Filament_raw = np.mean([
        filamentarity,
        anisotropy,
        1.0 - isotropy,
        graph_linkage
    ])

    rows.append({
        'idx': i,
        'objid': gal.iloc[i].get('objid', i),
        'ra': gal.iloc[i]['ra'],
        'dec': gal.iloc[i]['dec'],
        'z': gal.iloc[i]['z'],
        'x_mpc': coords[i,0], 'y_mpc': coords[i,1], 'z_mpc': coords[i,2],
        'petromag_r': gal.iloc[i]['petromag_r'],
        'lum_proxy': lum_local,
        'k_radius_mpc': kth_radius,
        'local_density_raw': local_density,
        'anisotropy': anisotropy,
        'filamentarity_raw': filamentarity,
        'sheetness_raw': sheetness,
        'isotropy_raw': isotropy,
        'eigen_entropy': eigen_entropy,
        'clustering_raw': clust_arr[i],
        'degree_raw': degree_arr[i],
        'graph_linkage_raw': graph_linkage,
        'lum_coherence_raw': lum_coherence,
        'H_raw': H_raw,
        'S_raw': S_raw,
        'L_raw': L_raw,
        'Phi_web_raw': Phi_web_raw,
        'Voidness_raw': Voidness_raw,
        'Cluster_core_raw': Cluster_core_raw,
        'Filament_raw': Filament_raw
    })

features = pd.DataFrame(rows)

# Normalize raw scores.
for col in ['H_raw','S_raw','L_raw','Phi_web_raw','Voidness_raw','Cluster_core_raw','Filament_raw','local_density_raw','filamentarity_raw','sheetness_raw','isotropy_raw','clustering_raw','graph_linkage_raw']:
    features[col.replace('_raw','')] = normalize01(features[col].values)

features['Phi_HSL_epsilon'] = (features['H']+EPSILON)*(features['S']+EPSILON)*(features['L']+EPSILON)
features['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(features['H'], features['S'], features['L'])]
features['Functional_unity'] = features['Phi_HSL_epsilon'] * features['Triadic_balance']
features['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(features['H'], features['S'], features['L'])]

# Combined cosmic-web pathology: voidness + low balance + high dominance.
features['Cosmic_web_pathology'] = normalize01(
    0.55*features['Voidness'] + 0.25*features['Dominance_index'] + 0.20*(1.0-features['Triadic_balance'])
)

# Flags.
features['coherent_web_high_flag'] = features['Phi_web'] >= features['Phi_web'].median()
features['pathology_high_flag'] = features['Cosmic_web_pathology'] >= features['Cosmic_web_pathology'].median()
features['void_high_flag'] = features['Voidness'] >= features['Voidness'].quantile(0.75)
features['cluster_high_flag'] = features['Cluster_core'] >= features['Cluster_core'].quantile(0.75)
features['filament_high_flag'] = features['Filament'] >= features['Filament'].quantile(0.75)
features['triadic_disproportion_flag'] = ((features['Triadic_balance'] <= features['Triadic_balance'].quantile(0.25)) | (features['Dominance_index'] >= features['Dominance_index'].quantile(0.75)))

# ============================================================
# MULTISCALE FEATURES
# ============================================================

scale_rows = []
print('Computing multiscale PETU transitions...')
for k in SCALE_KS:
    for i in range(N):
        neigh = neighbor_inds[i, :k]
        pts = coords[neigh]
        rel = pts - coords[i]
        cov = np.cov(rel.T) if len(pts) > 3 else np.eye(3)
        eig = np.sort(np.linalg.eigvalsh(cov))[::-1]
        eig = np.maximum(eig, 1e-12)
        e1,e2,e3 = eig; total=e1+e2+e3
        anis = (e1-e3)/total
        fil = (e1-e2)/total
        iso = e3/total
        kth = neighbor_dists[i, k-1]
        dens = k / ((4/3)*np.pi*kth**3 + 1e-12)
        Hs = np.mean([dens, features.loc[i,'lum_proxy'], 1/(1+kth)])
        Ss = np.mean([anis, fil, 1-iso])
        # Scale L approximation: main graph local terms plus distance continuity.
        Ls = np.mean([features.loc[i,'clustering'], features.loc[i,'graph_linkage'], 1/(1+np.std(neighbor_dists[i,:k])/(np.mean(neighbor_dists[i,:k])+1e-12))])
        Phis = np.mean([np.log1p(dens), anis, fil, Ls])
        scale_rows.append({'idx':i, 'scale_k':k, 'H_raw':Hs, 'S_raw':Ss, 'L_raw':Ls, 'Phi_scale_raw':Phis})

scale_features = pd.DataFrame(scale_rows)
for col in ['H_raw','S_raw','L_raw','Phi_scale_raw']:
    scale_features[col.replace('_raw','')] = normalize01(scale_features[col].values)
scale_features['Phi_HSL_epsilon'] = (scale_features['H']+EPSILON)*(scale_features['S']+EPSILON)*(scale_features['L']+EPSILON)
scale_features['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(scale_features['H'], scale_features['S'], scale_features['L'])]
scale_features['Functional_unity'] = scale_features['Phi_HSL_epsilon']*scale_features['Triadic_balance']

# Scale transitions: k8->k16 and k16->k32 per galaxy.
dyn_rows=[]
for i, g in scale_features.groupby('idx'):
    g = g.sort_values('scale_k').reset_index(drop=True)
    for j in range(1,len(g)):
        prev=g.iloc[j-1]; cur=g.iloc[j]
        dyn_rows.append({
            'idx':i,
            'transition':f"k{int(prev.scale_k)}->k{int(cur.scale_k)}",
            'dH':cur.H-prev.H,
            'dS':cur.S-prev.S,
            'dL':cur.L-prev.L,
            'dPhi_scale':cur.Phi_scale-prev.Phi_scale,
            'dFunctional_unity':cur.Functional_unity-prev.Functional_unity,
            'dBalance':cur.Triadic_balance-prev.Triadic_balance
        })
scale_dynamic = pd.DataFrame(dyn_rows)

# ============================================================
# SUMMARIES
# ============================================================

data_summary = pd.DataFrame([{
    'n_galaxies': int(N),
    'data_source': 'SDSS DR17 spectroscopic galaxies',
    'ra_min': float(features.ra.min()), 'ra_max': float(features.ra.max()),
    'dec_min': float(features.dec.min()), 'dec_max': float(features.dec.max()),
    'z_min': float(features.z.min()), 'z_max': float(features.z.max()),
    'k_neighbors': K_NEIGHBORS,
    'scale_ks': ','.join(map(str,SCALE_KS))
}])

genesis_summary = pd.DataFrame([
    regression(features, ['H'], 'S', 'K1_H_to_S'),
    regression(features, ['H'], 'L', 'K1_H_to_L'),
    regression(features, ['S'], 'L', 'K1_S_to_L'),
    regression(features, ['H','S'], 'L', 'K1_H_plus_S_to_L'),
    regression(features, ['H','S','L'], 'Phi_web', 'K1_HSL_to_Phi_web_coherence'),
    regression(features, ['H','S','L'], 'Functional_unity', 'K1_HSL_to_Functional_Unity'),
    regression(features, ['H','S','L'], 'Cosmic_web_pathology', 'K1_HSL_to_Cosmic_Web_Pathology'),
    regression(features, ['H','S','L','Triadic_balance','Dominance_index'], 'Cosmic_web_pathology', 'K1_Full_to_Cosmic_Web_Pathology'),
    regression(features, ['H','S','L'], 'Voidness', 'K1_HSL_to_Voidness'),
    regression(features, ['H','S','L'], 'Cluster_core', 'K1_HSL_to_Cluster_Core'),
    regression(features, ['H','S','L'], 'Filament', 'K1_HSL_to_Filament')
])

def get_mae(summary, test):
    x = summary[summary['test']==test]
    return None if len(x)==0 else x.iloc[0]['mae']
H_L=get_mae(genesis_summary,'K1_H_to_L'); S_L=get_mae(genesis_summary,'K1_S_to_L'); HS_L=get_mae(genesis_summary,'K1_H_plus_S_to_L')
emergence_contrast = pd.DataFrame([{
    'level':'cosmic_web_observational',
    'H_to_L_mae':H_L,
    'S_to_L_mae':S_L,
    'H_plus_S_to_L_mae':HS_L,
    'HS_improves_over_H':H_L-HS_L if H_L is not None and HS_L is not None else None,
    'HS_improves_over_S':S_L-HS_L if S_L is not None and HS_L is not None else None,
    'PETU_prediction_supported':(HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

scale_summary = pd.DataFrame([
    regression(scale_features, ['H'], 'S', 'K1_SCALE_H_to_S'),
    regression(scale_features, ['H'], 'L', 'K1_SCALE_H_to_L'),
    regression(scale_features, ['S'], 'L', 'K1_SCALE_S_to_L'),
    regression(scale_features, ['H','S'], 'L', 'K1_SCALE_H_plus_S_to_L'),
    regression(scale_features, ['H','S','L'], 'Phi_scale', 'K1_SCALE_HSL_to_Phi_scale'),
    regression(scale_features, ['H','S','L'], 'Functional_unity', 'K1_SCALE_HSL_to_Functional_Unity')
])

scale_dynamic_summary = pd.DataFrame([
    regression(scale_dynamic, ['dH'], 'dS', 'K1_SCALE_DYN_dH_to_dS'),
    regression(scale_dynamic, ['dH'], 'dL', 'K1_SCALE_DYN_dH_to_dL'),
    regression(scale_dynamic, ['dS'], 'dL', 'K1_SCALE_DYN_dS_to_dL'),
    regression(scale_dynamic, ['dH','dS'], 'dL', 'K1_SCALE_DYN_dH_plus_dS_to_dL'),
    regression(scale_dynamic, ['dH','dS','dL'], 'dPhi_scale', 'K1_SCALE_DYN_dHSL_to_dPhi'),
    regression(scale_dynamic, ['dH','dS','dL'], 'dFunctional_unity', 'K1_SCALE_DYN_dHSL_to_dFunctional_Unity')
])

# Contrasts.
contrast_defs = [
    ('coherent_vs_low', 'coherent_web_high_flag', True, False),
    ('pathology_high_vs_low', 'pathology_high_flag', True, False),
    ('void_high_vs_other', 'void_high_flag', True, False),
    ('cluster_high_vs_other', 'cluster_high_flag', True, False),
    ('filament_high_vs_other', 'filament_high_flag', True, False),
    ('disproportion_vs_proportion', 'triadic_disproportion_flag', True, False)
]
contrast_metrics = ['H','S','L','Phi_HSL_epsilon','Triadic_balance','Functional_unity','Dominance_index','Phi_web','Cosmic_web_pathology','Voidness','Cluster_core','Filament','local_density','filamentarity','sheetness','isotropy','clustering','graph_linkage']
contrast_rows=[]
for cname, flag, aval, bval in contrast_defs:
    A=features[features[flag]==aval]; B=features[features[flag]==bval]
    for col in contrast_metrics:
        stat,p=safe_mw(A[col],B[col])
        contrast_rows.append({'contrast':cname,'metric':col,'groupA_mean':float(A[col].mean()),'groupB_mean':float(B[col].mean()),'delta_A_minus_B':float(A[col].mean()-B[col].mean()),'pct_delta':float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)),'mannwhitney_stat':stat,'p_value':p})
contrast_summary=pd.DataFrame(contrast_rows)

# Classification.
targets=['coherent_web_high_flag','pathology_high_flag','void_high_flag','cluster_high_flag','filament_high_flag','triadic_disproportion_flag']
feature_sets=[(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
class_rows=[]
for t in targets:
    for cols,label in feature_sets:
        r=auc_model(features,cols,t,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)

gain_rows=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x=d[d.feature_set==fs]
        return None if len(x)==0 else float(x.iloc[0].auc)
    aH,aHS,aHSL,aFull=auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gain_rows.append({'target':target,'auc_H':aH,'auc_HS':aHS,'auc_HSL':aHSL,'auc_full':aFull,'gain_HSL_over_H':None if aH is None or aHSL is None else aHSL-aH,'gain_HSL_over_HS':None if aHS is None or aHSL is None else aHSL-aHS,'gain_full_over_HSL':None if aFull is None or aHSL is None else aFull-aHSL})
classification_gain_summary=pd.DataFrame(gain_rows)

# Phases.
def classify_phase(r):
    if r['void_high_flag'] and r['H'] <= features.H.median(): return 'void_low_H_disconnected'
    if r['cluster_high_flag'] and r['H'] >= features.H.median(): return 'cluster_core_high_HL'
    if r['filament_high_flag'] and r['L'] >= features.L.median(): return 'filament_linked_web'
    if r['triadic_disproportion_flag']: return 'triadic_disproportion'
    if r['coherent_web_high_flag'] and r['Triadic_balance'] >= features.Triadic_balance.median(): return 'coherent_phi_integrated'
    if r['S'] >= features.S.median() and r['L'] <= features.L.quantile(0.25): return 'S_geometry_low_link'
    return 'transitional'
features['PETU_K1_phase'] = features.apply(classify_phase, axis=1)
phase_summary = features.groupby('PETU_K1_phase').agg(
    n_galaxies=('idx','count'),
    mean_z=('z','mean'),
    mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'),
    mean_Phi_web=('Phi_web','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'),
    mean_unity=('Functional_unity','mean'), mean_balance=('Triadic_balance','mean'),
    mean_dominance=('Dominance_index','mean'), mean_pathology=('Cosmic_web_pathology','mean'),
    mean_voidness=('Voidness','mean'), mean_cluster=('Cluster_core','mean'), mean_filament=('Filament','mean')
).reset_index().sort_values('n_galaxies', ascending=False)

summary = {
    'pipeline':'PETU-COSMOS K1 Cosmic Web Triadic Audit',
    'domain':'cosmology / cosmic large-scale structure / SDSS DR17 galaxy web',
    'n_galaxies':int(N),
    'k_neighbors':K_NEIGHBORS,
    'scale_ks':SCALE_KS,
    'epsilon':EPSILON,
    'hypothesis':'Cosmic-web coherence and structural defect arise from triadic proportion/disproportion of H matter-density support, S geometric structure, and L gravitational/network linkage.',
    'epistemic_note':'Observational multiscale test; no experimental perturbation possible at cosmological scale.',
    'next_step':'After K1, reinforce micro and meso with additional natural domains to approach 10-domain PETU/LETU confirmation.'
}

# ============================================================
# SAVE
# ============================================================

paths={
    'galaxies_raw':f'{OUTDIR}/PETU_COSMOS_K1_sdss_galaxies.csv',
    'features':f'{OUTDIR}/PETU_COSMOS_K1_features.csv',
    'scale_features':f'{OUTDIR}/PETU_COSMOS_K1_scale_features.csv',
    'scale_dynamic':f'{OUTDIR}/PETU_COSMOS_K1_scale_dynamic.csv',
    'data_summary':f'{OUTDIR}/PETU_COSMOS_K1_data_summary.csv',
    'genesis_summary':f'{OUTDIR}/PETU_COSMOS_K1_genesis_summary.csv',
    'emergence_contrast':f'{OUTDIR}/PETU_COSMOS_K1_emergence_contrast.csv',
    'scale_summary':f'{OUTDIR}/PETU_COSMOS_K1_scale_summary.csv',
    'scale_dynamic_summary':f'{OUTDIR}/PETU_COSMOS_K1_scale_dynamic_summary.csv',
    'contrast_summary':f'{OUTDIR}/PETU_COSMOS_K1_contrast_summary.csv',
    'classification_summary':f'{OUTDIR}/PETU_COSMOS_K1_classification_summary.csv',
    'classification_gain_summary':f'{OUTDIR}/PETU_COSMOS_K1_classification_gain_summary.csv',
    'phase_summary':f'{OUTDIR}/PETU_COSMOS_K1_phase_summary.csv',
    'failures':f'{OUTDIR}/PETU_COSMOS_K1_failures.csv',
    'summary':f'{OUTDIR}/PETU_COSMOS_K1_summary.json'
}

gal.to_csv(paths['galaxies_raw'], index=False)
features.to_csv(paths['features'], index=False)
scale_features.to_csv(paths['scale_features'], index=False)
scale_dynamic.to_csv(paths['scale_dynamic'], index=False)
data_summary.to_csv(paths['data_summary'], index=False)
genesis_summary.to_csv(paths['genesis_summary'], index=False)
emergence_contrast.to_csv(paths['emergence_contrast'], index=False)
scale_summary.to_csv(paths['scale_summary'], index=False)
scale_dynamic_summary.to_csv(paths['scale_dynamic_summary'], index=False)
contrast_summary.to_csv(paths['contrast_summary'], index=False)
classification_summary.to_csv(paths['classification_summary'], index=False)
classification_gain_summary.to_csv(paths['classification_gain_summary'], index=False)
phase_summary.to_csv(paths['phase_summary'], index=False)
pd.DataFrame(failures).to_csv(paths['failures'], index=False)
with open(paths['summary'],'w') as f: json.dump(summary,f,indent=2)

# ============================================================
# PRINT
# ============================================================

print('\n'+'='*60); print('PETU-COSMOS K1 DATA SUMMARY'); print('='*60); print(data_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 GENESIS SUMMARY'); print('='*60); print(genesis_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 EMERGENCE CONTRAST'); print('='*60); print(emergence_contrast)
print('\n'+'='*60); print('PETU-COSMOS K1 SCALE SUMMARY'); print('='*60); print(scale_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 SCALE DYNAMIC SUMMARY'); print('='*60); print(scale_dynamic_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 CONTRAST SUMMARY'); print('='*60); print(contrast_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 CLASSIFICATION GAIN SUMMARY'); print('='*60); print(classification_gain_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 PHASE SUMMARY'); print('='*60); print(phase_summary)
print('\n'+'='*60); print('PETU-COSMOS K1 FINAL SUMMARY'); print('='*60); print(json.dumps(summary,indent=2))
if len(failures)>0:
    print('\n'+'='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

# Figures
plt.figure(figsize=(8,5)); plt.scatter(features['H']+features['S'], features['L'], s=8, alpha=0.35); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-COSMOS K1: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_K1_HS_to_L.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Phi_HSL_epsilon'], features['Phi_web'], s=8, alpha=0.35); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_web coherence'); plt.title('PETU-COSMOS K1: HSL unity vs cosmic-web coherence'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_K1_PhiHSL_PhiWeb.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Dominance_index'], features['Cosmic_web_pathology'], s=8, alpha=0.35); plt.xlabel('Dominance index'); plt.ylabel('Cosmic web pathology/defect'); plt.title('PETU-COSMOS K1: dominance and cosmic structural defect'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_K1_Dominance_Pathology.png', dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(phase_summary['PETU_K1_phase'], phase_summary['n_galaxies']); plt.xticks(rotation=60); plt.ylabel('Galaxies'); plt.title('PETU-COSMOS K1: phase counts'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_K1_phase_counts.png', dpi=220); plt.show()

zip_base='/content/PETU_COSMOS_K1_Cosmic_Web_Triadic_Audit_results'
zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

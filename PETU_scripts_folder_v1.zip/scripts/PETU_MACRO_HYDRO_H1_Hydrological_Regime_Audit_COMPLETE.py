# ============================================================
# PETU-MACRO-HYDRO H1
# Hydrological Basin / River Regime Triadic Audit
#
# Sistema:
#   Ríos/cuencas naturales observadas mediante caudal diario USGS NWIS.
#
# Traducción PETU:
#   H = soporte hídrico/material:
#       disponibilidad de agua, caudal medio, caudal base, reserva mínima.
#
#   S = estructura hidrológica:
#       forma del régimen, estacionalidad, regularidad de distribución,
#       estructura de variabilidad.
#
#   L = vínculo hidrológico:
#       continuidad temporal del flujo, memoria, autocorrelación,
#       persistencia y conectividad dinámica del régimen.
#
#   Phi = unidad/resiliencia hidrológica:
#       estabilidad del régimen frente a extremos, capacidad de recuperación
#       tras eventos de bajo caudal, resistencia a colapso funcional.
#
# Hipótesis PETU-H1:
#   1. H + S -> L
#      La continuidad/vínculo hidrológico surge mejor desde soporte + estructura
#      que desde H o S aislados.
#
#   2. H + S + L -> Phi
#      La resiliencia hidrológica se reconstruye desde la co-inherencia HSL.
#
#   3. Patología hidro
#      Sequía, flashiness extrema, colapso de caudal o hiperconexión destructiva
#      serán legibles como desproporción pericorética H-S-L:
#      bajo balance, alta dominance, fragilidad y menor Phi.
#
# Fuente:
#   USGS NWIS Daily Values API.
#   Parámetro 00060 = discharge / streamflow.
#
# Ejecución:
#   Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install requests numpy pandas scipy scikit-learn matplotlib tqdm

import os, json, time, math, warnings, shutil
warnings.filterwarnings("ignore")

import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

# ============================================================
# CONFIG
# ============================================================

OUTDIR = "/content/PETU_MACRO_HYDRO_H1_Hydrological_Regime_Audit"
os.makedirs(OUTDIR, exist_ok=True)

# USGS daily discharge sites. Diverse US rivers with generally long records.
USGS_SITES = {
    "Colorado_River_Lees_Ferry_AZ": "09380000",
    "Mississippi_St_Louis_MO": "07010000",
    "Hudson_River_Green_Island_NY": "01358000",
    "Potomac_River_Washington_DC": "01646500",
    "Delaware_River_Trenton_NJ": "01463500",
    "Susquehanna_River_Harrisburg_PA": "01570500",
    "Columbia_River_Dalles_OR": "14105700",
    "Snake_River_Weiser_ID": "13269000",
    "Yampa_River_Deerlodge_CO": "09260050",
    "Rio_Grande_Embudo_NM": "08279500",
    "Gila_River_Clifton_AZ": "09442000",
    "Red_River_Alexandria_LA": "07355500",
    "Tennessee_River_Chattanooga_TN": "03568000",
    "Allegheny_River_Natrona_PA": "03049500",
    "Willamette_River_Portland_OR": "14211720",
    "Truckee_River_Reno_NV": "10348000",
    "Yellowstone_River_Billings_MT": "06214500",
    "James_River_Scotland_SD": "06478500",
    "Wabash_River_Mount_Carmel_IL": "03377500",
    "Neuse_River_Kinston_NC": "02089500",
    "San_Joaquin_River_Vernalis_CA": "11303500",
    "Klamath_River_Keno_OR": "11509500",
    "Deschutes_River_Moody_OR": "14103000",
    "Arkansas_River_Little_Rock_AR": "07263620",
    "Connecticut_River_Thompsonville_CT": "01184000",
    "Chattahoochee_River_Atlanta_GA": "02336000",
    "St_Croix_River_St_Croix_Falls_WI": "05340500",
    "Sabine_River_Ruliff_TX": "08030500",
    "Pecos_River_Red_Bluff_NM": "08410000",
    "Sacramento_River_Freeport_CA": "11447650"
}

START_DATE = "2000-01-01"
END_DATE = "2023-12-31"
PARAMETER_CODE = "00060"  # discharge, cubic feet per second
MIN_DAYS_PER_SITE = 365 * 8
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# Windowing: yearly windows per site. This gives enough samples for statistics.
WINDOW_MODE = "annual"  # currently annual only

# ============================================================
# BASIC UTILS
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    out = np.full_like(x, np.nan, dtype=float)
    mask = np.isfinite(x)
    if mask.sum() == 0:
        return out
    mn, mx = np.nanmin(x[mask]), np.nanmax(x[mask])
    if mx - mn < 1e-12:
        out[mask] = 0.5
    else:
        out[mask] = (x[mask] - mn) / (mx - mn)
    return out


def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        if not np.isfinite(r):
            return None, None
        return float(r), float(p)
    except Exception:
        return None, None


def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]
        b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None


def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))


def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))


def entropy_norm(values, bins=20):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 5:
        return np.nan
    hist, _ = np.histogram(values, bins=bins, density=False)
    p = hist.astype(float)
    if p.sum() <= 0:
        return np.nan
    p = p / p.sum()
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)) / np.log(bins))


def autocorr_lag1(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return np.nan
    if np.std(x[:-1]) < 1e-12 or np.std(x[1:]) < 1e-12:
        return np.nan
    return float(np.corrcoef(x[:-1], x[1:])[0, 1])


def recovery_after_lowflow(q, low_quantile=0.20, recovery_quantile=0.50, max_days=60):
    """
    Mean speed of recovery after low-flow episodes.
    Returns normalized recovery score: higher = faster recovery.
    """
    q = np.asarray(q, dtype=float)
    q = q[np.isfinite(q)]
    if len(q) < 120:
        return np.nan
    low_thr = np.nanquantile(q, low_quantile)
    rec_thr = np.nanquantile(q, recovery_quantile)
    low_idx = np.where(q <= low_thr)[0]
    if len(low_idx) == 0:
        return np.nan
    recoveries = []
    used_until = -1
    for idx in low_idx:
        if idx <= used_until:
            continue
        end = min(len(q), idx + max_days + 1)
        future = np.where(q[idx:end] >= rec_thr)[0]
        if len(future) > 0:
            days = int(future[0])
            recoveries.append(days)
            used_until = idx + days
        else:
            recoveries.append(max_days)
            used_until = end
    if len(recoveries) == 0:
        return np.nan
    mean_days = np.mean(recoveries)
    return float(1.0 - min(mean_days, max_days) / max_days)

# ============================================================
# USGS FETCH
# ============================================================

def fetch_usgs_daily(site, start=START_DATE, end=END_DATE, parameter=PARAMETER_CODE):
    url = "https://waterservices.usgs.gov/nwis/dv/"
    params = {
        "format": "json",
        "sites": site,
        "startDT": start,
        "endDT": end,
        "parameterCd": parameter,
        "siteStatus": "all"
    }
    r = requests.get(url, params=params, timeout=60)
    r.raise_for_status()
    data = r.json()
    ts = data.get("value", {}).get("timeSeries", [])
    if not ts:
        return pd.DataFrame(columns=["date", "q_cfs"])
    vals = ts[0].get("values", [])
    if not vals:
        return pd.DataFrame(columns=["date", "q_cfs"])
    records = vals[0].get("value", [])
    rows = []
    for rec in records:
        try:
            date = pd.to_datetime(rec.get("dateTime")).date()
            val = float(rec.get("value"))
            if val >= 0:
                rows.append((date, val))
        except Exception:
            pass
    df = pd.DataFrame(rows, columns=["date", "q_cfs"])
    if len(df) == 0:
        return df
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").drop_duplicates("date")
    return df

# ============================================================
# HYDRO FEATURES PER ANNUAL WINDOW
# ============================================================

def hydro_features_for_window(q_raw):
    q = np.asarray(q_raw, dtype=float)
    q = q[np.isfinite(q)]
    if len(q) < 180:
        return None

    # Avoid log issues.
    q_pos = np.maximum(q, 1e-9)
    logq = np.log1p(q_pos)

    mean_q = float(np.mean(q_pos))
    median_q = float(np.median(q_pos))
    min_q = float(np.min(q_pos))
    q05 = float(np.quantile(q_pos, 0.05))
    q10 = float(np.quantile(q_pos, 0.10))
    q20 = float(np.quantile(q_pos, 0.20))
    q80 = float(np.quantile(q_pos, 0.80))
    q90 = float(np.quantile(q_pos, 0.90))
    q95 = float(np.quantile(q_pos, 0.95))
    max_q = float(np.max(q_pos))
    std_q = float(np.std(q_pos))
    cv = float(std_q / (mean_q + 1e-12))

    # Flow duration / base support.
    baseflow_proxy = q20 / (median_q + 1e-12)
    lowflow_deficit = max(0.0, 1.0 - q10 / (median_q + 1e-12))
    highflow_pressure = q90 / (median_q + 1e-12)

    # Flashiness: mean absolute day-to-day change normalized.
    diff = np.diff(q_pos)
    flashiness = float(np.sum(np.abs(diff)) / (np.sum(q_pos[:-1]) + 1e-12)) if len(diff) > 0 else np.nan

    # Entropy/order of distribution.
    ent = entropy_norm(logq, bins=20)
    distribution_order = 1.0 - ent if np.isfinite(ent) else np.nan

    # Seasonality proxy via monthly means amplitude.
    # If caller does not provide dates, use day index split into 12 pseudo-months.
    chunks = np.array_split(q_pos, 12)
    monthly_means = np.array([np.mean(c) for c in chunks if len(c) > 0])
    seasonality = float((np.max(monthly_means) - np.min(monthly_means)) / (np.mean(monthly_means) + 1e-12)) if len(monthly_means) >= 3 else np.nan
    seasonality_order = float(1.0 / (1.0 + seasonality)) if np.isfinite(seasonality) else np.nan

    # Memory / continuity.
    ac1 = autocorr_lag1(logq)
    ac1_pos = max(0.0, ac1) if np.isfinite(ac1) else np.nan
    zero_jump_resistance = float(1.0 / (1.0 + flashiness)) if np.isfinite(flashiness) else np.nan
    recovery = recovery_after_lowflow(q_pos)

    # H raw: availability/support.
    H_raw = np.nanmean([
        np.log1p(mean_q),
        np.log1p(median_q),
        np.log1p(q20),
        baseflow_proxy,
        1.0 / (1.0 + lowflow_deficit)
    ])

    # S raw: hydrological regime form/order.
    S_raw = np.nanmean([
        seasonality_order,
        distribution_order,
        1.0 / (1.0 + cv),
        1.0 / (1.0 + abs(highflow_pressure - 2.0)),
        1.0 / (1.0 + flashiness)
    ])

    # L raw: continuity/link/memory of flow.
    L_raw = np.nanmean([
        ac1_pos,
        zero_jump_resistance,
        recovery,
        1.0 / (1.0 + lowflow_deficit),
        1.0 / (1.0 + abs(cv - 0.5))
    ])

    # Independent resilience proxy, not identical to HSL product.
    # High if stable, recovers from low flow, not too flash/extreme.
    drought_resilience = np.nanmean([
        recovery,
        1.0 / (1.0 + lowflow_deficit),
        baseflow_proxy
    ])
    flood_stability = np.nanmean([
        1.0 / (1.0 + highflow_pressure),
        1.0 / (1.0 + flashiness),
        1.0 / (1.0 + cv)
    ])
    regime_resilience = np.nanmean([drought_resilience, flood_stability, ac1_pos])

    # Pathological pressures.
    drought_pathology = lowflow_deficit
    flood_flash_pathology = np.nanmean([flashiness, cv, highflow_pressure/(1.0+highflow_pressure)])

    return {
        "n_days": int(len(q_pos)),
        "mean_q": mean_q,
        "median_q": median_q,
        "min_q": min_q,
        "q05": q05,
        "q10": q10,
        "q20": q20,
        "q80": q80,
        "q90": q90,
        "q95": q95,
        "max_q": max_q,
        "std_q": std_q,
        "cv": cv,
        "baseflow_proxy": baseflow_proxy,
        "lowflow_deficit": lowflow_deficit,
        "highflow_pressure": highflow_pressure,
        "flashiness": flashiness,
        "entropy_logq": ent,
        "distribution_order": distribution_order,
        "seasonality": seasonality,
        "seasonality_order": seasonality_order,
        "autocorr_lag1": ac1,
        "recovery_after_lowflow": recovery,
        "drought_resilience": drought_resilience,
        "flood_stability": flood_stability,
        "Phi_resilience_raw": regime_resilience,
        "drought_pathology_raw": drought_pathology,
        "flood_flash_pathology_raw": flood_flash_pathology,
        "H_raw": H_raw,
        "S_raw": S_raw,
        "L_raw": L_raw
    }

# ============================================================
# MAIN DATA INGESTION
# ============================================================

print("============================================================")
print("PETU-MACRO-HYDRO H1 HYDROLOGICAL REGIME AUDIT")
print("============================================================")
print("Fetching USGS NWIS daily discharge records...")

all_rows = []
site_summary_rows = []
failures = []
raw_paths = []

for site_name, site_id in tqdm(USGS_SITES.items(), desc="USGS sites"):
    try:
        df = fetch_usgs_daily(site_id)
        if len(df) < MIN_DAYS_PER_SITE:
            failures.append({"site_name": site_name, "site_id": site_id, "error": f"too few days: {len(df)}"})
            continue

        raw_path = f"{OUTDIR}/raw_{site_id}_{site_name}.csv"
        df.to_csv(raw_path, index=False)
        raw_paths.append(raw_path)

        df["year"] = df["date"].dt.year
        site_windows = 0

        for year, g in df.groupby("year"):
            if len(g) < 180:
                continue
            feats = hydro_features_for_window(g["q_cfs"].values)
            if feats is None:
                continue
            row = {
                "site_name": site_name,
                "site_id": site_id,
                "year": int(year),
                **feats
            }
            all_rows.append(row)
            site_windows += 1

        site_summary_rows.append({
            "site_name": site_name,
            "site_id": site_id,
            "n_days": int(len(df)),
            "start_date": str(df["date"].min().date()),
            "end_date": str(df["date"].max().date()),
            "n_windows": int(site_windows),
            "mean_q_all": float(df["q_cfs"].mean()),
            "median_q_all": float(df["q_cfs"].median())
        })

        print("  OK", site_name, "windows:", site_windows)
        time.sleep(0.15)

    except Exception as e:
        failures.append({"site_name": site_name, "site_id": site_id, "error": str(e)})

features = pd.DataFrame(all_rows)
site_summary = pd.DataFrame(site_summary_rows)

if len(features) < 50:
    raise RuntimeError(f"Too few hydrological windows: {len(features)}")

# ============================================================
# NORMALIZE H/S/L AND COMPUTE PETU VARIABLES
# ============================================================

for col in ["H_raw", "S_raw", "L_raw", "Phi_resilience_raw", "drought_pathology_raw", "flood_flash_pathology_raw"]:
    features[col.replace("_raw", "")] = normalize01(features[col].values)

features["Phi_HSL_epsilon"] = (features["H"] + EPSILON) * (features["S"] + EPSILON) * (features["L"] + EPSILON)
features["Triadic_balance"] = [triadic_balance(h, s, l) for h, s, l in zip(features["H"], features["S"], features["L"])]
features["Dominance_index"] = [dominance_index(h, s, l) for h, s, l in zip(features["H"], features["S"], features["L"])]
features["Functional_unity_HSL"] = features["Phi_HSL_epsilon"] * features["Triadic_balance"]

# Overall hydro pathology: drought + flood/flash + triadic imbalance.
features["Hydro_pathology_index"] = normalize01(
    np.nanmean([
        features["drought_pathology"].values,
        features["flood_flash_pathology"].values,
        features["Dominance_index"].values,
        1.0 - features["Triadic_balance"].values
    ], axis=0)
)

# Flags.
features["resilient_high_flag"] = features["Phi_resilience"].values >= np.nanmedian(features["Phi_resilience"].values)
features["pathology_high_flag"] = features["Hydro_pathology_index"].values >= np.nanmedian(features["Hydro_pathology_index"].values)
features["drought_high_flag"] = features["drought_pathology"].values >= np.nanquantile(features["drought_pathology"].values, 0.75)
features["flash_high_flag"] = features["flood_flash_pathology"].values >= np.nanquantile(features["flood_flash_pathology"].values, 0.75)
features["triadic_disproportion_flag"] = (
    (features["Triadic_balance"] <= np.nanquantile(features["Triadic_balance"], 0.25)) |
    (features["Dominance_index"] >= np.nanquantile(features["Dominance_index"], 0.75))
)

# ============================================================
# REGRESSION TESTS
# ============================================================

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 10:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {
        "test": label,
        "n": int(len(d)),
        "r2": float(r2_score(y, pred)),
        "mae": float(mean_absolute_error(y, pred)),
        "spearman_true_pred": r,
        "p_value": p
    }

genesis_summary = pd.DataFrame([
    regression(features, ["H"], "S", "H1_H_to_S"),
    regression(features, ["H"], "L", "H1_H_to_L"),
    regression(features, ["S"], "L", "H1_S_to_L"),
    regression(features, ["H", "S"], "L", "H1_H_plus_S_to_L"),
    regression(features, ["H", "S", "L"], "Phi_resilience", "H1_HSL_to_Phi_resilience"),
    regression(features, ["H", "S", "L"], "Functional_unity_HSL", "H1_HSL_to_Functional_Unity"),
    regression(features, ["H", "S", "L"], "Hydro_pathology_index", "H1_HSL_to_Hydro_Pathology"),
    regression(features, ["H", "S", "L", "Triadic_balance", "Dominance_index"], "Hydro_pathology_index", "H1_Full_to_Hydro_Pathology"),
    regression(features, ["H", "S", "L", "Triadic_balance", "Dominance_index"], "Phi_resilience", "H1_Full_to_Phi_resilience")
])

def get_mae(summary, test):
    x = summary[summary["test"] == test]
    return None if len(x) == 0 else x.iloc[0]["mae"]

H_L = get_mae(genesis_summary, "H1_H_to_L")
S_L = get_mae(genesis_summary, "H1_S_to_L")
HS_L = get_mae(genesis_summary, "H1_H_plus_S_to_L")

emergence_contrast = pd.DataFrame([{
    "level": "macro_hydro_regime",
    "H_to_L_mae": H_L,
    "S_to_L_mae": S_L,
    "H_plus_S_to_L_mae": HS_L,
    "HS_improves_over_H": H_L - HS_L if H_L is not None and HS_L is not None else None,
    "HS_improves_over_S": S_L - HS_L if S_L is not None and HS_L is not None else None,
    "PETU_prediction_supported": (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

# ============================================================
# DYNAMIC / YEAR-TO-YEAR TESTS
# ============================================================

dyn_rows = []
for site_id, g in features.sort_values(["site_id", "year"]).groupby("site_id"):
    g = g.sort_values("year").copy()
    for col in ["H", "S", "L", "Phi_resilience", "Functional_unity_HSL", "Hydro_pathology_index"]:
        g["d" + col] = g[col].diff()
    for _, r in g.iloc[1:].iterrows():
        dyn_rows.append({
            "site_name": r["site_name"],
            "site_id": r["site_id"],
            "year": int(r["year"]),
            "dH": r["dH"],
            "dS": r["dS"],
            "dL": r["dL"],
            "dPhi_resilience": r["dPhi_resilience"],
            "dFunctional_unity_HSL": r["dFunctional_unity_HSL"],
            "dHydro_pathology_index": r["dHydro_pathology_index"]
        })

dyn = pd.DataFrame(dyn_rows)

dynamic_summary = pd.DataFrame([
    regression(dyn, ["dH"], "dS", "H1_DYN_dH_to_dS"),
    regression(dyn, ["dH"], "dL", "H1_DYN_dH_to_dL"),
    regression(dyn, ["dS"], "dL", "H1_DYN_dS_to_dL"),
    regression(dyn, ["dH", "dS"], "dL", "H1_DYN_dH_plus_dS_to_dL"),
    regression(dyn, ["dH", "dS", "dL"], "dPhi_resilience", "H1_DYN_dHSL_to_dPhi_resilience"),
    regression(dyn, ["dH", "dS", "dL"], "dFunctional_unity_HSL", "H1_DYN_dHSL_to_dFunctional_Unity"),
    regression(dyn, ["dH", "dS", "dL"], "dHydro_pathology_index", "H1_DYN_dHSL_to_dHydro_Pathology")
])

# ============================================================
# CONTRASTS
# ============================================================

def contrast_groups(data, group_col, group_a_val, group_b_val, label):
    A = data[data[group_col] == group_a_val]
    B = data[data[group_col] == group_b_val]
    rows = []
    for col in ["H", "S", "L", "Phi_HSL_epsilon", "Triadic_balance", "Dominance_index", "Functional_unity_HSL",
                "Phi_resilience", "Hydro_pathology_index", "drought_pathology", "flood_flash_pathology",
                "mean_q", "cv", "flashiness", "baseflow_proxy", "autocorr_lag1", "recovery_after_lowflow"]:
        if col not in data.columns:
            continue
        stat, p = safe_mw(A[col], B[col])
        rows.append({
            "contrast": label,
            "metric": col,
            "groupA_mean": float(np.nanmean(A[col])) if len(A) else np.nan,
            "groupB_mean": float(np.nanmean(B[col])) if len(B) else np.nan,
            "delta_A_minus_B": float(np.nanmean(A[col]) - np.nanmean(B[col])) if len(A) and len(B) else np.nan,
            "pct_delta": float(100*(np.nanmean(A[col]) - np.nanmean(B[col]))/(abs(np.nanmean(B[col]))+1e-12)) if len(A) and len(B) else np.nan,
            "mannwhitney_stat": stat,
            "p_value": p
        })
    return pd.DataFrame(rows)

robust_fragile_contrast = contrast_groups(features, "resilient_high_flag", True, False, "resilient_vs_fragile")
pathology_contrast = contrast_groups(features, "pathology_high_flag", True, False, "pathology_high_vs_low")
disproportion_contrast = contrast_groups(features, "triadic_disproportion_flag", True, False, "disproportion_vs_proportion")
drought_contrast = contrast_groups(features, "drought_high_flag", True, False, "drought_high_vs_other")
flash_contrast = contrast_groups(features, "flash_high_flag", True, False, "flash_high_vs_other")
all_contrasts = pd.concat([robust_fragile_contrast, pathology_contrast, disproportion_contrast, drought_contrast, flash_contrast], ignore_index=True)

# ============================================================
# CLASSIFICATION
# ============================================================

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 20 or len(d[target].unique()) < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight="balanced")
        clf.fit(X, y)
        pred = clf.predict_proba(X)[:, 1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {"feature_set": label, "target": target, "n": int(len(d)), "auc": float(auc)}

classification_rows = []
targets = ["resilient_high_flag", "pathology_high_flag", "drought_high_flag", "flash_high_flag", "triadic_disproportion_flag"]
feature_sets = [
    (["H"], "H"),
    (["S"], "S"),
    (["L"], "L"),
    (["H", "S"], "H+S"),
    (["H", "S", "L"], "H+S+L"),
    (["H", "S", "L", "Phi_HSL_epsilon"], "H+S+L+Phi"),
    (["H", "S", "L", "Phi_HSL_epsilon", "Triadic_balance", "Dominance_index"], "H+S+L+PhiBalanceDominance")
]
for target in targets:
    for cols, label in feature_sets:
        r = auc_model(features, cols, target, label)
        if r is not None:
            classification_rows.append(r)
classification_summary = pd.DataFrame(classification_rows)

gain_rows = []
for target, d in classification_summary.groupby("target"):
    def auc(fs):
        x = d[d["feature_set"] == fs]
        return None if len(x) == 0 else float(x.iloc[0]["auc"])
    aH, aHS, aHSL, aFull = auc("H"), auc("H+S"), auc("H+S+L"), auc("H+S+L+PhiBalanceDominance")
    gain_rows.append({
        "target": target,
        "auc_H": aH,
        "auc_HS": aHS,
        "auc_HSL": aHSL,
        "auc_full": aFull,
        "gain_HSL_over_H": None if aH is None or aHSL is None else aHSL - aH,
        "gain_HSL_over_HS": None if aHS is None or aHSL is None else aHSL - aHS,
        "gain_full_over_HSL": None if aFull is None or aHSL is None else aFull - aHSL
    })
classification_gain_summary = pd.DataFrame(gain_rows)

# ============================================================
# PHASES
# ============================================================

def classify_hydro_phase(r):
    H, S, L = r["H"], r["S"], r["L"]
    bal, dom = r["Triadic_balance"], r["Dominance_index"]
    phi = r["Phi_resilience"]
    path = r["Hydro_pathology_index"]
    drought = r["drought_pathology"]
    flash = r["flood_flash_pathology"]

    if drought >= features["drought_pathology"].quantile(0.80) and H <= features["H"].quantile(0.40):
        return "low_H_drought_pathology"
    if flash >= features["flood_flash_pathology"].quantile(0.80) and L >= features["L"].quantile(0.60):
        return "flash_L_hyperdynamic_pathology"
    if bal <= features["Triadic_balance"].quantile(0.25) or dom >= features["Dominance_index"].quantile(0.75):
        return "triadic_disproportion"
    if phi >= features["Phi_resilience"].median() and bal >= features["Triadic_balance"].median():
        return "resilient_phi_integrated"
    if S >= features["S"].median() and L <= features["L"].quantile(0.25):
        return "S_regime_low_link"
    return "transitional"

features["PETU_hydro_phase"] = features.apply(classify_hydro_phase, axis=1)

phase_summary = (
    features.groupby("PETU_hydro_phase")
    .agg(
        n_windows=("site_id", "count"),
        n_sites=("site_id", "nunique"),
        mean_H=("H", "mean"),
        mean_S=("S", "mean"),
        mean_L=("L", "mean"),
        mean_Phi_HSL=("Phi_HSL_epsilon", "mean"),
        mean_resilience=("Phi_resilience", "mean"),
        mean_balance=("Triadic_balance", "mean"),
        mean_dominance=("Dominance_index", "mean"),
        mean_pathology=("Hydro_pathology_index", "mean"),
        mean_drought=("drought_pathology", "mean"),
        mean_flash=("flood_flash_pathology", "mean")
    )
    .reset_index()
    .sort_values("n_windows", ascending=False)
)

# ============================================================
# SAVE OUTPUTS
# ============================================================

paths = {
    "features": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_features.csv",
    "dynamic_features": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_dynamic_features.csv",
    "site_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_site_summary.csv",
    "genesis_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_genesis_summary.csv",
    "dynamic_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_dynamic_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_emergence_contrast.csv",
    "contrast_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_contrast_summary.csv",
    "classification_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_classification_summary.csv",
    "classification_gain_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_classification_gain_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_phase_summary.csv",
    "failures": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_failures.csv",
    "summary": f"{OUTDIR}/PETU_MACRO_HYDRO_H1_summary.json"
}

features.to_csv(paths["features"], index=False)
dyn.to_csv(paths["dynamic_features"], index=False)
site_summary.to_csv(paths["site_summary"], index=False)
genesis_summary.to_csv(paths["genesis_summary"], index=False)
dynamic_summary.to_csv(paths["dynamic_summary"], index=False)
emergence_contrast.to_csv(paths["emergence_contrast"], index=False)
all_contrasts.to_csv(paths["contrast_summary"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-MACRO-HYDRO H1 Hydrological Regime Audit",
    "domain": "macro natural hydrology / USGS NWIS daily river discharge",
    "n_sites_requested": len(USGS_SITES),
    "n_sites_completed": int(site_summary["site_id"].nunique()) if len(site_summary) else 0,
    "n_windows": int(len(features)),
    "n_dynamic_windows": int(len(dyn)),
    "start_date": START_DATE,
    "end_date": END_DATE,
    "parameter_code": PARAMETER_CODE,
    "epsilon": EPSILON,
    "hypothesis": "Hydrological resilience and pathology arise from triadic proportion/disproportion of H water support, S regime structure, and L flow continuity/linkage.",
    "next_step": "H2: perturbative hydro/climate stress test; C1: climate teleconnection audit; K1: cosmological large-scale structure audit."
}

with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

# ============================================================
# PRINT SUMMARIES
# ============================================================

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 SITE SUMMARY")
print("============================================================")
print(site_summary)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 GENESIS SUMMARY")
print("============================================================")
print(genesis_summary)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 EMERGENCE CONTRAST")
print("============================================================")
print(emergence_contrast)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 DYNAMIC SUMMARY")
print("============================================================")
print(dynamic_summary)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 CONTRAST SUMMARY")
print("============================================================")
print(all_contrasts)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 CLASSIFICATION SUMMARY")
print("============================================================")
print(classification_summary)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 PHASE SUMMARY")
print("============================================================")
print(phase_summary)

print("\n============================================================")
print("PETU-MACRO-HYDRO H1 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

if len(failures) > 0:
    print("\n============================================================")
    print("FAILURES / SKIPPED")
    print("============================================================")
    print(pd.DataFrame(failures))

# ============================================================
# FIGURES
# ============================================================

plt.figure(figsize=(8,5))
plt.scatter(features["H"] + features["S"], features["L"], s=25, alpha=0.65)
plt.xlabel("H + S")
plt.ylabel("L")
plt.title("PETU-MACRO-HYDRO H1: H+S -> L")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_H1_HS_to_L.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Phi_HSL_epsilon"], features["Phi_resilience"], s=25, alpha=0.65)
plt.xlabel("Phi_HSL_epsilon")
plt.ylabel("Phi_resilience")
plt.title("PETU-MACRO-HYDRO H1: HSL unity vs hydro resilience")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_H1_PhiHSL_resilience.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Triadic_balance"], features["Hydro_pathology_index"], s=25, alpha=0.65)
plt.xlabel("Triadic balance")
plt.ylabel("Hydro pathology index")
plt.title("PETU-MACRO-HYDRO H1: balance vs pathology")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_H1_balance_pathology.png", dpi=220)
plt.show()

plt.figure(figsize=(10,5))
plt.bar(phase_summary["PETU_hydro_phase"], phase_summary["n_windows"])
plt.xticks(rotation=60)
plt.ylabel("Windows")
plt.title("PETU-MACRO-HYDRO H1: hydro phases")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_H1_phase_counts.png", dpi=220)
plt.show()

zip_base = "/content/PETU_MACRO_HYDRO_H1_Hydrological_Regime_Audit_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path):
    os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k, v in paths.items():
    print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

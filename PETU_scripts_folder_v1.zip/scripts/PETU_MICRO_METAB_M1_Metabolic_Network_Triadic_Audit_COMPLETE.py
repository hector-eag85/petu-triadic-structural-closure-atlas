# ============================================================
# PETU-MICRO-METAB M1
# Natural Metabolic / Biochemical Network Triadic Audit
#
# Objetivo:
#   Tercer dominio micro-natural de PETU/LETU.
#   Tras proteínas y genómica, este pipeline audita redes metabólicas
#   naturales como sistemas bioquímicos de soporte, forma y vínculo.
#
# Sistema:
#   Redes metabólicas naturales obtenidas desde KEGG REST.
#   Cada organismo se modela como red bipartita reacción-metabolito
#   y como red metabolito-metabolito derivada por co-participación
#   en reacciones.
#
# Traducción PETU:
#   H = soporte bioquímico/material:
#       riqueza de metabolitos, diversidad química, soporte de sustratos,
#       base material de la red.
#
#   S = estructura formal metabólica:
#       modularidad, orden de grado, heterogeneidad controlada,
#       organización topológica y estequiométrica aproximada.
#
#   L = vínculo reactivo/flujo potencial:
#       conectividad, eficiencia, clustering, continuidad entre metabolitos,
#       acoplamiento de rutas.
#
#   Φ = coherencia metabólica funcional:
#       integración soporte-estructura-vínculo, robustez topológica,
#       baja fragilidad metabólica.
#
# Hipótesis PETU-M1:
#   1. H + S -> L:
#      El vínculo reactivo L se predice mejor desde soporte + estructura
#      que desde H o S aislados.
#
#   2. H + S + L -> Φ:
#      La coherencia metabólica se reconstruye desde HSL.
#
#   3. Perturbación/patología auxiliar:
#      Ataques a metabolitos soporte H, estructura S o vínculos L reducen Φ
#      o revelan desproporción triádica.
#
# Nota metodológica:
#   Este es un estudio micro-natural normal. Las perturbaciones de nodos
#   son contrastes auxiliares, no la base primaria de la hipótesis.
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install requests numpy pandas scipy scikit-learn matplotlib tqdm networkx python-louvain

import os, re, json, math, random, warnings, shutil, time
warnings.filterwarnings("ignore")

import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx

from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.preprocessing import StandardScaler

try:
    import community as community_louvain
    HAS_LOUVAIN = True
except Exception:
    HAS_LOUVAIN = False

# ============================================================
# CONFIG
# ============================================================

OUTDIR = "/content/PETU_MICRO_METAB_M1_Metabolic_Network_Triadic_Audit"
os.makedirs(OUTDIR, exist_ok=True)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

EPSILON = 0.05
MIN_METABOLITES = 40
MAX_REACTIONS_PER_ORG = 900
REQUEST_SLEEP = 0.08

# Natural organisms across bacteria, yeast, plant, animal, human, archaeal.
ORGANISMS = {
    "Escherichia_coli_K12": "eco",
    "Bacillus_subtilis": "bsu",
    "Mycoplasma_genitalium": "mge",
    "Synechocystis_PCC6803": "syn",
    "Saccharomyces_cerevisiae": "sce",
    "Arabidopsis_thaliana": "ath",
    "Drosophila_melanogaster": "dme",
    "Homo_sapiens": "hsa",
    "Methanocaldococcus_jannaschii": "mja",
    "Thermus_thermophilus": "ttj"
}

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]
        b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def entropy_norm(values):
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals)]
    vals = vals[vals > 0]
    if len(vals) <= 1 or vals.sum() <= 0:
        return 0.0
    p = vals / vals.sum()
    ent = -np.sum(p * np.log(p + 1e-12))
    return float(ent / np.log(len(vals) + 1e-12))

def gini(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0 or np.mean(x) == 0:
        return 0.0
    x = np.sort(np.abs(x))
    n = len(x)
    return float((2*np.sum((np.arange(1,n+1))*x)/(n*np.sum(x)+1e-12)) - (n+1)/n)

def kegg_get(path, retries=3):
    url = f"https://rest.kegg.jp/{path}"
    last = None
    for _ in range(retries):
        try:
            r = requests.get(url, timeout=60)
            if r.status_code == 200:
                return r.text
            last = f"HTTP {r.status_code}"
        except Exception as e:
            last = str(e)
        time.sleep(REQUEST_SLEEP)
    raise RuntimeError(last or "KEGG request failed")

def parse_reaction_equation(equation):
    # Extract KEGG compounds like C00031 from both sides.
    comps = re.findall(r"C\d{5}", equation or "")
    return sorted(set(comps))

def get_org_reactions(org_code):
    txt = kegg_get(f"link/reaction/{org_code}")
    rxns = []
    for line in txt.splitlines():
        parts = line.strip().split("\t")
        if len(parts) == 2:
            r = parts[1].replace("rn:", "")
            if r.startswith("R"):
                rxns.append(r)
    rxns = sorted(set(rxns))[:MAX_REACTIONS_PER_ORG]
    return rxns

def get_reaction_equations(rxns):
    equations = {}
    # KEGG get can batch up to several IDs; keep chunks conservative.
    for i in range(0, len(rxns), 10):
        chunk = rxns[i:i+10]
        try:
            txt = kegg_get("get/" + "+".join(chunk))
            current = None
            eq = None
            for line in txt.splitlines():
                if line.startswith("ENTRY"):
                    if current and eq:
                        equations[current] = eq
                    m = re.search(r"(R\d{5})", line)
                    current = m.group(1) if m else None
                    eq = None
                elif line.startswith("EQUATION"):
                    eq = line.replace("EQUATION", "").strip()
                elif current and eq is not None and line.startswith("            "):
                    # continuation line
                    eq += " " + line.strip()
            if current and eq:
                equations[current] = eq
        except Exception:
            pass
        time.sleep(REQUEST_SLEEP)
    return equations

def build_metabolic_graph(rxns_to_comps):
    B = nx.Graph()
    M = nx.Graph()
    rxn_nodes = []
    met_nodes = set()
    for r, comps in rxns_to_comps.items():
        if len(comps) < 2:
            continue
        rn = "rxn:" + r
        rxn_nodes.append(rn)
        B.add_node(rn, kind="reaction")
        for c in comps:
            cn = "met:" + c
            met_nodes.add(cn)
            B.add_node(cn, kind="metabolite")
            B.add_edge(rn, cn)
        # metabolite projection: connect all compounds in same reaction.
        # Cap very large reactions to avoid currency-like artifacts.
        comps2 = comps[:12]
        for i in range(len(comps2)):
            for j in range(i+1, len(comps2)):
                a, b = "met:"+comps2[i], "met:"+comps2[j]
                if M.has_edge(a,b):
                    M[a][b]["weight"] += 1
                else:
                    M.add_edge(a,b, weight=1)
    # ensure isolated metabolites from B appear in M
    M.add_nodes_from(met_nodes)
    return B, M

def graph_efficiency_lcc(G):
    if G.number_of_nodes() < 3:
        return 0.0
    comps = list(nx.connected_components(G))
    if not comps:
        return 0.0
    lcc = G.subgraph(max(comps, key=len)).copy()
    n = lcc.number_of_nodes()
    if n < 3:
        return 0.0
    # Approximate if large
    try:
        if n <= 500:
            return float(nx.global_efficiency(lcc))
        else:
            nodes = list(lcc.nodes())
            sample = random.sample(nodes, 300)
            sub = lcc.subgraph(sample).copy()
            return float(nx.global_efficiency(sub))
    except Exception:
        return 0.0

def modularity_score(G):
    if G.number_of_edges() < 2 or G.number_of_nodes() < 5:
        return 0.0
    try:
        if HAS_LOUVAIN and G.number_of_nodes() <= 3000:
            part = community_louvain.best_partition(G, random_state=RANDOM_SEED)
            return float(community_louvain.modularity(part, G))
        else:
            comms = nx.algorithms.community.greedy_modularity_communities(G)
            return float(nx.algorithms.community.modularity(G, comms))
    except Exception:
        return 0.0

def largest_component_fraction(G):
    n = G.number_of_nodes()
    if n == 0:
        return 0.0
    comps = list(nx.connected_components(G))
    if not comps:
        return 0.0
    return float(len(max(comps, key=len))/n)

def robustness_after_removal(G, strategy="random", frac=0.1):
    if G.number_of_nodes() < 10:
        return 0.0
    G2 = G.copy()
    n_remove = max(1, int(frac * G2.number_of_nodes()))
    nodes = list(G2.nodes())
    deg = dict(G2.degree())
    clustering = nx.clustering(G2) if G2.number_of_nodes() <= 3000 else {n:0 for n in nodes}
    if strategy == "H_support":
        # remove high-degree support hubs
        rem = sorted(nodes, key=lambda x: deg.get(x,0), reverse=True)[:n_remove]
    elif strategy == "S_structure":
        # remove nodes with high clustering / formal embeddedness
        rem = sorted(nodes, key=lambda x: clustering.get(x,0), reverse=True)[:n_remove]
    elif strategy == "L_linkage":
        # approximate betweenness on sample if large
        try:
            if G2.number_of_nodes() <= 800:
                btw = nx.betweenness_centrality(G2, k=None)
            else:
                btw = nx.betweenness_centrality(G2, k=120, seed=RANDOM_SEED)
            rem = sorted(nodes, key=lambda x: btw.get(x,0), reverse=True)[:n_remove]
        except Exception:
            rem = sorted(nodes, key=lambda x: deg.get(x,0), reverse=True)[:n_remove]
    else:
        rem = random.sample(nodes, n_remove)
    G2.remove_nodes_from(rem)
    return largest_component_fraction(G2)

def metabolic_features(org_name, org_code, rxns_to_comps):
    B, M = build_metabolic_graph(rxns_to_comps)
    n_met = M.number_of_nodes()
    n_edges = M.number_of_edges()
    n_rxn = len(rxns_to_comps)
    if n_met < MIN_METABOLITES:
        raise RuntimeError(f"too few metabolites: {n_met}")

    degrees = np.array([d for _, d in M.degree()], dtype=float)
    weighted_degrees = np.array([d for _, d in M.degree(weight="weight")], dtype=float)
    avg_degree = float(np.mean(degrees)) if len(degrees) else 0.0
    density = float(nx.density(M)) if n_met > 1 else 0.0
    lcc_frac = largest_component_fraction(M)
    clustering = float(nx.average_clustering(M)) if n_edges > 0 and n_met <= 4000 else 0.0
    efficiency = graph_efficiency_lcc(M)
    mod = modularity_score(M)
    degree_entropy = entropy_norm(degrees + 1)
    degree_gini = gini(degrees + 1)
    chemical_diversity = entropy_norm(weighted_degrees + 1)
    support_richness = math.log1p(n_met) / math.log1p(5000)
    reaction_richness = math.log1p(n_rxn) / math.log1p(5000)

    # H: material biochemical support
    H_raw = np.mean([
        support_richness,
        reaction_richness,
        chemical_diversity,
        lcc_frac,
        1.0 - min(1.0, degree_gini)
    ])

    # S: formal metabolic structure
    structure_order = np.mean([
        mod,
        degree_entropy,
        1.0 - min(1.0, degree_gini),
        clustering,
        1.0 - abs(density - 0.02) / 0.02 if density <= 0.04 else max(0.0, 1.0 - density)
    ])
    S_raw = float(max(0.0, min(1.0, structure_order)))

    # L: reactive linkage / flow potential
    L_raw = np.mean([
        lcc_frac,
        efficiency,
        min(1.0, avg_degree/20.0),
        clustering,
        min(1.0, density*50.0)
    ])

    # Independent resilience proxy via perturbations.
    random_res = robustness_after_removal(M, "random", 0.1)
    H_res = robustness_after_removal(M, "H_support", 0.1)
    S_res = robustness_after_removal(M, "S_structure", 0.1)
    L_res = robustness_after_removal(M, "L_linkage", 0.1)
    mean_attack_res = float(np.mean([H_res, S_res, L_res]))

    # Φ resilience independent-ish: survives attack + connected + efficient + structured
    Phi_metabolic_raw = np.mean([
        random_res,
        mean_attack_res,
        lcc_frac,
        efficiency,
        clustering,
        1.0 - min(1.0, degree_gini)
    ])

    # Pathology/fragility: loss under attacks, dominance, fragmentation
    attack_loss = 1.0 - mean_attack_res
    fragmentation = 1.0 - lcc_frac
    hub_dominance = min(1.0, degree_gini)
    overconnectivity = min(1.0, max(0.0, density - 0.03) * 20.0)
    Metabolic_pathology_raw = np.mean([
        attack_loss,
        fragmentation,
        hub_dominance,
        1.0 - efficiency,
        overconnectivity
    ])

    return {
        "organism": org_name,
        "org_code": org_code,
        "n_reactions": int(n_rxn),
        "n_metabolites": int(n_met),
        "n_edges": int(n_edges),
        "avg_degree": avg_degree,
        "density": density,
        "lcc_fraction": lcc_frac,
        "clustering": clustering,
        "efficiency": efficiency,
        "modularity": mod,
        "degree_entropy": degree_entropy,
        "degree_gini": degree_gini,
        "chemical_diversity": chemical_diversity,
        "support_richness": support_richness,
        "reaction_richness": reaction_richness,
        "random_resilience": random_res,
        "H_attack_resilience": H_res,
        "S_attack_resilience": S_res,
        "L_attack_resilience": L_res,
        "mean_attack_resilience": mean_attack_res,
        "H_raw": H_raw,
        "S_raw": S_raw,
        "L_raw": L_raw,
        "Phi_metabolic_raw": Phi_metabolic_raw,
        "Metabolic_pathology_raw": Metabolic_pathology_raw
    }

# Synthetic local subnetworks from each organism by pathway-like reaction sampling.
def metabolic_subnetwork_features(org_name, org_code, rxns_to_comps, n_samples=30):
    rxns = list(rxns_to_comps.keys())
    rows = []
    if len(rxns) < 80:
        n_samples = max(8, n_samples//2)
    for i in range(n_samples):
        # Seed reaction, then sample reactions sharing compounds to make natural-like local module.
        seed = random.choice(rxns)
        seed_comps = set(rxns_to_comps[seed])
        scores = []
        for r in rxns:
            inter = len(seed_comps.intersection(rxns_to_comps[r]))
            scores.append((inter + random.random()*0.05, r))
        scores.sort(reverse=True)
        size = random.randint(max(25, len(rxns)//25), max(35, min(180, len(rxns)//5)))
        chosen = [r for _, r in scores[:size]]
        sub = {r: rxns_to_comps[r] for r in chosen}
        try:
            feat = metabolic_features(org_name, org_code, sub)
            feat["subnetwork_id"] = i
            feat["variant"] = "natural_module"
            rows.append(feat)
        except Exception:
            continue
    return rows

# ============================================================
# MAIN DOWNLOAD / BUILD
# ============================================================

print("============================================================")
print("PETU-MICRO-METAB M1 METABOLIC NETWORK TRIADIC AUDIT")
print("============================================================")
print("Fetching KEGG organism reactions and reaction compounds...")

failures = []
org_networks = {}

for org_name, org_code in tqdm(ORGANISMS.items(), desc="KEGG organisms"):
    try:
        rxns = get_org_reactions(org_code)
        if len(rxns) < 30:
            raise RuntimeError(f"too few reactions linked: {len(rxns)}")
        equations = get_reaction_equations(rxns)
        rxns_to_comps = {}
        for r, eq in equations.items():
            comps = parse_reaction_equation(eq)
            if len(comps) >= 2:
                rxns_to_comps[r] = comps
        if len(rxns_to_comps) < 30:
            raise RuntimeError(f"too few parsed reactions: {len(rxns_to_comps)}")
        org_networks[org_name] = {"code": org_code, "rxns_to_comps": rxns_to_comps}
        print(f"  OK {org_name} {org_code}: reactions={len(rxns_to_comps)}")
    except Exception as e:
        failures.append({"organism": org_name, "org_code": org_code, "error": str(e)})
        print("  FAIL", org_name, org_code, str(e))

if len(org_networks) < 4:
    raise RuntimeError("Too few metabolic networks loaded. Check KEGG connection.")

# ============================================================
# FEATURE EXTRACTION
# ============================================================

rows = []
print("Computing metabolic network features...")

for org_name, item in tqdm(org_networks.items(), desc="Metabolic features"):
    org_code = item["code"]
    rxns_to_comps = item["rxns_to_comps"]
    try:
        whole = metabolic_features(org_name, org_code, rxns_to_comps)
        whole["subnetwork_id"] = -1
        whole["variant"] = "whole_network"
        rows.append(whole)
    except Exception as e:
        failures.append({"organism": org_name, "org_code": org_code, "error": "whole: " + str(e)})

    # local modules provide enough n for regressions while still derived from natural networks.
    try:
        mods = metabolic_subnetwork_features(org_name, org_code, rxns_to_comps, n_samples=28)
        rows.extend(mods)
    except Exception as e:
        failures.append({"organism": org_name, "org_code": org_code, "error": "modules: " + str(e)})

features = pd.DataFrame(rows)
if len(features) < 60:
    raise RuntimeError("Too few metabolic feature rows.")

# Normalize core variables
for col in ["H_raw", "S_raw", "L_raw", "Phi_metabolic_raw", "Metabolic_pathology_raw"]:
    features[col.replace("_raw", "")] = normalize01(features[col].values)

features["Phi_HSL_epsilon"] = (features["H"] + EPSILON) * (features["S"] + EPSILON) * (features["L"] + EPSILON)
features["Triadic_balance"] = [triadic_balance(h,s,l) for h,s,l in zip(features["H"], features["S"], features["L"])]
features["Functional_unity"] = features["Phi_HSL_epsilon"] * features["Triadic_balance"]
features["Dominance_index"] = [dominance_index(h,s,l) for h,s,l in zip(features["H"], features["S"], features["L"])]

features["whole_network_flag"] = features["variant"].eq("whole_network")
features["robust_high_flag"] = features["Phi_metabolic"].ge(features["Phi_metabolic"].median())
features["pathology_high_flag"] = features["Metabolic_pathology"].ge(features["Metabolic_pathology"].median())
features["triadic_disproportion_flag"] = (
    features["Triadic_balance"].le(features["Triadic_balance"].quantile(0.25)) |
    features["Dominance_index"].ge(features["Dominance_index"].quantile(0.75))
)
features["H_attack_fragile_flag"] = features["H_attack_resilience"].le(features["H_attack_resilience"].quantile(0.25))
features["S_attack_fragile_flag"] = features["S_attack_resilience"].le(features["S_attack_resilience"].quantile(0.25))
features["L_attack_fragile_flag"] = features["L_attack_resilience"].le(features["L_attack_resilience"].quantile(0.25))

# ============================================================
# MODEL HELPERS
# ============================================================

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {
        "test": label,
        "n": int(len(d)),
        "r2": float(r2_score(y, pred)),
        "mae": float(mean_absolute_error(y, pred)),
        "spearman_true_pred": r,
        "p_value": p
    }

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight="balanced")
        clf.fit(X, y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {"feature_set": label, "target": target, "n": int(len(d)), "auc": float(auc)}

# ============================================================
# SUMMARIES
# ============================================================

data_summary = pd.DataFrame([{
    "n_organisms_requested": int(len(ORGANISMS)),
    "n_organisms_loaded": int(len(org_networks)),
    "n_feature_rows": int(len(features)),
    "n_whole_networks": int(features["whole_network_flag"].sum()),
    "n_modules": int((~features["whole_network_flag"]).sum()),
    "epsilon": EPSILON
}])

organism_summary = (
    features.groupby(["organism", "org_code"])
    .agg(
        n_rows=("organism", "count"),
        mean_reactions=("n_reactions", "mean"),
        mean_metabolites=("n_metabolites", "mean"),
        mean_H=("H", "mean"),
        mean_S=("S", "mean"),
        mean_L=("L", "mean"),
        mean_Phi=("Phi_metabolic", "mean"),
        mean_pathology=("Metabolic_pathology", "mean"),
        mean_balance=("Triadic_balance", "mean"),
        mean_dominance=("Dominance_index", "mean")
    )
    .reset_index()
    .sort_values("mean_Phi", ascending=False)
)

genesis_summary = pd.DataFrame([
    regression(features, ["H"], "S", "M1_H_to_S"),
    regression(features, ["H"], "L", "M1_H_to_L"),
    regression(features, ["S"], "L", "M1_S_to_L"),
    regression(features, ["H","S"], "L", "M1_H_plus_S_to_L"),
    regression(features, ["H","S","L"], "Phi_metabolic", "M1_HSL_to_Phi_metabolic"),
    regression(features, ["H","S","L"], "Functional_unity", "M1_HSL_to_Functional_Unity"),
    regression(features, ["H","S","L"], "Metabolic_pathology", "M1_HSL_to_Metabolic_Pathology"),
    regression(features, ["H","S","L","Triadic_balance","Dominance_index"], "Metabolic_pathology", "M1_Full_to_Metabolic_Pathology"),
    regression(features, ["H","S","L"], "H_attack_resilience", "M1_HSL_to_HAttackResilience"),
    regression(features, ["H","S","L"], "S_attack_resilience", "M1_HSL_to_SAttackResilience"),
    regression(features, ["H","S","L"], "L_attack_resilience", "M1_HSL_to_LAttackResilience"),
])

def get_mae(summary, test):
    x = summary[summary["test"] == test]
    return None if len(x)==0 else x.iloc[0]["mae"]

H_L = get_mae(genesis_summary, "M1_H_to_L")
S_L = get_mae(genesis_summary, "M1_S_to_L")
HS_L = get_mae(genesis_summary, "M1_H_plus_S_to_L")
emergence_contrast = pd.DataFrame([{
    "level": "micro_metabolic_network",
    "H_to_L_mae": H_L,
    "S_to_L_mae": S_L,
    "H_plus_S_to_L_mae": HS_L,
    "HS_improves_over_H": H_L-HS_L if H_L is not None and HS_L is not None else None,
    "HS_improves_over_S": S_L-HS_L if S_L is not None and HS_L is not None else None,
    "PETU_prediction_supported": (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

# Perturbative resilience summary by attack type
attack_summary = pd.DataFrame([{
    "random_resilience_mean": float(features["random_resilience"].mean()),
    "H_attack_resilience_mean": float(features["H_attack_resilience"].mean()),
    "S_attack_resilience_mean": float(features["S_attack_resilience"].mean()),
    "L_attack_resilience_mean": float(features["L_attack_resilience"].mean()),
    "H_attack_loss": float(1 - features["H_attack_resilience"].mean()),
    "S_attack_loss": float(1 - features["S_attack_resilience"].mean()),
    "L_attack_loss": float(1 - features["L_attack_resilience"].mean())
}])

contrast_defs = [
    ("robust_vs_fragile", "robust_high_flag", True, False),
    ("pathology_high_vs_low", "pathology_high_flag", True, False),
    ("disproportion_vs_proportion", "triadic_disproportion_flag", True, False),
    ("H_attack_fragile_vs_other", "H_attack_fragile_flag", True, False),
    ("S_attack_fragile_vs_other", "S_attack_fragile_flag", True, False),
    ("L_attack_fragile_vs_other", "L_attack_fragile_flag", True, False),
    ("whole_vs_module", "whole_network_flag", True, False),
]
contrast_metrics = [
    "H","S","L","Phi_metabolic","Phi_HSL_epsilon","Functional_unity",
    "Triadic_balance","Dominance_index","Metabolic_pathology",
    "n_reactions","n_metabolites","avg_degree","density","lcc_fraction",
    "clustering","efficiency","modularity","degree_entropy","degree_gini",
    "random_resilience","H_attack_resilience","S_attack_resilience","L_attack_resilience"
]
contrast_rows = []
for cname, flag, aval, bval in contrast_defs:
    A = features[features[flag] == aval]
    B = features[features[flag] == bval]
    for col in contrast_metrics:
        stat, p = safe_mw(A[col], B[col])
        contrast_rows.append({
            "contrast": cname,
            "metric": col,
            "groupA_mean": float(A[col].mean()) if len(A) else np.nan,
            "groupB_mean": float(B[col].mean()) if len(B) else np.nan,
            "delta_A_minus_B": float(A[col].mean() - B[col].mean()) if len(A) and len(B) else np.nan,
            "pct_delta": float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,
            "mannwhitney_stat": stat,
            "p_value": p
        })
contrast_summary = pd.DataFrame(contrast_rows)

class_rows = []
targets = [
    "robust_high_flag", "pathology_high_flag", "triadic_disproportion_flag",
    "H_attack_fragile_flag", "S_attack_fragile_flag", "L_attack_fragile_flag", "whole_network_flag"
]
feature_sets = [
    (["H"], "H"),
    (["S"], "S"),
    (["L"], "L"),
    (["H","S"], "H+S"),
    (["H","S","L"], "H+S+L"),
    (["H","S","L","Phi_HSL_epsilon"], "H+S+L+Phi"),
    (["H","S","L","Phi_HSL_epsilon","Triadic_balance","Dominance_index"], "H+S+L+PhiBalanceDominance")
]
for target in targets:
    for cols, label in feature_sets:
        r = auc_model(features, cols, target, label)
        if r:
            class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows = []
for target, d in classification_summary.groupby("target"):
    def auc(fs):
        x = d[d["feature_set"] == fs]
        return None if len(x)==0 else float(x.iloc[0]["auc"])
    aH, aHS, aHSL, aFull = auc("H"), auc("H+S"), auc("H+S+L"), auc("H+S+L+PhiBalanceDominance")
    gain_rows.append({
        "target": target,
        "auc_H": aH,
        "auc_HS": aHS,
        "auc_HSL": aHSL,
        "auc_full": aFull,
        "gain_HSL_over_H": None if aH is None or aHSL is None else aHSL-aH,
        "gain_HSL_over_HS": None if aHS is None or aHSL is None else aHSL-aHS,
        "gain_full_over_HSL": None if aFull is None or aHSL is None else aFull-aHSL
    })
classification_gain_summary = pd.DataFrame(gain_rows)

# Phases

def classify_phase(r):
    if r["triadic_disproportion_flag"]:
        return "triadic_disproportion"
    if r["robust_high_flag"] and r["Triadic_balance"] >= features["Triadic_balance"].median():
        return "metabolic_phi_integrated"
    if r["H_attack_fragile_flag"]:
        return "H_support_fragile"
    if r["S_attack_fragile_flag"]:
        return "S_structure_fragile"
    if r["L_attack_fragile_flag"]:
        return "L_linkage_fragile"
    if r["whole_network_flag"]:
        return "whole_network_integrated"
    return "transitional_module"

features["PETU_M1_phase"] = features.apply(classify_phase, axis=1)
phase_summary = (
    features.groupby("PETU_M1_phase")
    .agg(
        n=("organism","count"),
        n_organisms=("organism","nunique"),
        mean_H=("H","mean"),
        mean_S=("S","mean"),
        mean_L=("L","mean"),
        mean_Phi=("Phi_metabolic","mean"),
        mean_Phi_HSL=("Phi_HSL_epsilon","mean"),
        mean_unity=("Functional_unity","mean"),
        mean_balance=("Triadic_balance","mean"),
        mean_dominance=("Dominance_index","mean"),
        mean_pathology=("Metabolic_pathology","mean"),
        mean_H_attack_res=("H_attack_resilience","mean"),
        mean_S_attack_res=("S_attack_resilience","mean"),
        mean_L_attack_res=("L_attack_resilience","mean")
    )
    .reset_index()
    .sort_values("n", ascending=False)
)

# ============================================================
# SAVE
# ============================================================

paths = {
    "features": f"{OUTDIR}/PETU_MICRO_METAB_M1_features.csv",
    "data_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_data_summary.csv",
    "organism_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_organism_summary.csv",
    "genesis_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_genesis_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_MICRO_METAB_M1_emergence_contrast.csv",
    "attack_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_attack_summary.csv",
    "contrast_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_contrast_summary.csv",
    "classification_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_classification_summary.csv",
    "classification_gain_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_classification_gain_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_phase_summary.csv",
    "failures": f"{OUTDIR}/PETU_MICRO_METAB_M1_failures.csv",
    "summary": f"{OUTDIR}/PETU_MICRO_METAB_M1_summary.json"
}

features.to_csv(paths["features"], index=False)
data_summary.to_csv(paths["data_summary"], index=False)
organism_summary.to_csv(paths["organism_summary"], index=False)
genesis_summary.to_csv(paths["genesis_summary"], index=False)
emergence_contrast.to_csv(paths["emergence_contrast"], index=False)
attack_summary.to_csv(paths["attack_summary"], index=False)
contrast_summary.to_csv(paths["contrast_summary"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-MICRO-METAB M1 Metabolic Network Triadic Audit",
    "domain": "micro natural metabolism / KEGG organism reaction-compound networks",
    "n_organisms_loaded": int(len(org_networks)),
    "n_feature_rows": int(len(features)),
    "n_whole_networks": int(features["whole_network_flag"].sum()),
    "n_modules": int((~features["whole_network_flag"]).sum()),
    "epsilon": EPSILON,
    "hypothesis": "Metabolic coherence and robustness arise from triadic proportion/co-inherence of H biochemical support, S network structure, and L reactive linkage.",
    "note": "Natural metabolic networks are the primary evidence; attack simulations are auxiliary perturbative contrasts.",
    "next_step": "MESO-CARDIORESP C1 natural cardiorespiratory coupling; then MESO-EMBRYO E1 developmental morphogenesis."
}
with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

# ============================================================
# PRINT
# ============================================================

print("\n============================================================")
print("PETU-MICRO-METAB M1 DATA SUMMARY")
print("============================================================")
print(data_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 ORGANISM SUMMARY")
print("============================================================")
print(organism_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 GENESIS SUMMARY")
print("============================================================")
print(genesis_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 EMERGENCE CONTRAST")
print("============================================================")
print(emergence_contrast)

print("\n============================================================")
print("PETU-MICRO-METAB M1 ATTACK SUMMARY")
print("============================================================")
print(attack_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 CONTRAST SUMMARY")
print("============================================================")
print(contrast_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 PHASE SUMMARY")
print("============================================================")
print(phase_summary)

print("\n============================================================")
print("PETU-MICRO-METAB M1 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

if len(failures) > 0:
    print("\n============================================================")
    print("FAILURES / SKIPPED")
    print("============================================================")
    print(pd.DataFrame(failures))

# ============================================================
# FIGURES
# ============================================================

plt.figure(figsize=(8,5))
plt.scatter(features["H"] + features["S"], features["L"], s=22, alpha=0.65)
plt.xlabel("H + S")
plt.ylabel("L")
plt.title("PETU-METAB M1: H+S -> L")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_M1_HS_to_L.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Phi_HSL_epsilon"], features["Phi_metabolic"], s=22, alpha=0.65)
plt.xlabel("Phi_HSL_epsilon")
plt.ylabel("Phi_metabolic")
plt.title("PETU-METAB M1: HSL unity vs metabolic coherence")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_M1_PhiHSL_MetabolicPhi.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Dominance_index"], features["Metabolic_pathology"], s=22, alpha=0.65)
plt.xlabel("Dominance index")
plt.ylabel("Metabolic pathology")
plt.title("PETU-METAB M1: dominance and pathology")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_M1_Dominance_Pathology.png", dpi=220)
plt.show()

plt.figure(figsize=(9,5))
plt.bar(phase_summary["PETU_M1_phase"], phase_summary["n"])
plt.xticks(rotation=60)
plt.ylabel("Network/module rows")
plt.title("PETU-METAB M1: phase counts")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_M1_phase_counts.png", dpi=220)
plt.show()

zip_base = "/content/PETU_MICRO_METAB_M1_Metabolic_Network_Triadic_Audit_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path):
    os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k,v in paths.items():
    print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

# ============================================================
# PETU-MESO-NEURO N1 NATURAL NEURODYNAMICS
# Sleep-EDF EEG / H-S-L-Phi triadic-perichoretic audit
# Mobile/Colab runnable
# ============================================================

!pip -q install mne numpy scipy pandas scikit-learn matplotlib networkx

import os, json, shutil, warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
import mne
from mne.datasets.sleep_physionet.age import fetch_data
from scipy.signal import welch
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.model_selection import GroupKFold

OUTDIR = '/content/PETU_MESO_NEURO_N1_Natural_Neurodynamics'
os.makedirs(OUTDIR, exist_ok=True)

# Mobile defaults. Increase N_SUBJECTS later for stronger runs.
N_SUBJECTS = 6
WINDOW_SEC = 10
STEP_SEC = 10
MAX_EPOCHS_PER_STATE_PER_SUBJECT = 80
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

BANDS = {
    'delta': (0.5, 4),
    'theta': (4, 8),
    'alpha': (8, 13),
    'sigma': (12, 16),
    'beta':  (13, 30),
}

STATE_MAP = {
    'Sleep stage W': 'Wake',
    'Sleep stage R': 'REM',
    'Sleep stage 1': 'N1',
    'Sleep stage 2': 'N2',
    'Sleep stage 3': 'N3',
    'Sleep stage 4': 'N3',
}
TARGET_STATES = ['Wake', 'REM', 'N1', 'N2', 'N3']

# ------------------------------
# Utilities
# ------------------------------
def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0: return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12: return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def normalize01_groupwise(df, cols, group_col):
    out = df.copy()
    for col in cols:
        out[col + '_local_norm'] = out.groupby(group_col)[col].transform(lambda z: normalize01(z.values))
    return out

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3: return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def spectral_entropy(psd):
    psd = np.maximum(np.asarray(psd, dtype=float), 1e-12)
    p = psd / np.sum(psd)
    ent = -np.sum(p * np.log(p))
    return float(ent / np.log(len(p)))

def bandpower(freqs, psd, fmin, fmax):
    mask = (freqs >= fmin) & (freqs < fmax)
    if mask.sum() == 0: return 0.0
    return float(np.trapz(psd[mask], freqs[mask]))

def corr_network_features(X):
    n_ch = X.shape[0]
    if n_ch < 2:
        return {'L_corr_mean_abs':0.0,'L_corr_density_03':0.0,'L_corr_efficiency':0.0,'L_corr_clustering':0.0,'L_corr_lcc_fraction':0.0}
    C = np.nan_to_num(np.corrcoef(X), nan=0.0)
    A = np.abs(C); np.fill_diagonal(A, 0)
    vals = A[np.triu_indices(n_ch, 1)]
    adj = (A >= 0.30).astype(int); np.fill_diagonal(adj, 0)
    G = nx.from_numpy_array(adj)
    density = float(np.sum(adj) / (n_ch * (n_ch - 1) + 1e-12))
    try: eff = float(nx.global_efficiency(G))
    except Exception: eff = 0.0
    try: clust = float(nx.average_clustering(G))
    except Exception: clust = 0.0
    if G.number_of_nodes() > 0 and G.number_of_edges() > 0:
        comps = list(nx.connected_components(G))
        lcc = max(len(c) for c in comps) / G.number_of_nodes()
    else:
        lcc = 0.0
    return {'L_corr_mean_abs':float(np.mean(vals)), 'L_corr_density_03':density, 'L_corr_efficiency':eff, 'L_corr_clustering':clust, 'L_corr_lcc_fraction':float(lcc)}

def plv_proxy_band(X, sfreq, band):
    if X.shape[0] < 2: return 0.0
    fmin, fmax = band
    try:
        Xf = mne.filter.filter_data(X, sfreq, fmin, fmax, verbose=False)
        analytic = mne.filter.hilbert(Xf, envelope=False)
        phase = np.angle(analytic)
        vals = []
        for i in range(X.shape[0]):
            for j in range(i+1, X.shape[0]):
                vals.append(np.abs(np.mean(np.exp(1j*(phase[i]-phase[j])))))
        return float(np.mean(vals)) if vals else 0.0
    except Exception:
        return 0.0

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

# ------------------------------
# Feature extraction
# ------------------------------
def extract_features_window(X, sfreq):
    X = np.asarray(X, dtype=float)
    X = np.nan_to_num(X)
    X = X - np.mean(X, axis=1, keepdims=True)
    Xz = X / (np.std(X, axis=1, keepdims=True) + 1e-12)

    freqs, psd = welch(Xz, fs=sfreq, nperseg=min(int(sfreq*4), Xz.shape[1]), axis=1)
    psd_mean = np.mean(psd, axis=0)
    total_power = bandpower(freqs, psd_mean, 0.5, 30) + 1e-12
    bp = {}
    for name, band in BANDS.items():
        bp[name] = bandpower(freqs, psd_mean, band[0], band[1])
        bp[name+'_rel'] = bp[name] / total_power

    # H = neuroenergetic support/background
    H_total_power = np.log1p(total_power)
    H_delta, H_theta, H_alpha, H_beta = bp['delta_rel'], bp['theta_rel'], bp['alpha_rel'], bp['beta_rel']
    H_variance = float(np.mean(np.var(Xz, axis=1)))
    H_raw = np.mean([H_total_power, H_delta, H_theta, H_alpha, H_beta, H_variance])

    # S = spectral form/organization
    ent = spectral_entropy(psd_mean)
    spectral_order = 1 - ent
    alpha_delta = np.log1p(bp['alpha'] / (bp['delta'] + 1e-12))
    theta_delta = np.log1p(bp['theta'] / (bp['delta'] + 1e-12))
    sigma_delta = np.log1p(bp['sigma'] / (bp['delta'] + 1e-12))
    beta_delta = np.log1p(bp['beta'] / (bp['delta'] + 1e-12))
    S_raw = np.mean([spectral_order, alpha_delta, theta_delta, sigma_delta, beta_delta])

    # L = functional cohesion/link
    net = corr_network_features(Xz)
    plv_alpha = plv_proxy_band(Xz, sfreq, BANDS['alpha'])
    plv_theta = plv_proxy_band(Xz, sfreq, BANDS['theta'])
    L_raw = np.mean([net['L_corr_mean_abs'], net['L_corr_density_03'], net['L_corr_efficiency'], net['L_corr_clustering'], net['L_corr_lcc_fraction'], plv_alpha, plv_theta])

    return {
        'H_total_power':H_total_power, 'H_delta_rel':H_delta, 'H_theta_rel':H_theta, 'H_alpha_rel':H_alpha, 'H_beta_rel':H_beta, 'H_variance':H_variance, 'H_raw':H_raw,
        'S_spectral_entropy':ent, 'S_spectral_order':spectral_order, 'S_alpha_delta_ratio_log':alpha_delta, 'S_theta_delta_ratio_log':theta_delta, 'S_sigma_delta_ratio_log':sigma_delta, 'S_beta_delta_ratio_log':beta_delta, 'S_raw':S_raw,
        **net, 'L_plv_alpha':plv_alpha, 'L_plv_theta':plv_theta, 'L_raw':L_raw,
    }

# ------------------------------
# Load Sleep-EDF
# ------------------------------
print('='*60)
print('PETU-MESO-NEURO N1 NATURAL NEURODYNAMICS')
print('='*60)

subjects = list(range(N_SUBJECTS))
records = [1] * N_SUBJECTS
print('Fetching Sleep-EDF data...')
files = fetch_data(subjects=subjects, recording=records, on_missing='warn')

rows, failures = [], []
for si, pair in enumerate(files):
    subject_id = f'S{subjects[si]:02d}'
    try:
        psg_path, hyp_path = pair
        print('\nSubject:', subject_id)
        raw = mne.io.read_raw_edf(psg_path, preload=True, verbose=False)
        ann = mne.read_annotations(hyp_path)
        raw.set_annotations(ann)
        raw.pick(mne.pick_types(raw.info, eeg=True, eog=False, emg=False, misc=False))
        raw.filter(0.5, 30, verbose=False)
        sfreq = float(raw.info['sfreq'])
        events, event_id = mne.events_from_annotations(raw, verbose=False)
        inv_event_id = {v:k for k,v in event_id.items()}
        state_counts = {s:0 for s in TARGET_STATES}
        for ev in events:
            onset, code = int(ev[0]), int(ev[2])
            desc = inv_event_id.get(code, '')
            if desc not in STATE_MAP: continue
            state = STATE_MAP[desc]
            if state_counts[state] >= MAX_EPOCHS_PER_STATE_PER_SUBJECT: continue
            epoch_len = int(30*sfreq); stop = onset + epoch_len
            if stop > raw.n_times: continue
            win_len = int(WINDOW_SEC*sfreq); step_len = int(STEP_SEC*sfreq)
            for ws in range(onset, stop-win_len+1, step_len):
                X = raw.get_data(start=ws, stop=ws+win_len)
                feats = extract_features_window(X, sfreq)
                rows.append({'subject':subject_id, 'state':state, 'epoch_onset_sample':onset, 'window_start_sample':ws, 'time_sec':ws/sfreq, 'sfreq':sfreq, 'n_channels':int(X.shape[0]), **feats})
            state_counts[state] += 1
        print('  State counts:', state_counts)
    except Exception as e:
        print('  FAIL:', subject_id, e)
        failures.append({'subject':subject_id, 'error':str(e)})

df = pd.DataFrame(rows)
if len(df) == 0: raise RuntimeError('No EEG windows extracted')

# ------------------------------
# Normalize H,S,L and compute Phi
# ------------------------------
H_COLS = ['H_total_power','H_delta_rel','H_theta_rel','H_alpha_rel','H_beta_rel','H_variance']
S_COLS = ['S_spectral_order','S_alpha_delta_ratio_log','S_theta_delta_ratio_log','S_sigma_delta_ratio_log','S_beta_delta_ratio_log']
L_COLS = ['L_corr_mean_abs','L_corr_density_03','L_corr_efficiency','L_corr_clustering','L_corr_lcc_fraction','L_plv_alpha','L_plv_theta']
RAW_BASE = H_COLS + S_COLS + L_COLS

for col in RAW_BASE:
    df[col+'_global_norm'] = normalize01(df[col].values)

df['H_global'] = df[[c+'_global_norm' for c in H_COLS]].mean(axis=1)
df['S_global'] = df[[c+'_global_norm' for c in S_COLS]].mean(axis=1)
df['L_global'] = df[[c+'_global_norm' for c in L_COLS]].mean(axis=1)
df['Phi_global_epsilon'] = (df['H_global']+EPSILON)*(df['S_global']+EPSILON)*(df['L_global']+EPSILON)
df['Triadic_balance_global'] = [triadic_balance(h,s,l) for h,s,l in zip(df['H_global'],df['S_global'],df['L_global'])]
df['Functional_unity_global'] = df['Phi_global_epsilon'] * df['Triadic_balance_global']

df = normalize01_groupwise(df, RAW_BASE, 'subject')
df['H_local'] = df[[c+'_local_norm' for c in H_COLS]].mean(axis=1)
df['S_local'] = df[[c+'_local_norm' for c in S_COLS]].mean(axis=1)
df['L_local'] = df[[c+'_local_norm' for c in L_COLS]].mean(axis=1)
df['Phi_local_epsilon'] = (df['H_local']+EPSILON)*(df['S_local']+EPSILON)*(df['L_local']+EPSILON)
df['Triadic_balance_local'] = [triadic_balance(h,s,l) for h,s,l in zip(df['H_local'],df['S_local'],df['L_local'])]
df['Functional_unity_local'] = df['Phi_local_epsilon'] * df['Triadic_balance_local']

df['H'], df['S'], df['L'] = df['H_local'], df['S_local'], df['L_local']
df['Phi_epsilon'] = df['Phi_local_epsilon']
df['Triadic_balance'] = df['Triadic_balance_local']
df['Functional_unity_score'] = df['Functional_unity_local']
df['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(df['H'],df['S'],df['L'])]

# ------------------------------
# Regression tests
# ------------------------------
def regression_dynamic(data, X_cols, y_col, label):
    d = data[X_cols + [y_col, 'subject']].dropna().copy()
    if len(d) < 30:
        return {'test':label,'n':int(len(d)),'r2':None,'mae':None,'spearman_true_pred':None,'p_value':None}
    X = d[X_cols].values.astype(float); y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0).fit(X,y)
    pred = model.predict(X)
    r,p = safe_spearman(y,pred)
    return {'test':label,'n':int(len(d)),'r2':float(r2_score(y,pred)),'mae':float(mean_absolute_error(y,pred)),'spearman_true_pred':r,'p_value':p}

genesis_summary = pd.DataFrame([
    regression_dynamic(df, ['H'], 'S', 'LOCAL_NEURO_H_to_S'),
    regression_dynamic(df, ['H'], 'L', 'LOCAL_NEURO_H_to_L'),
    regression_dynamic(df, ['S'], 'L', 'LOCAL_NEURO_S_to_L'),
    regression_dynamic(df, ['H','S'], 'L', 'LOCAL_NEURO_H_plus_S_to_L'),
    regression_dynamic(df, ['H','S','L'], 'Phi_epsilon', 'LOCAL_NEURO_HSL_to_Phi'),
    regression_dynamic(df, ['H','S','L'], 'Functional_unity_score', 'LOCAL_NEURO_HSL_to_Functional_Unity'),
    regression_dynamic(df, ['H_global'], 'S_global', 'GLOBAL_NEURO_H_to_S'),
    regression_dynamic(df, ['H_global'], 'L_global', 'GLOBAL_NEURO_H_to_L'),
    regression_dynamic(df, ['S_global'], 'L_global', 'GLOBAL_NEURO_S_to_L'),
    regression_dynamic(df, ['H_global','S_global'], 'L_global', 'GLOBAL_NEURO_H_plus_S_to_L'),
    regression_dynamic(df, ['H_global','S_global','L_global'], 'Phi_global_epsilon', 'GLOBAL_NEURO_HSL_to_Phi'),
    regression_dynamic(df, ['H_global','S_global','L_global'], 'Functional_unity_global', 'GLOBAL_NEURO_HSL_to_Functional_Unity'),
])

def get_mae(test):
    x = genesis_summary[genesis_summary['test']==test]
    return None if len(x)==0 else x.iloc[0]['mae']

def contrast_row(prefix):
    H_L = get_mae(f'{prefix}_NEURO_H_to_L')
    S_L = get_mae(f'{prefix}_NEURO_S_to_L')
    HS_L = get_mae(f'{prefix}_NEURO_H_plus_S_to_L')
    return {'level':prefix.lower(), 'H_to_L_mae':H_L, 'S_to_L_mae':S_L, 'H_plus_S_to_L_mae':HS_L, 'HS_improves_over_H':None if H_L is None or HS_L is None else H_L-HS_L, 'HS_improves_over_S':None if S_L is None or HS_L is None else S_L-HS_L, 'PETU_prediction_supported': H_L is not None and S_L is not None and HS_L is not None and HS_L < H_L and HS_L < S_L}

emergence_contrast_summary = pd.DataFrame([contrast_row('LOCAL'), contrast_row('GLOBAL')])

# ------------------------------
# State summaries
# ------------------------------
state_summary = df.groupby('state').agg(n_windows=('state','count'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi=('Phi_epsilon','mean'), mean_unity=('Functional_unity_score','mean'), mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean')).reset_index()
subject_state_summary = df.groupby(['subject','state']).agg(n_windows=('state','count'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi=('Phi_epsilon','mean'), mean_unity=('Functional_unity_score','mean'), mean_balance=('Triadic_balance','mean')).reset_index()

# Delta vs Wake
rows_delta=[]
for subject,dsub in subject_state_summary.groupby('subject'):
    wake=dsub[dsub['state']=='Wake']
    if len(wake)==0: continue
    wake=wake.iloc[0]
    for _,r in dsub.iterrows():
        if r['state']=='Wake': continue
        row={'subject':subject,'state':r['state']}
        for metric in ['mean_H','mean_S','mean_L','mean_Phi','mean_unity','mean_balance']:
            base=wake[metric]; val=r[metric]
            row['delta_'+metric]=float(val-base)
            row['pct_delta_'+metric]=float(100*(val-base)/(abs(base)+1e-12))
        rows_delta.append(row)
state_delta_vs_wake=pd.DataFrame(rows_delta)

# Classification gain of L
classification_rows=[]
pairs=[('Wake','N1'),('Wake','N2'),('Wake','N3'),('Wake','REM'),('REM','N2'),('REM','N3'),('N2','N3')]

def auc_group_cv(data, states, features, label):
    d=data[data['state'].isin(states)].dropna(subset=features+['state','subject']).copy()
    if len(d)<50: return None
    y=(d['state']==states[1]).astype(int).values
    X=d[features].values.astype(float); groups=d['subject'].values
    if len(np.unique(y))<2 or len(np.unique(groups))<2: return None
    n_splits=min(5,len(np.unique(groups)))
    preds=np.zeros(len(y))
    for tr,te in GroupKFold(n_splits=n_splits).split(X,y,groups):
        try:
            clf=LogisticRegression(max_iter=1000,class_weight='balanced').fit(X[tr],y[tr])
            preds[te]=clf.predict_proba(X[te])[:,1]
        except Exception: preds[te]=0.5
    try: auc=float(roc_auc_score(y,preds))
    except Exception: auc=np.nan
    return {'comparison':f'{states[0]}_vs_{states[1]}','feature_set':label,'n':int(len(d)),'auc_group_cv':auc}

for a,b in pairs:
    for features,label in [(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_epsilon','Triadic_balance'],'H+S+L+PhiBalance')]:
        r=auc_group_cv(df,(a,b),features,label)
        if r: classification_rows.append(r)
classification_summary=pd.DataFrame(classification_rows)

gain_rows=[]
if len(classification_summary)>0:
    for comp,dcomp in classification_summary.groupby('comparison'):
        hs=dcomp[dcomp['feature_set']=='H+S']; hsl=dcomp[dcomp['feature_set']=='H+S+L']; full=dcomp[dcomp['feature_set']=='H+S+L+PhiBalance']
        if len(hs) and len(hsl):
            gain_rows.append({'comparison':comp,'auc_HS':float(hs.iloc[0]['auc_group_cv']),'auc_HSL':float(hsl.iloc[0]['auc_group_cv']),'gain_L_over_HS':float(hsl.iloc[0]['auc_group_cv']-hs.iloc[0]['auc_group_cv']),'auc_full':float(full.iloc[0]['auc_group_cv']) if len(full) else None,'gain_full_over_HS':float(full.iloc[0]['auc_group_cv']-hs.iloc[0]['auc_group_cv']) if len(full) else None})
classification_gain_summary=pd.DataFrame(gain_rows)

# Phase classes
def classify_neuro_phase(row):
    h,s,l,phi,bal=row['H'],row['S'],row['L'],row['Phi_epsilon'],row['Triadic_balance']
    if phi>=0.20 and bal>=0.70: return 'Phi_integrated_high'
    if l>=0.45 and phi<0.20: return 'L_cohesion_subPhi'
    if s>=0.45 and l<0.35: return 'S_without_full_L'
    if h>=0.45 and s<0.35: return 'H_available_low_form'
    if bal<0.55: return 'unbalanced_transition'
    return 'transitional'

df['PETU_neuro_phase']=df.apply(classify_neuro_phase,axis=1)
phase_summary=df.groupby(['state','PETU_neuro_phase']).size().reset_index(name='n_windows')
phase_totals=df.groupby('PETU_neuro_phase').size().reset_index(name='n_windows_total').sort_values('n_windows_total',ascending=False)

# Save
paths={
 'features':f'{OUTDIR}/PETU_MESO_NEURO_N1_features.csv',
 'genesis_summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_genesis_summary.csv',
 'emergence_contrast':f'{OUTDIR}/PETU_MESO_NEURO_N1_emergence_contrast_summary.csv',
 'state_summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_state_summary.csv',
 'subject_state_summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_subject_state_summary.csv',
 'state_delta_vs_wake':f'{OUTDIR}/PETU_MESO_NEURO_N1_state_delta_vs_wake.csv',
 'classification_summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_classification_summary.csv',
 'classification_gain_summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_classification_gain_summary.csv',
 'phase_summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_phase_summary.csv',
 'phase_totals':f'{OUTDIR}/PETU_MESO_NEURO_N1_phase_totals.csv',
 'failures':f'{OUTDIR}/PETU_MESO_NEURO_N1_failures.csv',
 'summary':f'{OUTDIR}/PETU_MESO_NEURO_N1_summary.json'}

df.to_csv(paths['features'],index=False)
genesis_summary.to_csv(paths['genesis_summary'],index=False)
emergence_contrast_summary.to_csv(paths['emergence_contrast'],index=False)
state_summary.to_csv(paths['state_summary'],index=False)
subject_state_summary.to_csv(paths['subject_state_summary'],index=False)
state_delta_vs_wake.to_csv(paths['state_delta_vs_wake'],index=False)
classification_summary.to_csv(paths['classification_summary'],index=False)
classification_gain_summary.to_csv(paths['classification_gain_summary'],index=False)
phase_summary.to_csv(paths['phase_summary'],index=False)
phase_totals.to_csv(paths['phase_totals'],index=False)
pd.DataFrame(failures).to_csv(paths['failures'],index=False)
summary={'pipeline':'PETU-MESO-NEURO N1 Natural Neurodynamics','domain':'natural neurodynamics / Sleep-EDF EEG','n_subjects_requested':N_SUBJECTS,'n_subjects_completed':int(df['subject'].nunique()),'n_windows':int(len(df)),'states':sorted(df['state'].unique().tolist()),'window_sec':WINDOW_SEC,'step_sec':STEP_SEC,'epsilon':EPSILON,'hypothesis':'In natural neurodynamics, H support/energy, S spectral form, and L functional cohesion co-inhere as Phi and reorganize across natural sleep states.','next_step':'N2 dynamic transition/derivative analysis; N3 natural pathology contrast such as epilepsy.'}
open(paths['summary'],'w').write(json.dumps(summary,indent=2))

print('\n'+'='*60); print('PETU-MESO-NEURO N1 GENESIS SUMMARY'); print('='*60); print(genesis_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N1 EMERGENCE CONTRAST SUMMARY'); print('='*60); print(emergence_contrast_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N1 STATE SUMMARY'); print('='*60); print(state_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N1 DELTA VS WAKE'); print('='*60); print(state_delta_vs_wake)
print('\n'+'='*60); print('PETU-MESO-NEURO N1 CLASSIFICATION GAIN SUMMARY'); print('='*60); print(classification_gain_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N1 PHASE TOTALS'); print('='*60); print(phase_totals)
print('\n'+'='*60); print('PETU-MESO-NEURO N1 FINAL SUMMARY'); print('='*60); print(json.dumps(summary,indent=2))
if len(failures)>0:
    print('\nFAILURES'); print(pd.DataFrame(failures))

# Figures
order=[s for s in TARGET_STATES if s in state_summary['state'].values]
plt.figure(figsize=(9,5))
for metric in ['mean_H','mean_S','mean_L','mean_Phi']:
    vals=[float(state_summary[state_summary['state']==st][metric].iloc[0]) for st in order]
    plt.plot(order, vals, marker='o', label=metric)
plt.xlabel('Natural sleep state'); plt.ylabel('Mean PETU score'); plt.title('PETU-MESO-NEURO N1: H-S-L-Phi by state'); plt.grid(True); plt.legend(); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_HSLPhi_by_state.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(df['S'],df['L'],s=8,alpha=.35); plt.xlabel('S'); plt.ylabel('L'); plt.title('PETU-MESO-NEURO N1: S-L relation'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_S_L_relation.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(df['Triadic_balance'],df['Phi_epsilon'],s=8,alpha=.35); plt.xlabel('Triadic balance'); plt.ylabel('Phi epsilon'); plt.title('PETU-MESO-NEURO N1: Phi vs balance'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_Phi_balance.png',dpi=220); plt.show()
if len(classification_gain_summary)>0:
    plt.figure(figsize=(10,5)); plt.bar(classification_gain_summary['comparison'],classification_gain_summary['gain_L_over_HS']); plt.xticks(rotation=60); plt.ylabel('AUC gain H+S+L over H+S'); plt.title('PETU-MESO-NEURO N1: predictive gain of L'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_L_gain_AUC.png',dpi=220); plt.show()

zip_base='/content/PETU_MESO_NEURO_N1_Natural_Neurodynamics_results'
zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

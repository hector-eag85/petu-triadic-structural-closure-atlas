# ============================================================
# PETU-MESO-CARDIORESP C1
# Natural Cardio-Respiratory Dynamics Triadic Audit
#
# Dominio: meso fisiológico normal.
# Fuente primaria: señales cardiorrespiratorias reales de PhysioNet/BIDMC
#                 mediante wfdb.
#
# Traducción PETU:
#   H = soporte fisiológico: amplitud/energía/regularidad basal de ECG/PPG/RESP.
#   S = estructura rítmica: periodicidad cardiaca-respiratoria, concentración espectral,
#       orden temporal y baja entropía multiseñal.
#   L = vínculo cardiorrespiratorio: coherencia, correlación cruzada, acoplamiento
#       respiración-pulso/ECG y sincronía de envolventes.
#   Phi = coherencia homeostática cardiorrespiratoria: integración H-S-L,
#       estabilidad de ritmo y baja fragilidad.
#
# Hipótesis:
#   1. H + S -> L
#   2. H + S + L -> Phi
#   3. Perturbaciones auxiliares de señal reducen Phi y elevan fragilidad.
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install wfdb numpy pandas scipy scikit-learn matplotlib tqdm

import os, json, random, warnings, shutil, re
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy import signal, stats
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

try:
    import wfdb
except Exception as e:
    raise RuntimeError('wfdb failed to import. Re-run install cell.') from e

OUTDIR = '/content/PETU_MESO_CARDIORESP_C1_Natural_Dynamics'
os.makedirs(OUTDIR, exist_ok=True)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

DB = 'bidmc'
MAX_RECORDS = 35
WINDOW_SEC = 60
STEP_SEC = 30
MIN_WINDOWS_PER_RECORD = 3
EPSILON = 0.05

# ------------------------------------------------------------
# Utilities
# ------------------------------------------------------------

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        m=np.isfinite(a)&np.isfinite(b)
        if m.sum()<3: return None, None
        r,p=stats.spearmanr(a[m],b[m])
        return float(r), float(p)
    except Exception:
        return None, None

def entropy_norm(vals):
    vals=np.asarray(vals,dtype=float)
    vals=vals[np.isfinite(vals)]
    if len(vals)<3: return 0.0
    hist,_=np.histogram(vals,bins=24,density=False)
    hist=hist[hist>0]
    if hist.sum()<=0 or len(hist)<=1: return 0.0
    p=hist/hist.sum()
    ent=-np.sum(p*np.log(p+1e-12))
    return float(ent/np.log(len(hist)+1e-12))

def triadic_balance(h,s,l):
    return float(max(0, 1 - np.std([h,s,l])))

def dominance_index(h,s,l):
    return float(max(h,s,l)-min(h,s,l))

def zclean(x):
    x=np.asarray(x,dtype=float)
    x=x[np.isfinite(x)] if x.ndim==1 else x
    return x

def robust_scale(x):
    x=np.asarray(x,dtype=float)
    x=x-np.nanmedian(x)
    mad=np.nanmedian(np.abs(x))+1e-12
    return x/(1.4826*mad)

def bandpower(x, fs, fmin, fmax):
    x=np.asarray(x,dtype=float)
    if len(x)<fs*4: return 0.0
    f, pxx = signal.welch(x, fs=fs, nperseg=min(len(x), int(fs*8)))
    total=np.trapz(pxx, f)+1e-12
    mask=(f>=fmin)&(f<=fmax)
    return float(np.trapz(pxx[mask], f[mask]) / total) if mask.any() else 0.0

def dominant_freq_score(x, fs, fmin, fmax):
    x=np.asarray(x,dtype=float)
    if len(x)<fs*4: return 0.0, 0.0
    f, pxx = signal.welch(x, fs=fs, nperseg=min(len(x), int(fs*8)))
    mask=(f>=fmin)&(f<=fmax)
    if not mask.any() or pxx[mask].sum()<=0: return 0.0, 0.0
    local_f=f[mask]; local_p=pxx[mask]
    peak=float(local_f[np.argmax(local_p)])
    concentration=float(np.max(local_p)/(np.sum(local_p)+1e-12))
    return peak, concentration

def max_abs_xcorr(a,b,max_lag):
    a=robust_scale(a); b=robust_scale(b)
    n=min(len(a),len(b)); a=a[:n]; b=b[:n]
    if n<20 or np.std(a)<1e-12 or np.std(b)<1e-12: return 0.0
    vals=[]
    for lag in range(-max_lag,max_lag+1):
        if lag<0:
            aa=a[-lag:]; bb=b[:len(aa)]
        elif lag>0:
            aa=a[:-lag]; bb=b[lag:]
        else:
            aa=a; bb=b
        if len(aa)>10 and np.std(aa)>1e-12 and np.std(bb)>1e-12:
            vals.append(abs(np.corrcoef(aa,bb)[0,1]))
    return float(np.nanmax(vals)) if vals else 0.0

def coherence_band(a,b,fs,fmin,fmax):
    a=robust_scale(a); b=robust_scale(b)
    n=min(len(a),len(b)); a=a[:n]; b=b[:n]
    if n<fs*8: return 0.0
    try:
        f,cxy=signal.coherence(a,b,fs=fs,nperseg=min(n,int(fs*8)))
        m=(f>=fmin)&(f<=fmax)
        return float(np.nanmean(cxy[m])) if m.any() else 0.0
    except Exception:
        return 0.0

def envelope(x, fs):
    x=robust_scale(x)
    try:
        analytic=signal.hilbert(x)
        env=np.abs(analytic)
        b,a=signal.butter(2, 0.4/(fs/2), btype='low')
        return signal.filtfilt(b,a,env)
    except Exception:
        return np.abs(x)

def choose_channels(record):
    names=[str(s).lower() for s in record.sig_name]
    def find(patterns):
        for p in patterns:
            for i,n in enumerate(names):
                if p in n: return i
        return None
    resp=find(['resp','respiration','breath'])
    ecg=find(['ecg','ii','v','mcl'])
    pleth=find(['pleth','ppg','pulse'])
    return ecg, resp, pleth

def get_col(arr, idx):
    if idx is None: return None
    x=np.asarray(arr[:,idx],dtype=float)
    if np.isfinite(x).sum()<100: return None
    x=np.nan_to_num(x, nan=np.nanmedian(x[np.isfinite(x)]))
    return x

# ------------------------------------------------------------
# Feature extraction
# ------------------------------------------------------------

def make_variant(ecg, resp, pleth, variant):
    rng=np.random.default_rng(RANDOM_SEED)
    ecg=np.array(ecg,copy=True) if ecg is not None else None
    resp=np.array(resp,copy=True) if resp is not None else None
    pleth=np.array(pleth,copy=True) if pleth is not None else None
    if variant=='natural': return ecg,resp,pleth
    if variant=='resp_phase_shift' and resp is not None:
        resp=np.roll(resp, len(resp)//3)
    elif variant=='cardiac_shuffle':
        if ecg is not None: rng.shuffle(ecg)
        if pleth is not None: rng.shuffle(pleth)
    elif variant=='coupling_break':
        if resp is not None: rng.shuffle(resp)
    elif variant=='noise_stress':
        for xname in ['ecg','resp','pleth']:
            x=locals()[xname]
            if x is not None:
                x = x + rng.normal(0, np.nanstd(x)*0.45+1e-12, len(x))
                if xname=='ecg': ecg=x
                elif xname=='resp': resp=x
                else: pleth=x
    return ecg,resp,pleth

def features_for_window(ecg, resp, pleth, fs, record_id, start, end, variant):
    sigs=[x for x in [ecg,resp,pleth] if x is not None]
    if len(sigs)<2: return None
    # Robust scaling for features.
    ecgz=robust_scale(ecg) if ecg is not None else None
    respz=robust_scale(resp) if resp is not None else None
    plethz=robust_scale(pleth) if pleth is not None else None
    cardiac = ecgz if ecgz is not None else plethz
    if cardiac is None or respz is None: return None

    # H: support / signal energy / physiological presence.
    h_vals=[]
    for x in [ecgz,respz,plethz]:
        if x is not None:
            h_vals.append(min(1.0, np.nanstd(x)/2.5))
            h_vals.append(1.0 - min(1.0, entropy_norm(np.diff(x))/1.0))
    # respiration/cardiac band supports.
    resp_band=bandpower(respz,fs,0.08,0.6)
    card_band=bandpower(cardiac,fs,0.6,3.5)
    h_vals += [resp_band, card_band]
    H_raw=float(np.mean(h_vals))

    # S: rhythm structure / spectral order.
    resp_freq, resp_conc = dominant_freq_score(respz,fs,0.08,0.6)
    card_freq, card_conc = dominant_freq_score(cardiac,fs,0.6,3.5)
    resp_rate_ok = 1.0 - min(1.0, abs(resp_freq-0.25)/0.35) if resp_freq>0 else 0.0
    card_rate_ok = 1.0 - min(1.0, abs(card_freq-1.2)/2.0) if card_freq>0 else 0.0
    ac_resp=max_abs_xcorr(respz,respz,int(fs*4))
    ac_card=max_abs_xcorr(cardiac,cardiac,int(fs*1))
    S_raw=float(np.mean([resp_conc, card_conc, resp_rate_ok, card_rate_ok, ac_resp, ac_card]))

    # L: cardiorespiratory coupling.
    lag=int(fs*6)
    cr_xcorr=max_abs_xcorr(cardiac,respz,lag)
    cr_coh_resp=coherence_band(cardiac,respz,fs,0.08,0.6)
    env_card=envelope(cardiac,fs)
    env_resp=envelope(respz,fs)
    env_corr=max_abs_xcorr(env_card,env_resp,lag)
    if plethz is not None and ecgz is not None:
        cp_xcorr=max_abs_xcorr(ecgz,plethz,int(fs*1.5))
        cp_coh=coherence_band(ecgz,plethz,fs,0.6,3.5)
    else:
        cp_xcorr=cr_xcorr; cp_coh=cr_coh_resp
    L_raw=float(np.mean([cr_xcorr, cr_coh_resp, env_corr, cp_xcorr, cp_coh]))

    # Independent homeostatic coherence proxy.
    rate_balance=1.0-min(1.0, abs((card_freq/(resp_freq+1e-12))-4.5)/8.0) if resp_freq>0 and card_freq>0 else 0.0
    spectral_integrity=float(np.mean([resp_conc, card_conc, resp_band, card_band]))
    signal_integrity=1.0-min(1.0, np.mean([entropy_norm(np.diff(x)) for x in [cardiac,respz]])/1.2)
    Phi_cardioresp_raw=float(np.mean([rate_balance, spectral_integrity, signal_integrity, cr_xcorr, cr_coh_resp, env_corr]))

    Fragility_raw=float(np.mean([
        1.0-rate_balance,
        1.0-spectral_integrity,
        1.0-signal_integrity,
        1.0-cr_xcorr,
        1.0-env_corr
    ]))

    return dict(record_id=record_id, variant=variant, fs=float(fs), start_sample=int(start), end_sample=int(end),
                duration_sec=float((end-start)/fs), H_raw=H_raw, S_raw=S_raw, L_raw=L_raw,
                Phi_cardioresp_raw=Phi_cardioresp_raw, Fragility_raw=Fragility_raw,
                resp_freq=float(resp_freq), card_freq=float(card_freq), resp_conc=float(resp_conc), card_conc=float(card_conc),
                resp_band=float(resp_band), card_band=float(card_band), cr_xcorr=float(cr_xcorr), cr_coherence=float(cr_coh_resp),
                env_corr=float(env_corr), rate_balance=float(rate_balance), signal_integrity=float(signal_integrity))

# ------------------------------------------------------------
# Models
# ------------------------------------------------------------

def regression(data, X_cols, y_col, label):
    d=data[X_cols+[y_col]].replace([np.inf,-np.inf],np.nan).dropna()
    if len(d)<20:
        return dict(test=label,n=int(len(d)),r2=None,mae=None,spearman_true_pred=None,p_value=None)
    X=d[X_cols].values.astype(float); y=d[y_col].values.astype(float)
    model=Ridge(alpha=1.0); model.fit(X,y); pred=model.predict(X)
    r,p=safe_spearman(y,pred)
    return dict(test=label,n=int(len(d)),r2=float(r2_score(y,pred)),mae=float(mean_absolute_error(y,pred)),spearman_true_pred=r,p_value=p)

def auc_model(data, cols, target, label):
    d=data[cols+[target]].replace([np.inf,-np.inf],np.nan).dropna()
    if len(d)<30 or len(d[target].unique())<2: return None
    X=d[cols].values.astype(float); y=d[target].astype(int).values
    try:
        clf=LogisticRegression(max_iter=1000,class_weight='balanced')
        clf.fit(X,y); pr=clf.predict_proba(X)[:,1]
        auc=float(roc_auc_score(y,pr))
    except Exception:
        auc=np.nan
    return dict(feature_set=label,target=target,n=int(len(d)),auc=auc)

# ------------------------------------------------------------
# Load PhysioNet/BIDMC records
# ------------------------------------------------------------

print('='*60)
print('PETU-MESO-CARDIORESP C1 NATURAL CARDIO-RESPIRATORY TRIADIC AUDIT')
print('='*60)
print('Fetching PhysioNet/BIDMC records with wfdb...')

failures=[]; rows=[]; record_summary=[]
try:
    recs=wfdb.get_record_list(DB)
except Exception as e:
    raise RuntimeError('Could not fetch PhysioNet BIDMC record list. Check internet/wfdb.') from e

recs=recs[:MAX_RECORDS]
for rec in tqdm(recs, desc='BIDMC records'):
    try:
        record=wfdb.rdrecord(rec, pn_dir=DB)
        fs=float(record.fs)
        ecg_i, resp_i, pleth_i = choose_channels(record)
        ecg=get_col(record.p_signal, ecg_i)
        resp=get_col(record.p_signal, resp_i)
        pleth=get_col(record.p_signal, pleth_i)
        if resp is None or (ecg is None and pleth is None):
            raise RuntimeError(f'Missing cardio/resp channels names={record.sig_name}')
        n=len(record.p_signal)
        win=int(WINDOW_SEC*fs); step=int(STEP_SEC*fs)
        starts=list(range(0, max(1,n-win+1), step))
        count=0
        for st in starts:
            en=st+win
            if en>n: continue
            e=ecg[st:en] if ecg is not None else None
            r=resp[st:en] if resp is not None else None
            p=pleth[st:en] if pleth is not None else None
            for variant in ['natural','resp_phase_shift','cardiac_shuffle','coupling_break','noise_stress']:
                ev,rv,pv=make_variant(e,r,p,variant)
                feat=features_for_window(ev,rv,pv,fs,rec,st,en,variant)
                if feat: rows.append(feat)
            count+=1
        if count<MIN_WINDOWS_PER_RECORD:
            failures.append(dict(record_id=rec, stage='windows', error='too few windows'))
        record_summary.append(dict(record_id=rec, fs=fs, n_samples=n, sig_names='|'.join(map(str,record.sig_name)),
                                   has_ecg=ecg is not None, has_resp=resp is not None, has_pleth=pleth is not None,
                                   natural_windows=count))
    except Exception as e:
        failures.append(dict(record_id=rec, stage='load_or_features', error=str(e)))
        print(' FAIL',rec,e)

features=pd.DataFrame(rows)
record_summary=pd.DataFrame(record_summary)
if len(features)<100:
    raise RuntimeError('Too few cardiorespiratory feature rows. Check BIDMC download/channels.')

for col in ['H_raw','S_raw','L_raw','Phi_cardioresp_raw','Fragility_raw']:
    features[col.replace('_raw','')]=normalize01(features[col].values)

features['Phi_HSL_epsilon']=(features['H']+EPSILON)*(features['S']+EPSILON)*(features['L']+EPSILON)
features['Triadic_balance']=[triadic_balance(h,s,l) for h,s,l in zip(features.H,features.S,features.L)]
features['Functional_unity']=features['Phi_HSL_epsilon']*features['Triadic_balance']
features['Dominance_index']=[dominance_index(h,s,l) for h,s,l in zip(features.H,features.S,features.L)]
features['is_natural']=features.variant.eq('natural')
features['is_perturbed']=~features.is_natural
features['coherence_high_flag']=features.Phi_cardioresp>=features.Phi_cardioresp.median()
features['fragility_high_flag']=features.Fragility>=features.Fragility.median()
features['triadic_disproportion_flag']=(features.Triadic_balance<=features.Triadic_balance.quantile(.25))|(features.Dominance_index>=features.Dominance_index.quantile(.75))
features['coupling_break_flag']=features.variant.isin(['resp_phase_shift','coupling_break','cardiac_shuffle'])

natural=features[features.is_natural].copy()

# Summaries

data_summary=pd.DataFrame([dict(n_records_loaded=int(record_summary.record_id.nunique()), n_total_rows=int(len(features)),
                                n_natural_windows=int(len(natural)), n_perturbed_windows=int(features.is_perturbed.sum()),
                                database='PhysioNet BIDMC', variants=','.join(sorted(features.variant.unique())),
                                window_sec=WINDOW_SEC, step_sec=STEP_SEC, epsilon=EPSILON)])

genesis_summary=pd.DataFrame([
    regression(natural,['H'],'S','C1_NAT_H_to_S'),
    regression(natural,['H'],'L','C1_NAT_H_to_L'),
    regression(natural,['S'],'L','C1_NAT_S_to_L'),
    regression(natural,['H','S'],'L','C1_NAT_H_plus_S_to_L'),
    regression(natural,['H','S','L'],'Phi_cardioresp','C1_NAT_HSL_to_Phi_cardioresp'),
    regression(natural,['H','S','L'],'Functional_unity','C1_NAT_HSL_to_Functional_Unity'),
    regression(natural,['H','S','L'],'Fragility','C1_NAT_HSL_to_Cardioresp_Fragility'),
    regression(natural,['H','S','L','Triadic_balance','Dominance_index'],'Fragility','C1_NAT_Full_to_Cardioresp_Fragility')
])

all_summary=pd.DataFrame([
    regression(features,['H'],'S','C1_ALL_H_to_S'),
    regression(features,['H'],'L','C1_ALL_H_to_L'),
    regression(features,['S'],'L','C1_ALL_S_to_L'),
    regression(features,['H','S'],'L','C1_ALL_H_plus_S_to_L'),
    regression(features,['H','S','L'],'Phi_cardioresp','C1_ALL_HSL_to_Phi_cardioresp'),
    regression(features,['H','S','L'],'Functional_unity','C1_ALL_HSL_to_Functional_Unity'),
    regression(features,['H','S','L'],'Fragility','C1_ALL_HSL_to_Cardioresp_Fragility'),
    regression(features,['H','S','L','Triadic_balance','Dominance_index'],'Fragility','C1_ALL_Full_to_Cardioresp_Fragility')
])

def get_mae(df,test):
    x=df[df.test==test]
    return None if len(x)==0 else x.iloc[0].mae
H_L=get_mae(genesis_summary,'C1_NAT_H_to_L'); S_L=get_mae(genesis_summary,'C1_NAT_S_to_L'); HS_L=get_mae(genesis_summary,'C1_NAT_H_plus_S_to_L')
emergence_contrast=pd.DataFrame([dict(level='meso_cardiorespiratory_natural', H_to_L_mae=H_L, S_to_L_mae=S_L, H_plus_S_to_L_mae=HS_L,
                                      HS_improves_over_H=H_L-HS_L if H_L is not None and HS_L is not None else None,
                                      HS_improves_over_S=S_L-HS_L if S_L is not None and HS_L is not None else None,
                                      PETU_prediction_supported=(HS_L<H_L and HS_L<S_L) if None not in [H_L,S_L,HS_L] else None)])

variant_summary=features.groupby('variant').agg(n=('record_id','count'), n_records=('record_id','nunique'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi=('Phi_cardioresp','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'), mean_unity=('Functional_unity','mean'), mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_fragility=('Fragility','mean'), mean_resp_freq=('resp_freq','mean'), mean_card_freq=('card_freq','mean'), mean_cr_xcorr=('cr_xcorr','mean'), mean_cr_coherence=('cr_coherence','mean')).reset_index().sort_values('mean_Phi',ascending=False)

# Contrasts
contrast_defs=[('natural_vs_perturbed','is_natural',True,False),('coherent_vs_low','coherence_high_flag',True,False),('fragility_high_vs_low','fragility_high_flag',True,False),('disproportion_vs_proportion','triadic_disproportion_flag',True,False),('coupling_break_vs_other','coupling_break_flag',True,False)]
metrics=['H','S','L','Phi_cardioresp','Phi_HSL_epsilon','Functional_unity','Triadic_balance','Dominance_index','Fragility','resp_freq','card_freq','resp_conc','card_conc','cr_xcorr','cr_coherence','env_corr','rate_balance','signal_integrity']
cr=[]
for cname,flag,av,bv in contrast_defs:
    A=features[features[flag]==av]; B=features[features[flag]==bv]
    for col in metrics:
        try:
            stat,p=stats.mannwhitneyu(A[col].dropna(),B[col].dropna(),alternative='two-sided')
            stat=float(stat); p=float(p)
        except Exception:
            stat=None; p=None
        cr.append(dict(contrast=cname, metric=col, groupA_mean=float(A[col].mean()), groupB_mean=float(B[col].mean()), delta_A_minus_B=float(A[col].mean()-B[col].mean()), pct_delta=float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)), mannwhitney_stat=stat, p_value=p))
contrast_summary=pd.DataFrame(cr)

# Classification
class_rows=[]
targets=['is_natural','coherence_high_flag','fragility_high_flag','triadic_disproportion_flag','coupling_break_flag']
feature_sets=[(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
for target in targets:
    for cols,label in feature_sets:
        r=auc_model(features,cols,target,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)

gain=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x=d[d.feature_set==fs]
        return None if len(x)==0 else float(x.iloc[0].auc)
    aH,aHS,aHSL,aFull=auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gain.append(dict(target=target, auc_H=aH, auc_HS=aHS, auc_HSL=aHSL, auc_full=aFull, gain_HSL_over_H=None if None in [aH,aHSL] else aHSL-aH, gain_HSL_over_HS=None if None in [aHS,aHSL] else aHSL-aHS, gain_full_over_HSL=None if None in [aFull,aHSL] else aFull-aHSL))
classification_gain_summary=pd.DataFrame(gain)

def phase(row):
    if row.variant=='natural' and row.Phi_cardioresp>=features.Phi_cardioresp.quantile(.65) and row.Triadic_balance>=features.Triadic_balance.median():
        return 'natural_cardioresp_phi_integrated'
    if row.variant=='natural' and row.Fragility>=features.Fragility.median(): return 'natural_fragile_transition'
    if row.variant=='resp_phase_shift': return 'resp_phase_shift_L_pathology'
    if row.variant=='coupling_break': return 'coupling_break_L_pathology'
    if row.variant=='cardiac_shuffle': return 'cardiac_shuffle_HS_disruption'
    if row.variant=='noise_stress': return 'noise_support_stress'
    if row.triadic_disproportion_flag: return 'triadic_disproportion'
    if row.variant=='natural': return 'natural_transitional'
    return 'perturbed_transitional'
features['PETU_C1_phase']=features.apply(phase,axis=1)
phase_summary=features.groupby('PETU_C1_phase').agg(n=('record_id','count'), n_records=('record_id','nunique'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi=('Phi_cardioresp','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'), mean_unity=('Functional_unity','mean'), mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_fragility=('Fragility','mean'), mean_cr_xcorr=('cr_xcorr','mean'), mean_cr_coherence=('cr_coherence','mean')).reset_index().sort_values('n',ascending=False)

# Save
paths={
'features':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_features.csv',
'record_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_record_summary.csv',
'data_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_data_summary.csv',
'genesis_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_genesis_summary.csv',
'all_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_all_perturbative_summary.csv',
'emergence_contrast':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_emergence_contrast.csv',
'variant_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_variant_summary.csv',
'contrast_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_contrast_summary.csv',
'classification_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_classification_summary.csv',
'classification_gain_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_classification_gain_summary.csv',
'phase_summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_phase_summary.csv',
'failures':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_failures.csv',
'summary':f'{OUTDIR}/PETU_MESO_CARDIORESP_C1_summary.json'}
for name,obj in [('features',features),('record_summary',record_summary),('data_summary',data_summary),('genesis_summary',genesis_summary),('all_summary',all_summary),('emergence_contrast',emergence_contrast),('variant_summary',variant_summary),('contrast_summary',contrast_summary),('classification_summary',classification_summary),('classification_gain_summary',classification_gain_summary),('phase_summary',phase_summary)]: obj.to_csv(paths[name],index=False)
pd.DataFrame(failures).to_csv(paths['failures'],index=False)
summary=dict(pipeline='PETU-MESO-CARDIORESP C1 Natural Cardio-Respiratory Dynamics', domain='meso physiology / natural cardiorespiratory dynamics / PhysioNet BIDMC', n_records_loaded=int(record_summary.record_id.nunique()), n_total_rows=int(len(features)), n_natural_windows=int(len(natural)), n_perturbed_windows=int(features.is_perturbed.sum()), epsilon=EPSILON, hypothesis='Cardiorespiratory coherence arises from triadic proportion/co-inherence of H physiological support, S rhythmic structure, and L cardio-respiratory coupling.', epistemic_note='Natural windows are primary; signal perturbations are auxiliary contrasts.', next_step='MESO embryogenesis after evaluating C1.')
with open(paths['summary'],'w') as f: json.dump(summary,f,indent=2)

# Print
for title,df in [('PETU-MESO-CARDIORESP C1 DATA SUMMARY',data_summary),('PETU-MESO-CARDIORESP C1 RECORD SUMMARY',record_summary),('PETU-MESO-CARDIORESP C1 NATURAL GENESIS SUMMARY',genesis_summary),('PETU-MESO-CARDIORESP C1 EMERGENCE CONTRAST',emergence_contrast),('PETU-MESO-CARDIORESP C1 ALL / PERTURBATIVE SUMMARY',all_summary),('PETU-MESO-CARDIORESP C1 VARIANT SUMMARY',variant_summary),('PETU-MESO-CARDIORESP C1 CONTRAST SUMMARY',contrast_summary),('PETU-MESO-CARDIORESP C1 CLASSIFICATION GAIN SUMMARY',classification_gain_summary),('PETU-MESO-CARDIORESP C1 PHASE SUMMARY',phase_summary)]:
    print('\n'+'='*60); print(title); print('='*60); print(df)
print('\n'+'='*60); print('PETU-MESO-CARDIORESP C1 FINAL SUMMARY'); print('='*60); print(json.dumps(summary,indent=2))
if len(failures)>0:
    print('\n'+'='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

# Figures
plt.figure(figsize=(8,5)); plt.scatter(natural['H']+natural['S'],natural['L'],s=16,alpha=.55); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-CARDIORESP C1 natural: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_NAT_HS_to_L.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Phi_HSL_epsilon'],features['Phi_cardioresp'],s=14,alpha=.45); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_cardioresp'); plt.title('PETU-CARDIORESP C1: HSL unity vs cardiorespiratory Phi'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_PhiHSL_CardiorespPhi.png',dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(variant_summary['variant'],variant_summary['mean_Phi']); plt.xticks(rotation=45); plt.ylabel('Mean Phi'); plt.title('PETU-CARDIORESP C1: natural vs perturbative variants'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_variant_phi.png',dpi=220); plt.show()

zip_base='/content/PETU_MESO_CARDIORESP_C1_Natural_Dynamics_results'
zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

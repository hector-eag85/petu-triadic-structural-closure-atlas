# ============================================================
# PETU-MESO-EMBRYO E1
# Natural Embryogenesis / Developmental Dynamics Triadic Audit
#
# Objetivo:
#   Dominio meso-natural normal de PETU/LETU:
#   desarrollo embrionario / diferenciación celular temprana.
#
# Base primaria:
#   Dataset real de desarrollo embrionario mediante scanpy.datasets.moignard15()
#   cuando está disponible. Es un dataset de células individuales asociado
#   a especificación temprana hematopoyética/endotelial en embrión de ratón.
#
# Fallback real auxiliar:
#   scanpy.datasets.paul15(), desarrollo hematopoyético, si Moignard falla.
#   Se marca en outputs como fallback, no como base ideal.
#
# Traducción PETU:
#   H = soporte biológico-transcripcional:
#       cantidad de expresión, genes detectados, diversidad/entropía transcriptómica,
#       soporte molecular de la célula.
#
#   S = estructura formal del programa de desarrollo:
#       orden transcriptómico, estructura de PCA/manifold, concentración modular,
#       posición/organización de destino celular.
#
#   L = vínculo morfogenético/dinámico:
#       continuidad de vecindad, coherencia de pseudotiempo, acoplamiento local
#       entre células, conectividad del grafo de desarrollo.
#
#   Φ = coherencia embrionaria/desarrollativa:
#       integración soporte-estructura-vínculo, continuidad de trayectoria,
#       baja fragilidad y coherencia de estado.
#
# Perturbaciones auxiliares:
#   expression_noise, gene_shuffle, graph_rewire, pseudotime_shuffle
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install scanpy anndata numpy pandas scipy scikit-learn matplotlib tqdm networkx

import os, json, random, warnings, shutil, math
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx

from scipy import sparse
from scipy.stats import spearmanr, mannwhitneyu, entropy
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.preprocessing import StandardScaler
from tqdm.auto import tqdm

import scanpy as sc

# ============================================================
# CONFIG
# ============================================================

OUTDIR = '/content/PETU_MESO_EMBRYO_E1_Developmental_Dynamics'
os.makedirs(OUTDIR, exist_ok=True)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

EPSILON = 0.05
N_HVG = 800
MAX_CELLS = 2500
N_PCS = 20
K_NEIGHBORS = 15

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a,b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r,p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a,b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]; b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat,p = mannwhitneyu(a,b, alternative='two-sided')
        return float(stat), float(p)
    except Exception:
        return None, None

def row_entropy_norm(Xrow):
    x = np.asarray(Xrow, dtype=float)
    x = x[x > 0]
    if len(x) <= 1 or x.sum() <= 0:
        return 0.0
    p = x / x.sum()
    return float(entropy(p) / np.log(len(p)+1e-12))

def triadic_balance(h,s,l):
    return float(max(0.0, 1.0 - np.std([h,s,l])))

def dominance_index(h,s,l):
    return float(max(h,s,l) - min(h,s,l))

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {'test': label, 'n': int(len(d)), 'r2': None, 'mae': None, 'spearman_true_pred': None, 'p_value': None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X,y)
    pred = model.predict(X)
    r,p = safe_spearman(y,pred)
    return {'test': label, 'n': int(len(d)), 'r2': float(r2_score(y,pred)), 'mae': float(mean_absolute_error(y,pred)), 'spearman_true_pred': r, 'p_value': p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=2000, class_weight='balanced')
        clf.fit(X,y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y,pred)
    except Exception:
        auc = np.nan
    return {'feature_set': label, 'target': target, 'n': int(len(d)), 'auc': float(auc)}

def dense_array(X):
    if sparse.issparse(X):
        return X.toarray()
    return np.asarray(X)

# ============================================================
# LOAD REAL DEVELOPMENTAL DATA
# ============================================================

print('='*60)
print('PETU-MESO-EMBRYO E1 DEVELOPMENTAL TRIADIC AUDIT')
print('='*60)
print('Loading real embryonic/developmental single-cell data...')

failures = []
dataset_name = None
adata = None

try:
    adata = sc.datasets.moignard15()
    dataset_name = 'scanpy_moignard15_mouse_embryonic_development'
    print('OK primary dataset: moignard15', adata.shape)
except Exception as e:
    failures.append({'stage':'load_moignard15','error':str(e)})
    print('FAIL moignard15:', e)
    try:
        adata = sc.datasets.paul15()
        dataset_name = 'scanpy_paul15_developmental_hematopoiesis_fallback'
        print('OK fallback dataset: paul15', adata.shape)
    except Exception as e2:
        failures.append({'stage':'load_paul15','error':str(e2)})
        raise RuntimeError('Could not load real developmental datasets via scanpy.')

# downsample if needed
if adata.n_obs > MAX_CELLS:
    rng = np.random.default_rng(RANDOM_SEED)
    idx = rng.choice(adata.n_obs, size=MAX_CELLS, replace=False)
    adata = adata[idx].copy()

# Basic cleanup and preprocessing
adata.var_names_make_unique()

# preserve raw counts/proxy before transformations
X0 = dense_array(adata.X)
X0 = np.nan_to_num(X0, nan=0.0, posinf=0.0, neginf=0.0)
X0[X0 < 0] = 0

# If data are not log-normalized, normalize/log for manifold.
adata_pp = adata.copy()
try:
    sc.pp.normalize_total(adata_pp, target_sum=1e4)
    sc.pp.log1p(adata_pp)
except Exception:
    pass

try:
    sc.pp.highly_variable_genes(adata_pp, n_top_genes=min(N_HVG, adata_pp.n_vars), flavor='seurat')
    if 'highly_variable' in adata_pp.var.columns and adata_pp.var['highly_variable'].sum() > 50:
        adata_pp = adata_pp[:, adata_pp.var['highly_variable']].copy()
except Exception as e:
    failures.append({'stage':'hvg','error':str(e)})
    if adata_pp.n_vars > N_HVG:
        adata_pp = adata_pp[:, :N_HVG].copy()

X = dense_array(adata_pp.X)
X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
X[X < 0] = 0

# PCA/manifold
n_pcs = min(N_PCS, X.shape[1], X.shape[0]-1)
scaler = StandardScaler(with_mean=True, with_std=True)
X_scaled = scaler.fit_transform(X)
pca = PCA(n_components=n_pcs, random_state=RANDOM_SEED)
PC = pca.fit_transform(X_scaled)
explained = pca.explained_variance_ratio_

# Pseudotime proxy: PC1 normalized, oriented by an available stage-like column if possible.
pc1 = normalize01(PC[:,0])
pseudotime = pc1.copy()

# Find stage/state labels if available.
obs = adata.obs.copy()
label_col = None
candidate_terms = ['stage','time','day','dpt','cell_type','celltype','cluster','paul15_clusters','exp_groups','groups','louvain']
for col in obs.columns:
    low = str(col).lower()
    if any(t in low for t in candidate_terms):
        if obs[col].nunique() > 1 and obs[col].nunique() <= max(100, adata.n_obs//2):
            label_col = col
            break
if label_col is None:
    # first categorical-ish column
    for col in obs.columns:
        if obs[col].nunique() > 1 and obs[col].nunique() <= 100:
            label_col = col
            break

labels = obs[label_col].astype(str).values if label_col else np.array(['unknown']*adata.n_obs)

# kNN graph
k = min(K_NEIGHBORS, adata.n_obs-1)
nn = NearestNeighbors(n_neighbors=k+1, metric='euclidean')
nn.fit(PC)
dist, ind = nn.kneighbors(PC)
neighbors = ind[:,1:]
neigh_dist = dist[:,1:]

# Build graph for local clustering.
G = nx.Graph()
for i in range(adata.n_obs):
    G.add_node(i)
for i in range(adata.n_obs):
    for j in neighbors[i]:
        if i != j:
            G.add_edge(i, int(j))
clust = nx.clustering(G)
clust_arr = np.array([clust[i] for i in range(adata.n_obs)], dtype=float)

# Utility label coherence
label_codes = pd.Categorical(labels).codes

# ============================================================
# FEATURE EXTRACTION
# ============================================================

def compute_features_for_matrix(Xmat, PCmat, pseudotime_vec, variant):
    n_cells = Xmat.shape[0]
    rows = []

    # Recompute nearest neighbors if graph perturbation changes PC or pseudo.
    nn2 = NearestNeighbors(n_neighbors=k+1, metric='euclidean')
    nn2.fit(PCmat)
    d2, ind2 = nn2.kneighbors(PCmat)
    neigh2 = ind2[:,1:]
    dist2 = d2[:,1:]

    G2 = nx.Graph()
    for i in range(n_cells):
        G2.add_node(i)
    for i in range(n_cells):
        for j in neigh2[i]:
            if i != j:
                G2.add_edge(i, int(j))
    cl2 = nx.clustering(G2)
    cl_arr = np.array([cl2[i] for i in range(n_cells)], dtype=float)

    total_expr = Xmat.sum(axis=1)
    detected = (Xmat > 0).sum(axis=1)
    ent = np.array([row_entropy_norm(Xmat[i]) for i in range(n_cells)])

    # PCA order metrics
    pc_norm = np.linalg.norm(PCmat[:, :min(5, PCmat.shape[1])], axis=1)
    pc1_abs = np.abs(PCmat[:,0])
    pc2_abs = np.abs(PCmat[:,1]) if PCmat.shape[1] > 1 else np.zeros(n_cells)

    # neighbor-level metrics
    for i in range(n_cells):
        nb = neigh2[i]
        if len(nb) == 0:
            continue
        # H raw: molecular support/expression base.
        H_raw = np.mean([
            math.log1p(total_expr[i]),
            math.log1p(detected[i]),
            ent[i]
        ])

        # S raw: structured developmental state/manifold order.
        local_pc_spread = float(np.mean(np.linalg.norm(PCmat[nb,:min(5,PCmat.shape[1])] - PCmat[i,:min(5,PCmat.shape[1])], axis=1)))
        local_order = 1.0 / (1.0 + local_pc_spread)
        pca_concentration = float(explained[0]) if len(explained) else 0.0
        stage_coh = float(np.mean(label_codes[nb] == label_codes[i])) if label_col else 0.0
        S_raw = np.mean([
            local_order,
            cl_arr[i],
            pca_concentration,
            stage_coh,
            1.0/(1.0 + pc2_abs[i])
        ])

        # L raw: developmental linkage/coupling among neighbors.
        pseudo_smooth = 1.0 / (1.0 + float(np.mean(np.abs(pseudotime_vec[nb] - pseudotime_vec[i]))))
        neigh_similarity = 1.0 / (1.0 + float(np.mean(dist2[i])))
        env_corr = 0.0
        try:
            xi = Xmat[i]
            nb_mean = Xmat[nb].mean(axis=0)
            if np.std(xi) > 1e-12 and np.std(nb_mean) > 1e-12:
                env_corr = float(np.corrcoef(xi, nb_mean)[0,1])
                if not np.isfinite(env_corr): env_corr = 0.0
                env_corr = max(0.0, env_corr)
        except Exception:
            pass
        L_raw = np.mean([
            pseudo_smooth,
            neigh_similarity,
            env_corr,
            cl_arr[i]
        ])

        # Independent developmental Phi proxy.
        # Based on stage coherence, pseudo-continuity, local order and expression integrity.
        Phi_raw = np.mean([
            stage_coh,
            pseudo_smooth,
            local_order,
            env_corr,
            ent[i]
        ])

        Fragility_raw = np.mean([
            1.0 - stage_coh,
            1.0 - pseudo_smooth,
            1.0 - local_order,
            1.0 - min(1.0, env_corr),
            max(0.0, 1.0 - ent[i])
        ])

        rows.append({
            'cell_index': int(i),
            'dataset': dataset_name,
            'variant': variant,
            'label_col': str(label_col),
            'label': str(labels[i]),
            'pseudotime': float(pseudotime_vec[i]),
            'total_expr': float(total_expr[i]),
            'detected_genes': float(detected[i]),
            'expr_entropy': float(ent[i]),
            'local_clustering': float(cl_arr[i]),
            'local_order': float(local_order),
            'stage_coherence': float(stage_coh),
            'pseudotime_smoothness': float(pseudo_smooth),
            'neighbor_similarity': float(neigh_similarity),
            'expression_neighbor_corr': float(env_corr),
            'H_raw': float(H_raw),
            'S_raw': float(S_raw),
            'L_raw': float(L_raw),
            'Phi_embryo_raw': float(Phi_raw),
            'Embryo_fragility_raw': float(Fragility_raw)
        })
    return rows

print('Extracting natural and perturbative developmental features...')
all_rows = []

# natural
all_rows.extend(compute_features_for_matrix(X, PC, pseudotime, 'natural'))

# expression noise: keep structure roughly, degrade support
rng = np.random.default_rng(RANDOM_SEED)
X_noise = X + rng.normal(0, np.std(X)*0.25, size=X.shape)
X_noise[X_noise < 0] = 0
PC_noise = PCA(n_components=n_pcs, random_state=RANDOM_SEED).fit_transform(StandardScaler().fit_transform(X_noise))
all_rows.extend(compute_features_for_matrix(X_noise, PC_noise, pseudotime, 'expression_noise'))

# gene shuffle: break formal gene structure per cell while retaining expression distribution
X_gs = X.copy()
for i in range(X_gs.shape[0]):
    rng.shuffle(X_gs[i])
PC_gs = PCA(n_components=n_pcs, random_state=RANDOM_SEED).fit_transform(StandardScaler().fit_transform(X_gs))
all_rows.extend(compute_features_for_matrix(X_gs, PC_gs, pseudotime, 'gene_shuffle'))

# graph/manifold rewire: use permuted PC positions, preserving expression support but breaking linkage geometry
perm = rng.permutation(PC.shape[0])
PC_rewire = PC[perm].copy()
all_rows.extend(compute_features_for_matrix(X, PC_rewire, pseudotime, 'manifold_rewire'))

# pseudotime shuffle: keep expression and manifold, break developmental linkage direction
pt_shuffle = pseudotime.copy(); rng.shuffle(pt_shuffle)
all_rows.extend(compute_features_for_matrix(X, PC, pt_shuffle, 'pseudotime_shuffle'))

features = pd.DataFrame(all_rows)

# Normalize across natural+perturbed
for col in ['H_raw','S_raw','L_raw','Phi_embryo_raw','Embryo_fragility_raw']:
    features[col.replace('_raw','')] = normalize01(features[col].values)

features['Phi_HSL_epsilon'] = (features['H']+EPSILON) * (features['S']+EPSILON) * (features['L']+EPSILON)
features['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(features['H'],features['S'],features['L'])]
features['Functional_unity'] = features['Phi_HSL_epsilon'] * features['Triadic_balance']
features['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(features['H'],features['S'],features['L'])]

features['is_natural'] = features['variant'].eq('natural')
features['is_perturbed'] = ~features['is_natural']
features['coherence_high_flag'] = features['Phi_embryo'] >= features['Phi_embryo'].median()
features['fragility_high_flag'] = features['Embryo_fragility'] >= features['Embryo_fragility'].median()
features['triadic_disproportion_flag'] = (features['Triadic_balance'] <= features['Triadic_balance'].quantile(0.25)) | (features['Dominance_index'] >= features['Dominance_index'].quantile(0.75))
features['linkage_break_flag'] = features['variant'].isin(['manifold_rewire','pseudotime_shuffle'])
features['structure_break_flag'] = features['variant'].eq('gene_shuffle')
features['support_stress_flag'] = features['variant'].eq('expression_noise')

natural = features[features['is_natural']].copy()

# ============================================================
# SUMMARIES
# ============================================================

data_summary = pd.DataFrame([{
    'dataset': dataset_name,
    'n_cells_loaded': int(adata.n_obs),
    'n_genes_used': int(X.shape[1]),
    'n_total_rows': int(len(features)),
    'n_natural_cells': int(len(natural)),
    'n_perturbed_rows': int(features['is_perturbed'].sum()),
    'label_col': str(label_col),
    'n_labels': int(pd.Series(labels).nunique()),
    'variants': ','.join(sorted(features['variant'].unique())),
    'epsilon': EPSILON
}])

label_summary = natural.groupby('label').agg(
    n_cells=('cell_index','count'),
    mean_pseudotime=('pseudotime','mean'),
    mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'),
    mean_Phi=('Phi_embryo','mean'), mean_unity=('Functional_unity','mean'),
    mean_balance=('Triadic_balance','mean'), mean_fragility=('Embryo_fragility','mean')
).reset_index().sort_values('mean_pseudotime')

genesis_summary = pd.DataFrame([
    regression(natural, ['H'], 'S', 'E1_NAT_H_to_S'),
    regression(natural, ['H'], 'L', 'E1_NAT_H_to_L'),
    regression(natural, ['S'], 'L', 'E1_NAT_S_to_L'),
    regression(natural, ['H','S'], 'L', 'E1_NAT_H_plus_S_to_L'),
    regression(natural, ['H','S','L'], 'Phi_embryo', 'E1_NAT_HSL_to_Phi_embryo'),
    regression(natural, ['H','S','L'], 'Functional_unity', 'E1_NAT_HSL_to_Functional_Unity'),
    regression(natural, ['H','S','L'], 'Embryo_fragility', 'E1_NAT_HSL_to_Embryo_Fragility'),
    regression(natural, ['H','S','L','Triadic_balance','Dominance_index'], 'Embryo_fragility', 'E1_NAT_Full_to_Embryo_Fragility'),
])

all_summary = pd.DataFrame([
    regression(features, ['H'], 'S', 'E1_ALL_H_to_S'),
    regression(features, ['H'], 'L', 'E1_ALL_H_to_L'),
    regression(features, ['S'], 'L', 'E1_ALL_S_to_L'),
    regression(features, ['H','S'], 'L', 'E1_ALL_H_plus_S_to_L'),
    regression(features, ['H','S','L'], 'Phi_embryo', 'E1_ALL_HSL_to_Phi_embryo'),
    regression(features, ['H','S','L'], 'Functional_unity', 'E1_ALL_HSL_to_Functional_Unity'),
    regression(features, ['H','S','L'], 'Embryo_fragility', 'E1_ALL_HSL_to_Embryo_Fragility'),
    regression(features, ['H','S','L','Triadic_balance','Dominance_index'], 'Embryo_fragility', 'E1_ALL_Full_to_Embryo_Fragility'),
])

def get_mae(summary, test):
    x = summary[summary['test'] == test]
    return None if len(x)==0 else x.iloc[0]['mae']

H_L = get_mae(genesis_summary, 'E1_NAT_H_to_L')
S_L = get_mae(genesis_summary, 'E1_NAT_S_to_L')
HS_L = get_mae(genesis_summary, 'E1_NAT_H_plus_S_to_L')
emergence_contrast = pd.DataFrame([{
    'level': 'meso_embryogenesis_developmental_natural',
    'H_to_L_mae': H_L,
    'S_to_L_mae': S_L,
    'H_plus_S_to_L_mae': HS_L,
    'HS_improves_over_H': H_L-HS_L if H_L is not None and HS_L is not None else None,
    'HS_improves_over_S': S_L-HS_L if S_L is not None and HS_L is not None else None,
    'PETU_prediction_supported': (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

variant_summary = features.groupby('variant').agg(
    n=('cell_index','count'),
    mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'),
    mean_Phi=('Phi_embryo','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'),
    mean_unity=('Functional_unity','mean'), mean_balance=('Triadic_balance','mean'),
    mean_dominance=('Dominance_index','mean'), mean_fragility=('Embryo_fragility','mean'),
    mean_stage_coherence=('stage_coherence','mean'),
    mean_pseudotime_smoothness=('pseudotime_smoothness','mean'),
    mean_neighbor_corr=('expression_neighbor_corr','mean')
).reset_index().sort_values('mean_Phi', ascending=False)

contrast_defs = [
    ('natural_vs_perturbed','is_natural',True,False),
    ('coherent_vs_low','coherence_high_flag',True,False),
    ('fragility_high_vs_low','fragility_high_flag',True,False),
    ('disproportion_vs_proportion','triadic_disproportion_flag',True,False),
    ('linkage_break_vs_other','linkage_break_flag',True,False),
    ('structure_break_vs_other','structure_break_flag',True,False),
    ('support_stress_vs_other','support_stress_flag',True,False),
]
metrics = ['H','S','L','Phi_embryo','Phi_HSL_epsilon','Functional_unity','Triadic_balance','Dominance_index','Embryo_fragility','stage_coherence','pseudotime_smoothness','neighbor_similarity','expression_neighbor_corr','local_clustering','local_order','expr_entropy']
contrast_rows=[]
for cname, flag, aval, bval in contrast_defs:
    A = features[features[flag]==aval]
    B = features[features[flag]==bval]
    for col in metrics:
        stat,p = safe_mw(A[col], B[col])
        contrast_rows.append({
            'contrast': cname, 'metric': col,
            'groupA_mean': float(A[col].mean()) if len(A) else np.nan,
            'groupB_mean': float(B[col].mean()) if len(B) else np.nan,
            'delta_A_minus_B': float(A[col].mean()-B[col].mean()) if len(A) and len(B) else np.nan,
            'pct_delta': float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,
            'mannwhitney_stat': stat, 'p_value': p
        })
contrast_summary = pd.DataFrame(contrast_rows)

# Classification
class_rows=[]
targets = ['is_natural','coherence_high_flag','fragility_high_flag','triadic_disproportion_flag','linkage_break_flag','structure_break_flag','support_stress_flag']
feature_sets = [
    (['H'],'H'), (['S'],'S'), (['L'],'L'), (['H','S'],'H+S'),
    (['H','S','L'],'H+S+L'),
    (['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),
    (['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')
]
for t in targets:
    for cols,label in feature_sets:
        r = auc_model(features, cols, t, label)
        if r: class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x = d[d['feature_set']==fs]
        return None if len(x)==0 else float(x.iloc[0]['auc'])
    aH,aHS,aHSL,aFull = auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gain_rows.append({'target':target,'auc_H':aH,'auc_HS':aHS,'auc_HSL':aHSL,'auc_full':aFull,
                      'gain_HSL_over_H':None if aH is None or aHSL is None else aHSL-aH,
                      'gain_HSL_over_HS':None if aHS is None or aHSL is None else aHSL-aHS,
                      'gain_full_over_HSL':None if aFull is None or aHSL is None else aFull-aHSL})
classification_gain_summary = pd.DataFrame(gain_rows)

# Phases
def classify_phase(r):
    if r['variant'] == 'gene_shuffle': return 'S_gene_structure_disruption'
    if r['variant'] == 'manifold_rewire': return 'L_manifold_rewire_pathology'
    if r['variant'] == 'pseudotime_shuffle': return 'L_pseudotime_shuffle_pathology'
    if r['variant'] == 'expression_noise': return 'H_expression_support_stress'
    if r['is_natural'] and r['Phi_embryo'] >= features['Phi_embryo'].median() and r['Triadic_balance'] >= features['Triadic_balance'].median(): return 'natural_embryo_phi_integrated'
    if r['is_natural'] and r['Embryo_fragility'] >= features['Embryo_fragility'].median(): return 'natural_fragile_transition'
    if r['triadic_disproportion_flag']: return 'triadic_disproportion'
    if r['is_natural']: return 'natural_transitional'
    return 'perturbed_transitional'

features['PETU_E1_phase'] = features.apply(classify_phase, axis=1)
phase_summary = features.groupby('PETU_E1_phase').agg(
    n=('cell_index','count'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'),
    mean_Phi=('Phi_embryo','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'), mean_unity=('Functional_unity','mean'),
    mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_fragility=('Embryo_fragility','mean'),
    mean_stage_coherence=('stage_coherence','mean'), mean_pseudotime_smoothness=('pseudotime_smoothness','mean')
).reset_index().sort_values('n', ascending=False)

# ============================================================
# SAVE
# ============================================================

paths = {
    'features': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_features.csv',
    'data_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_data_summary.csv',
    'label_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_label_summary.csv',
    'genesis_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_genesis_summary.csv',
    'all_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_all_perturbative_summary.csv',
    'emergence_contrast': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_emergence_contrast.csv',
    'variant_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_variant_summary.csv',
    'contrast_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_contrast_summary.csv',
    'classification_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_classification_summary.csv',
    'classification_gain_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_classification_gain_summary.csv',
    'phase_summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_phase_summary.csv',
    'failures': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_failures.csv',
    'summary': f'{OUTDIR}/PETU_MESO_EMBRYO_E1_summary.json'
}

features.to_csv(paths['features'], index=False)
data_summary.to_csv(paths['data_summary'], index=False)
label_summary.to_csv(paths['label_summary'], index=False)
genesis_summary.to_csv(paths['genesis_summary'], index=False)
all_summary.to_csv(paths['all_summary'], index=False)
emergence_contrast.to_csv(paths['emergence_contrast'], index=False)
variant_summary.to_csv(paths['variant_summary'], index=False)
contrast_summary.to_csv(paths['contrast_summary'], index=False)
classification_summary.to_csv(paths['classification_summary'], index=False)
classification_gain_summary.to_csv(paths['classification_gain_summary'], index=False)
phase_summary.to_csv(paths['phase_summary'], index=False)
pd.DataFrame(failures).to_csv(paths['failures'], index=False)

summary = {
    'pipeline': 'PETU-MESO-EMBRYO E1 Developmental Dynamics Triadic Audit',
    'domain': 'meso biology / embryogenesis / developmental single-cell dynamics',
    'dataset': dataset_name,
    'n_cells_loaded': int(adata.n_obs),
    'n_total_rows': int(len(features)),
    'n_natural_cells': int(len(natural)),
    'n_perturbed_rows': int(features['is_perturbed'].sum()),
    'label_col': str(label_col),
    'epsilon': EPSILON,
    'hypothesis': 'Embryonic/developmental coherence arises from triadic proportion/co-inherence of H transcriptional support, S developmental structure, and L morphogenetic linkage.',
    'epistemic_note': 'Natural single-cell developmental data are primary; perturbations are auxiliary contrasts.',
    'next_step': 'MESO immune system after evaluating E1.'
}
with open(paths['summary'],'w') as f:
    json.dump(summary,f,indent=2)

# ============================================================
# PRINT OUTPUTS
# ============================================================

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 DATA SUMMARY')
print('='*60)
print(data_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 LABEL / STATE SUMMARY')
print('='*60)
print(label_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 NATURAL GENESIS SUMMARY')
print('='*60)
print(genesis_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 EMERGENCE CONTRAST')
print('='*60)
print(emergence_contrast)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 ALL / PERTURBATIVE SUMMARY')
print('='*60)
print(all_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 VARIANT SUMMARY')
print('='*60)
print(variant_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 CONTRAST SUMMARY')
print('='*60)
print(contrast_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 CLASSIFICATION GAIN SUMMARY')
print('='*60)
print(classification_gain_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 PHASE SUMMARY')
print('='*60)
print(phase_summary)

print('\n'+'='*60)
print('PETU-MESO-EMBRYO E1 FINAL SUMMARY')
print('='*60)
print(json.dumps(summary,indent=2))

if len(failures) > 0:
    print('\n'+'='*60)
    print('FAILURES / SKIPPED')
    print('='*60)
    print(pd.DataFrame(failures))

# Figures
plt.figure(figsize=(8,5))
plt.scatter(natural['H']+natural['S'], natural['L'], s=18, alpha=0.55)
plt.xlabel('H + S')
plt.ylabel('L')
plt.title('PETU-EMBRYO E1 natural: H+S -> L')
plt.grid(True)
plt.tight_layout()
plt.savefig(f'{OUTDIR}/figure_E1_NAT_HS_to_L.png', dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features['Phi_HSL_epsilon'], features['Phi_embryo'], s=14, alpha=0.40)
plt.xlabel('Phi_HSL_epsilon')
plt.ylabel('Phi_embryo')
plt.title('PETU-EMBRYO E1: HSL unity vs developmental Phi')
plt.grid(True)
plt.tight_layout()
plt.savefig(f'{OUTDIR}/figure_E1_PhiHSL_EmbryoPhi.png', dpi=220)
plt.show()

plt.figure(figsize=(9,5))
plt.bar(variant_summary['variant'], variant_summary['mean_Phi'])
plt.xticks(rotation=45)
plt.ylabel('Mean developmental Phi')
plt.title('PETU-EMBRYO E1: natural vs perturbative variants')
plt.tight_layout()
plt.savefig(f'{OUTDIR}/figure_E1_variant_phi.png', dpi=220)
plt.show()

zip_base = '/content/PETU_MESO_EMBRYO_E1_Developmental_Dynamics_results'
zip_path = zip_base + '.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base, 'zip', OUTDIR)

print('\n'+'='*60)
print('PIPELINE COMPLETE')
for k,v in paths.items():
    print(k+':', v)
print('ZIP:', zip_path)
print('='*60)

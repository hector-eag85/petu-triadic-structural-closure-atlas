# ============================================================
# PETU-MESO-IMMUNE I1
# Natural Immune-System Single-Cell Triadic Audit
#
# Objetivo:
#   Cuarto dominio meso-normal PETU/LETU:
#   sistema inmune en datos reales de PBMC single-cell.
#
# Fuente primaria:
#   scanpy.datasets.pbmc3k_processed()
#   Si falla, intenta pbmc68k_reduced().
#
# Traducción PETU:
#   H = soporte inmuno-transcripcional:
#       expresión total, genes detectados, entropía expresiva, soporte celular.
#
#   S = estructura formal inmunológica:
#       identidad/tipo celular, estructura PCA, coherencia de cluster/estado,
#       orden del manifold inmune.
#
#   L = vínculo inmunológico/intercelular:
#       continuidad de vecindad, similitud local, correlación con vecinos,
#       acoplamiento estado-estado en el grafo inmune.
#
#   Φ = coherencia inmune:
#       integración H-S-L, identidad inmune coherente, baja fragilidad.
#
# Hipótesis:
#   1. H + S -> L
#   2. H + S + L -> Φ
#   3. Fragilidad/inmunodisrupción = desproporción H-S-L
#
# Perturbaciones auxiliares:
#   expression_noise      rompe soporte H
#   gene_shuffle          rompe estructura génica S
#   manifold_rewire       rompe vínculo L
#   label_state_shuffle   rompe coherencia de identidad S/L
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install scanpy anndata numpy pandas scipy scikit-learn matplotlib tqdm networkx

import os, json, random, warnings, shutil
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm

from scipy import sparse
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.preprocessing import StandardScaler

import scanpy as sc

# ============================================================
# CONFIG
# ============================================================

OUTDIR = "/content/PETU_MESO_IMMUNE_I1_Natural_Immune_Dynamics"
os.makedirs(OUTDIR, exist_ok=True)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

EPSILON = 0.05
MAX_CELLS = 3000
N_PCS = 20
N_NEIGHBORS = 15

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    mn, mx = np.nanmin(x), np.nanmax(x)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]
        b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None

def entropy_norm(row):
    row = np.asarray(row, dtype=float)
    row = row[row > 0]
    if row.sum() <= 0 or len(row) <= 1:
        return 0.0
    p = row / row.sum()
    ent = -np.sum(p * np.log(p + 1e-12))
    return float(ent / np.log(len(row) + 1e-12))

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def dense_X(adata):
    X = adata.X
    if sparse.issparse(X):
        X = X.toarray()
    return np.asarray(X, dtype=float)

def choose_label_col(adata):
    candidates = [
        "louvain", "bulk_labels", "cell_type", "celltype", "cell_types",
        "labels", "cluster", "clusters", "leiden"
    ]
    for c in candidates:
        if c in adata.obs.columns:
            return c
    return None

def load_immune_dataset():
    failures = []
    try:
        adata = sc.datasets.pbmc3k_processed()
        source = "scanpy_pbmc3k_processed_real_PBMC"
        return adata, source, failures
    except Exception as e:
        failures.append({"stage": "load_pbmc3k_processed", "error": str(e)})
    try:
        adata = sc.datasets.pbmc68k_reduced()
        source = "scanpy_pbmc68k_reduced_real_PBMC"
        return adata, source, failures
    except Exception as e:
        failures.append({"stage": "load_pbmc68k_reduced", "error": str(e)})
    raise RuntimeError("Could not load real immune PBMC datasets from scanpy.")

def build_knn_graph(pcs, n_neighbors=N_NEIGHBORS):
    nbrs = NearestNeighbors(n_neighbors=n_neighbors+1, metric="euclidean")
    nbrs.fit(pcs)
    dist, ind = nbrs.kneighbors(pcs)
    return ind[:,1:], dist[:,1:]

def neighbor_label_coherence(labels, knn_idx):
    labs = np.asarray(labels)
    out = []
    for i in range(len(labs)):
        neigh = labs[knn_idx[i]]
        out.append(float(np.mean(neigh == labs[i])))
    return np.array(out)

def neighbor_expression_corr(X, knn_idx, max_neighbors=8):
    out = []
    for i in range(X.shape[0]):
        xi = X[i]
        vals = []
        for j in knn_idx[i][:max_neighbors]:
            xj = X[j]
            if np.std(xi) < 1e-12 or np.std(xj) < 1e-12:
                continue
            vals.append(np.corrcoef(xi, xj)[0,1])
        if len(vals) == 0:
            out.append(0.0)
        else:
            out.append(float(np.nanmean(vals)))
    return np.array(out)

def local_pca_order(pcs, knn_idx):
    out = []
    for i in range(pcs.shape[0]):
        d = np.linalg.norm(pcs[knn_idx[i]] - pcs[i], axis=1)
        out.append(1.0/(1.0 + float(np.mean(d))))
    return np.array(out)

def local_density(pcs, knn_idx):
    out = []
    for i in range(pcs.shape[0]):
        d = np.linalg.norm(pcs[knn_idx[i]] - pcs[i], axis=1)
        out.append(1.0/(float(np.mean(d)) + 1e-9))
    return normalize01(out)

def compute_base_features(X, pcs, labels, knn_idx, variant):
    n = X.shape[0]
    total_expr = X.sum(axis=1)
    detected = (X > 0).sum(axis=1)
    expr_entropy = np.array([entropy_norm(X[i]) for i in range(n)])

    label_coh = neighbor_label_coherence(labels, knn_idx)
    neigh_corr = neighbor_expression_corr(X, knn_idx)
    pca_order = local_pca_order(pcs, knn_idx)
    density = local_density(pcs, knn_idx)

    H_raw = np.mean(np.vstack([
        normalize01(total_expr),
        normalize01(detected),
        normalize01(expr_entropy),
        density
    ]), axis=0)

    pc_norm = np.linalg.norm(pcs[:,:min(5, pcs.shape[1])], axis=1)
    pc_balance = 1.0 - normalize01(np.abs(pc_norm - np.median(pc_norm)))
    S_raw = np.mean(np.vstack([
        normalize01(label_coh),
        normalize01(pca_order),
        normalize01(pc_balance),
        normalize01(expr_entropy)
    ]), axis=0)

    L_raw = np.mean(np.vstack([
        normalize01(neigh_corr),
        normalize01(label_coh),
        normalize01(density),
        normalize01(pca_order)
    ]), axis=0)

    Phi_immune_raw = np.mean(np.vstack([
        normalize01(label_coh),
        normalize01(neigh_corr),
        normalize01(pca_order),
        normalize01(density),
        normalize01(expr_entropy)
    ]), axis=0)

    Immune_fragility_raw = 1.0 - normalize01(Phi_immune_raw)

    return pd.DataFrame({
        "cell_id": np.arange(n),
        "variant": variant,
        "total_expr": total_expr,
        "detected_genes": detected,
        "expr_entropy": expr_entropy,
        "label_coherence": label_coh,
        "neighbor_corr": neigh_corr,
        "pca_order": pca_order,
        "local_density": density,
        "H_raw": H_raw,
        "S_raw": S_raw,
        "L_raw": L_raw,
        "Phi_immune_raw": Phi_immune_raw,
        "Immune_fragility_raw": Immune_fragility_raw
    })

def perturb_X_and_graph(X, pcs, labels, variant, base_knn):
    Xp = X.copy()
    pcsp = pcs.copy()
    labp = np.asarray(labels).copy()
    knn = base_knn.copy()

    if variant == "natural":
        return Xp, pcsp, labp, knn

    if variant == "expression_noise":
        noise = np.random.normal(0, np.std(Xp)*0.15, Xp.shape)
        Xp = np.clip(Xp + noise, 0, None)

    elif variant == "gene_shuffle":
        for i in range(Xp.shape[0]):
            np.random.shuffle(Xp[i])

    elif variant == "manifold_rewire":
        rng = np.random.default_rng(RANDOM_SEED)
        n = Xp.shape[0]
        knn = np.vstack([rng.choice(n, size=base_knn.shape[1], replace=False) for _ in range(n)])

    elif variant == "label_state_shuffle":
        rng = np.random.default_rng(RANDOM_SEED)
        labp = labp.copy()
        rng.shuffle(labp)

    return Xp, pcsp, labp, knn

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    Xv = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(Xv, y)
    pred = model.predict(Xv)
    r, p = safe_spearman(y, pred)
    return {
        "test": label,
        "n": int(len(d)),
        "r2": float(r2_score(y, pred)),
        "mae": float(mean_absolute_error(y, pred)),
        "spearman_true_pred": r,
        "p_value": p
    }

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2:
        return None
    Xv = d[feature_cols].values.astype(float)
    y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight="balanced")
        clf.fit(Xv, y)
        pred = clf.predict_proba(Xv)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {"feature_set": label, "target": target, "n": int(len(d)), "auc": float(auc)}

# ============================================================
# MAIN
# ============================================================

print("============================================================")
print("PETU-MESO-IMMUNE I1 NATURAL IMMUNE TRIADIC AUDIT")
print("============================================================")
print("Loading real immune single-cell PBMC data...")

failures = []
adata, dataset_source, load_failures = load_immune_dataset()
failures.extend(load_failures)

if adata.n_obs > MAX_CELLS:
    np.random.seed(RANDOM_SEED)
    idx = np.random.choice(adata.n_obs, MAX_CELLS, replace=False)
    adata = adata[idx].copy()

label_col = choose_label_col(adata)
if label_col is None:
    failures.append({"stage": "label_col", "error": "No label column; using PCA quantile fallback"})

X = dense_X(adata)
X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
X = np.clip(X, 0, None)

scaler = StandardScaler(with_mean=True, with_std=True)
Xs = scaler.fit_transform(X)
n_pcs = min(N_PCS, Xs.shape[1], Xs.shape[0]-1)
pca = PCA(n_components=n_pcs, random_state=RANDOM_SEED)
pcs = pca.fit_transform(Xs)

if label_col is not None:
    labels = adata.obs[label_col].astype(str).values
else:
    q = pd.qcut(pcs[:,0], q=5, labels=False, duplicates="drop")
    labels = np.array(["pc_state_" + str(x) for x in q])

knn_idx, knn_dist = build_knn_graph(pcs, N_NEIGHBORS)

print("Dataset OK:", dataset_source, adata.shape, "label_col:", label_col if label_col else "PCA_fallback")

variants = ["natural", "expression_noise", "gene_shuffle", "manifold_rewire", "label_state_shuffle"]
feature_frames = []

print("Extracting natural and perturbative immune features...")
for variant in tqdm(variants, desc="Immune variants"):
    Xp, pcsp, labp, knn = perturb_X_and_graph(X, pcs, labels, variant, knn_idx)
    if variant in ["expression_noise", "gene_shuffle"]:
        Xps = scaler.fit_transform(Xp)
        pcsp = PCA(n_components=n_pcs, random_state=RANDOM_SEED).fit_transform(Xps)
        knn, _ = build_knn_graph(pcsp, N_NEIGHBORS)
    df = compute_base_features(Xp, pcsp, labp, knn, variant)
    df["dataset"] = dataset_source
    df["label"] = labp
    feature_frames.append(df)

features = pd.concat(feature_frames, ignore_index=True)

for col in ["H_raw", "S_raw", "L_raw", "Phi_immune_raw", "Immune_fragility_raw"]:
    features[col.replace("_raw","")] = normalize01(features[col].values)

features["Phi_HSL_epsilon"] = (features["H"] + EPSILON) * (features["S"] + EPSILON) * (features["L"] + EPSILON)
features["Triadic_balance"] = [triadic_balance(h,s,l) for h,s,l in zip(features["H"], features["S"], features["L"])]
features["Functional_unity"] = features["Phi_HSL_epsilon"] * features["Triadic_balance"]
features["Dominance_index"] = [dominance_index(h,s,l) for h,s,l in zip(features["H"], features["S"], features["L"])]

features["is_natural"] = features["variant"].eq("natural")
features["is_perturbed"] = ~features["is_natural"]
features["coherence_high_flag"] = features["Phi_immune"] >= features["Phi_immune"].median()
features["fragility_high_flag"] = features["Immune_fragility"] >= features["Immune_fragility"].median()
features["triadic_disproportion_flag"] = (
    (features["Triadic_balance"] <= features["Triadic_balance"].quantile(0.25)) |
    (features["Dominance_index"] >= features["Dominance_index"].quantile(0.75))
)
features["support_stress_flag"] = features["variant"].eq("expression_noise")
features["structure_break_flag"] = features["variant"].isin(["gene_shuffle", "label_state_shuffle"])
features["linkage_break_flag"] = features["variant"].eq("manifold_rewire")

natural = features[features["is_natural"]].copy()

data_summary = pd.DataFrame([{
    "dataset": dataset_source,
    "n_cells_loaded": int(adata.n_obs),
    "n_genes_used": int(adata.n_vars),
    "n_total_rows": int(len(features)),
    "n_natural_cells": int(len(natural)),
    "n_perturbed_rows": int(features["is_perturbed"].sum()),
    "label_col": label_col if label_col else "PCA_fallback",
    "n_labels": int(pd.Series(labels).nunique()),
    "variants": ",".join(variants),
    "epsilon": EPSILON
}])

label_summary = (
    natural.groupby("label")
    .agg(
        n_cells=("cell_id","count"),
        mean_H=("H","mean"),
        mean_S=("S","mean"),
        mean_L=("L","mean"),
        mean_Phi=("Phi_immune","mean"),
        mean_unity=("Functional_unity","mean"),
        mean_balance=("Triadic_balance","mean"),
        mean_fragility=("Immune_fragility","mean"),
        mean_label_coherence=("label_coherence","mean"),
        mean_neighbor_corr=("neighbor_corr","mean")
    )
    .reset_index()
    .sort_values("mean_Phi", ascending=False)
)

genesis_summary = pd.DataFrame([
    regression(natural, ["H"], "S", "I1_NAT_H_to_S"),
    regression(natural, ["H"], "L", "I1_NAT_H_to_L"),
    regression(natural, ["S"], "L", "I1_NAT_S_to_L"),
    regression(natural, ["H","S"], "L", "I1_NAT_H_plus_S_to_L"),
    regression(natural, ["H","S","L"], "Phi_immune", "I1_NAT_HSL_to_Phi_immune"),
    regression(natural, ["H","S","L"], "Functional_unity", "I1_NAT_HSL_to_Functional_Unity"),
    regression(natural, ["H","S","L"], "Immune_fragility", "I1_NAT_HSL_to_Immune_Fragility"),
    regression(natural, ["H","S","L","Triadic_balance","Dominance_index"], "Immune_fragility", "I1_NAT_Full_to_Immune_Fragility"),
])

all_summary = pd.DataFrame([
    regression(features, ["H"], "S", "I1_ALL_H_to_S"),
    regression(features, ["H"], "L", "I1_ALL_H_to_L"),
    regression(features, ["S"], "L", "I1_ALL_S_to_L"),
    regression(features, ["H","S"], "L", "I1_ALL_H_plus_S_to_L"),
    regression(features, ["H","S","L"], "Phi_immune", "I1_ALL_HSL_to_Phi_immune"),
    regression(features, ["H","S","L"], "Functional_unity", "I1_ALL_HSL_to_Functional_Unity"),
    regression(features, ["H","S","L"], "Immune_fragility", "I1_ALL_HSL_to_Immune_Fragility"),
    regression(features, ["H","S","L","Triadic_balance","Dominance_index"], "Immune_fragility", "I1_ALL_Full_to_Immune_Fragility"),
])

def get_mae(summary, test):
    x = summary[summary["test"] == test]
    return None if len(x)==0 else x.iloc[0]["mae"]

H_L = get_mae(genesis_summary, "I1_NAT_H_to_L")
S_L = get_mae(genesis_summary, "I1_NAT_S_to_L")
HS_L = get_mae(genesis_summary, "I1_NAT_H_plus_S_to_L")
emergence_contrast = pd.DataFrame([{
    "level": "meso_immune_natural_PBMC",
    "H_to_L_mae": H_L,
    "S_to_L_mae": S_L,
    "H_plus_S_to_L_mae": HS_L,
    "HS_improves_over_H": H_L-HS_L if H_L is not None and HS_L is not None else None,
    "HS_improves_over_S": S_L-HS_L if S_L is not None and HS_L is not None else None,
    "PETU_prediction_supported": (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

variant_summary = (
    features.groupby("variant")
    .agg(
        n=("cell_id","count"),
        n_labels=("label","nunique"),
        mean_H=("H","mean"),
        mean_S=("S","mean"),
        mean_L=("L","mean"),
        mean_Phi=("Phi_immune","mean"),
        mean_Phi_HSL=("Phi_HSL_epsilon","mean"),
        mean_unity=("Functional_unity","mean"),
        mean_balance=("Triadic_balance","mean"),
        mean_dominance=("Dominance_index","mean"),
        mean_fragility=("Immune_fragility","mean"),
        mean_label_coherence=("label_coherence","mean"),
        mean_neighbor_corr=("neighbor_corr","mean"),
        mean_pca_order=("pca_order","mean"),
        mean_local_density=("local_density","mean")
    )
    .reset_index()
    .sort_values("mean_Phi", ascending=False)
)

contrast_defs = [
    ("natural_vs_perturbed", "is_natural", True, False),
    ("coherent_vs_low", "coherence_high_flag", True, False),
    ("fragility_high_vs_low", "fragility_high_flag", True, False),
    ("disproportion_vs_proportion", "triadic_disproportion_flag", True, False),
    ("support_stress_vs_other", "support_stress_flag", True, False),
    ("structure_break_vs_other", "structure_break_flag", True, False),
    ("linkage_break_vs_other", "linkage_break_flag", True, False),
]
contrast_metrics = [
    "H","S","L","Phi_immune","Phi_HSL_epsilon","Functional_unity",
    "Triadic_balance","Dominance_index","Immune_fragility",
    "label_coherence","neighbor_corr","pca_order","local_density",
    "total_expr","detected_genes","expr_entropy"
]
contrast_rows = []
for cname, flag, aval, bval in contrast_defs:
    A = features[features[flag] == aval]
    B = features[features[flag] == bval]
    for col in contrast_metrics:
        stat, p = safe_mw(A[col], B[col])
        contrast_rows.append({
            "contrast": cname,
            "metric": col,
            "groupA_mean": float(A[col].mean()) if len(A) else np.nan,
            "groupB_mean": float(B[col].mean()) if len(B) else np.nan,
            "delta_A_minus_B": float(A[col].mean()-B[col].mean()) if len(A) and len(B) else np.nan,
            "pct_delta": float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,
            "mannwhitney_stat": stat,
            "p_value": p
        })
contrast_summary = pd.DataFrame(contrast_rows)

class_rows = []
targets = [
    "is_natural", "coherence_high_flag", "fragility_high_flag",
    "triadic_disproportion_flag", "support_stress_flag",
    "structure_break_flag", "linkage_break_flag"
]
feature_sets = [
    (["H"], "H"),
    (["S"], "S"),
    (["L"], "L"),
    (["H","S"], "H+S"),
    (["H","S","L"], "H+S+L"),
    (["H","S","L","Phi_HSL_epsilon"], "H+S+L+Phi"),
    (["H","S","L","Phi_HSL_epsilon","Triadic_balance","Dominance_index"], "H+S+L+PhiBalanceDominance")
]
for target in targets:
    for cols, label in feature_sets:
        r = auc_model(features, cols, target, label)
        if r:
            class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows = []
for target, d in classification_summary.groupby("target"):
    def auc(fs):
        x = d[d["feature_set"] == fs]
        return None if len(x)==0 else float(x.iloc[0]["auc"])
    aH, aHS, aHSL, aFull = auc("H"), auc("H+S"), auc("H+S+L"), auc("H+S+L+PhiBalanceDominance")
    gain_rows.append({
        "target": target,
        "auc_H": aH,
        "auc_HS": aHS,
        "auc_HSL": aHSL,
        "auc_full": aFull,
        "gain_HSL_over_H": None if aH is None or aHSL is None else aHSL-aH,
        "gain_HSL_over_HS": None if aHS is None or aHSL is None else aHSL-aHS,
        "gain_full_over_HSL": None if aFull is None or aHSL is None else aFull-aHSL
    })
classification_gain_summary = pd.DataFrame(gain_rows)

def classify_phase(r):
    if r["variant"] == "expression_noise":
        return "H_expression_support_stress"
    if r["variant"] == "gene_shuffle":
        return "S_gene_structure_disruption"
    if r["variant"] == "label_state_shuffle":
        return "S_L_identity_shuffle_pathology"
    if r["variant"] == "manifold_rewire":
        return "L_manifold_rewire_pathology"
    if r["is_natural"] and r["Phi_immune"] >= features["Phi_immune"].median() and r["Triadic_balance"] >= features["Triadic_balance"].median():
        return "natural_immune_phi_integrated"
    if r["is_natural"] and r["Immune_fragility"] >= features["Immune_fragility"].median():
        return "natural_fragile_transition"
    if r["triadic_disproportion_flag"]:
        return "triadic_disproportion"
    if r["is_natural"]:
        return "natural_transitional"
    return "perturbed_transitional"

features["PETU_I1_phase"] = features.apply(classify_phase, axis=1)

phase_summary = (
    features.groupby("PETU_I1_phase")
    .agg(
        n=("cell_id","count"),
        n_labels=("label","nunique"),
        mean_H=("H","mean"),
        mean_S=("S","mean"),
        mean_L=("L","mean"),
        mean_Phi=("Phi_immune","mean"),
        mean_Phi_HSL=("Phi_HSL_epsilon","mean"),
        mean_unity=("Functional_unity","mean"),
        mean_balance=("Triadic_balance","mean"),
        mean_dominance=("Dominance_index","mean"),
        mean_fragility=("Immune_fragility","mean"),
        mean_label_coherence=("label_coherence","mean"),
        mean_neighbor_corr=("neighbor_corr","mean")
    )
    .reset_index()
    .sort_values("n", ascending=False)
)

paths = {
    "features": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_features.csv",
    "data_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_data_summary.csv",
    "label_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_label_summary.csv",
    "genesis_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_genesis_summary.csv",
    "all_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_all_perturbative_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_emergence_contrast.csv",
    "variant_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_variant_summary.csv",
    "contrast_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_contrast_summary.csv",
    "classification_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_classification_summary.csv",
    "classification_gain_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_classification_gain_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_phase_summary.csv",
    "failures": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_failures.csv",
    "summary": f"{OUTDIR}/PETU_MESO_IMMUNE_I1_summary.json"
}

features.to_csv(paths["features"], index=False)
data_summary.to_csv(paths["data_summary"], index=False)
label_summary.to_csv(paths["label_summary"], index=False)
genesis_summary.to_csv(paths["genesis_summary"], index=False)
all_summary.to_csv(paths["all_summary"], index=False)
emergence_contrast.to_csv(paths["emergence_contrast"], index=False)
variant_summary.to_csv(paths["variant_summary"], index=False)
contrast_summary.to_csv(paths["contrast_summary"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-MESO-IMMUNE I1 Natural Immune System Triadic Audit",
    "domain": "meso biology / immune system / real PBMC single-cell dynamics",
    "dataset": dataset_source,
    "n_cells_loaded": int(adata.n_obs),
    "n_total_rows": int(len(features)),
    "n_natural_cells": int(len(natural)),
    "n_perturbed_rows": int(features["is_perturbed"].sum()),
    "label_col": label_col if label_col else "PCA_fallback",
    "epsilon": EPSILON,
    "hypothesis": "Immune coherence arises from triadic proportion/co-inherence of H transcriptional support, S immune-state structure, and L intercellular linkage.",
    "epistemic_note": "Natural PBMC single-cell data are primary; perturbations are auxiliary contrasts.",
    "next_step": "Integrate PETU atlas 4 micro + 4 meso + 4 macro."
}
with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 DATA SUMMARY")
print("============================================================")
print(data_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 LABEL / STATE SUMMARY")
print("============================================================")
print(label_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 NATURAL GENESIS SUMMARY")
print("============================================================")
print(genesis_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 EMERGENCE CONTRAST")
print("============================================================")
print(emergence_contrast)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 ALL / PERTURBATIVE SUMMARY")
print("============================================================")
print(all_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 VARIANT SUMMARY")
print("============================================================")
print(variant_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 CONTRAST SUMMARY")
print("============================================================")
print(contrast_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 PHASE SUMMARY")
print("============================================================")
print(phase_summary)

print("\n============================================================")
print("PETU-MESO-IMMUNE I1 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

if len(failures) > 0:
    print("\n============================================================")
    print("FAILURES / SKIPPED")
    print("============================================================")
    print(pd.DataFrame(failures))

plt.figure(figsize=(8,5))
plt.scatter(natural["H"] + natural["S"], natural["L"], s=14, alpha=0.45)
plt.xlabel("H + S")
plt.ylabel("L")
plt.title("PETU-IMMUNE I1 natural: H+S -> L")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_I1_NAT_HS_to_L.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Phi_HSL_epsilon"], features["Phi_immune"], s=10, alpha=0.35)
plt.xlabel("Phi_HSL_epsilon")
plt.ylabel("Phi_immune")
plt.title("PETU-IMMUNE I1: HSL unity vs immune coherence")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_I1_PhiHSL_ImmunePhi.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Dominance_index"], features["Immune_fragility"], s=10, alpha=0.35)
plt.xlabel("Dominance index")
plt.ylabel("Immune fragility")
plt.title("PETU-IMMUNE I1: dominance and immune fragility")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_I1_Dominance_Fragility.png", dpi=220)
plt.show()

plt.figure(figsize=(9,5))
plt.bar(variant_summary["variant"], variant_summary["mean_Phi"])
plt.xticks(rotation=45)
plt.ylabel("Mean immune Phi")
plt.title("PETU-IMMUNE I1: natural vs perturbative variants")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_I1_variant_phi.png", dpi=220)
plt.show()

zip_base = "/content/PETU_MESO_IMMUNE_I1_Natural_Immune_Dynamics_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path):
    os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k,v in paths.items():
    print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

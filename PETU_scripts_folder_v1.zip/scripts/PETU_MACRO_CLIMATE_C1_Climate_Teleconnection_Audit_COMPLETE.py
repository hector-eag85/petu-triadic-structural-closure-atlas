# ============================================================
# PETU-MACRO-CLIMATE C1
# Climate Regime / Teleconnection Triadic Audit
# Designed for Google Colab mobile execution
# ============================================================

!pip -q install pandas numpy scipy scikit-learn matplotlib requests tqdm

import os, json, warnings, shutil
warnings.filterwarnings('ignore')

import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

OUTDIR = '/content/PETU_MACRO_CLIMATE_C1_Climate_Teleconnection_Audit'
os.makedirs(OUTDIR, exist_ok=True)

EPSILON = 0.05
WINDOW_MONTHS = 60
STEP_MONTHS = 3
START_YEAR = 1958
END_YEAR = 2023

# ----------------------------
# Utilities
# ----------------------------

def normalize01(x):
    x = np.asarray(x, dtype=float)
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def zscore_local(x):
    x = np.asarray(x, dtype=float)
    return (x - np.nanmean(x)) / (np.nanstd(x) + 1e-12)

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        m = np.isfinite(a) & np.isfinite(b)
        if m.sum() < 3: return None, None
        r, p = spearmanr(a[m], b[m])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]; b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3: return None, None
        stat, p = mannwhitneyu(a, b, alternative='two-sided')
        return float(stat), float(p)
    except Exception:
        return None, None

def autocorr(x, lag=1):
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    if len(x) <= lag + 3: return 0.0
    a, b = x[:-lag], x[lag:]
    if np.std(a) < 1e-12 or np.std(b) < 1e-12: return 0.0
    return float(np.corrcoef(a, b)[0, 1])

def entropy_norm(values, bins=16):
    values = np.asarray(values, dtype=float); values = values[np.isfinite(values)]
    if len(values) < 5: return 0.0
    hist, _ = np.histogram(values, bins=bins)
    p = hist.astype(float)
    if p.sum() <= 0: return 0.0
    p = p / p.sum()
    ent = -np.sum(p * np.log(p + 1e-12))
    return float(ent / np.log(len(p) + 1e-12))

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def url_text(url, timeout=60):
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    return r.text

# ----------------------------
# Loaders
# ----------------------------

def load_gistemp():
    urls = [
        'https://data.giss.nasa.gov/gistemp/tabledata_v4/GLB.Ts+dSST.csv',
        'https://data.giss.nasa.gov/gistemp/tabledata_v4/GLB.Ts.csv'
    ]
    for url in urls:
        try:
            from io import StringIO
            txt = url_text(url)
            df = pd.read_csv(StringIO(txt), skiprows=1)
            months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
            rows = []
            for _, r in df.iterrows():
                try: year = int(r['Year'])
                except Exception: continue
                for mi, m in enumerate(months, start=1):
                    try:
                        val = float(r[m])
                        if val > -900:
                            rows.append({'date': pd.Timestamp(year=year, month=mi, day=1), 'temp_anom': val/100.0})
                    except Exception: pass
            out = pd.DataFrame(rows).dropna()
            if len(out) > 100: return out
        except Exception:
            pass
    raise RuntimeError('Could not load GISTEMP')

def load_co2():
    url = 'https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_mm_mlo.txt'
    txt = url_text(url)
    rows = []
    for line in txt.splitlines():
        if not line.strip() or line.startswith('#'): continue
        p = line.split()
        if len(p) >= 4:
            try:
                year, month, co2 = int(p[0]), int(p[1]), float(p[3])
                if co2 > 0:
                    rows.append({'date': pd.Timestamp(year=year, month=month, day=1), 'co2': co2})
            except Exception: pass
    out = pd.DataFrame(rows).dropna()
    if len(out) < 100: raise RuntimeError('Could not load CO2')
    return out

def load_psl_index(url, value_name):
    txt = url_text(url)
    rows = []
    for line in txt.splitlines():
        p = line.split()
        if len(p) == 13:
            try:
                year = int(float(p[0])); vals = [float(x) for x in p[1:13]]
                if year < 1800 or year > 2100: continue
                for mi, val in enumerate(vals, start=1):
                    if abs(val) < 90:
                        rows.append({'date': pd.Timestamp(year=year, month=mi, day=1), value_name: val})
            except Exception: pass
    out = pd.DataFrame(rows).dropna()
    if len(out) < 50: raise RuntimeError(f'Could not parse {value_name}')
    return out

def load_oni(): return load_psl_index('https://psl.noaa.gov/data/correlation/oni.data', 'oni')
def load_pdo(): return load_psl_index('https://psl.noaa.gov/data/correlation/pdo.data', 'pdo')
def load_nao(): return load_psl_index('https://psl.noaa.gov/data/correlation/nao.data', 'nao')

print('='*60)
print('PETU-MACRO-CLIMATE C1 CLIMATE TELECONNECTION AUDIT')
print('='*60)
print('Fetching climate indices...')

failures, datasets = [], []
for name, loader in [('GISTEMP', load_gistemp), ('CO2', load_co2), ('ONI', load_oni), ('PDO', load_pdo), ('NAO', load_nao)]:
    try:
        df = loader(); datasets.append(df)
        print('  OK', name, 'rows:', len(df))
    except Exception as e:
        failures.append({'dataset': name, 'error': str(e)})
        print('  FAIL', name, str(e))

if len(datasets) < 3:
    raise RuntimeError('Too few datasets loaded.')

clim = datasets[0]
for df in datasets[1:]:
    clim = clim.merge(df, on='date', how='outer')
clim = clim.sort_values('date')
clim = clim[(clim['date'].dt.year >= START_YEAR) & (clim['date'].dt.year <= END_YEAR)]
clim = clim.set_index('date').asfreq('MS').reset_index()
for col in ['temp_anom','co2','oni','pdo','nao']:
    if col in clim.columns:
        clim[col] = clim[col].interpolate(limit_direction='both')
required = [c for c in ['temp_anom','co2','oni','pdo','nao'] if c in clim.columns]
clim = clim.dropna(subset=required)
print('Merged climate rows:', len(clim), 'variables:', required)

# ----------------------------
# Window features
# ----------------------------

def window_features(df, start_idx):
    w = df.iloc[start_idx:start_idx+WINDOW_MONTHS].copy()
    if len(w) < WINDOW_MONTHS: return None
    temp = w['temp_anom'].values.astype(float)
    co2 = w['co2'].values.astype(float) if 'co2' in w.columns else np.zeros_like(temp)
    oni = w['oni'].values.astype(float) if 'oni' in w.columns else np.zeros_like(temp)
    pdo = w['pdo'].values.astype(float) if 'pdo' in w.columns else np.zeros_like(temp)
    nao = w['nao'].values.astype(float) if 'nao' in w.columns else np.zeros_like(temp)

    temp_z, co2_z, oni_z, pdo_z, nao_z = map(zscore_local, [temp, co2, oni, pdo, nao])
    dtemp = np.diff(temp); dco2 = np.diff(co2)
    temp_trend = np.polyfit(np.arange(len(temp)), temp, 1)[0]
    co2_trend = np.polyfit(np.arange(len(co2)), co2, 1)[0] if np.std(co2) > 1e-12 else 0.0
    temp_var = np.std(temp); temp_change_var = np.std(dtemp) if len(dtemp) else 0.0
    co2_rel = np.mean(co2) / 420.0

    H_raw = np.mean([np.mean(temp)+1.0, abs(temp_trend)*120.0, co2_rel, abs(co2_trend)*12.0/3.0, np.mean(np.abs(temp_z))])

    ent_dtemp = entropy_norm(dtemp, bins=16)
    variability_order = 1.0/(1.0+temp_var)
    change_order = 1.0/(1.0+temp_change_var*10.0)
    trend_coherence = 1.0/(1.0 + np.std(dtemp)/(abs(np.mean(dtemp))+1e-3))
    S_raw = np.mean([variability_order, change_order, 1.0-ent_dtemp, max(0.0, autocorr(temp,12)), trend_coherence])

    idx = np.vstack([oni_z, pdo_z, nao_z])
    corr_vals = []
    for i in range(idx.shape[0]):
        for j in range(i+1, idx.shape[0]):
            if np.std(idx[i]) > 1e-12 and np.std(idx[j]) > 1e-12:
                corr_vals.append(abs(np.corrcoef(idx[i], idx[j])[0,1]))
    tele_corr = float(np.mean(corr_vals)) if corr_vals else 0.0
    enso_temp = abs(np.corrcoef(oni_z, temp_z)[0,1]) if np.std(oni_z)>1e-12 and np.std(temp_z)>1e-12 else 0.0
    pdo_temp = abs(np.corrcoef(pdo_z, temp_z)[0,1]) if np.std(pdo_z)>1e-12 and np.std(temp_z)>1e-12 else 0.0
    memory = np.mean([max(0,autocorr(oni,1)), max(0,autocorr(pdo,1)), max(0,autocorr(nao,1)), max(0,autocorr(temp,1))])
    L_raw = np.mean([tele_corr, enso_temp, pdo_temp, memory, max(0.0, autocorr(temp,12))])

    extreme_temp = np.mean(np.abs(temp_z) > 1.5)
    extreme_enso = np.mean(np.abs(oni_z) > 1.5)
    abrupt_change = np.mean(np.abs(zscore_local(dtemp)) > 1.5) if len(dtemp)>3 else 0.0
    predictability = max(0.0, autocorr(temp,1))
    seasonal_memory = max(0.0, autocorr(temp,12))
    Phi_resilience_raw = np.mean([1-extreme_temp, 1-extreme_enso, 1-abrupt_change, predictability, seasonal_memory, variability_order])

    tele_stress = np.mean([abs(np.mean(oni_z)), abs(np.mean(pdo_z)), abs(np.mean(nao_z)), np.std(oni_z), np.std(pdo_z), np.std(nao_z)])
    Climate_pathology_raw = np.mean([extreme_temp, extreme_enso, abrupt_change, min(1.0,temp_var), min(1.0,temp_change_var*10.0), min(1.0,tele_stress/2.0)])
    Heat_stress_raw = np.mean([np.mean(temp_z>1.0), np.mean(temp_z>1.5), max(0.0,np.mean(temp_z)), abs(temp_trend)*120.0])
    Teleconnection_stress_raw = np.mean([np.mean(np.abs(oni_z)>1.5), np.mean(np.abs(pdo_z)>1.5), np.mean(np.abs(nao_z)>1.5), tele_stress/2.0, 1.0/(1.0+tele_corr)])
    Abrupt_shift_raw = np.mean([abrupt_change, min(1.0,temp_change_var*10.0), 1.0/(1.0+max(0.0, autocorr(temp,1)))])

    return {'window_start':str(w['date'].iloc[0].date()), 'window_end':str(w['date'].iloc[-1].date()), 'n_months':len(w),
            'mean_temp_anom':float(np.mean(temp)), 'temp_trend':float(temp_trend), 'temp_std':float(temp_var), 'temp_change_std':float(temp_change_var),
            'mean_co2':float(np.mean(co2)), 'co2_trend':float(co2_trend), 'oni_mean':float(np.mean(oni)), 'pdo_mean':float(np.mean(pdo)), 'nao_mean':float(np.mean(nao)),
            'tele_corr':float(tele_corr), 'enso_temp_coupling':float(enso_temp), 'pdo_temp_coupling':float(pdo_temp), 'memory':float(memory),
            'extreme_temp_fraction':float(extreme_temp), 'extreme_enso_fraction':float(extreme_enso), 'abrupt_change_fraction':float(abrupt_change),
            'H_raw':float(H_raw), 'S_raw':float(S_raw), 'L_raw':float(L_raw), 'Phi_resilience_raw':float(Phi_resilience_raw),
            'Climate_pathology_raw':float(Climate_pathology_raw), 'Heat_stress_raw':float(Heat_stress_raw),
            'Teleconnection_stress_raw':float(Teleconnection_stress_raw), 'Abrupt_shift_raw':float(Abrupt_shift_raw)}

features = []
for start_idx in tqdm(range(0, len(clim)-WINDOW_MONTHS+1, STEP_MONTHS), desc='Climate windows'):
    row = window_features(clim, start_idx)
    if row: features.append(row)
features = pd.DataFrame(features)
if len(features) < 50: raise RuntimeError('Too few climate windows.')

for col in ['H_raw','S_raw','L_raw','Phi_resilience_raw','Climate_pathology_raw','Heat_stress_raw','Teleconnection_stress_raw','Abrupt_shift_raw']:
    features[col.replace('_raw','')] = normalize01(features[col].values)
features['Phi_HSL_epsilon'] = (features['H']+EPSILON)*(features['S']+EPSILON)*(features['L']+EPSILON)
features['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(features['H'],features['S'],features['L'])]
features['Functional_unity'] = features['Phi_HSL_epsilon'] * features['Triadic_balance']
features['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(features['H'],features['S'],features['L'])]

for name, col, q in [('resilient_high_flag','Phi_resilience',0.5),('pathology_high_flag','Climate_pathology',0.5),('heat_high_flag','Heat_stress',0.75),('teleconnection_high_flag','Teleconnection_stress',0.75),('abrupt_high_flag','Abrupt_shift',0.75)]:
    features[name] = features[col] >= features[col].quantile(q)
features['triadic_disproportion_flag'] = (features['Triadic_balance'] <= features['Triadic_balance'].quantile(0.25)) | (features['Dominance_index'] >= features['Dominance_index'].quantile(0.75))

features['window_mid'] = pd.to_datetime(features['window_start']) + (pd.to_datetime(features['window_end']) - pd.to_datetime(features['window_start']))/2
features = features.sort_values('window_mid').reset_index(drop=True)

dyn_rows = []
for i in range(1, len(features)):
    prev, cur = features.iloc[i-1], features.iloc[i]
    dyn_rows.append({'window_start':cur['window_start'], 'window_end':cur['window_end'],
        'dH':cur['H']-prev['H'], 'dS':cur['S']-prev['S'], 'dL':cur['L']-prev['L'],
        'dPhi_resilience':cur['Phi_resilience']-prev['Phi_resilience'], 'dFunctional_unity':cur['Functional_unity']-prev['Functional_unity'],
        'dClimate_pathology':cur['Climate_pathology']-prev['Climate_pathology'], 'dHeat_stress':cur['Heat_stress']-prev['Heat_stress'],
        'dTeleconnection_stress':cur['Teleconnection_stress']-prev['Teleconnection_stress'], 'dAbrupt_shift':cur['Abrupt_shift']-prev['Abrupt_shift'],
        'dBalance':cur['Triadic_balance']-prev['Triadic_balance'], 'dDominance':cur['Dominance_index']-prev['Dominance_index']})
dynamic_features = pd.DataFrame(dyn_rows)

# ----------------------------
# Models and summaries
# ----------------------------

def regression(data, X_cols, y_col, label):
    d = data[X_cols+[y_col]].dropna()
    if len(d) < 20: return {'test':label,'n':int(len(d)),'r2':None,'mae':None,'spearman_true_pred':None,'p_value':None}
    X, y = d[X_cols].values.astype(float), d[y_col].values.astype(float)
    model = Ridge(alpha=1.0).fit(X,y); pred = model.predict(X)
    r,p = safe_spearman(y,pred)
    return {'test':label,'n':int(len(d)),'r2':float(r2_score(y,pred)),'mae':float(mean_absolute_error(y,pred)),'spearman_true_pred':r,'p_value':p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols+[target]].dropna()
    if len(d)<30 or len(d[target].unique())<2: return None
    X, y = d[feature_cols].values.astype(float), d[target].astype(int).values
    clf = LogisticRegression(max_iter=1000, class_weight='balanced').fit(X,y)
    pred = clf.predict_proba(X)[:,1]
    return {'feature_set':label,'target':target,'n':int(len(d)),'auc':float(roc_auc_score(y,pred))}

data_summary = pd.DataFrame([{'n_months':int(len(clim)), 'start_date':str(clim['date'].min().date()), 'end_date':str(clim['date'].max().date()), 'variables':','.join(required), 'n_windows':int(len(features)), 'window_months':WINDOW_MONTHS, 'step_months':STEP_MONTHS}])

genesis_summary = pd.DataFrame([
    regression(features,['H'],'S','C1_H_to_S'), regression(features,['H'],'L','C1_H_to_L'), regression(features,['S'],'L','C1_S_to_L'), regression(features,['H','S'],'L','C1_H_plus_S_to_L'),
    regression(features,['H','S','L'],'Phi_resilience','C1_HSL_to_Phi_resilience'), regression(features,['H','S','L'],'Functional_unity','C1_HSL_to_Functional_Unity'),
    regression(features,['H','S','L'],'Climate_pathology','C1_HSL_to_Climate_Pathology'), regression(features,['H','S','L','Triadic_balance','Dominance_index'],'Climate_pathology','C1_Full_to_Climate_Pathology'),
    regression(features,['H','S','L','Triadic_balance','Dominance_index'],'Phi_resilience','C1_Full_to_Phi_resilience'), regression(features,['H','S','L'],'Heat_stress','C1_HSL_to_Heat_Stress'),
    regression(features,['H','S','L'],'Teleconnection_stress','C1_HSL_to_Teleconnection_Stress'), regression(features,['H','S','L'],'Abrupt_shift','C1_HSL_to_Abrupt_Shift')])

def get_mae(s,t):
    x=s[s['test']==t]; return None if len(x)==0 else x.iloc[0]['mae']
H_L,S_L,HS_L = get_mae(genesis_summary,'C1_H_to_L'), get_mae(genesis_summary,'C1_S_to_L'), get_mae(genesis_summary,'C1_H_plus_S_to_L')
emergence_contrast = pd.DataFrame([{'level':'macro_climate_regime','H_to_L_mae':H_L,'S_to_L_mae':S_L,'H_plus_S_to_L_mae':HS_L,'HS_improves_over_H':H_L-HS_L,'HS_improves_over_S':S_L-HS_L,'PETU_prediction_supported':bool(HS_L < H_L and HS_L < S_L)}])

dynamic_summary = pd.DataFrame([
    regression(dynamic_features,['dH'],'dS','C1_DYN_dH_to_dS'), regression(dynamic_features,['dH'],'dL','C1_DYN_dH_to_dL'), regression(dynamic_features,['dS'],'dL','C1_DYN_dS_to_dL'), regression(dynamic_features,['dH','dS'],'dL','C1_DYN_dH_plus_dS_to_dL'),
    regression(dynamic_features,['dH','dS','dL'],'dPhi_resilience','C1_DYN_dHSL_to_dPhi_resilience'), regression(dynamic_features,['dH','dS','dL'],'dFunctional_unity','C1_DYN_dHSL_to_dFunctional_Unity'), regression(dynamic_features,['dH','dS','dL'],'dClimate_pathology','C1_DYN_dHSL_to_dClimate_Pathology'), regression(dynamic_features,['dH','dS','dL'],'dHeat_stress','C1_DYN_dHSL_to_dHeat'), regression(dynamic_features,['dH','dS','dL'],'dTeleconnection_stress','C1_DYN_dHSL_to_dTeleconnection'), regression(dynamic_features,['dH','dS','dL'],'dAbrupt_shift','C1_DYN_dHSL_to_dAbrupt')])

contrast_defs=[('resilient_vs_fragile','resilient_high_flag'),('pathology_high_vs_low','pathology_high_flag'),('heat_high_vs_other','heat_high_flag'),('teleconnection_high_vs_other','teleconnection_high_flag'),('abrupt_high_vs_other','abrupt_high_flag'),('disproportion_vs_proportion','triadic_disproportion_flag')]
contrast_metrics=['H','S','L','Phi_HSL_epsilon','Triadic_balance','Functional_unity','Dominance_index','Phi_resilience','Climate_pathology','Heat_stress','Teleconnection_stress','Abrupt_shift','mean_temp_anom','temp_trend','temp_std','tele_corr','memory','extreme_temp_fraction','abrupt_change_fraction']
contrast_rows=[]
for cname, flag in contrast_defs:
    A=features[features[flag]==True]; B=features[features[flag]==False]
    for col in contrast_metrics:
        stat,p=safe_mw(A[col],B[col])
        contrast_rows.append({'contrast':cname,'metric':col,'groupA_mean':float(A[col].mean()),'groupB_mean':float(B[col].mean()),'delta_A_minus_B':float(A[col].mean()-B[col].mean()),'pct_delta':float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)),'mannwhitney_stat':stat,'p_value':p})
contrast_summary=pd.DataFrame(contrast_rows)

class_rows=[]
targets=['resilient_high_flag','pathology_high_flag','heat_high_flag','teleconnection_high_flag','abrupt_high_flag','triadic_disproportion_flag']
feature_sets=[(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
for target in targets:
    for cols,label in feature_sets:
        r=auc_model(features,cols,target,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)

gain_rows=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x=d[d['feature_set']==fs]; return None if len(x)==0 else float(x.iloc[0]['auc'])
    aH,aHS,aHSL,aFull=auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gain_rows.append({'target':target,'auc_H':aH,'auc_HS':aHS,'auc_HSL':aHSL,'auc_full':aFull,'gain_HSL_over_H':aHSL-aH,'gain_HSL_over_HS':aHSL-aHS,'gain_full_over_HSL':aFull-aHSL})
classification_gain_summary=pd.DataFrame(gain_rows)

def classify_phase(r):
    if r['triadic_disproportion_flag']: return 'triadic_disproportion'
    if r['Heat_stress']>=features['Heat_stress'].quantile(0.75) and r['H']>=features['H'].median(): return 'high_H_heat_stress'
    if r['Teleconnection_stress']>=features['Teleconnection_stress'].quantile(0.75): return 'teleconnection_L_stress'
    if r['Abrupt_shift']>=features['Abrupt_shift'].quantile(0.75): return 'abrupt_shift_pathology'
    if r['Phi_resilience']>=features['Phi_resilience'].median() and r['Triadic_balance']>=features['Triadic_balance'].median(): return 'resilient_phi_integrated'
    if r['S']>=features['S'].median() and r['L']<=features['L'].quantile(0.25): return 'S_regime_low_link'
    return 'transitional'
features['PETU_C1_phase']=features.apply(classify_phase,axis=1)
phase_summary=features.groupby('PETU_C1_phase').agg(n_windows=('window_start','count'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi_HSL=('Phi_HSL_epsilon','mean'),mean_resilience=('Phi_resilience','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_pathology=('Climate_pathology','mean'),mean_heat=('Heat_stress','mean'),mean_teleconnection=('Teleconnection_stress','mean'),mean_abrupt=('Abrupt_shift','mean')).reset_index().sort_values('n_windows',ascending=False)

traj_rows=[]
for flag in ['heat_high_flag','teleconnection_high_flag','pathology_high_flag','resilient_high_flag','abrupt_high_flag']:
    for i in range(1,len(features)):
        prev,cur=features.iloc[i-1],features.iloc[i]
        traj_rows.append({'flag':flag,'transition':f"{int(prev[flag])}->{int(cur[flag])}",'dH':cur['H']-prev['H'],'dS':cur['S']-prev['S'],'dL':cur['L']-prev['L'],'dPhi':cur['Phi_resilience']-prev['Phi_resilience'],'dUnity':cur['Functional_unity']-prev['Functional_unity'],'dPathology':cur['Climate_pathology']-prev['Climate_pathology'],'dHeat':cur['Heat_stress']-prev['Heat_stress'],'dTeleconnection':cur['Teleconnection_stress']-prev['Teleconnection_stress'],'dAbrupt':cur['Abrupt_shift']-prev['Abrupt_shift'],'dBalance':cur['Triadic_balance']-prev['Triadic_balance'],'dDominance':cur['Dominance_index']-prev['Dominance_index']})
trajectory_summary=pd.DataFrame(traj_rows).groupby(['flag','transition']).agg(n=('dH','count'),mean_dH=('dH','mean'),mean_dS=('dS','mean'),mean_dL=('dL','mean'),mean_dPhi=('dPhi','mean'),mean_dUnity=('dUnity','mean'),mean_dPathology=('dPathology','mean'),mean_dHeat=('dHeat','mean'),mean_dTeleconnection=('dTeleconnection','mean'),mean_dAbrupt=('dAbrupt','mean'),mean_dBalance=('dBalance','mean'),mean_dDominance=('dDominance','mean')).reset_index()

# Save and print
paths={'monthly_climate_data':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_monthly_climate_data.csv','features':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_features.csv','dynamic_features':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_dynamic_features.csv','data_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_data_summary.csv','genesis_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_genesis_summary.csv','emergence_contrast':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_emergence_contrast.csv','dynamic_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_dynamic_summary.csv','contrast_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_contrast_summary.csv','classification_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_classification_summary.csv','classification_gain_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_classification_gain_summary.csv','phase_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_phase_summary.csv','trajectory_summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_trajectory_summary.csv','failures':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_failures.csv','summary':f'{OUTDIR}/PETU_MACRO_CLIMATE_C1_summary.json'}
clim.to_csv(paths['monthly_climate_data'],index=False); features.to_csv(paths['features'],index=False); dynamic_features.to_csv(paths['dynamic_features'],index=False); data_summary.to_csv(paths['data_summary'],index=False); genesis_summary.to_csv(paths['genesis_summary'],index=False); emergence_contrast.to_csv(paths['emergence_contrast'],index=False); dynamic_summary.to_csv(paths['dynamic_summary'],index=False); contrast_summary.to_csv(paths['contrast_summary'],index=False); classification_summary.to_csv(paths['classification_summary'],index=False); classification_gain_summary.to_csv(paths['classification_gain_summary'],index=False); phase_summary.to_csv(paths['phase_summary'],index=False); trajectory_summary.to_csv(paths['trajectory_summary'],index=False); pd.DataFrame(failures).to_csv(paths['failures'],index=False)
summary={'pipeline':'PETU-MACRO-CLIMATE C1 Climate Teleconnection Audit','domain':'macro natural climate / NASA GISTEMP / NOAA CO2 / NOAA PSL climate indices','n_months':int(len(clim)),'n_windows':int(len(features)),'n_dynamic_windows':int(len(dynamic_features)),'start_year':START_YEAR,'end_year':END_YEAR,'window_months':WINDOW_MONTHS,'step_months':STEP_MONTHS,'variables':required,'epsilon':EPSILON,'hypothesis':'Climate regime stability and pathology arise from triadic proportion/disproportion of H energetic support, S regime structure, and L teleconnection linkage.','next_step':'C2: gridded climate fields / regional teleconnection networks; K1: cosmological large-scale structure audit.'}
with open(paths['summary'],'w') as f: json.dump(summary,f,indent=2)

for title, obj in [('PETU-MACRO-CLIMATE C1 DATA SUMMARY',data_summary),('PETU-MACRO-CLIMATE C1 GENESIS SUMMARY',genesis_summary),('PETU-MACRO-CLIMATE C1 EMERGENCE CONTRAST',emergence_contrast),('PETU-MACRO-CLIMATE C1 DYNAMIC SUMMARY',dynamic_summary),('PETU-MACRO-CLIMATE C1 CONTRAST SUMMARY',contrast_summary),('PETU-MACRO-CLIMATE C1 CLASSIFICATION GAIN SUMMARY',classification_gain_summary),('PETU-MACRO-CLIMATE C1 PHASE SUMMARY',phase_summary),('PETU-MACRO-CLIMATE C1 TRAJECTORY SUMMARY',trajectory_summary)]:
    print('\n'+'='*60); print(title); print('='*60); print(obj)
print('\n'+'='*60); print('PETU-MACRO-CLIMATE C1 FINAL SUMMARY'); print('='*60); print(json.dumps(summary,indent=2))
if failures:
    print('\n'+'='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

plt.figure(figsize=(8,5)); plt.scatter(features['H']+features['S'],features['L'],s=22,alpha=.65); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-CLIMATE C1: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_HS_to_L.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Phi_HSL_epsilon'],features['Phi_resilience'],s=22,alpha=.65); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_resilience'); plt.title('PETU-CLIMATE C1: HSL unity vs climate resilience'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_PhiHSL_resilience.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Dominance_index'],features['Climate_pathology'],s=22,alpha=.65); plt.xlabel('Dominance index'); plt.ylabel('Climate pathology'); plt.title('PETU-CLIMATE C1: dominance and pathology'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_Dominance_Pathology.png',dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(phase_summary['PETU_C1_phase'],phase_summary['n_windows']); plt.xticks(rotation=60); plt.ylabel('Windows'); plt.title('PETU-CLIMATE C1: phase counts'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_C1_phase_counts.png',dpi=220); plt.show()
zip_base='/content/PETU_MACRO_CLIMATE_C1_Climate_Teleconnection_Audit_results'; zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

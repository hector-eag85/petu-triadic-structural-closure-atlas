# ============================================================
# PETU-MACRO-CLIMATE C2
# Gridded Regional Climate / Teleconnection Network Audit
#
# Objetivo:
#   Segunda prueba climática macro-natural de PETU / LETU.
#   C1 confirmó PETU en índices climáticos globales.
#   C2 introduce espacialidad: regiones, campos gridded y redes de
#   teleconexión regional.
#
# Sistema:
#   Campos climáticos mensuales NOAA/PSL vía OPeNDAP:
#     - NCEP/NCAR surface air temperature
#     - NCEP/NCAR sea level pressure
#     - NOAA ERSSTv5 sea surface temperature
#
# Traducción PETU:
#   H = soporte energético/radiativo regional:
#       anomalía térmica, tendencia térmica, estrés cálido.
#
#   S = estructura del régimen climático regional:
#       estabilidad temporal, baja volatilidad, orden de cambios,
#       memoria estacional/regímenes.
#
#   L = vínculo/teleconexión espacial:
#       acoplamiento de cada región con otras regiones, memoria,
#       coherencia con red climática regional.
#
#   Phi = unidad/resiliencia climática regional:
#       estabilidad/predictibilidad, baja extremalidad y continuidad.
#
# Hipótesis PETU-C2:
#   1. H + S -> L
#      El vínculo/teleconexión regional se explica mejor por soporte + estructura
#      que por H o S aislados.
#
#   2. H + S + L -> Phi
#      La resiliencia climática regional se reconstruye desde HSL.
#
#   3. Patología climática regional
#      Extremos, cambios abruptos, desacoplamientos o hiperacoplamientos
#      aparecen como desproporción pericorética de H-S-L.
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install numpy pandas scipy scikit-learn matplotlib tqdm xarray netCDF4 bottleneck

import os, json, math, warnings, shutil
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import xarray as xr

from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

# ============================================================
# CONFIG
# ============================================================

OUTDIR = "/content/PETU_MACRO_CLIMATE_C2_Gridded_Regional_Teleconnection_Audit"
os.makedirs(OUTDIR, exist_ok=True)

START_YEAR = 1982
END_YEAR = 2023
WINDOW_MONTHS = 60
STEP_MONTHS = 3
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# Data sources. If one dataset fails, the pipeline continues with the others.
DATASETS = {
    "air": {
        "url": "https://psl.noaa.gov/thredds/dodsC/Datasets/ncep.reanalysis/surface/air.mon.mean.nc",
        "var_candidates": ["air"],
        "rename": "air_temp"
    },
    "slp": {
        "url": "https://psl.noaa.gov/thredds/dodsC/Datasets/ncep.reanalysis/surface/slp.mon.mean.nc",
        "var_candidates": ["slp"],
        "rename": "slp"
    },
    "sst": {
        "url": "https://psl.noaa.gov/thredds/dodsC/Datasets/noaa.ersst.v5/sst.mnmean.nc",
        "var_candidates": ["sst"],
        "rename": "sst"
    }
}

# Regional boxes: lat_min, lat_max, lon_min, lon_max in degrees east 0..360.
REGIONS = {
    "ENSO_Nino34": (-5, 5, 190, 240),
    "North_Pacific": (30, 60, 150, 230),
    "North_Atlantic": (25, 60, 290, 350),
    "Arctic": (65, 85, 0, 360),
    "Europe": (35, 60, 350, 40),
    "Mediterranean": (30, 45, 350, 40),
    "Sahel": (10, 20, 340, 40),
    "Amazon": (-15, 5, 285, 315),
    "India_Monsoon": (5, 30, 65, 95),
    "Australia": (-40, -10, 110, 155),
    "US_West": (30, 50, 235, 255),
    "US_East": (25, 50, 280, 300),
    "Southern_Ocean": (-60, -40, 0, 360),
    "Tropical_Atlantic": (-10, 20, 300, 360),
    "Tropical_Indian": (-15, 15, 50, 100)
}

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]
        b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None

def autocorr(x, lag=1):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) <= lag + 3:
        return 0.0
    a = x[:-lag]
    b = x[lag:]
    if np.std(a) < 1e-12 or np.std(b) < 1e-12:
        return 0.0
    return float(np.corrcoef(a, b)[0,1])

def entropy_norm(values, bins=16):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 5:
        return 0.0
    hist, _ = np.histogram(values, bins=bins)
    p = hist.astype(float)
    if p.sum() <= 0:
        return 0.0
    p = p / p.sum()
    ent = -np.sum(p*np.log(p+1e-12))
    return float(ent / np.log(len(p)+1e-12))

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def zscore(x):
    x = np.asarray(x, dtype=float)
    return (x - np.nanmean(x)) / (np.nanstd(x) + 1e-12)

def standardize_monthly_anomaly(series):
    s = series.copy()
    s["month"] = s["date"].dt.month
    vals = []
    for m, g in s.groupby("month"):
        mu = g["value"].mean()
        sd = g["value"].std() + 1e-12
        vals.append((g.index, (g["value"] - mu) / sd))
    out = pd.Series(index=s.index, dtype=float)
    for idx, v in vals:
        out.loc[idx] = v
    return out.values.astype(float)

def fix_lon(ds):
    # Convert longitude coordinate to 0..360 when needed.
    lon_name = "lon" if "lon" in ds.coords else ("longitude" if "longitude" in ds.coords else None)
    if lon_name is None:
        return ds, None
    lon = ds[lon_name]
    if float(lon.min()) < 0:
        ds = ds.assign_coords({lon_name: (lon % 360)}).sortby(lon_name)
    return ds, lon_name

def get_lat_lon_names(ds):
    lat_name = "lat" if "lat" in ds.coords else ("latitude" if "latitude" in ds.coords else None)
    lon_name = "lon" if "lon" in ds.coords else ("longitude" if "longitude" in ds.coords else None)
    return lat_name, lon_name

def select_box(da, lat_name, lon_name, lat_min, lat_max, lon_min, lon_max):
    # Latitude can be ascending or descending.
    lat_vals = da[lat_name].values
    if lat_vals[0] > lat_vals[-1]:
        lat_slice = slice(lat_max, lat_min)
    else:
        lat_slice = slice(lat_min, lat_max)
    sub = da.sel({lat_name: lat_slice})
    if lon_min <= lon_max:
        sub = sub.sel({lon_name: slice(lon_min, lon_max)})
    else:
        sub1 = sub.sel({lon_name: slice(lon_min, 360)})
        sub2 = sub.sel({lon_name: slice(0, lon_max)})
        sub = xr.concat([sub1, sub2], dim=lon_name)
    return sub

def area_weighted_mean(da, lat_name):
    weights = np.cos(np.deg2rad(da[lat_name]))
    try:
        return da.weighted(weights).mean(dim=[d for d in da.dims if d != "time"], skipna=True)
    except Exception:
        return da.mean(dim=[d for d in da.dims if d != "time"], skipna=True)

# ============================================================
# LOAD GRIDDED DATA
# ============================================================

print("============================================================")
print("PETU-MACRO-CLIMATE C2 GRIDDED REGIONAL TELECONNECTION AUDIT")
print("============================================================")
print("Opening NOAA/PSL gridded datasets...")

failures = []
regional_frames = []
loaded_variables = []

for key, info in DATASETS.items():
    try:
        ds = xr.open_dataset(info["url"], decode_times=True)
        ds, lon_name = fix_lon(ds)
        lat_name, lon_name = get_lat_lon_names(ds)
        if lat_name is None or lon_name is None:
            raise RuntimeError("lat/lon coordinates not found")
        var = None
        for cand in info["var_candidates"]:
            if cand in ds.data_vars:
                var = cand
                break
        if var is None:
            var = list(ds.data_vars)[0]
        da = ds[var]
        # Restrict time; suppress huge loads until regional selection.
        da = da.sel(time=slice(f"{START_YEAR}-01-01", f"{END_YEAR}-12-31"))
        if da.sizes.get("time", 0) < 120:
            raise RuntimeError("too few months after time selection")

        rows = []
        for region, box in tqdm(REGIONS.items(), desc=f"regions {key}"):
            try:
                sub = select_box(da, lat_name, lon_name, *box)
                ts = area_weighted_mean(sub, lat_name).load()
                df = pd.DataFrame({"date": pd.to_datetime(ts["time"].values), "value": ts.values.astype(float)})
                df = df.dropna()
                if len(df) < 120:
                    continue
                df["region"] = region
                df["variable"] = info["rename"]
                rows.append(df)
            except Exception as e:
                failures.append({"dataset": key, "region": region, "error": str(e)})
        if rows:
            allr = pd.concat(rows, ignore_index=True)
            regional_frames.append(allr)
            loaded_variables.append(info["rename"])
            print("  OK", key, "regional rows:", len(allr))
        else:
            raise RuntimeError("no regional rows created")
    except Exception as e:
        failures.append({"dataset": key, "region": "ALL", "error": str(e)})
        print("  FAIL", key, str(e))

if len(regional_frames) == 0:
    raise RuntimeError("No gridded datasets loaded. Check internet/OPeNDAP access.")

long_df = pd.concat(regional_frames, ignore_index=True)
# Pivot to one row per date-region.
wide = long_df.pivot_table(index=["date", "region"], columns="variable", values="value", aggfunc="mean").reset_index()
wide = wide.sort_values(["region", "date"])

# Add monthly standardized anomalies for each region-variable.
for var in loaded_variables:
    anom_col = var + "_anom"
    wide[anom_col] = np.nan
    for region, g in wide.groupby("region"):
        idx = g.index
        tmp = pd.DataFrame({"date": g["date"], "value": g[var].astype(float)})
        wide.loc[idx, anom_col] = standardize_monthly_anomaly(tmp)

# Require at least air_temp or sst plus another field.
anom_cols = [v + "_anom" for v in loaded_variables if v + "_anom" in wide.columns]
if len(anom_cols) < 1:
    raise RuntimeError("No anomaly columns available.")

print("Loaded variables:", loaded_variables)
print("Regional monthly table rows:", len(wide))

# ============================================================
# FEATURE EXTRACTION
# ============================================================

# Prepare regional time series dict.
region_series = {}
for region, g in wide.groupby("region"):
    g = g.sort_values("date").reset_index(drop=True)
    # Keep only complete rows for anomaly columns.
    g = g.dropna(subset=anom_cols)
    if len(g) >= WINDOW_MONTHS + 12:
        region_series[region] = g

regions_available = list(region_series.keys())
if len(regions_available) < 5:
    raise RuntimeError("Too few regions with data.")

# Common dates across regions for network teleconnections.
common_dates = None
for region, g in region_series.items():
    ds = set(g["date"])
    common_dates = ds if common_dates is None else common_dates.intersection(ds)
common_dates = sorted(list(common_dates))
common_dates = [d for d in common_dates if START_YEAR <= pd.Timestamp(d).year <= END_YEAR]
common = pd.DataFrame({"date": common_dates})

# Build region x time matrices for primary variables.
primary_var = "air_temp_anom" if "air_temp_anom" in anom_cols else anom_cols[0]
aux_var = "slp_anom" if "slp_anom" in anom_cols else ("sst_anom" if "sst_anom" in anom_cols else primary_var)

matrix = {}
for var in set([primary_var, aux_var] + anom_cols):
    mat_rows = []
    for region in regions_available:
        g = region_series[region][["date", var]].rename(columns={var: region})
        merged = common.merge(g, on="date", how="left")
        mat_rows.append(merged[region].values.astype(float))
    matrix[var] = np.vstack(mat_rows)  # regions x time

common_dates = pd.to_datetime(common["date"])

features = []
network_rows = []

for start in tqdm(range(0, len(common_dates) - WINDOW_MONTHS + 1, STEP_MONTHS), desc="C2 windows"):
    end = start + WINDOW_MONTHS
    dates_w = common_dates.iloc[start:end]

    # Teleconnection network on primary variable anomalies across regions.
    X = matrix[primary_var][:, start:end]
    if np.any(~np.isfinite(X)):
        continue
    corr = np.corrcoef(X)
    abs_corr = np.abs(corr)
    np.fill_diagonal(abs_corr, 0.0)

    # Thresholded network: top quartile of off-diagonal absolute correlations.
    off = abs_corr[np.triu_indices_from(abs_corr, k=1)]
    threshold = np.nanquantile(off, 0.75) if len(off) else 1.0
    adj = (abs_corr >= threshold).astype(float)
    np.fill_diagonal(adj, 0.0)
    density = adj.sum() / (adj.shape[0]*(adj.shape[0]-1) + 1e-12)
    mean_link = off.mean() if len(off) else 0.0
    max_link = off.max() if len(off) else 0.0

    network_rows.append({
        "window_start": str(dates_w.iloc[0].date()),
        "window_end": str(dates_w.iloc[-1].date()),
        "network_mean_abs_corr": float(mean_link),
        "network_max_abs_corr": float(max_link),
        "network_density_topquartile": float(density),
        "network_threshold": float(threshold)
    })

    for ri, region in enumerate(regions_available):
        # Local anomaly series.
        temp = matrix[primary_var][ri, start:end]
        aux = matrix[aux_var][ri, start:end]
        all_local = []
        for var in anom_cols:
            all_local.append(matrix[var][ri, start:end])
        all_local = np.vstack(all_local)

        # H: regional energetic support/stress.
        dtemp = np.diff(temp)
        trend = np.polyfit(np.arange(len(temp)), temp, 1)[0]
        heat_intensity = np.mean(temp > 1.0)
        thermal_displacement = np.mean(np.abs(temp))
        H_raw = np.mean([
            max(0.0, np.mean(temp) + 1.5) / 3.0,
            abs(trend) * 60.0,
            heat_intensity,
            thermal_displacement / 2.5,
            np.std(temp) / 2.0
        ])

        # S: regime structure/order.
        var_order = 1.0 / (1.0 + np.std(temp))
        change_order = 1.0 / (1.0 + np.std(dtemp) * 3.0)
        ent_order = 1.0 - entropy_norm(dtemp, bins=16)
        seasonal_memory = max(0.0, autocorr(temp, 12))
        aux_order = 1.0 / (1.0 + np.std(aux))
        S_raw = np.mean([var_order, change_order, ent_order, seasonal_memory, aux_order])

        # L: teleconnection linkage for region.
        regional_links = abs_corr[ri, :]
        L_network = np.mean(regional_links[regional_links > 0]) if np.any(regional_links > 0) else 0.0
        L_top = np.mean(adj[ri, :]) if adj.shape[0] > 1 else 0.0
        memory = np.mean([max(0.0, autocorr(temp,1)), max(0.0, autocorr(temp,3)), max(0.0, autocorr(aux,1))])
        cross_var_couplings = []
        for vi in range(all_local.shape[0]):
            for vj in range(vi+1, all_local.shape[0]):
                if np.std(all_local[vi]) > 1e-12 and np.std(all_local[vj]) > 1e-12:
                    cross_var_couplings.append(abs(np.corrcoef(all_local[vi], all_local[vj])[0,1]))
        local_coupling = float(np.mean(cross_var_couplings)) if cross_var_couplings else 0.0
        L_raw = np.mean([L_network, L_top, memory, local_coupling, mean_link])

        # Independent Phi/resilience.
        extreme_hot = np.mean(temp > 1.5)
        extreme_cold = np.mean(temp < -1.5)
        abrupt = np.mean(np.abs(zscore(dtemp)) > 1.5) if len(dtemp) > 5 else 0.0
        predictability = max(0.0, autocorr(temp,1))
        structural_stability = var_order
        tele_stability = 1.0 / (1.0 + np.std(regional_links))
        Phi_resilience_raw = np.mean([
            1.0 - extreme_hot,
            1.0 - extreme_cold,
            1.0 - abrupt,
            predictability,
            seasonal_memory,
            structural_stability,
            tele_stability
        ])

        # Pathology and stress.
        Climate_pathology_raw = np.mean([
            extreme_hot,
            extreme_cold,
            abrupt,
            min(1.0, np.std(temp)/2.0),
            min(1.0, np.std(dtemp)*2.0),
            min(1.0, max_link),
            1.0/(1.0 + seasonal_memory)
        ])
        Heat_stress_raw = np.mean([extreme_hot, heat_intensity, max(0.0, np.mean(temp))/2.0, abs(trend)*60.0])
        Teleconnection_stress_raw = np.mean([max_link, L_network, L_top, np.std(regional_links), 1.0/(1.0+local_coupling)])
        Abrupt_shift_raw = np.mean([abrupt, min(1.0, np.std(dtemp)*2.0), 1.0/(1.0+predictability)])

        features.append({
            "region": region,
            "window_start": str(dates_w.iloc[0].date()),
            "window_end": str(dates_w.iloc[-1].date()),
            "n_months": WINDOW_MONTHS,
            "mean_primary_anom": float(np.mean(temp)),
            "trend_primary": float(trend),
            "std_primary": float(np.std(temp)),
            "abrupt_fraction": float(abrupt),
            "extreme_hot_fraction": float(extreme_hot),
            "extreme_cold_fraction": float(extreme_cold),
            "regional_mean_link": float(L_network),
            "regional_toplink_density": float(L_top),
            "local_memory": float(memory),
            "local_coupling": float(local_coupling),
            "network_mean_abs_corr": float(mean_link),
            "network_max_abs_corr": float(max_link),
            "H_raw": float(H_raw),
            "S_raw": float(S_raw),
            "L_raw": float(L_raw),
            "Phi_resilience_raw": float(Phi_resilience_raw),
            "Climate_pathology_raw": float(Climate_pathology_raw),
            "Heat_stress_raw": float(Heat_stress_raw),
            "Teleconnection_stress_raw": float(Teleconnection_stress_raw),
            "Abrupt_shift_raw": float(Abrupt_shift_raw)
        })

features = pd.DataFrame(features)
network_summary = pd.DataFrame(network_rows)

if len(features) < 100:
    raise RuntimeError("Too few regional climate windows.")

# Normalize globally across region-window observations.
for col in ["H_raw", "S_raw", "L_raw", "Phi_resilience_raw", "Climate_pathology_raw", "Heat_stress_raw", "Teleconnection_stress_raw", "Abrupt_shift_raw"]:
    features[col.replace("_raw", "")] = normalize01(features[col].values)

features["Phi_HSL_epsilon"] = (features["H"] + EPSILON) * (features["S"] + EPSILON) * (features["L"] + EPSILON)
features["Triadic_balance"] = [triadic_balance(h,s,l) for h,s,l in zip(features["H"], features["S"], features["L"])]
features["Functional_unity"] = features["Phi_HSL_epsilon"] * features["Triadic_balance"]
features["Dominance_index"] = [dominance_index(h,s,l) for h,s,l in zip(features["H"], features["S"], features["L"])]

features["resilient_high_flag"] = features["Phi_resilience"] >= features["Phi_resilience"].median()
features["pathology_high_flag"] = features["Climate_pathology"] >= features["Climate_pathology"].median()
features["heat_high_flag"] = features["Heat_stress"] >= features["Heat_stress"].quantile(0.75)
features["teleconnection_high_flag"] = features["Teleconnection_stress"] >= features["Teleconnection_stress"].quantile(0.75)
features["abrupt_high_flag"] = features["Abrupt_shift"] >= features["Abrupt_shift"].quantile(0.75)
features["triadic_disproportion_flag"] = (
    (features["Triadic_balance"] <= features["Triadic_balance"].quantile(0.25)) |
    (features["Dominance_index"] >= features["Dominance_index"].quantile(0.75))
)

# Dynamic features by region.
features["window_mid"] = pd.to_datetime(features["window_start"]) + (pd.to_datetime(features["window_end"]) - pd.to_datetime(features["window_start"])) / 2
features = features.sort_values(["region", "window_mid"]).reset_index(drop=True)

dyn_rows = []
for region, g in features.groupby("region"):
    g = g.sort_values("window_mid").reset_index(drop=True)
    for i in range(1, len(g)):
        prev = g.iloc[i-1]
        cur = g.iloc[i]
        dyn_rows.append({
            "region": region,
            "window_start": cur["window_start"],
            "window_end": cur["window_end"],
            "dH": cur["H"] - prev["H"],
            "dS": cur["S"] - prev["S"],
            "dL": cur["L"] - prev["L"],
            "dPhi_resilience": cur["Phi_resilience"] - prev["Phi_resilience"],
            "dFunctional_unity": cur["Functional_unity"] - prev["Functional_unity"],
            "dClimate_pathology": cur["Climate_pathology"] - prev["Climate_pathology"],
            "dHeat_stress": cur["Heat_stress"] - prev["Heat_stress"],
            "dTeleconnection_stress": cur["Teleconnection_stress"] - prev["Teleconnection_stress"],
            "dAbrupt_shift": cur["Abrupt_shift"] - prev["Abrupt_shift"],
            "dBalance": cur["Triadic_balance"] - prev["Triadic_balance"],
            "dDominance": cur["Dominance_index"] - prev["Dominance_index"]
        })
dynamic_features = pd.DataFrame(dyn_rows)

# ============================================================
# MODEL HELPERS
# ============================================================

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {
        "test": label,
        "n": int(len(d)),
        "r2": float(r2_score(y, pred)),
        "mae": float(mean_absolute_error(y, pred)),
        "spearman_true_pred": r,
        "p_value": p
    }

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight="balanced")
        clf.fit(X, y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {"feature_set": label, "target": target, "n": int(len(d)), "auc": float(auc)}

# ============================================================
# SUMMARIES
# ============================================================

data_summary = pd.DataFrame([{
    "n_regions": int(features["region"].nunique()),
    "regions": ",".join(sorted(features["region"].unique())),
    "loaded_variables": ",".join(loaded_variables),
    "primary_var": primary_var,
    "aux_var": aux_var,
    "n_region_windows": int(len(features)),
    "n_dynamic_windows": int(len(dynamic_features)),
    "window_months": WINDOW_MONTHS,
    "step_months": STEP_MONTHS,
    "start_date": str(common_dates.min().date()),
    "end_date": str(common_dates.max().date())
}])

genesis_summary = pd.DataFrame([
    regression(features, ["H"], "S", "C2_H_to_S"),
    regression(features, ["H"], "L", "C2_H_to_L"),
    regression(features, ["S"], "L", "C2_S_to_L"),
    regression(features, ["H","S"], "L", "C2_H_plus_S_to_L"),
    regression(features, ["H","S","L"], "Phi_resilience", "C2_HSL_to_Phi_resilience"),
    regression(features, ["H","S","L"], "Functional_unity", "C2_HSL_to_Functional_Unity"),
    regression(features, ["H","S","L"], "Climate_pathology", "C2_HSL_to_Climate_Pathology"),
    regression(features, ["H","S","L","Triadic_balance","Dominance_index"], "Climate_pathology", "C2_Full_to_Climate_Pathology"),
    regression(features, ["H","S","L","Triadic_balance","Dominance_index"], "Phi_resilience", "C2_Full_to_Phi_resilience"),
    regression(features, ["H","S","L"], "Heat_stress", "C2_HSL_to_Heat_Stress"),
    regression(features, ["H","S","L"], "Teleconnection_stress", "C2_HSL_to_Teleconnection_Stress"),
    regression(features, ["H","S","L"], "Abrupt_shift", "C2_HSL_to_Abrupt_Shift"),
])

def get_mae(summary, test):
    x = summary[summary["test"] == test]
    return None if len(x)==0 else x.iloc[0]["mae"]

H_L = get_mae(genesis_summary, "C2_H_to_L")
S_L = get_mae(genesis_summary, "C2_S_to_L")
HS_L = get_mae(genesis_summary, "C2_H_plus_S_to_L")

emergence_contrast = pd.DataFrame([{
    "level": "macro_climate_gridded_regional",
    "H_to_L_mae": H_L,
    "S_to_L_mae": S_L,
    "H_plus_S_to_L_mae": HS_L,
    "HS_improves_over_H": H_L-HS_L if H_L is not None and HS_L is not None else None,
    "HS_improves_over_S": S_L-HS_L if S_L is not None and HS_L is not None else None,
    "PETU_prediction_supported": (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

dynamic_summary = pd.DataFrame([
    regression(dynamic_features, ["dH"], "dS", "C2_DYN_dH_to_dS"),
    regression(dynamic_features, ["dH"], "dL", "C2_DYN_dH_to_dL"),
    regression(dynamic_features, ["dS"], "dL", "C2_DYN_dS_to_dL"),
    regression(dynamic_features, ["dH","dS"], "dL", "C2_DYN_dH_plus_dS_to_dL"),
    regression(dynamic_features, ["dH","dS","dL"], "dPhi_resilience", "C2_DYN_dHSL_to_dPhi_resilience"),
    regression(dynamic_features, ["dH","dS","dL"], "dFunctional_unity", "C2_DYN_dHSL_to_dFunctional_Unity"),
    regression(dynamic_features, ["dH","dS","dL"], "dClimate_pathology", "C2_DYN_dHSL_to_dClimate_Pathology"),
    regression(dynamic_features, ["dH","dS","dL"], "dHeat_stress", "C2_DYN_dHSL_to_dHeat"),
    regression(dynamic_features, ["dH","dS","dL"], "dTeleconnection_stress", "C2_DYN_dHSL_to_dTeleconnection"),
    regression(dynamic_features, ["dH","dS","dL"], "dAbrupt_shift", "C2_DYN_dHSL_to_dAbrupt"),
])

# Regional summary
region_summary = (
    features.groupby("region")
    .agg(
        n_windows=("region", "count"),
        mean_H=("H", "mean"),
        mean_S=("S", "mean"),
        mean_L=("L", "mean"),
        mean_Phi=("Phi_resilience", "mean"),
        mean_pathology=("Climate_pathology", "mean"),
        mean_heat=("Heat_stress", "mean"),
        mean_teleconnection=("Teleconnection_stress", "mean"),
        mean_abrupt=("Abrupt_shift", "mean"),
        mean_balance=("Triadic_balance", "mean"),
        mean_dominance=("Dominance_index", "mean")
    )
    .reset_index()
    .sort_values("mean_pathology", ascending=False)
)

# Contrasts
contrast_defs = [
    ("resilient_vs_fragile", "resilient_high_flag", True, False),
    ("pathology_high_vs_low", "pathology_high_flag", True, False),
    ("heat_high_vs_other", "heat_high_flag", True, False),
    ("teleconnection_high_vs_other", "teleconnection_high_flag", True, False),
    ("abrupt_high_vs_other", "abrupt_high_flag", True, False),
    ("disproportion_vs_proportion", "triadic_disproportion_flag", True, False),
]
contrast_metrics = [
    "H","S","L","Phi_HSL_epsilon","Triadic_balance","Functional_unity",
    "Dominance_index","Phi_resilience","Climate_pathology","Heat_stress",
    "Teleconnection_stress","Abrupt_shift","mean_primary_anom","trend_primary",
    "std_primary","regional_mean_link","regional_toplink_density","local_memory",
    "local_coupling","network_mean_abs_corr","network_max_abs_corr","abrupt_fraction",
    "extreme_hot_fraction","extreme_cold_fraction"
]
contrast_rows = []
for cname, flag, aval, bval in contrast_defs:
    A = features[features[flag] == aval]
    B = features[features[flag] == bval]
    for col in contrast_metrics:
        stat, p = safe_mw(A[col], B[col])
        contrast_rows.append({
            "contrast": cname,
            "metric": col,
            "groupA_mean": float(A[col].mean()) if len(A) else np.nan,
            "groupB_mean": float(B[col].mean()) if len(B) else np.nan,
            "delta_A_minus_B": float(A[col].mean() - B[col].mean()) if len(A) and len(B) else np.nan,
            "pct_delta": float(100*(A[col].mean() - B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,
            "mannwhitney_stat": stat,
            "p_value": p
        })
contrast_summary = pd.DataFrame(contrast_rows)

# Classification
class_rows = []
targets = [
    "resilient_high_flag",
    "pathology_high_flag",
    "heat_high_flag",
    "teleconnection_high_flag",
    "abrupt_high_flag",
    "triadic_disproportion_flag"
]
feature_sets = [
    (["H"], "H"),
    (["S"], "S"),
    (["L"], "L"),
    (["H","S"], "H+S"),
    (["H","S","L"], "H+S+L"),
    (["H","S","L","Phi_HSL_epsilon"], "H+S+L+Phi"),
    (["H","S","L","Phi_HSL_epsilon","Triadic_balance","Dominance_index"], "H+S+L+PhiBalanceDominance")
]
for target in targets:
    for cols, label in feature_sets:
        r = auc_model(features, cols, target, label)
        if r:
            class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows = []
for target, d in classification_summary.groupby("target"):
    def auc(fs):
        x = d[d["feature_set"] == fs]
        return None if len(x)==0 else float(x.iloc[0]["auc"])
    aH, aHS, aHSL, aFull = auc("H"), auc("H+S"), auc("H+S+L"), auc("H+S+L+PhiBalanceDominance")
    gain_rows.append({
        "target": target,
        "auc_H": aH,
        "auc_HS": aHS,
        "auc_HSL": aHSL,
        "auc_full": aFull,
        "gain_HSL_over_H": None if aH is None or aHSL is None else aHSL-aH,
        "gain_HSL_over_HS": None if aHS is None or aHSL is None else aHSL-aHS,
        "gain_full_over_HSL": None if aFull is None or aHSL is None else aFull-aHSL
    })
classification_gain_summary = pd.DataFrame(gain_rows)

# Phases

def classify_phase(r):
    if r["triadic_disproportion_flag"]:
        return "triadic_disproportion"
    if r["Heat_stress"] >= features["Heat_stress"].quantile(0.75) and r["H"] >= features["H"].median():
        return "high_H_heat_stress"
    if r["Teleconnection_stress"] >= features["Teleconnection_stress"].quantile(0.75):
        return "teleconnection_L_stress"
    if r["Abrupt_shift"] >= features["Abrupt_shift"].quantile(0.75):
        return "abrupt_shift_pathology"
    if r["Phi_resilience"] >= features["Phi_resilience"].median() and r["Triadic_balance"] >= features["Triadic_balance"].median():
        return "resilient_phi_integrated"
    if r["S"] >= features["S"].median() and r["L"] <= features["L"].quantile(0.25):
        return "S_regime_low_link"
    return "transitional"

features["PETU_C2_phase"] = features.apply(classify_phase, axis=1)
phase_summary = (
    features.groupby("PETU_C2_phase")
    .agg(
        n_windows=("region","count"),
        n_regions=("region","nunique"),
        mean_H=("H","mean"),
        mean_S=("S","mean"),
        mean_L=("L","mean"),
        mean_Phi_HSL=("Phi_HSL_epsilon","mean"),
        mean_resilience=("Phi_resilience","mean"),
        mean_balance=("Triadic_balance","mean"),
        mean_dominance=("Dominance_index","mean"),
        mean_pathology=("Climate_pathology","mean"),
        mean_heat=("Heat_stress","mean"),
        mean_teleconnection=("Teleconnection_stress","mean"),
        mean_abrupt=("Abrupt_shift","mean")
    )
    .reset_index()
    .sort_values("n_windows", ascending=False)
)

# Trajectories
def trajectory_for_flag(flag):
    rows = []
    for region, g in features.groupby("region"):
        g = g.sort_values("window_mid").reset_index(drop=True)
        for i in range(1, len(g)):
            prev = g.iloc[i-1]
            cur = g.iloc[i]
            rows.append({
                "flag": flag,
                "transition": f"{int(prev[flag])}->{int(cur[flag])}",
                "region": region,
                "dH": cur["H"] - prev["H"],
                "dS": cur["S"] - prev["S"],
                "dL": cur["L"] - prev["L"],
                "dPhi": cur["Phi_resilience"] - prev["Phi_resilience"],
                "dUnity": cur["Functional_unity"] - prev["Functional_unity"],
                "dPathology": cur["Climate_pathology"] - prev["Climate_pathology"],
                "dHeat": cur["Heat_stress"] - prev["Heat_stress"],
                "dTeleconnection": cur["Teleconnection_stress"] - prev["Teleconnection_stress"],
                "dAbrupt": cur["Abrupt_shift"] - prev["Abrupt_shift"],
                "dBalance": cur["Triadic_balance"] - prev["Triadic_balance"],
                "dDominance": cur["Dominance_index"] - prev["Dominance_index"]
            })
    return rows

traj_rows = []
for flag in ["heat_high_flag", "teleconnection_high_flag", "pathology_high_flag", "resilient_high_flag", "abrupt_high_flag"]:
    traj_rows.extend(trajectory_for_flag(flag))
trajectory = pd.DataFrame(traj_rows)
trajectory_summary = (
    trajectory.groupby(["flag","transition"])
    .agg(
        n=("region","count"),
        mean_dH=("dH","mean"),
        mean_dS=("dS","mean"),
        mean_dL=("dL","mean"),
        mean_dPhi=("dPhi","mean"),
        mean_dUnity=("dUnity","mean"),
        mean_dPathology=("dPathology","mean"),
        mean_dHeat=("dHeat","mean"),
        mean_dTeleconnection=("dTeleconnection","mean"),
        mean_dAbrupt=("dAbrupt","mean"),
        mean_dBalance=("dBalance","mean"),
        mean_dDominance=("dDominance","mean")
    )
    .reset_index()
)

# ============================================================
# SAVE
# ============================================================

paths = {
    "regional_monthly_data": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_regional_monthly_data.csv",
    "features": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_features.csv",
    "dynamic_features": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_dynamic_features.csv",
    "network_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_network_summary.csv",
    "data_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_data_summary.csv",
    "region_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_region_summary.csv",
    "genesis_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_genesis_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_emergence_contrast.csv",
    "dynamic_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_dynamic_summary.csv",
    "contrast_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_contrast_summary.csv",
    "classification_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_classification_summary.csv",
    "classification_gain_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_classification_gain_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_phase_summary.csv",
    "trajectory_summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_trajectory_summary.csv",
    "failures": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_failures.csv",
    "summary": f"{OUTDIR}/PETU_MACRO_CLIMATE_C2_summary.json"
}

wide.to_csv(paths["regional_monthly_data"], index=False)
features.to_csv(paths["features"], index=False)
dynamic_features.to_csv(paths["dynamic_features"], index=False)
network_summary.to_csv(paths["network_summary"], index=False)
data_summary.to_csv(paths["data_summary"], index=False)
region_summary.to_csv(paths["region_summary"], index=False)
genesis_summary.to_csv(paths["genesis_summary"], index=False)
emergence_contrast.to_csv(paths["emergence_contrast"], index=False)
dynamic_summary.to_csv(paths["dynamic_summary"], index=False)
contrast_summary.to_csv(paths["contrast_summary"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
trajectory_summary.to_csv(paths["trajectory_summary"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-MACRO-CLIMATE C2 Gridded Regional Teleconnection Audit",
    "domain": "macro natural climate / gridded regional fields / NOAA PSL OPeNDAP",
    "n_regions": int(features["region"].nunique()),
    "n_region_windows": int(len(features)),
    "n_dynamic_windows": int(len(dynamic_features)),
    "loaded_variables": loaded_variables,
    "primary_var": primary_var,
    "aux_var": aux_var,
    "start_year": START_YEAR,
    "end_year": END_YEAR,
    "window_months": WINDOW_MONTHS,
    "step_months": STEP_MONTHS,
    "epsilon": EPSILON,
    "hypothesis": "Regional climate resilience and pathology arise from triadic proportion/disproportion of H energetic support, S regional regime structure, and L teleconnection linkage.",
    "next_step": "K1: cosmological large-scale structure audit; later: additional micro and meso replications to reach 10-domain PETU/LETU confirmation."
}
with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

# ============================================================
# PRINT
# ============================================================

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 DATA SUMMARY")
print("============================================================")
print(data_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 REGION SUMMARY")
print("============================================================")
print(region_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 GENESIS SUMMARY")
print("============================================================")
print(genesis_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 EMERGENCE CONTRAST")
print("============================================================")
print(emergence_contrast)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 DYNAMIC SUMMARY")
print("============================================================")
print(dynamic_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 CONTRAST SUMMARY")
print("============================================================")
print(contrast_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 PHASE SUMMARY")
print("============================================================")
print(phase_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 TRAJECTORY SUMMARY")
print("============================================================")
print(trajectory_summary)

print("\n============================================================")
print("PETU-MACRO-CLIMATE C2 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

if len(failures) > 0:
    print("\n============================================================")
    print("FAILURES / SKIPPED")
    print("============================================================")
    print(pd.DataFrame(failures))

# ============================================================
# FIGURES
# ============================================================

plt.figure(figsize=(8,5))
plt.scatter(features["H"] + features["S"], features["L"], s=12, alpha=0.45)
plt.xlabel("H + S")
plt.ylabel("L")
plt.title("PETU-CLIMATE C2: H+S -> L")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_C2_HS_to_L.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Phi_HSL_epsilon"], features["Phi_resilience"], s=12, alpha=0.45)
plt.xlabel("Phi_HSL_epsilon")
plt.ylabel("Phi_resilience")
plt.title("PETU-CLIMATE C2: HSL unity vs regional climate resilience")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_C2_PhiHSL_resilience.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(features["Dominance_index"], features["Climate_pathology"], s=12, alpha=0.45)
plt.xlabel("Dominance index")
plt.ylabel("Climate pathology")
plt.title("PETU-CLIMATE C2: dominance and climate pathology")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_C2_Dominance_Pathology.png", dpi=220)
plt.show()

plt.figure(figsize=(10,5))
plt.bar(phase_summary["PETU_C2_phase"], phase_summary["n_windows"])
plt.xticks(rotation=60)
plt.ylabel("Region-windows")
plt.title("PETU-CLIMATE C2: phase counts")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_C2_phase_counts.png", dpi=220)
plt.show()

zip_base = "/content/PETU_MACRO_CLIMATE_C2_Gridded_Regional_Teleconnection_Audit_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path):
    os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k,v in paths.items():
    print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

# ============================================================
# PETU-MICRO-METAB M1 v2 CORRECTED
# Metabolic Network Triadic Audit
# ============================================================
# Correccion: usa endpoints KEGG REST validos:
#   https://rest.kegg.jp/link/rn/{organism}
#   https://rest.kegg.jp/link/reaction/{organism}
# y descarga ecuaciones via:
#   https://rest.kegg.jp/get/R00010+R00020+...
# Incluye fallback interno si KEGG falla por red/API.
# ============================================================

!pip -q install requests numpy pandas scipy scikit-learn matplotlib tqdm networkx

import os, re, json, time, random, warnings, shutil
warnings.filterwarnings('ignore')
import requests
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

OUTDIR = '/content/PETU_MICRO_METAB_M1_Metabolic_Network_Triadic_Audit_CORRECTED'
os.makedirs(OUTDIR, exist_ok=True)
SEED = 42
random.seed(SEED); np.random.seed(SEED)
EPSILON = 0.05
MAX_REACTIONS_PER_ORGANISM = 900
MAX_SUBGRAPHS_PER_ORGANISM = 70
MIN_SUBGRAPH_NODES = 18
MAX_SUBGRAPH_NODES = 120

ORGANISMS = {
    'Escherichia_coli_K12':'eco', 'Bacillus_subtilis':'bsu',
    'Mycoplasma_genitalium':'mge', 'Synechocystis_PCC6803':'syn',
    'Saccharomyces_cerevisiae':'sce', 'Arabidopsis_thaliana':'ath',
    'Drosophila_melanogaster':'dme', 'Homo_sapiens':'hsa',
    'Methanocaldococcus_jannaschii':'mja', 'Thermus_thermophilus':'ttj'
}

# ----------------------------- utilities -----------------------------
def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x)==0: return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx-mn < 1e-12:
        return np.zeros_like(x)
    return (x-mn)/(mx-mn)

def entropy_norm(vals):
    vals = np.asarray(vals, dtype=float)
    vals = vals[vals>0]
    if vals.sum() <= 0 or len(vals) <= 1: return 0.0
    p = vals/vals.sum(); ent = -np.sum(p*np.log(p+1e-12))
    return float(ent/np.log(len(vals)+1e-12))

def safe_spearman(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        m=np.isfinite(a)&np.isfinite(b)
        if m.sum()<3: return None, None
        r,p=spearmanr(a[m],b[m]); return float(r), float(p)
    except Exception: return None, None

def safe_mw(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        a=a[np.isfinite(a)]; b=b[np.isfinite(b)]
        if len(a)<3 or len(b)<3: return None, None
        s,p=mannwhitneyu(a,b,alternative='two-sided'); return float(s), float(p)
    except Exception: return None, None

def triadic_balance(h,s,l): return float(max(0.0, 1.0-np.std([h,s,l])))
def dominance_index(h,s,l): return float(max(h,s,l)-min(h,s,l))

def get_text(url, retries=3, timeout=70):
    err = None
    for i in range(retries):
        try:
            r = requests.get(url, timeout=timeout)
            if r.status_code == 200 and r.text.strip(): return r.text
            err = f'HTTP {r.status_code}'
        except Exception as e: err = str(e)
        time.sleep(0.5 + i*0.5)
    raise RuntimeError(err)

# ----------------------------- KEGG corrected -----------------------------
def fetch_reaction_ids(org):
    urls = [
        f'https://rest.kegg.jp/link/rn/{org}',
        f'https://rest.kegg.jp/link/reaction/{org}',
        f'https://rest.kegg.jp/link/rn/{org}:',
        f'https://rest.kegg.jp/link/reaction/{org}:'
    ]
    errors=[]
    for url in urls:
        try:
            txt=get_text(url)
            ids=sorted(set(re.findall(r'R\d{5}', txt)))
            if ids: return ids, url
        except Exception as e:
            errors.append(f'{url} -> {e}')
    raise RuntimeError('KEGG link failed: ' + ' | '.join(errors[:2]))

def parse_equations(txt):
    out=[]
    for ent in txt.split('///'):
        m=re.search(r'ENTRY\s+(R\d{5})', ent)
        if not m: continue
        rid=m.group(1)
        eq=''; collect=False
        for ln in ent.splitlines():
            if ln.startswith('EQUATION'):
                eq += ' ' + ln.replace('EQUATION','',1).strip(); collect=True
            elif collect and re.match(r'^\s+', ln) and not re.match(r'^[A-Z_]+\s+', ln):
                eq += ' ' + ln.strip()
            elif collect: collect=False
        if not eq: continue
        eq=re.sub(r'\b\d+(\.\d+)?\s+(C\d{5})', r'\2', eq)
        if '<=>' in eq: left,right=eq.split('<=>',1)
        elif '=>' in eq: left,right=eq.split('=>',1)
        elif '<=' in eq: right,left=eq.split('<=',1)
        elif '=' in eq: left,right=eq.split('=',1)
        else: left,right=eq,''
        subs=re.findall(r'C\d{5}', left); prods=re.findall(r'C\d{5}', right)
        comps=sorted(set(subs+prods))
        if len(comps)>=2:
            out.append({'reaction_id':rid,'substrates':sorted(set(subs)),
                        'products':sorted(set(prods)),'compounds':comps,'equation':eq.strip()})
    return out

def fetch_equations(ids, max_rxn=MAX_REACTIONS_PER_ORGANISM, chunk=10):
    if len(ids) > max_rxn:
        idx=np.linspace(0,len(ids)-1,max_rxn).astype(int); ids=[ids[i] for i in idx]
    parsed=[]
    for i in range(0,len(ids),chunk):
        ch=ids[i:i+chunk]
        try:
            parsed += parse_equations(get_text('https://rest.kegg.jp/get/' + '+'.join(ch)))
        except Exception: pass
        time.sleep(0.12)
    seen=set(); out=[]
    for r in parsed:
        if r['reaction_id'] not in seen:
            seen.add(r['reaction_id']); out.append(r)
    return out

def build_graph(reactions):
    G=nx.Graph()
    for r in reactions:
        rid=r['reaction_id']; subs=r.get('substrates',[]); prods=r.get('products',[]); comps=r.get('compounds',[])
        for c in comps: G.add_node(c)
        made=False
        if subs and prods:
            for a in subs:
                for b in prods:
                    if a!=b:
                        G.add_edge(a,b); made=True
        if not made and len(comps)>=2:
            for i in range(len(comps)):
                for j in range(i+1,len(comps)): G.add_edge(comps[i], comps[j])
    return G

# ----------------------------- fallback -----------------------------
def fallback_reactions(org):
    base=[
        ('F001',['C00031'],['C00668']),('F002',['C00668'],['C05345']),('F003',['C05345'],['C00111','C00118']),
        ('F004',['C00118'],['C00236']),('F005',['C00236'],['C00074']),('F006',['C00074'],['C00022']),
        ('F007',['C00022'],['C00024']),('F008',['C00024'],['C00158']),('F009',['C00158'],['C00036']),
        ('F010',['C00036'],['C00026']),('F011',['C00026'],['C00042']),('F012',['C00042'],['C00122']),
        ('F013',['C00122'],['C00036']),('F014',['C00036'],['C00022']),('F015',['C00022'],['C00149']),
        ('F016',['C00149'],['C00026']),('F017',['C00024'],['C00083']),('F018',['C00083'],['C00249']),
        ('F019',['C00249'],['C00162']),('F020',['C00031'],['C00103']),('F021',['C00103'],['C00092']),
        ('F022',['C00092'],['C00085']),('F023',['C00085'],['C00111']),('F024',['C00022'],['C00186']),
        ('F025',['C00186'],['C00022']),('F026',['C00026'],['C00025']),('F027',['C00025'],['C00064']),
        ('F028',['C00064'],['C00014']),('F029',['C00037'],['C00065']),('F030',['C00065'],['C00188']),
        ('F031',['C00073'],['C00097']),('F032',['C00097'],['C00041']),('F033',['C00049'],['C00152']),
        ('F034',['C00152'],['C00025']),('F035',['C00082'],['C00079']),('F036',['C00079'],['C00135']),
        ('F037',['C00135'],['C00078']),('F038',['C00078'],['C00082']),('F039',['C00002'],['C00008']),
        ('F040',['C00008'],['C00020']),('F041',['C00003'],['C00004']),('F042',['C00006'],['C00005']),
        ('F043',['C00010'],['C00024']),('F044',['C00024'],['C00010']),('F045',['C00001'],['C00080']),
        ('F046',['C00009'],['C00013'])]
    rng=random.Random(abs(hash(org))%(2**32)); chosen=base+rng.sample(base,rng.randint(0,12))
    return [{'reaction_id':f'{rid}_{i}','substrates':s,'products':p,'compounds':sorted(set(s+p)),'equation':''} for i,(rid,s,p) in enumerate(chosen)]

# ----------------------------- graph features -----------------------------
def lcc(G):
    if G.number_of_nodes()==0: return G.copy()
    return G.subgraph(max(nx.connected_components(G), key=len)).copy()

def efficiency(G):
    try: return float(nx.global_efficiency(G)) if G.number_of_nodes()>2 else 0.0
    except Exception: return 0.0

def modularity(G):
    try:
        if G.number_of_nodes()<5 or G.number_of_edges()<4: return 0.0
        comm=list(nx.algorithms.community.greedy_modularity_communities(G))
        return float(nx.algorithms.community.modularity(G,comm)) if len(comm)>1 else 0.0
    except Exception: return 0.0

def clustering(G):
    try: return float(nx.average_clustering(G))
    except Exception: return 0.0

def sample_subgraphs(G, org):
    if G.number_of_nodes()<MIN_SUBGRAPH_NODES: return []
    deg=dict(G.degree()); nodes=list(G.nodes())
    hubs=[n for n,_ in sorted(deg.items(), key=lambda x:x[1], reverse=True)[:max(10,MAX_SUBGRAPHS_PER_ORGANISM//3)]]
    rng=random.Random(abs(hash(org))%(2**32)); rnd=rng.sample(nodes, min(len(nodes),MAX_SUBGRAPHS_PER_ORGANISM))
    seeds=[]
    for n in hubs+rnd:
        if n not in seeds: seeds.append(n)
    out=[]
    for seed in seeds:
        if len(out)>=MAX_SUBGRAPHS_PER_ORGANISM: break
        ns=list(nx.ego_graph(G, seed, radius=2).nodes())
        if len(ns)>MAX_SUBGRAPH_NODES: ns=ns[:MAX_SUBGRAPH_NODES]
        sg=G.subgraph(ns).copy()
        if sg.number_of_nodes()>=MIN_SUBGRAPH_NODES and sg.number_of_edges()>=MIN_SUBGRAPH_NODES-1:
            out.append((f'ego2_{seed}', sg))
    return out

def attacked_graph(G, mode, frac=0.12):
    H=G.copy(); nrem=max(1,int(frac*H.number_of_nodes()))
    if H.number_of_nodes()<=nrem+3: return H
    if mode=='random_attack': rem=random.sample(list(H.nodes()), nrem)
    elif mode=='H_support_attack': rem=[n for n,_ in sorted(H.degree(), key=lambda x:x[1], reverse=True)[:nrem]]
    elif mode=='L_bridge_attack':
        try:
            b=nx.betweenness_centrality(H, k=min(30,H.number_of_nodes()), seed=SEED)
            rem=[n for n,_ in sorted(b.items(), key=lambda x:x[1], reverse=True)[:nrem]]
        except Exception: rem=[n for n,_ in sorted(H.degree(), key=lambda x:x[1], reverse=True)[:nrem]]
    elif mode=='S_module_attack':
        try:
            comm=list(nx.algorithms.community.greedy_modularity_communities(H)); rem=list(max(comm,key=len))[:nrem]
        except Exception: rem=[n for n,_ in sorted(H.degree(), key=lambda x:x[1], reverse=True)[:nrem]]
    else: rem=[]
    H.remove_nodes_from(rem); return H

def graph_features(G, organism, code, sub_id, variant, source):
    n=G.number_of_nodes(); m=G.number_of_edges()
    if n<3: return None
    C=lcc(G); lcc_frac=C.number_of_nodes()/(n+1e-12); dens=nx.density(G) if n>1 else 0.0
    deg=np.array([d for _,d in G.degree()], dtype=float)
    mean_deg=float(np.mean(deg)) if len(deg) else 0.0
    max_deg=float(np.max(deg)) if len(deg) else 0.0
    deg_cv=float(np.std(deg)/(np.mean(deg)+1e-12)) if len(deg) else 0.0
    deg_ent=entropy_norm(deg); cl=clustering(G); eff=efficiency(C); mod=modularity(C)
    try: arts=len(list(nx.articulation_points(C)))/(C.number_of_nodes()+1e-12)
    except Exception: arts=0.0
    H_raw=np.mean([np.log1p(n)/np.log1p(MAX_SUBGRAPH_NODES), np.log1p(m)/np.log1p(MAX_SUBGRAPH_NODES*4), min(1,mean_deg/8), lcc_frac, min(1,dens*20)])
    S_raw=np.mean([mod, deg_ent, cl, min(1,deg_cv/2), 1-min(1,abs(dens-0.08)/0.25)])
    L_raw=np.mean([lcc_frac, eff, cl, 1-min(1,arts), min(1,mean_deg/6)])
    def retained(G2): return lcc(G2).number_of_nodes()/(C.number_of_nodes()+1e-12) if C.number_of_nodes()>0 else 0.0
    hres=retained(attacked_graph(C,'H_support_attack')); sres=retained(attacked_graph(C,'S_module_attack')); lres=retained(attacked_graph(C,'L_bridge_attack'))
    Phi_raw=np.mean([lcc_frac,eff,cl,hres,sres,lres,1-min(1,arts)])
    Frag_raw=np.mean([1-hres,1-sres,1-lres,min(1,arts),1-lcc_frac,min(1,deg_cv/3)])
    return dict(organism=organism, org_code=code, subgraph_id=sub_id, variant=variant, source=source,
                n_nodes=int(n), n_edges=int(m), lcc_fraction=float(lcc_frac), density=float(dens), mean_degree=mean_deg, max_degree=max_deg,
                degree_cv=deg_cv, degree_entropy=float(deg_ent), clustering=float(cl), efficiency=float(eff), modularity=float(mod),
                articulation_penalty=float(arts), H_attack_resilience=float(hres), S_attack_resilience=float(sres), L_attack_resilience=float(lres),
                H_raw=float(H_raw), S_raw=float(S_raw), L_raw=float(L_raw), Phi_metabolic_raw=float(Phi_raw), Fragility_raw=float(Frag_raw))

# ----------------------------- modeling helpers -----------------------------
def regression(data, Xcols, ycol, label):
    d=data[Xcols+[ycol]].dropna()
    if len(d)<20: return dict(test=label,n=int(len(d)),r2=None,mae=None,spearman_true_pred=None,p_value=None)
    X=d[Xcols].values.astype(float); y=d[ycol].values.astype(float)
    model=Ridge(alpha=1.0).fit(X,y); pred=model.predict(X); r,p=safe_spearman(y,pred)
    return dict(test=label,n=int(len(d)),r2=float(r2_score(y,pred)),mae=float(mean_absolute_error(y,pred)),spearman_true_pred=r,p_value=p)

def auc_model(data, cols, target, label):
    d=data[cols+[target]].dropna()
    if len(d)<30 or len(d[target].unique())<2: return None
    X=d[cols].values.astype(float); y=d[target].astype(int).values
    try:
        clf=LogisticRegression(max_iter=1000,class_weight='balanced').fit(X,y)
        auc=roc_auc_score(y,clf.predict_proba(X)[:,1])
    except Exception: auc=np.nan
    return dict(feature_set=label,target=target,n=int(len(d)),auc=float(auc))

# ============================================================
# MAIN
# ============================================================
print('='*60); print('PETU-MICRO-METAB M1 METABOLIC NETWORK TRIADIC AUDIT v2 CORRECTED'); print('='*60)
print('Fetching KEGG organism reactions and reaction compounds...')
org_networks={}; org_sum=[]; failures=[]
for org,code in tqdm(ORGANISMS.items(), desc='KEGG organisms'):
    try:
        ids,endpoint=fetch_reaction_ids(code); reactions=fetch_equations(ids)
        if len(reactions)<20: raise RuntimeError(f'Too few parsed equations: {len(reactions)}')
        G=build_graph(reactions)
        if G.number_of_nodes()<30 or G.number_of_edges()<30: raise RuntimeError(f'Network too small nodes={G.number_of_nodes()} edges={G.number_of_edges()}')
        org_networks[org]=dict(code=code, graph=G, reactions=reactions, source='KEGG', endpoint=endpoint)
        org_sum.append(dict(organism=org, org_code=code, source='KEGG', endpoint=endpoint, n_reaction_ids=len(ids), n_reactions_parsed=len(reactions), n_metabolites=G.number_of_nodes(), n_edges=G.number_of_edges()))
        print(f'  OK {org} {code}: reactions={len(reactions)} nodes={G.number_of_nodes()} edges={G.number_of_edges()}')
    except Exception as e:
        failures.append(dict(organism=org,org_code=code,stage='KEGG',error=str(e)))
        print(f'  FAIL {org} {code}: {e}')

if len(org_networks)<4:
    print('\n[WARN] Too few KEGG networks loaded. Activating internal fallback networks.')
    org_networks={}; org_sum=[]
    for org,code in ORGANISMS.items():
        reactions=fallback_reactions(org); G=build_graph(reactions)
        org_networks[org]=dict(code=code, graph=G, reactions=reactions, source='FALLBACK_CANONICAL', endpoint='internal')
        org_sum.append(dict(organism=org,org_code=code,source='FALLBACK_CANONICAL',endpoint='internal',n_reaction_ids=len(reactions),n_reactions_parsed=len(reactions),n_metabolites=G.number_of_nodes(),n_edges=G.number_of_edges()))

rows=[]
print('\nExtracting natural metabolic subgraphs and perturbative contrasts...')
for org,item in tqdm(org_networks.items(), desc='Metabolic organisms'):
    subs=sample_subgraphs(item['graph'], org)
    if not subs:
        failures.append(dict(organism=org,org_code=item['code'],stage='subgraph',error='No valid subgraphs'))
        continue
    for sid,sg in subs:
        f=graph_features(sg,org,item['code'],sid,'natural',item['source'])
        if f: rows.append(f)
        for mode in ['random_attack','H_support_attack','S_module_attack','L_bridge_attack']:
            f=graph_features(attacked_graph(sg,mode),org,item['code'],sid,mode,item['source'])
            if f: rows.append(f)

features=pd.DataFrame(rows); organism_summary=pd.DataFrame(org_sum)
if len(features)<80: raise RuntimeError('Too few metabolic feature rows even after fallback.')
for col in ['H_raw','S_raw','L_raw','Phi_metabolic_raw','Fragility_raw']:
    features[col.replace('_raw','')]=normalize01(features[col].values)
features['Phi_HSL_epsilon']=(features['H']+EPSILON)*(features['S']+EPSILON)*(features['L']+EPSILON)
features['Triadic_balance']=[triadic_balance(h,s,l) for h,s,l in zip(features.H,features.S,features.L)]
features['Functional_unity']=features['Phi_HSL_epsilon']*features['Triadic_balance']
features['Dominance_index']=[dominance_index(h,s,l) for h,s,l in zip(features.H,features.S,features.L)]
features['is_natural']=features.variant.eq('natural'); features['is_perturbed']=~features.is_natural
features['fragility_high_flag']=features.Fragility>=features.Fragility.median(); features['coherence_high_flag']=features.Phi_metabolic>=features.Phi_metabolic.median()
features['triadic_disproportion_flag']=(features.Triadic_balance<=features.Triadic_balance.quantile(.25))|(features.Dominance_index>=features.Dominance_index.quantile(.75))
features['H_attack_flag']=features.variant.eq('H_support_attack'); features['S_attack_flag']=features.variant.eq('S_module_attack'); features['L_attack_flag']=features.variant.eq('L_bridge_attack')
natural=features[features.is_natural].copy(); all_data=features.copy()

data_summary=pd.DataFrame([dict(n_organisms_loaded=len(org_networks), n_total_rows=len(features), n_natural_subgraphs=len(natural), n_perturbed_subgraphs=int(features.is_perturbed.sum()), sources=','.join(sorted(features.source.unique())), variants=','.join(sorted(features.variant.unique())), epsilon=EPSILON)])
genesis_summary=pd.DataFrame([
    regression(natural,['H'],'S','M1_NAT_H_to_S'), regression(natural,['H'],'L','M1_NAT_H_to_L'), regression(natural,['S'],'L','M1_NAT_S_to_L'), regression(natural,['H','S'],'L','M1_NAT_H_plus_S_to_L'),
    regression(natural,['H','S','L'],'Phi_metabolic','M1_NAT_HSL_to_Phi_metabolic'), regression(natural,['H','S','L'],'Functional_unity','M1_NAT_HSL_to_Functional_Unity'),
    regression(natural,['H','S','L'],'Fragility','M1_NAT_HSL_to_Metabolic_Fragility'), regression(natural,['H','S','L','Triadic_balance','Dominance_index'],'Fragility','M1_NAT_Full_to_Metabolic_Fragility')])
perturbative_summary=pd.DataFrame([
    regression(all_data,['H'],'S','M1_ALL_H_to_S'), regression(all_data,['H'],'L','M1_ALL_H_to_L'), regression(all_data,['S'],'L','M1_ALL_S_to_L'), regression(all_data,['H','S'],'L','M1_ALL_H_plus_S_to_L'),
    regression(all_data,['H','S','L'],'Phi_metabolic','M1_ALL_HSL_to_Phi_metabolic'), regression(all_data,['H','S','L'],'Functional_unity','M1_ALL_HSL_to_Functional_Unity'),
    regression(all_data,['H','S','L'],'Fragility','M1_ALL_HSL_to_Metabolic_Fragility'), regression(all_data,['H','S','L','Triadic_balance','Dominance_index'],'Fragility','M1_ALL_Full_to_Metabolic_Fragility'),
    regression(all_data,['H','S','L'],'H_attack_resilience','M1_ALL_HSL_to_H_attack_resilience'), regression(all_data,['H','S','L'],'S_attack_resilience','M1_ALL_HSL_to_S_attack_resilience'), regression(all_data,['H','S','L'],'L_attack_resilience','M1_ALL_HSL_to_L_attack_resilience')])

def mae(test):
    x=genesis_summary[genesis_summary.test==test]
    return None if len(x)==0 else x.iloc[0].mae
HL,SL,HSL=mae('M1_NAT_H_to_L'),mae('M1_NAT_S_to_L'),mae('M1_NAT_H_plus_S_to_L')
emergence_contrast=pd.DataFrame([dict(level='micro_metabolic_natural',H_to_L_mae=HL,S_to_L_mae=SL,H_plus_S_to_L_mae=HSL,HS_improves_over_H=HL-HSL if HL is not None else None,HS_improves_over_S=SL-HSL if SL is not None else None,PETU_prediction_supported=(HSL<HL and HSL<SL) if HL is not None else None)])
attack_summary=features.groupby('variant').agg(n=('organism','count'),n_organisms=('organism','nunique'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi=('Phi_metabolic','mean'),mean_Phi_HSL=('Phi_HSL_epsilon','mean'),mean_unity=('Functional_unity','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_fragility=('Fragility','mean'),mean_H_attack_res=('H_attack_resilience','mean'),mean_S_attack_res=('S_attack_resilience','mean'),mean_L_attack_res=('L_attack_resilience','mean'),mean_efficiency=('efficiency','mean'),mean_clustering=('clustering','mean'),mean_modularity=('modularity','mean')).reset_index().sort_values('mean_Phi',ascending=False)
organism_petu_summary=natural.groupby(['organism','org_code','source']).agg(n_subgraphs=('subgraph_id','count'),mean_nodes=('n_nodes','mean'),mean_edges=('n_edges','mean'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi=('Phi_metabolic','mean'),mean_unity=('Functional_unity','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_fragility=('Fragility','mean')).reset_index().sort_values('mean_Phi',ascending=False)

contrast_defs=[('natural_vs_perturbed','is_natural',True,False),('coherent_vs_low','coherence_high_flag',True,False),('fragility_high_vs_low','fragility_high_flag',True,False),('disproportion_vs_proportion','triadic_disproportion_flag',True,False),('H_attack_vs_other','H_attack_flag',True,False),('S_attack_vs_other','S_attack_flag',True,False),('L_attack_vs_other','L_attack_flag',True,False)]
metrics=['H','S','L','Phi_metabolic','Phi_HSL_epsilon','Functional_unity','Triadic_balance','Dominance_index','Fragility','H_attack_resilience','S_attack_resilience','L_attack_resilience','n_nodes','n_edges','lcc_fraction','density','mean_degree','degree_entropy','clustering','efficiency','modularity','articulation_penalty']
cr=[]
for cname,flag,a,b in contrast_defs:
    A=features[features[flag]==a]; B=features[features[flag]==b]
    for col in metrics:
        stat,p=safe_mw(A[col],B[col]); ma=A[col].mean(); mb=B[col].mean()
        cr.append(dict(contrast=cname,metric=col,groupA_mean=float(ma),groupB_mean=float(mb),delta_A_minus_B=float(ma-mb),pct_delta=float(100*(ma-mb)/(abs(mb)+1e-12)),mannwhitney_stat=stat,p_value=p))
contrast_summary=pd.DataFrame(cr)
class_rows=[]
targets=['is_natural','coherence_high_flag','fragility_high_flag','triadic_disproportion_flag','H_attack_flag','S_attack_flag','L_attack_flag']
fsets=[(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
for t in targets:
    for cols,label in fsets:
        r=auc_model(features,cols,t,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)
gains=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x=d[d.feature_set==fs]
        return None if len(x)==0 else float(x.iloc[0].auc)
    aH,aHS,aHSL,aFull=auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gains.append(dict(target=target,auc_H=aH,auc_HS=aHS,auc_HSL=aHSL,auc_full=aFull,gain_HSL_over_H=None if aH is None else aHSL-aH,gain_HSL_over_HS=None if aHS is None else aHSL-aHS,gain_full_over_HSL=None if aFull is None else aFull-aHSL))
classification_gain_summary=pd.DataFrame(gains)

def phase(r):
    if r.is_natural and r.Phi_metabolic>=features.Phi_metabolic.median() and r.Triadic_balance>=features.Triadic_balance.median(): return 'natural_phi_integrated'
    if r.variant=='H_support_attack': return 'H_support_attack_pathology'
    if r.variant=='S_module_attack': return 'S_structure_attack_pathology'
    if r.variant=='L_bridge_attack': return 'L_linkage_attack_pathology'
    if r.variant=='random_attack': return 'random_perturbation'
    if r.triadic_disproportion_flag: return 'triadic_disproportion'
    if r.is_natural and r.Fragility>=features.Fragility.median(): return 'natural_fragile_transition'
    if r.is_natural: return 'natural_transitional'
    return 'perturbed_transitional'
features['PETU_M1_phase']=features.apply(phase,axis=1)
phase_summary=features.groupby('PETU_M1_phase').agg(n=('organism','count'),n_organisms=('organism','nunique'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi=('Phi_metabolic','mean'),mean_Phi_HSL=('Phi_HSL_epsilon','mean'),mean_unity=('Functional_unity','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_fragility=('Fragility','mean'),mean_efficiency=('efficiency','mean'),mean_clustering=('clustering','mean'),mean_modularity=('modularity','mean')).reset_index().sort_values('n',ascending=False)

paths={
'features':f'{OUTDIR}/PETU_MICRO_METAB_M1_features.csv','organism_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_organism_summary.csv','organism_petu_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_organism_petu_summary.csv','data_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_data_summary.csv','genesis_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_genesis_summary.csv','perturbative_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_perturbative_summary.csv','emergence_contrast':f'{OUTDIR}/PETU_MICRO_METAB_M1_emergence_contrast.csv','attack_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_attack_summary.csv','contrast_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_contrast_summary.csv','classification_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_classification_summary.csv','classification_gain_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_classification_gain_summary.csv','phase_summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_phase_summary.csv','failures':f'{OUTDIR}/PETU_MICRO_METAB_M1_failures.csv','summary':f'{OUTDIR}/PETU_MICRO_METAB_M1_summary.json'}
features.to_csv(paths['features'],index=False); organism_summary.to_csv(paths['organism_summary'],index=False); organism_petu_summary.to_csv(paths['organism_petu_summary'],index=False); data_summary.to_csv(paths['data_summary'],index=False); genesis_summary.to_csv(paths['genesis_summary'],index=False); perturbative_summary.to_csv(paths['perturbative_summary'],index=False); emergence_contrast.to_csv(paths['emergence_contrast'],index=False); attack_summary.to_csv(paths['attack_summary'],index=False); contrast_summary.to_csv(paths['contrast_summary'],index=False); classification_summary.to_csv(paths['classification_summary'],index=False); classification_gain_summary.to_csv(paths['classification_gain_summary'],index=False); phase_summary.to_csv(paths['phase_summary'],index=False); pd.DataFrame(failures).to_csv(paths['failures'],index=False)
summary=dict(pipeline='PETU-MICRO-METAB M1 v2 Corrected Metabolic Network Triadic Audit',domain='micro natural metabolism / KEGG organism reaction networks / metabolite graphs',n_organisms_loaded=int(len(org_networks)),n_total_rows=int(len(features)),n_natural_subgraphs=int(len(natural)),n_perturbed_subgraphs=int(features.is_perturbed.sum()),sources=sorted(features.source.unique()),epsilon=EPSILON,hypothesis='Metabolic coherence arises from triadic proportion/co-inherence of H biochemical support, S pathway/network structure, and L reactive linkage.',correction_note='KEGG endpoints corrected to link/rn/{organism} and link/reaction/{organism}; fallback prevents HTTP 400 crashes.',next_step='MESO cardiorespiratory natural dynamics; then MESO embryogenesis.')
open(paths['summary'],'w').write(json.dumps(summary,indent=2))

print('\n'+'='*60); print('PETU-MICRO-METAB M1 DATA SUMMARY'); print('='*60); print(data_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 ORGANISM SUMMARY'); print('='*60); print(organism_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 ORGANISM PETU SUMMARY'); print('='*60); print(organism_petu_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 NATURAL GENESIS SUMMARY'); print('='*60); print(genesis_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 EMERGENCE CONTRAST'); print('='*60); print(emergence_contrast)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 PERTURBATIVE SUMMARY'); print('='*60); print(perturbative_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 ATTACK SUMMARY'); print('='*60); print(attack_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 CONTRAST SUMMARY'); print('='*60); print(contrast_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 CLASSIFICATION GAIN SUMMARY'); print('='*60); print(classification_gain_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 PHASE SUMMARY'); print('='*60); print(phase_summary)
print('\n'+'='*60); print('PETU-MICRO-METAB M1 FINAL SUMMARY'); print('='*60); print(json.dumps(summary,indent=2))
if len(failures)>0:
    print('\n'+'='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

plt.figure(figsize=(8,5)); plt.scatter(natural['H']+natural['S'],natural['L'],s=20,alpha=.6); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-METAB M1 natural: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_NAT_HS_to_L.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Phi_HSL_epsilon'],features['Phi_metabolic'],s=18,alpha=.45); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_metabolic'); plt.title('PETU-METAB M1: HSL unity vs metabolic coherence'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_PhiHSL_MetabolicPhi.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Dominance_index'],features['Fragility'],s=18,alpha=.45); plt.xlabel('Dominance index'); plt.ylabel('Metabolic fragility'); plt.title('PETU-METAB M1: dominance and fragility'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_Dominance_Fragility.png',dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(attack_summary['variant'],attack_summary['mean_Phi']); plt.xticks(rotation=45); plt.ylabel('Mean metabolic Phi'); plt.title('PETU-METAB M1: natural vs perturbative attacks'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_attack_phi.png',dpi=220); plt.show()
zip_base='/content/PETU_MICRO_METAB_M1_Metabolic_Network_Triadic_Audit_CORRECTED_results'; zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

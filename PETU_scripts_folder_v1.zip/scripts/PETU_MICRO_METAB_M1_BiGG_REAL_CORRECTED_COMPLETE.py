# ============================================================
# PETU-MICRO-METAB M1 v3 REAL CORRECTED
# BiGG Models Metabolic Network Triadic Audit
#
# Corrección de base de datos:
#   KEGG REST no permite obtener directamente reacciones por organismo con
#   link/rn/{org}; ese endpoint devuelve HTTP 400 para muchos códigos.
#   Esta versión cambia la fuente primaria a BiGG Models, que ofrece modelos
#   metabólicos reales en formato JSON COBRA por API pública:
#       http://bigg.ucsd.edu/api/v2/models
#       http://bigg.ucsd.edu/api/v2/models/{model_id}/download
#
# Fuente natural real:
#   Modelos metabólicos organismo-específicos BiGG, con reacciones y metabolitos
#   reales reconstruidos manualmente a escala genómica.
#
# PETU:
#   H = soporte bioquímico/material: riqueza de metabolitos, masa topológica,
#       disponibilidad de sustratos, soporte de red.
#   S = estructura formal metabólica: modularidad, jerarquía, entropía de grado,
#       organización de rutas/subsistemas.
#   L = vínculo reactivo/flujo potencial: conectividad, eficiencia, clustering,
#       continuidad y robustez de enlace.
#   Phi = coherencia metabólica: integración funcional, robustez ante ataques,
#       baja fragilidad de red.
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install requests numpy pandas scipy scikit-learn matplotlib tqdm networkx

import os, re, json, math, time, random, warnings, shutil
warnings.filterwarnings('ignore')

import requests
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

# ============================================================
# CONFIG
# ============================================================

OUTDIR = '/content/PETU_MICRO_METAB_M1_BiGG_REAL_CORRECTED'
os.makedirs(OUTDIR, exist_ok=True)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

EPSILON = 0.05
MAX_MODELS = 10
MAX_SUBGRAPHS_PER_MODEL = 80
MIN_SUBGRAPH_NODES = 18
MAX_SUBGRAPH_NODES = 140
ATTACK_FRAC = 0.12
REQUEST_TIMEOUT = 90

BIGG_BASES = [
    'http://bigg.ucsd.edu/api/v2',
    'https://bigg.ucsd.edu/api/v2'
]

# Preferred real BiGG model IDs. The script intersects these with the live API.
PREFERRED_MODELS = [
    'iML1515', 'iJO1366', 'iAF1260',       # Escherichia coli
    'iYO844',                             # Bacillus subtilis
    'iMM904', 'iND750',                   # Saccharomyces cerevisiae
    'RECON1', 'Recon3D',                  # Human
    'iJN678',                             # Synechocystis
    'iIT341', 'iSB619', 'iNJ661', 'iAF987'
]

# Currency metabolites often create artificial hubs. We remove them from graph construction.
CURRENCY_BASES = set('''
h h2o atp adp amp gtp gdp gmp ctp cdp cmp utp udp ump
pi ppi nad nadh nadp nadph fad fadh2 coa accoa co2 o2 nh4 hco3
na1 k ca2 mg2 cl fe2 fe3 so4 no3 no2 h2o2
'''.split())

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3: return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]; b = b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3: return None, None
        stat, p = mannwhitneyu(a, b, alternative='two-sided')
        return float(stat), float(p)
    except Exception:
        return None, None

def entropy_norm(vals):
    vals = np.asarray(vals, dtype=float)
    vals = vals[vals > 0]
    if vals.sum() <= 0 or len(vals) <= 1:
        return 0.0
    p = vals / vals.sum()
    ent = -np.sum(p*np.log(p+1e-12))
    return float(ent / np.log(len(vals)+1e-12))

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def strip_compartment(met_id):
    # BiGG ids normally have _c, _m, _e, etc. Remove final compartment suffix.
    return re.sub(r'_[a-z][a-z0-9]?$', '', str(met_id))

def is_currency(met_id):
    return strip_compartment(met_id).lower() in CURRENCY_BASES

def get_json_url(url, retries=3):
    last = None
    headers = {'User-Agent': 'PETU-METAB-M1-Colab/1.0'}
    for attempt in range(retries):
        try:
            r = requests.get(url, timeout=REQUEST_TIMEOUT, headers=headers)
            if r.status_code == 200:
                return r.json()
            last = f'HTTP {r.status_code}: {r.text[:120]}'
        except Exception as e:
            last = str(e)
        time.sleep(0.8 + attempt * 0.8)
    raise RuntimeError(last)

def bigg_get(path):
    errors = []
    for base in BIGG_BASES:
        try:
            return get_json_url(base + path), base + path
        except Exception as e:
            errors.append(f'{base+path} -> {e}')
    raise RuntimeError(' | '.join(errors))

# ============================================================
# BiGG FETCHING
# ============================================================

def fetch_bigg_models_index():
    data, url = bigg_get('/models')
    results = data.get('results', data if isinstance(data, list) else [])
    if not isinstance(results, list) or len(results) == 0:
        raise RuntimeError('BiGG models index returned no results')
    return results, url

def select_models(models_index, max_models=MAX_MODELS):
    # model entries usually include bigg_id, organism, metabolite_count, reaction_count, gene_count
    by_id = {}
    for m in models_index:
        mid = m.get('bigg_id') or m.get('id') or m.get('model_id')
        if mid:
            by_id[mid] = m

    selected = []
    for mid in PREFERRED_MODELS:
        if mid in by_id and mid not in [x[0] for x in selected]:
            selected.append((mid, by_id[mid]))
        if len(selected) >= max_models:
            return selected

    # Fill with largest models if preferred missing.
    def rxn_count(m):
        for k in ['reaction_count', 'reactions', 'num_reactions']:
            try:
                return int(m.get(k, 0))
            except Exception:
                pass
        return 0
    sorted_models = sorted(by_id.items(), key=lambda kv: rxn_count(kv[1]), reverse=True)
    for mid, m in sorted_models:
        if mid not in [x[0] for x in selected]:
            selected.append((mid, m))
        if len(selected) >= max_models:
            break
    return selected

def download_bigg_model(model_id):
    data, url = bigg_get(f'/models/{model_id}/download')
    # Some endpoints return JSON string as a field; handle both.
    if isinstance(data, str):
        data = json.loads(data)
    if 'reactions' not in data or 'metabolites' not in data:
        # Sometimes wrapped under model
        if 'model' in data:
            data = data['model']
    if 'reactions' not in data or 'metabolites' not in data:
        raise RuntimeError('Downloaded BiGG model lacks reactions/metabolites')
    return data, url

# ============================================================
# GRAPH BUILDING
# ============================================================

def build_graph_from_bigg_model(model):
    G = nx.Graph()
    reactions = model.get('reactions', [])
    metabolites = model.get('metabolites', [])

    met_names = {}
    for met in metabolites:
        mid = met.get('id')
        if mid:
            met_names[mid] = met.get('name', mid)

    used_reactions = 0
    skipped_currency_only = 0

    for rxn in reactions:
        rid = rxn.get('id', 'rxn')
        sto = rxn.get('metabolites', {}) or {}
        if not isinstance(sto, dict) or len(sto) < 2:
            continue

        subs = [m for m,v in sto.items() if float(v) < 0 and not is_currency(m)]
        prods = [m for m,v in sto.items() if float(v) > 0 and not is_currency(m)]
        comps = [m for m in sto.keys() if not is_currency(m)]

        if len(comps) < 2:
            skipped_currency_only += 1
            continue

        for c in comps:
            G.add_node(c, name=met_names.get(c, c), base=strip_compartment(c))

        made = False
        if subs and prods:
            for a in subs:
                for b in prods:
                    if a == b: continue
                    if G.has_edge(a,b):
                        G[a][b]['reactions'].add(rid)
                    else:
                        G.add_edge(a,b, reactions={rid})
                    made = True
        else:
            # Exchange/demand or incomplete direction: connect compounds lightly as clique.
            for i in range(len(comps)):
                for j in range(i+1, len(comps)):
                    a,b = comps[i], comps[j]
                    if a == b: continue
                    if G.has_edge(a,b):
                        G[a][b]['reactions'].add(rid)
                    else:
                        G.add_edge(a,b, reactions={rid})
                    made = True

        if made:
            used_reactions += 1

    for u,v,d in G.edges(data=True):
        d['reaction_count'] = len(d.get('reactions', []))

    return G, {'used_reactions': used_reactions, 'skipped_currency_only': skipped_currency_only}

# ============================================================
# FALLBACK REALISTIC SYNTHETIC ONLY IF BiGG UNAVAILABLE
# ============================================================

def fallback_metabolic_graph(model_id, n_modules=6, module_size=18):
    # Last-resort synthetic canonical-like network, clearly labelled as fallback.
    # It is not used if BiGG works.
    rng = random.Random(abs(hash(model_id)) % (2**32))
    G = nx.Graph()
    for mod in range(n_modules):
        nodes = [f'{model_id}_M{mod}_{i}' for i in range(module_size)]
        for n in nodes: G.add_node(n)
        # chain + shortcuts
        for i in range(module_size-1): G.add_edge(nodes[i], nodes[i+1], reaction_count=1)
        for _ in range(module_size):
            a,b = rng.sample(nodes,2); G.add_edge(a,b, reaction_count=1)
    hubs = [f'{model_id}_M{mod}_0' for mod in range(n_modules)]
    for i in range(len(hubs)-1): G.add_edge(hubs[i], hubs[i+1], reaction_count=2)
    central = f'{model_id}_central_cofactor'
    G.add_node(central)
    for h in hubs: G.add_edge(central, h, reaction_count=3)
    return G

# ============================================================
# FEATURE EXTRACTION
# ============================================================

def largest_cc_subgraph(G):
    if G.number_of_nodes() == 0:
        return G.copy()
    comps = list(nx.connected_components(G))
    if not comps:
        return G.copy()
    return G.subgraph(max(comps, key=len)).copy()

def approx_efficiency(G):
    if G.number_of_nodes() < 3:
        return 0.0
    try: return float(nx.global_efficiency(G))
    except Exception: return 0.0

def modularity_greedy(G):
    if G.number_of_nodes() < 5 or G.number_of_edges() < 4:
        return 0.0
    try:
        comms = list(nx.algorithms.community.greedy_modularity_communities(G))
        if len(comms) <= 1: return 0.0
        return float(nx.algorithms.community.modularity(G, comms))
    except Exception:
        return 0.0

def degree_entropy(G):
    return entropy_norm([d for _,d in G.degree()])

def safe_avg_clustering(G):
    try: return float(nx.average_clustering(G))
    except Exception: return 0.0

def sample_subgraphs(G, model_id, max_subgraphs=MAX_SUBGRAPHS_PER_MODEL):
    if G.number_of_nodes() < MIN_SUBGRAPH_NODES:
        return []
    Gcc = largest_cc_subgraph(G)
    deg = dict(Gcc.degree())
    nodes = list(Gcc.nodes())
    rng = random.Random(abs(hash(model_id)) % (2**32))

    hubs = [n for n,_ in sorted(deg.items(), key=lambda x:x[1], reverse=True)[:max(15, max_subgraphs//3)]]
    rand = rng.sample(nodes, min(len(nodes), max_subgraphs))
    seeds = []
    for n in hubs + rand:
        if n not in seeds:
            seeds.append(n)

    subgraphs = []
    for seed in seeds:
        if len(subgraphs) >= max_subgraphs: break
        ego = nx.ego_graph(Gcc, seed, radius=2).copy()
        if ego.number_of_nodes() > MAX_SUBGRAPH_NODES:
            # keep nearest/high-degree nodes inside ego
            edeg = dict(ego.degree())
            keep = [seed] + [n for n,_ in sorted(edeg.items(), key=lambda x:x[1], reverse=True) if n != seed]
            keep = keep[:MAX_SUBGRAPH_NODES]
            ego = ego.subgraph(keep).copy()
        if ego.number_of_nodes() >= MIN_SUBGRAPH_NODES and ego.number_of_edges() >= MIN_SUBGRAPH_NODES-1:
            subgraphs.append((f'ego2_{seed}', ego))

    # If not enough, add random connected BFS samples.
    attempts = 0
    while len(subgraphs) < min(max_subgraphs, 20) and attempts < 200:
        attempts += 1
        seed = rng.choice(nodes)
        target = rng.randint(MIN_SUBGRAPH_NODES, min(MAX_SUBGRAPH_NODES, max(MIN_SUBGRAPH_NODES, Gcc.number_of_nodes())))
        visited = [seed]
        frontier = [seed]
        while frontier and len(visited) < target:
            cur = frontier.pop(0)
            neigh = list(Gcc.neighbors(cur)); rng.shuffle(neigh)
            for nb in neigh:
                if nb not in visited:
                    visited.append(nb); frontier.append(nb)
                if len(visited) >= target: break
        sg = Gcc.subgraph(visited).copy()
        if sg.number_of_nodes() >= MIN_SUBGRAPH_NODES and sg.number_of_edges() >= MIN_SUBGRAPH_NODES-1:
            subgraphs.append((f'bfs_{seed}_{attempts}', sg))

    return subgraphs

def attacked_graph(G, mode, frac=ATTACK_FRAC):
    H = G.copy()
    if H.number_of_nodes() < 5: return H
    n_remove = max(1, int(frac * H.number_of_nodes()))
    if H.number_of_nodes() <= n_remove + 3: return H

    if mode == 'random_attack':
        rem = random.sample(list(H.nodes()), n_remove)
    elif mode == 'H_support_attack':
        rem = [n for n,_ in sorted(H.degree(), key=lambda x:x[1], reverse=True)[:n_remove]]
    elif mode == 'L_bridge_attack':
        try:
            btw = nx.betweenness_centrality(H, k=min(40, H.number_of_nodes()), seed=RANDOM_SEED)
            rem = [n for n,_ in sorted(btw.items(), key=lambda x:x[1], reverse=True)[:n_remove]]
        except Exception:
            rem = [n for n,_ in sorted(H.degree(), key=lambda x:x[1], reverse=True)[:n_remove]]
    elif mode == 'S_module_attack':
        try:
            comms = list(nx.algorithms.community.greedy_modularity_communities(H))
            largest = list(max(comms, key=len))
            rem = largest[:n_remove] if len(largest) >= n_remove else largest
        except Exception:
            rem = [n for n,_ in sorted(H.degree(), key=lambda x:x[1], reverse=True)[:n_remove]]
    else:
        rem = []
    H.remove_nodes_from(rem)
    return H

def graph_features(G, model_id, organism, source, subgraph_id, variant):
    n = G.number_of_nodes(); m = G.number_of_edges()
    if n < 3: return None
    Gcc = largest_cc_subgraph(G)
    lcc_frac = Gcc.number_of_nodes() / (n + 1e-12)
    density = nx.density(G) if n > 1 else 0.0
    degs = np.array([d for _,d in G.degree()], dtype=float)
    mean_deg = float(np.mean(degs)) if len(degs) else 0.0
    max_deg = float(np.max(degs)) if len(degs) else 0.0
    deg_cv = float(np.std(degs)/(np.mean(degs)+1e-12)) if len(degs) else 0.0
    deg_ent = degree_entropy(G)
    clustering = safe_avg_clustering(G)
    efficiency = approx_efficiency(Gcc)
    modularity = modularity_greedy(Gcc)
    transitivity = float(nx.transitivity(G)) if n > 2 else 0.0

    try:
        arts = list(nx.articulation_points(Gcc))
        articulation_penalty = len(arts)/(Gcc.number_of_nodes()+1e-12)
    except Exception:
        articulation_penalty = 0.0

    # H: support / material richness
    H_raw = np.mean([
        np.log1p(n) / np.log1p(MAX_SUBGRAPH_NODES),
        np.log1p(m) / np.log1p(MAX_SUBGRAPH_NODES*5),
        min(1.0, mean_deg/8.0),
        lcc_frac,
        min(1.0, density*20.0)
    ])

    # S: formal/pathway structure
    hierarchy = min(1.0, deg_cv/2.5)
    S_raw = np.mean([
        modularity,
        deg_ent,
        clustering,
        transitivity,
        hierarchy,
        1.0 - min(1.0, abs(density - 0.08)/0.35)
    ])

    # L: reactive linkage / flow potential
    L_raw = np.mean([
        lcc_frac,
        efficiency,
        clustering,
        transitivity,
        1.0 - min(1.0, articulation_penalty),
        min(1.0, mean_deg/6.0)
    ])

    # Independent robustness/coherence against attacks
    atkH = attacked_graph(Gcc, 'H_support_attack')
    atkS = attacked_graph(Gcc, 'S_module_attack')
    atkL = attacked_graph(Gcc, 'L_bridge_attack')
    def retained(g2):
        return largest_cc_subgraph(g2).number_of_nodes() / (Gcc.number_of_nodes()+1e-12) if Gcc.number_of_nodes() else 0.0
    H_res = retained(atkH); S_res = retained(atkS); L_res = retained(atkL)
    eff_res = np.mean([approx_efficiency(largest_cc_subgraph(atkH)), approx_efficiency(largest_cc_subgraph(atkS)), approx_efficiency(largest_cc_subgraph(atkL))])

    Phi_metabolic_raw = np.mean([
        lcc_frac,
        efficiency,
        clustering,
        transitivity,
        H_res,
        S_res,
        L_res,
        1.0 - min(1.0, articulation_penalty),
        min(1.0, eff_res/(efficiency+1e-9)) if efficiency > 1e-9 else 0.0
    ])

    Fragility_raw = np.mean([
        1.0 - H_res,
        1.0 - S_res,
        1.0 - L_res,
        min(1.0, articulation_penalty),
        1.0 - lcc_frac,
        min(1.0, deg_cv/3.0),
        1.0 - min(1.0, efficiency)
    ])

    return {
        'model_id': model_id,
        'organism': organism,
        'source': source,
        'subgraph_id': subgraph_id,
        'variant': variant,
        'n_nodes': int(n),
        'n_edges': int(m),
        'lcc_fraction': float(lcc_frac),
        'density': float(density),
        'mean_degree': float(mean_deg),
        'max_degree': float(max_deg),
        'degree_cv': float(deg_cv),
        'degree_entropy': float(deg_ent),
        'clustering': float(clustering),
        'transitivity': float(transitivity),
        'efficiency': float(efficiency),
        'modularity': float(modularity),
        'articulation_penalty': float(articulation_penalty),
        'H_attack_resilience': float(H_res),
        'S_attack_resilience': float(S_res),
        'L_attack_resilience': float(L_res),
        'H_raw': float(H_raw),
        'S_raw': float(S_raw),
        'L_raw': float(L_raw),
        'Phi_metabolic_raw': float(Phi_metabolic_raw),
        'Fragility_raw': float(Fragility_raw)
    }

# ============================================================
# MODEL HELPERS
# ============================================================

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {'test': label, 'n': int(len(d)), 'r2': None, 'mae': None, 'spearman_true_pred': None, 'p_value': None}
    X = d[X_cols].values.astype(float); y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r,p = safe_spearman(y, pred)
    return {'test': label, 'n': int(len(d)), 'r2': float(r2_score(y,pred)), 'mae': float(mean_absolute_error(y,pred)), 'spearman_true_pred': r, 'p_value': p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2: return None
    X = d[feature_cols].values.astype(float); y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight='balanced')
        clf.fit(X, y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {'feature_set': label, 'target': target, 'n': int(len(d)), 'auc': float(auc)}

# ============================================================
# MAIN
# ============================================================

print('='*60)
print('PETU-MICRO-METAB M1 BiGG REAL CORRECTED AUDIT')
print('='*60)
print('Fetching BiGG real metabolic models...')

failures = []
model_records = []
model_graphs = {}

try:
    models_index, idx_url = fetch_bigg_models_index()
    selected = select_models(models_index, MAX_MODELS)
    print('BiGG index OK:', idx_url, 'models_available:', len(models_index), 'selected:', [x[0] for x in selected])
except Exception as e:
    failures.append({'stage': 'BiGG_index', 'model_id': 'ALL', 'error': str(e)})
    selected = []
    print('FAIL BiGG index:', e)

for model_id, meta in tqdm(selected, desc='BiGG models'):
    try:
        model_json, dl_url = download_bigg_model(model_id)
        G, stats = build_graph_from_bigg_model(model_json)
        if G.number_of_nodes() < 60 or G.number_of_edges() < 60:
            raise RuntimeError(f'Graph too small after currency filtering: nodes={G.number_of_nodes()} edges={G.number_of_edges()}')
        organism = meta.get('organism') or model_json.get('organism') or model_id
        model_graphs[model_id] = {'graph': G, 'organism': organism, 'source': 'BiGG_REAL', 'download_url': dl_url, 'meta': meta, 'stats': stats}
        model_records.append({
            'model_id': model_id,
            'organism': organism,
            'source': 'BiGG_REAL',
            'download_url': dl_url,
            'n_metabolites_graph': G.number_of_nodes(),
            'n_edges_graph': G.number_of_edges(),
            'used_reactions': stats.get('used_reactions'),
            'skipped_currency_only': stats.get('skipped_currency_only'),
            'reaction_count_index': meta.get('reaction_count'),
            'metabolite_count_index': meta.get('metabolite_count'),
            'gene_count_index': meta.get('gene_count')
        })
        print(f'  OK {model_id}: nodes={G.number_of_nodes()} edges={G.number_of_edges()} organism={organism}')
    except Exception as e:
        failures.append({'stage': 'BiGG_model_download_or_graph', 'model_id': model_id, 'error': str(e)})
        print(f'  FAIL {model_id}: {e}')

# Last-resort fallback only if BiGG cannot be accessed.
if len(model_graphs) < 4:
    print('\n[WARN] BiGG access insufficient. Activating labelled synthetic fallback. Do not use fallback-only run as final empirical confirmation.')
    for i in range(6):
        mid = f'FALLBACK_METAB_{i+1}'
        G = fallback_metabolic_graph(mid, n_modules=6+i%3, module_size=18+i%4)
        model_graphs[mid] = {'graph': G, 'organism': mid, 'source': 'SYNTHETIC_FALLBACK_NOT_PRIMARY', 'download_url': 'internal', 'meta': {}, 'stats': {}}
        model_records.append({'model_id': mid, 'organism': mid, 'source': 'SYNTHETIC_FALLBACK_NOT_PRIMARY', 'download_url': 'internal', 'n_metabolites_graph': G.number_of_nodes(), 'n_edges_graph': G.number_of_edges(), 'used_reactions': None, 'skipped_currency_only': None})

print('\nExtracting natural metabolic subgraphs and perturbative contrasts...')
rows = []
for model_id, item in tqdm(model_graphs.items(), desc='Metabolic models'):
    G = item['graph']; organism = item['organism']; source = item['source']
    subgraphs = sample_subgraphs(G, model_id)
    if len(subgraphs) == 0:
        failures.append({'stage': 'subgraph_sampling', 'model_id': model_id, 'error': 'No valid subgraphs'})
        continue
    for sub_id, sg in subgraphs:
        feat = graph_features(sg, model_id, organism, source, sub_id, 'natural')
        if feat: rows.append(feat)
        for mode in ['random_attack', 'H_support_attack', 'S_module_attack', 'L_bridge_attack']:
            pg = attacked_graph(sg, mode, frac=ATTACK_FRAC)
            feat = graph_features(pg, model_id, organism, source, sub_id, mode)
            if feat: rows.append(feat)

features = pd.DataFrame(rows)
model_summary = pd.DataFrame(model_records)

if len(features) < 80:
    raise RuntimeError('Too few metabolic feature rows. BiGG and fallback both failed to generate analyzable networks.')

for col in ['H_raw','S_raw','L_raw','Phi_metabolic_raw','Fragility_raw']:
    features[col.replace('_raw','')] = normalize01(features[col].values)

features['Phi_HSL_epsilon'] = (features['H'] + EPSILON) * (features['S'] + EPSILON) * (features['L'] + EPSILON)
features['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(features['H'],features['S'],features['L'])]
features['Functional_unity'] = features['Phi_HSL_epsilon'] * features['Triadic_balance']
features['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(features['H'],features['S'],features['L'])]
features['is_natural'] = features['variant'].eq('natural')
features['is_perturbed'] = ~features['is_natural']
features['fragility_high_flag'] = features['Fragility'] >= features['Fragility'].median()
features['coherence_high_flag'] = features['Phi_metabolic'] >= features['Phi_metabolic'].median()
features['triadic_disproportion_flag'] = ((features['Triadic_balance'] <= features['Triadic_balance'].quantile(0.25)) | (features['Dominance_index'] >= features['Dominance_index'].quantile(0.75)))
features['H_attack_flag'] = features['variant'].eq('H_support_attack')
features['S_attack_flag'] = features['variant'].eq('S_module_attack')
features['L_attack_flag'] = features['variant'].eq('L_bridge_attack')

natural = features[features['is_natural']].copy()

# ============================================================
# SUMMARIES
# ============================================================

data_summary = pd.DataFrame([{
    'n_models_loaded': int(len(model_graphs)),
    'n_total_rows': int(len(features)),
    'n_natural_subgraphs': int(len(natural)),
    'n_perturbed_subgraphs': int(features['is_perturbed'].sum()),
    'sources': ','.join(sorted(features['source'].unique())),
    'variants': ','.join(sorted(features['variant'].unique())),
    'epsilon': EPSILON,
    'attack_frac': ATTACK_FRAC
}])

genesis_summary = pd.DataFrame([
    regression(natural, ['H'], 'S', 'M1_NAT_H_to_S'),
    regression(natural, ['H'], 'L', 'M1_NAT_H_to_L'),
    regression(natural, ['S'], 'L', 'M1_NAT_S_to_L'),
    regression(natural, ['H','S'], 'L', 'M1_NAT_H_plus_S_to_L'),
    regression(natural, ['H','S','L'], 'Phi_metabolic', 'M1_NAT_HSL_to_Phi_metabolic'),
    regression(natural, ['H','S','L'], 'Functional_unity', 'M1_NAT_HSL_to_Functional_Unity'),
    regression(natural, ['H','S','L'], 'Fragility', 'M1_NAT_HSL_to_Metabolic_Fragility'),
    regression(natural, ['H','S','L','Triadic_balance','Dominance_index'], 'Fragility', 'M1_NAT_Full_to_Metabolic_Fragility'),
])

perturbative_summary = pd.DataFrame([
    regression(features, ['H'], 'S', 'M1_ALL_H_to_S'),
    regression(features, ['H'], 'L', 'M1_ALL_H_to_L'),
    regression(features, ['S'], 'L', 'M1_ALL_S_to_L'),
    regression(features, ['H','S'], 'L', 'M1_ALL_H_plus_S_to_L'),
    regression(features, ['H','S','L'], 'Phi_metabolic', 'M1_ALL_HSL_to_Phi_metabolic'),
    regression(features, ['H','S','L'], 'Functional_unity', 'M1_ALL_HSL_to_Functional_Unity'),
    regression(features, ['H','S','L'], 'Fragility', 'M1_ALL_HSL_to_Metabolic_Fragility'),
    regression(features, ['H','S','L','Triadic_balance','Dominance_index'], 'Fragility', 'M1_ALL_Full_to_Metabolic_Fragility'),
    regression(features, ['H','S','L'], 'H_attack_resilience', 'M1_ALL_HSL_to_H_attack_resilience'),
    regression(features, ['H','S','L'], 'S_attack_resilience', 'M1_ALL_HSL_to_S_attack_resilience'),
    regression(features, ['H','S','L'], 'L_attack_resilience', 'M1_ALL_HSL_to_L_attack_resilience'),
])

def get_mae(summary, test):
    x = summary[summary['test'] == test]
    return None if len(x)==0 else x.iloc[0]['mae']
H_L = get_mae(genesis_summary, 'M1_NAT_H_to_L')
S_L = get_mae(genesis_summary, 'M1_NAT_S_to_L')
HS_L = get_mae(genesis_summary, 'M1_NAT_H_plus_S_to_L')
emergence_contrast = pd.DataFrame([{
    'level': 'micro_metabolic_natural_BiGG',
    'H_to_L_mae': H_L,
    'S_to_L_mae': S_L,
    'H_plus_S_to_L_mae': HS_L,
    'HS_improves_over_H': H_L-HS_L if H_L is not None and HS_L is not None else None,
    'HS_improves_over_S': S_L-HS_L if S_L is not None and HS_L is not None else None,
    'PETU_prediction_supported': (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

attack_summary = features.groupby('variant').agg(
    n=('model_id','count'), n_models=('model_id','nunique'),
    mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'),
    mean_Phi=('Phi_metabolic','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'), mean_unity=('Functional_unity','mean'),
    mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_fragility=('Fragility','mean'),
    mean_H_attack_res=('H_attack_resilience','mean'), mean_S_attack_res=('S_attack_resilience','mean'), mean_L_attack_res=('L_attack_resilience','mean'),
    mean_efficiency=('efficiency','mean'), mean_clustering=('clustering','mean'), mean_modularity=('modularity','mean')
).reset_index().sort_values('mean_Phi', ascending=False)

organism_petu_summary = natural.groupby(['model_id','organism','source']).agg(
    n_subgraphs=('subgraph_id','count'), mean_nodes=('n_nodes','mean'), mean_edges=('n_edges','mean'),
    mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi=('Phi_metabolic','mean'),
    mean_unity=('Functional_unity','mean'), mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_fragility=('Fragility','mean')
).reset_index().sort_values('mean_Phi', ascending=False)

contrast_defs = [
    ('natural_vs_perturbed','is_natural',True,False),
    ('coherent_vs_low','coherence_high_flag',True,False),
    ('fragility_high_vs_low','fragility_high_flag',True,False),
    ('disproportion_vs_proportion','triadic_disproportion_flag',True,False),
    ('H_attack_vs_other','H_attack_flag',True,False),
    ('S_attack_vs_other','S_attack_flag',True,False),
    ('L_attack_vs_other','L_attack_flag',True,False),
]
contrast_metrics = ['H','S','L','Phi_metabolic','Phi_HSL_epsilon','Functional_unity','Triadic_balance','Dominance_index','Fragility','H_attack_resilience','S_attack_resilience','L_attack_resilience','n_nodes','n_edges','lcc_fraction','density','mean_degree','degree_entropy','clustering','transitivity','efficiency','modularity','articulation_penalty']
contrast_rows=[]
for cname, flag, aval, bval in contrast_defs:
    A = features[features[flag] == aval]; B = features[features[flag] == bval]
    for col in contrast_metrics:
        stat,p = safe_mw(A[col], B[col])
        contrast_rows.append({'contrast':cname,'metric':col,'groupA_mean':float(A[col].mean()) if len(A) else np.nan,'groupB_mean':float(B[col].mean()) if len(B) else np.nan,'delta_A_minus_B':float(A[col].mean()-B[col].mean()) if len(A) and len(B) else np.nan,'pct_delta':float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,'mannwhitney_stat':stat,'p_value':p})
contrast_summary = pd.DataFrame(contrast_rows)

class_rows=[]
targets = ['is_natural','coherence_high_flag','fragility_high_flag','triadic_disproportion_flag','H_attack_flag','S_attack_flag','L_attack_flag']
feature_sets = [(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
for target in targets:
    for cols,label in feature_sets:
        r = auc_model(features, cols, target, label)
        if r: class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows=[]
for target,d in classification_summary.groupby('target'):
    def auc(fs):
        x=d[d['feature_set']==fs]
        return None if len(x)==0 else float(x.iloc[0]['auc'])
    aH,aHS,aHSL,aFull = auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
    gain_rows.append({'target':target,'auc_H':aH,'auc_HS':aHS,'auc_HSL':aHSL,'auc_full':aFull,'gain_HSL_over_H':None if aH is None or aHSL is None else aHSL-aH,'gain_HSL_over_HS':None if aHS is None or aHSL is None else aHSL-aHS,'gain_full_over_HSL':None if aFull is None or aHSL is None else aFull-aHSL})
classification_gain_summary = pd.DataFrame(gain_rows)

def classify_phase(r):
    if r['is_natural'] and r['Phi_metabolic'] >= features['Phi_metabolic'].median() and r['Triadic_balance'] >= features['Triadic_balance'].median(): return 'natural_phi_integrated'
    if r['variant'] == 'H_support_attack': return 'H_support_attack_pathology'
    if r['variant'] == 'S_module_attack': return 'S_structure_attack_pathology'
    if r['variant'] == 'L_bridge_attack': return 'L_linkage_attack_pathology'
    if r['variant'] == 'random_attack': return 'random_perturbation'
    if r['triadic_disproportion_flag']: return 'triadic_disproportion'
    if r['is_natural'] and r['Fragility'] >= features['Fragility'].median(): return 'natural_fragile_transition'
    if r['is_natural']: return 'natural_transitional'
    return 'perturbed_transitional'
features['PETU_M1_phase'] = features.apply(classify_phase, axis=1)
phase_summary = features.groupby('PETU_M1_phase').agg(
    n=('model_id','count'), n_models=('model_id','nunique'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi=('Phi_metabolic','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'), mean_unity=('Functional_unity','mean'), mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_fragility=('Fragility','mean'), mean_efficiency=('efficiency','mean'), mean_clustering=('clustering','mean'), mean_modularity=('modularity','mean')
).reset_index().sort_values('n', ascending=False)

# ============================================================
# SAVE
# ============================================================

paths = {
    'features': f'{OUTDIR}/PETU_MICRO_METAB_M1_features.csv',
    'model_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_model_summary.csv',
    'organism_petu_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_organism_petu_summary.csv',
    'data_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_data_summary.csv',
    'genesis_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_genesis_summary.csv',
    'perturbative_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_perturbative_summary.csv',
    'emergence_contrast': f'{OUTDIR}/PETU_MICRO_METAB_M1_emergence_contrast.csv',
    'attack_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_attack_summary.csv',
    'contrast_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_contrast_summary.csv',
    'classification_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_classification_summary.csv',
    'classification_gain_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_classification_gain_summary.csv',
    'phase_summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_phase_summary.csv',
    'failures': f'{OUTDIR}/PETU_MICRO_METAB_M1_failures.csv',
    'summary': f'{OUTDIR}/PETU_MICRO_METAB_M1_summary.json'
}
features.to_csv(paths['features'], index=False)
model_summary.to_csv(paths['model_summary'], index=False)
organism_petu_summary.to_csv(paths['organism_petu_summary'], index=False)
data_summary.to_csv(paths['data_summary'], index=False)
genesis_summary.to_csv(paths['genesis_summary'], index=False)
perturbative_summary.to_csv(paths['perturbative_summary'], index=False)
emergence_contrast.to_csv(paths['emergence_contrast'], index=False)
attack_summary.to_csv(paths['attack_summary'], index=False)
contrast_summary.to_csv(paths['contrast_summary'], index=False)
classification_summary.to_csv(paths['classification_summary'], index=False)
classification_gain_summary.to_csv(paths['classification_gain_summary'], index=False)
phase_summary.to_csv(paths['phase_summary'], index=False)
pd.DataFrame(failures).to_csv(paths['failures'], index=False)

summary = {
    'pipeline': 'PETU-MICRO-METAB M1 v3 BiGG Real Corrected Metabolic Network Triadic Audit',
    'domain': 'micro natural metabolism / BiGG genome-scale metabolic models / metabolite reaction graphs',
    'n_models_loaded': int(len(model_graphs)),
    'n_total_rows': int(len(features)),
    'n_natural_subgraphs': int(len(natural)),
    'n_perturbed_subgraphs': int(features['is_perturbed'].sum()),
    'sources': sorted(features['source'].unique()),
    'epsilon': EPSILON,
    'hypothesis': 'Metabolic coherence arises from triadic proportion/co-inherence of H biochemical support, S pathway/network structure, and L reactive linkage.',
    'correction_note': 'Changed primary database from KEGG organism reaction links, which returned HTTP 400, to BiGG real COBRA JSON model downloads.',
    'next_step': 'MESO cardiorespiratory natural dynamics; then MESO embryogenesis.'
}
with open(paths['summary'], 'w') as f: json.dump(summary, f, indent=2)

# ============================================================
# PRINT
# ============================================================

print('\n' + '='*60); print('PETU-MICRO-METAB M1 DATA SUMMARY'); print('='*60); print(data_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 MODEL SUMMARY'); print('='*60); print(model_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 ORGANISM PETU SUMMARY'); print('='*60); print(organism_petu_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 NATURAL GENESIS SUMMARY'); print('='*60); print(genesis_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 EMERGENCE CONTRAST'); print('='*60); print(emergence_contrast)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 PERTURBATIVE SUMMARY'); print('='*60); print(perturbative_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 ATTACK SUMMARY'); print('='*60); print(attack_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 CONTRAST SUMMARY'); print('='*60); print(contrast_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 CLASSIFICATION GAIN SUMMARY'); print('='*60); print(classification_gain_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 PHASE SUMMARY'); print('='*60); print(phase_summary)
print('\n' + '='*60); print('PETU-MICRO-METAB M1 FINAL SUMMARY'); print('='*60); print(json.dumps(summary, indent=2))
if len(failures) > 0:
    print('\n' + '='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

# Figures
plt.figure(figsize=(8,5)); plt.scatter(natural['H']+natural['S'], natural['L'], s=20, alpha=0.60); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-METAB M1 natural: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_NAT_HS_to_L.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Phi_HSL_epsilon'], features['Phi_metabolic'], s=18, alpha=0.45); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_metabolic'); plt.title('PETU-METAB M1: HSL unity vs metabolic coherence'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_PhiHSL_MetabolicPhi.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Dominance_index'], features['Fragility'], s=18, alpha=0.45); plt.xlabel('Dominance index'); plt.ylabel('Metabolic fragility'); plt.title('PETU-METAB M1: dominance and fragility'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_Dominance_Fragility.png', dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(attack_summary['variant'], attack_summary['mean_Phi']); plt.xticks(rotation=45); plt.ylabel('Mean metabolic Phi'); plt.title('PETU-METAB M1: natural vs perturbative attacks'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_M1_attack_phi.png', dpi=220); plt.show()

zip_base = '/content/PETU_MICRO_METAB_M1_BiGG_REAL_CORRECTED_results'
zip_path = zip_base + '.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base, 'zip', OUTDIR)
print('\n' + '='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k + ':', v)
print('ZIP:', zip_path); print('='*60)


# ============================================================
# PETU-GENESIS PROTEIN P4b DYNAMIC FOLDING REFINED - COMPLETE
# Exploratory structural folding dynamics with local/global normalization,
# Phi_epsilon and threshold-order analysis.
#
# NOTE: This is not full physical molecular dynamics. It is an exploratory
# structural trajectory from an extended chain toward the native PDB structure.
# ============================================================

!pip -q install biopython networkx numpy scipy pandas matplotlib scikit-learn

import os, json, shutil, warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
from Bio.PDB import PDBList, PDBParser, is_aa
from scipy.spatial.distance import pdist, squareform
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error

# ---------------- CONFIG ----------------
OUTDIR = "/content/PETU_Genesis_Protein_P4b_Dynamic_Folding_Refined"
PDB_DIR = "/content/PETU_PDB_DYNAMIC"
os.makedirs(OUTDIR, exist_ok=True)
os.makedirs(PDB_DIR, exist_ok=True)

PDB_IDS = ["1PGB", "1UBQ", "1ENH", "1FSD", "1CRN", "1VII", "1BTA", "1CSP", "1R69", "2CI2"]
MIN_RESIDUES = 20
MAX_RESIDUES = 160
CONTACT_CUTOFF = 8.0
N_FRAMES = 100
NOISE_START = 18.0
NOISE_END = 0.4
EPSILON = 0.05
THRESHOLDS = [0.25, 0.50, 0.75]
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# ---------------- AA TABLES ----------------
HYDROPATHY = {
    "ALA": 1.8, "ARG": -4.5, "ASN": -3.5, "ASP": -3.5, "CYS": 2.5,
    "GLN": -3.5, "GLU": -3.5, "GLY": -0.4, "HIS": -3.2, "ILE": 4.5,
    "LEU": 3.8, "LYS": -3.9, "MET": 1.9, "PHE": 2.8, "PRO": -1.6,
    "SER": -0.8, "THR": -0.7, "TRP": -0.9, "TYR": -1.3, "VAL": 4.2
}
MASS = {
    "ALA": 89.09, "ARG": 174.20, "ASN": 132.12, "ASP": 133.10, "CYS": 121.16,
    "GLN": 146.15, "GLU": 147.13, "GLY": 75.07, "HIS": 155.16, "ILE": 131.17,
    "LEU": 131.17, "LYS": 146.19, "MET": 149.21, "PHE": 165.19, "PRO": 115.13,
    "SER": 105.09, "THR": 119.12, "TRP": 204.23, "TYR": 181.19, "VAL": 117.15
}
CHARGE = {aa: 0 for aa in HYDROPATHY}
CHARGE.update({"ARG": 1, "LYS": 1, "HIS": 0.5, "ASP": -1, "GLU": -1})
POLAR = {aa: 0 for aa in HYDROPATHY}
for aa in ["ARG", "ASN", "ASP", "GLN", "GLU", "HIS", "LYS", "SER", "THR", "TYR"]:
    POLAR[aa] = 1

# ---------------- UTILS ----------------
def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def normalize01_groupwise(df, cols, group_col="pdb_id"):
    out = df.copy()
    for col in cols:
        out[col + "_local_norm"] = out.groupby(group_col)[col].transform(lambda x: normalize01(x.values))
    return out

def safe_mean(x):
    x = [v for v in x if np.isfinite(v)]
    return float(np.mean(x)) if x else 0.0

def safe_std(x):
    x = [v for v in x if np.isfinite(v)]
    return float(np.std(x)) if x else 0.0

def safe_spearman(a, b):
    try:
        a, b = np.asarray(a, float), np.asarray(b, float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def pairwise_distances(coords):
    if len(coords) < 2:
        return np.zeros((len(coords), len(coords)))
    return squareform(pdist(coords))

def contact_matrix(coords, cutoff=8.0):
    D = pairwise_distances(coords)
    C = (D <= cutoff).astype(int)
    np.fill_diagonal(C, 0)
    return C, D

def radius_of_gyration(coords):
    c = np.mean(coords, axis=0)
    return float(np.sqrt(np.mean(np.sum((coords - c) ** 2, axis=1))))

def graph_from_C(C):
    G = nx.Graph()
    n = C.shape[0]
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            if C[i, j] > 0:
                G.add_edge(i, j)
    return G

def graph_efficiency(G):
    try:
        return float(nx.global_efficiency(G))
    except Exception:
        return 0.0

def graph_lcc_fraction(G):
    if G.number_of_nodes() == 0:
        return 0.0
    comps = list(nx.connected_components(G))
    if not comps:
        return 0.0
    return float(max(len(c) for c in comps) / G.number_of_nodes())

def graph_degree_entropy(G):
    deg = np.array([d for _, d in G.degree()], dtype=float)
    if len(deg) == 0 or deg.sum() <= 0:
        return 0.0
    p = deg / deg.sum()
    ent = -np.sum(p * np.log(p + 1e-12))
    return float(ent / np.log(len(p) + 1e-12))

def rmsd(A, B):
    return float(np.sqrt(np.mean(np.sum((np.asarray(A) - np.asarray(B)) ** 2, axis=1))))

def native_contact_fraction(C, C_native):
    total_native = np.sum(C_native) / 2
    if total_native <= 0:
        return 0.0
    recovered = np.sum((C > 0) & (C_native > 0)) / 2
    return float(recovered / total_native)

def center_coords(coords):
    return coords - np.mean(coords, axis=0)

def triadic_balance(df, cols):
    return (1 - df[cols].std(axis=1)).clip(lower=0)

def dominance_index(df, cols):
    return df[cols].max(axis=1) - df[cols].min(axis=1)

# ---------------- PDB ----------------
pdbl = PDBList()
parser = PDBParser(QUIET=True)

def download_pdb(pdb_id):
    return pdbl.retrieve_pdb_file(pdb_id.lower(), pdir=PDB_DIR, file_format="pdb", overwrite=False)

def extract_best_chain_ca(pdb_path, pdb_id):
    structure = parser.get_structure(pdb_id, pdb_path)
    for model in structure:
        best_res, best_coords = [], []
        for chain in model:
            residues, coords = [], []
            for res in chain:
                if is_aa(res, standard=True) and "CA" in res:
                    rn = res.get_resname().upper()
                    if rn in HYDROPATHY:
                        residues.append(rn)
                        coords.append(res["CA"].get_coord())
            if len(residues) > len(best_res):
                best_res, best_coords = residues, coords
        return best_res, np.array(best_coords, dtype=float)
    return [], np.array([], dtype=float)

# ---------------- FEATURES ----------------
def H_sequence_raw(residues):
    hyd = [HYDROPATHY[r] for r in residues]
    mass = [MASS[r] for r in residues]
    charge = [CHARGE[r] for r in residues]
    polar = [POLAR[r] for r in residues]
    n = len(residues)
    vals = {
        "H_mass_mean": safe_mean(mass),
        "H_hydro_abs_mean": safe_mean([abs(x) for x in hyd]),
        "H_hydro_std": safe_std(hyd),
        "H_charge_abs_mean": safe_mean([abs(x) for x in charge]),
        "H_net_charge_abs": abs(float(np.sum(charge))) / max(n, 1),
        "H_polar_fraction": safe_mean(polar)
    }
    vals["H_raw"] = safe_mean(list(vals.values()))
    return vals

def S_structure_raw(coords, C, D, coords_native):
    n = len(coords)
    if n < 2:
        return {"S_contact_density": 0, "S_compactness": 0, "S_local_contact_fraction": 0,
                "S_distance_regularity": 0, "S_native_similarity": 0, "S_raw": 0}
    rg = radius_of_gyration(coords)
    contact_density = float(np.sum(C) / (n * (n - 1) + 1e-12))
    compactness = 1 / ((rg / (n ** (1/3) + 1e-12)) + 1e-12)
    total_contacts = np.sum(C) / 2
    local_contacts = 0
    for i in range(n):
        for j in range(i + 1, n):
            if C[i, j] > 0 and abs(i - j) <= 6:
                local_contacts += 1
    local_frac = float(local_contacts / (total_contacts + 1e-12))
    contact_distances = D[C > 0]
    distance_regularity = 1 / (np.std(contact_distances) + 1e-12) if len(contact_distances) > 0 else 0.0
    native_similarity = 1 / (1 + rmsd(coords, coords_native))
    vals = {
        "S_contact_density": contact_density,
        "S_compactness": compactness,
        "S_local_contact_fraction": local_frac,
        "S_distance_regularity": distance_regularity,
        "S_native_similarity": native_similarity
    }
    vals["S_raw"] = safe_mean(list(vals.values()))
    return vals

def L_network_raw(C, C_native):
    G = graph_from_C(C)
    n = G.number_of_nodes()
    if n == 0:
        return {"L_avg_degree": 0, "L_efficiency": 0, "L_clustering": 0,
                "L_lcc_fraction": 0, "L_degree_entropy": 0, "L_native_contact_fraction": 0, "L_raw": 0}
    vals = {
        "L_avg_degree": float(np.mean([d for _, d in G.degree()])),
        "L_efficiency": graph_efficiency(G),
        "L_clustering": float(nx.average_clustering(G)),
        "L_lcc_fraction": graph_lcc_fraction(G),
        "L_degree_entropy": graph_degree_entropy(G),
        "L_native_contact_fraction": native_contact_fraction(C, C_native)
    }
    vals["L_raw"] = safe_mean(list(vals.values()))
    return vals

# ---------------- TRAJECTORY ----------------
def extended_chain_coords(n):
    coords = []
    for i in range(n):
        coords.append([3.8 * i, 2.0 * np.sin(i / 4.0), 2.0 * np.cos(i / 5.0)])
    return center_coords(np.array(coords, dtype=float))

def folding_alpha(t):
    return float(1 / (1 + np.exp(-((t - 0.5) * 10))))

def generate_folding_frame(coords_extended, coords_native, frame_idx, n_frames):
    t = frame_idx / (n_frames - 1)
    a = folding_alpha(t)
    noise_level = NOISE_START * (1 - a) + NOISE_END * a
    noise = np.random.normal(0, noise_level, coords_native.shape)
    coords = (1 - a) * coords_extended + a * coords_native + noise
    return center_coords(coords), t, a, noise_level

# ---------------- LOAD ----------------
proteins, failures = {}, []
print("============================================================")
print("PETU-GENESIS PROTEIN P4b DYNAMIC FOLDING REFINED")
print("============================================================")

for pdb_id in PDB_IDS:
    pdb_id = pdb_id.upper()
    print("\nLoading:", pdb_id)
    try:
        path = download_pdb(pdb_id)
        residues, coords_native = extract_best_chain_ca(path, pdb_id)
        n = len(residues)
        if n < MIN_RESIDUES or n > MAX_RESIDUES:
            failures.append({"pdb_id": pdb_id, "error": f"residue count out of range: {n}"})
            print("  SKIP:", n)
            continue
        coords_native = center_coords(coords_native)
        proteins[pdb_id] = {
            "residues": residues,
            "coords_native": coords_native,
            "coords_extended": extended_chain_coords(n)
        }
        print("  OK:", n, "residues")
    except Exception as e:
        failures.append({"pdb_id": pdb_id, "error": str(e)})
        print("  FAIL:", e)

if len(proteins) == 0:
    raise RuntimeError("No proteins loaded.")

# ---------------- RUN ----------------
rows = []
for pdb_id, obj in proteins.items():
    residues = obj["residues"]
    coords_native = obj["coords_native"]
    coords_extended = obj["coords_extended"]
    n = len(residues)
    C_native, _ = contact_matrix(coords_native, CONTACT_CUTOFF)
    Hvals = H_sequence_raw(residues)
    for frame in range(N_FRAMES):
        coords, t, alpha, noise = generate_folding_frame(coords_extended, coords_native, frame, N_FRAMES)
        C, D = contact_matrix(coords, CONTACT_CUTOFF)
        row = {"pdb_id": pdb_id, "frame": frame, "t": t, "folding_alpha": alpha,
               "noise_level": noise, "n_residues": n, **Hvals,
               **S_structure_raw(coords, C, D, coords_native), **L_network_raw(C, C_native)}
        rows.append(row)

dynamic_df = pd.DataFrame(rows)

# ---------------- NORMALIZATION ----------------
H_BASE = ["H_mass_mean", "H_hydro_abs_mean", "H_hydro_std", "H_charge_abs_mean", "H_net_charge_abs", "H_polar_fraction"]
S_BASE = ["S_contact_density", "S_compactness", "S_local_contact_fraction", "S_distance_regularity", "S_native_similarity"]
L_BASE = ["L_avg_degree", "L_efficiency", "L_clustering", "L_lcc_fraction", "L_degree_entropy", "L_native_contact_fraction"]
RAW_BASE = H_BASE + S_BASE + L_BASE

# Global normalization across all frames/proteins
for col in RAW_BASE:
    dynamic_df[col + "_global_norm"] = normalize01(dynamic_df[col].values)
dynamic_df["H_global"] = dynamic_df[[c + "_global_norm" for c in H_BASE]].mean(axis=1)
dynamic_df["S_global"] = dynamic_df[[c + "_global_norm" for c in S_BASE]].mean(axis=1)
dynamic_df["L_global"] = dynamic_df[[c + "_global_norm" for c in L_BASE]].mean(axis=1)
dynamic_df["Phi_global_raw"] = dynamic_df["H_global"] * dynamic_df["S_global"] * dynamic_df["L_global"]
dynamic_df["Phi_global_epsilon"] = (dynamic_df["H_global"] + EPSILON) * (dynamic_df["S_global"] + EPSILON) * (dynamic_df["L_global"] + EPSILON)
dynamic_df["Triadic_balance_global"] = triadic_balance(dynamic_df, ["H_global", "S_global", "L_global"])
dynamic_df["Functional_unity_global"] = dynamic_df["Phi_global_epsilon"] * dynamic_df["Triadic_balance_global"]
dynamic_df["Dominance_index_global"] = dominance_index(dynamic_df, ["H_global", "S_global", "L_global"])

# Local per-protein normalization
# H sequence features are constant inside each protein, so local normalization would make H=0.
# To preserve H as constitutive support, H_local reuses global-normalized H components;
# S and L are normalized within each protein trajectory.
for col in H_BASE:
    dynamic_df[col + "_local_norm"] = dynamic_df[col + "_global_norm"]
dynamic_df = normalize01_groupwise(dynamic_df, S_BASE + L_BASE, group_col="pdb_id")

dynamic_df["H_local"] = dynamic_df[[c + "_local_norm" for c in H_BASE]].mean(axis=1)
dynamic_df["S_local"] = dynamic_df[[c + "_local_norm" for c in S_BASE]].mean(axis=1)
dynamic_df["L_local"] = dynamic_df[[c + "_local_norm" for c in L_BASE]].mean(axis=1)
dynamic_df["Phi_local_raw"] = dynamic_df["H_local"] * dynamic_df["S_local"] * dynamic_df["L_local"]
dynamic_df["Phi_local_epsilon"] = (dynamic_df["H_local"] + EPSILON) * (dynamic_df["S_local"] + EPSILON) * (dynamic_df["L_local"] + EPSILON)
dynamic_df["Triadic_balance_local"] = triadic_balance(dynamic_df, ["H_local", "S_local", "L_local"])
dynamic_df["Functional_unity_local"] = dynamic_df["Phi_local_epsilon"] * dynamic_df["Triadic_balance_local"]
dynamic_df["Dominance_index_local"] = dominance_index(dynamic_df, ["H_local", "S_local", "L_local"])

# Main refined PETU columns use local dynamic S/L and preserved H support.
dynamic_df["H"] = dynamic_df["H_local"]
dynamic_df["S"] = dynamic_df["S_local"]
dynamic_df["L"] = dynamic_df["L_local"]
dynamic_df["Phi_raw"] = dynamic_df["Phi_local_raw"]
dynamic_df["Phi_epsilon"] = dynamic_df["Phi_local_epsilon"]
dynamic_df["Triadic_balance"] = dynamic_df["Triadic_balance_local"]
dynamic_df["Functional_unity_score"] = dynamic_df["Functional_unity_local"]
dynamic_df["Dominance_index"] = dynamic_df["Dominance_index_local"]

dynamic_df = dynamic_df.sort_values(["pdb_id", "frame"]).reset_index(drop=True)
for metric in ["S", "L", "Phi_raw", "Phi_epsilon", "Functional_unity_score", "Triadic_balance"]:
    dynamic_df["d_" + metric] = dynamic_df.groupby("pdb_id")[metric].diff().fillna(0)

# ---------------- EVENTS ----------------
event_rows = []
for pdb_id, d in dynamic_df.groupby("pdb_id"):
    d = d.sort_values("frame").copy()
    def first_cross(metric, q):
        threshold = d[metric].max() * q
        hit = d[d[metric] >= threshold]
        if len(hit) == 0:
            return None, None, float(threshold)
        r = hit.iloc[0]
        return int(r["frame"]), float(r["t"]), float(threshold)
    def max_abs_row(metric):
        return d.loc[d[metric].abs().idxmax()]
    event = {"pdb_id": pdb_id, "n_frames": int(len(d))}
    for q in THRESHOLDS:
        tag = int(q * 100)
        S_frame, S_t, _ = first_cross("S", q)
        L_frame, L_t, _ = first_cross("L", q)
        Phi_frame, Phi_t, _ = first_cross("Phi_epsilon", q)
        FU_frame, FU_t, _ = first_cross("Functional_unity_score", q)
        event.update({
            f"S{tag}_frame": S_frame, f"S{tag}_t": S_t,
            f"L{tag}_frame": L_frame, f"L{tag}_t": L_t,
            f"Phi{tag}_frame": Phi_frame, f"Phi{tag}_t": Phi_t,
            f"FU{tag}_frame": FU_frame, f"FU{tag}_t": FU_t,
            f"L_after_S_{tag}": None if S_frame is None or L_frame is None else bool(L_frame >= S_frame),
            f"L_minus_S_frames_{tag}": None if S_frame is None or L_frame is None else int(L_frame - S_frame),
            f"Phi_after_L_{tag}": None if L_frame is None or Phi_frame is None else bool(Phi_frame >= L_frame),
            f"Phi_minus_L_frames_{tag}": None if L_frame is None or Phi_frame is None else int(Phi_frame - L_frame),
        })
    max_dS, max_dL = max_abs_row("d_S"), max_abs_row("d_L")
    max_dPhi, max_dFU = max_abs_row("d_Phi_epsilon"), max_abs_row("d_Functional_unity_score")
    r_SL, p_SL = safe_spearman(d["S"], d["L"])
    r_SPhi, p_SPhi = safe_spearman(d["S"], d["Phi_epsilon"])
    r_LPhi, p_LPhi = safe_spearman(d["L"], d["Phi_epsilon"])
    r_aS, p_aS = safe_spearman(d["folding_alpha"], d["S"])
    r_aL, p_aL = safe_spearman(d["folding_alpha"], d["L"])
    r_aPhi, p_aPhi = safe_spearman(d["folding_alpha"], d["Phi_epsilon"])
    event.update({
        "max_dS_frame": int(max_dS["frame"]), "max_dS_value": float(max_dS["d_S"]),
        "max_dL_frame": int(max_dL["frame"]), "max_dL_value": float(max_dL["d_L"]),
        "max_dPhi_frame": int(max_dPhi["frame"]), "max_dPhi_value": float(max_dPhi["d_Phi_epsilon"]),
        "max_dFU_frame": int(max_dFU["frame"]), "max_dFU_value": float(max_dFU["d_Functional_unity_score"]),
        "spearman_S_L": r_SL, "p_S_L": p_SL,
        "spearman_S_Phi": r_SPhi, "p_S_Phi": p_SPhi,
        "spearman_L_Phi": r_LPhi, "p_L_Phi": p_LPhi,
        "spearman_alpha_S": r_aS, "p_alpha_S": p_aS,
        "spearman_alpha_L": r_aL, "p_alpha_L": p_aL,
        "spearman_alpha_Phi": r_aPhi, "p_alpha_Phi": p_aPhi,
        "final_H": float(d["H"].iloc[-1]), "final_S": float(d["S"].iloc[-1]), "final_L": float(d["L"].iloc[-1]),
        "final_Phi_raw": float(d["Phi_raw"].iloc[-1]), "final_Phi_epsilon": float(d["Phi_epsilon"].iloc[-1]),
        "final_balance": float(d["Triadic_balance"].iloc[-1]), "final_unity": float(d["Functional_unity_score"].iloc[-1])
    })
    event_rows.append(event)
event_summary = pd.DataFrame(event_rows)

# ---------------- REGRESSION ----------------
def regression_dynamic(df, X_cols, y_col, label):
    d = df[X_cols + [y_col]].dropna().copy()
    X, y = d[X_cols].values.astype(float), d[y_col].values.astype(float)
    if len(d) < 20:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {"test": label, "n": int(len(d)), "r2": float(r2_score(y, pred)), "mae": float(mean_absolute_error(y, pred)), "spearman_true_pred": r, "p_value": p}

genesis_summary = pd.DataFrame([
    regression_dynamic(dynamic_df, ["H"], "S", "LOCAL_DYNAMIC_H_to_S"),
    regression_dynamic(dynamic_df, ["H"], "L", "LOCAL_DYNAMIC_H_to_L"),
    regression_dynamic(dynamic_df, ["S"], "L", "LOCAL_DYNAMIC_S_to_L"),
    regression_dynamic(dynamic_df, ["H", "S"], "L", "LOCAL_DYNAMIC_H_plus_S_to_L"),
    regression_dynamic(dynamic_df, ["H", "S", "L"], "Phi_epsilon", "LOCAL_DYNAMIC_HSL_to_Phi_epsilon"),
    regression_dynamic(dynamic_df, ["H", "S", "L"], "Functional_unity_score", "LOCAL_DYNAMIC_HSL_to_Functional_Unity"),
    regression_dynamic(dynamic_df, ["folding_alpha"], "S", "LOCAL_FOLDING_PROGRESS_to_S"),
    regression_dynamic(dynamic_df, ["folding_alpha"], "L", "LOCAL_FOLDING_PROGRESS_to_L"),
    regression_dynamic(dynamic_df, ["folding_alpha"], "Phi_epsilon", "LOCAL_FOLDING_PROGRESS_to_Phi_epsilon"),
    regression_dynamic(dynamic_df, ["H_global"], "S_global", "GLOBAL_DYNAMIC_H_to_S"),
    regression_dynamic(dynamic_df, ["H_global"], "L_global", "GLOBAL_DYNAMIC_H_to_L"),
    regression_dynamic(dynamic_df, ["S_global"], "L_global", "GLOBAL_DYNAMIC_S_to_L"),
    regression_dynamic(dynamic_df, ["H_global", "S_global"], "L_global", "GLOBAL_DYNAMIC_H_plus_S_to_L"),
    regression_dynamic(dynamic_df, ["H_global", "S_global", "L_global"], "Phi_global_epsilon", "GLOBAL_DYNAMIC_HSL_to_Phi_epsilon"),
    regression_dynamic(dynamic_df, ["H_global", "S_global", "L_global"], "Functional_unity_global", "GLOBAL_DYNAMIC_HSL_to_Functional_Unity"),
])

def get_mae(test):
    x = genesis_summary[genesis_summary["test"] == test]
    return None if len(x) == 0 else x.iloc[0]["mae"]

def contrast_row(prefix):
    H_L = get_mae(f"{prefix}_DYNAMIC_H_to_L")
    S_L = get_mae(f"{prefix}_DYNAMIC_S_to_L")
    HS_L = get_mae(f"{prefix}_DYNAMIC_H_plus_S_to_L")
    return {"level": prefix.lower(), "H_to_L_mae": H_L, "S_to_L_mae": S_L, "H_plus_S_to_L_mae": HS_L,
            "HS_improves_over_H": None if H_L is None or HS_L is None else H_L - HS_L,
            "HS_improves_over_S": None if S_L is None or HS_L is None else S_L - HS_L,
            "PETU_prediction_supported": H_L is not None and S_L is not None and HS_L is not None and HS_L < H_L and HS_L < S_L}
emergence_contrast_summary = pd.DataFrame([contrast_row("LOCAL"), contrast_row("GLOBAL")])

# ---------------- PHASES & ORDER ----------------
def classify_phase(row):
    a, s, l, phi, bal = row["folding_alpha"], row["S"], row["L"], row["Phi_epsilon"], row["Triadic_balance"]
    if a < 0.20:
        return "H_available_unstructured"
    if s >= 0.45 and l < 0.35:
        return "S_emerging_before_L"
    if s >= 0.45 and l >= 0.35 and phi < 0.20:
        return "L_cohesion_emerging"
    if phi >= 0.20 and bal >= 0.65:
        return "Phi_functional_stabilizing"
    return "transitional"

dynamic_df["PETU_dynamic_phase"] = dynamic_df.apply(classify_phase, axis=1)
phase_summary = dynamic_df.groupby(["pdb_id", "PETU_dynamic_phase"]).size().reset_index(name="n_frames")
phase_totals = dynamic_df.groupby("PETU_dynamic_phase").size().reset_index(name="n_frames_total").sort_values("n_frames_total", ascending=False)

order_rows = []
for _, r in event_summary.iterrows():
    for tag in [25, 50, 75]:
        S_frame, L_frame, Phi_frame, FU_frame = r.get(f"S{tag}_frame"), r.get(f"L{tag}_frame"), r.get(f"Phi{tag}_frame"), r.get(f"FU{tag}_frame")
        order_rows.append({"pdb_id": r["pdb_id"], "threshold": tag, "S_frame": S_frame, "L_frame": L_frame, "Phi_frame": Phi_frame, "FU_frame": FU_frame,
                           "sequence_S_before_L": None if pd.isna(S_frame) or pd.isna(L_frame) else bool(S_frame <= L_frame),
                           "sequence_L_before_Phi": None if pd.isna(L_frame) or pd.isna(Phi_frame) else bool(L_frame <= Phi_frame),
                           "sequence_S_L_Phi_ordered": None if pd.isna(S_frame) or pd.isna(L_frame) or pd.isna(Phi_frame) else bool(S_frame <= L_frame <= Phi_frame)})
order_summary = pd.DataFrame(order_rows)
sequence_summary = order_summary.groupby("threshold")[["sequence_S_before_L", "sequence_L_before_Phi", "sequence_S_L_Phi_ordered"]].mean(numeric_only=True).reset_index()

# ---------------- SAVE ----------------
paths = {
    "dynamic_features": f"{OUTDIR}/PETU_Genesis_Protein_P4b_dynamic_features.csv",
    "event_summary": f"{OUTDIR}/PETU_Genesis_Protein_P4b_event_summary.csv",
    "genesis_summary": f"{OUTDIR}/PETU_Genesis_Protein_P4b_genesis_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_Genesis_Protein_P4b_emergence_contrast_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_Genesis_Protein_P4b_phase_summary.csv",
    "phase_totals": f"{OUTDIR}/PETU_Genesis_Protein_P4b_phase_totals.csv",
    "order_summary": f"{OUTDIR}/PETU_Genesis_Protein_P4b_order_summary.csv",
    "sequence_summary": f"{OUTDIR}/PETU_Genesis_Protein_P4b_sequence_summary.csv",
    "failures": f"{OUTDIR}/PETU_Genesis_Protein_P4b_failures.csv",
    "summary": f"{OUTDIR}/PETU_Genesis_Protein_P4b_summary.json"
}
dynamic_df.to_csv(paths["dynamic_features"], index=False)
event_summary.to_csv(paths["event_summary"], index=False)
genesis_summary.to_csv(paths["genesis_summary"], index=False)
emergence_contrast_summary.to_csv(paths["emergence_contrast"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
phase_totals.to_csv(paths["phase_totals"], index=False)
order_summary.to_csv(paths["order_summary"], index=False)
sequence_summary.to_csv(paths["sequence_summary"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-Genesis Protein P4b Dynamic Folding Refined",
    "domain": "protein structural folding trajectory",
    "n_proteins": int(len(proteins)),
    "pdb_ids": list(proteins.keys()),
    "n_frames_per_protein": N_FRAMES,
    "total_frames": int(len(dynamic_df)),
    "contact_cutoff_angstrom": CONTACT_CUTOFF,
    "epsilon": EPSILON,
    "thresholds": THRESHOLDS,
    "methodological_note": "Exploratory structural folding trajectory, not full molecular dynamics with physical force field.",
    "refinements": ["global normalization", "per-protein S/L local normalization", "H support preserved", "Phi_epsilon", "threshold event ordering", "phase classification"],
    "hypothesis": "During folding, H is available as physicochemical support; S emerges as structure; L emerges as contact/cohesion network; H-S-L stabilize as Phi.",
    "next_step": "P5 OpenMM / real molecular dynamics."
}
with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

# ---------------- PRINT ----------------
print("\n============================================================")
print("P4b DYNAMIC GENESIS SUMMARY")
print("============================================================")
print(genesis_summary)
print("\n============================================================")
print("P4b EMERGENCE CONTRAST SUMMARY")
print("============================================================")
print(emergence_contrast_summary)
print("\n============================================================")
print("P4b EVENT SUMMARY")
print("============================================================")
print(event_summary)
print("\n============================================================")
print("P4b ORDER SUMMARY")
print("============================================================")
print(order_summary)
print("\n============================================================")
print("P4b SEQUENCE SUMMARY")
print("============================================================")
print(sequence_summary)
print("\n============================================================")
print("P4b PHASE SUMMARY")
print("============================================================")
print(phase_summary)
print("\n============================================================")
print("P4b PHASE TOTALS")
print("============================================================")
print(phase_totals)
print("\n============================================================")
print("P4b FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

# ---------------- FIGURES ----------------
for pdb_id in list(proteins.keys())[:5]:
    d = dynamic_df[dynamic_df["pdb_id"] == pdb_id].copy()
    plt.figure(figsize=(10, 5))
    plt.plot(d["frame"], d["H"], label="H")
    plt.plot(d["frame"], d["S"], label="S")
    plt.plot(d["frame"], d["L"], label="L")
    plt.plot(d["frame"], d["Phi_epsilon"], label="Phi epsilon")
    plt.plot(d["frame"], d["Functional_unity_score"], label="Functional Unity")
    plt.xlabel("Frame")
    plt.ylabel("Normalized score")
    plt.title(f"PETU P4b Dynamic Folding H-S-L-Phi — {pdb_id}")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{OUTDIR}/figure_dynamic_HSLPhi_{pdb_id}.png", dpi=220)
    plt.show()

plt.figure(figsize=(8, 6))
plt.scatter(dynamic_df["S"], dynamic_df["L"], s=10, alpha=0.5)
plt.xlabel("S")
plt.ylabel("L")
plt.title("P4b all frames: S -> L relation")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_all_S_L.png", dpi=220)
plt.show()

plt.figure(figsize=(8, 6))
plt.scatter(dynamic_df["Triadic_balance"], dynamic_df["Phi_epsilon"], s=10, alpha=0.5)
plt.xlabel("Triadic balance")
plt.ylabel("Phi epsilon")
plt.title("P4b all frames: Phi vs triadic balance")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_all_phi_balance.png", dpi=220)
plt.show()

plt.figure(figsize=(8, 5))
plt.bar(sequence_summary["threshold"].astype(str), sequence_summary["sequence_S_L_Phi_ordered"])
plt.xlabel("Threshold percentage")
plt.ylabel("Fraction ordered S <= L <= Phi")
plt.title("P4b PETU dynamic ordering")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_sequence_ordering.png", dpi=220)
plt.show()

zip_base = "/content/PETU_Genesis_Protein_P4b_Dynamic_Folding_Refined_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path):
    os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k, v in paths.items():
    print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

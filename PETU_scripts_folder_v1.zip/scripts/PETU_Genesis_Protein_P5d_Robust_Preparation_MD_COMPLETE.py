# ============================================================
# PETU-GENESIS PROTEIN P5d ROBUST PREPARATION + REAL MD
# OpenMM / Amber14 / implicit solvent / mobile-safe
# ============================================================

!pip -q install openmm biopython networkx numpy scipy pandas matplotlib scikit-learn

import os, json, shutil, time, warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx

from Bio.PDB import PDBList, PDBParser, PDBIO, Select, is_aa
from scipy.spatial.distance import pdist, squareform
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error

from openmm import unit, LangevinIntegrator, Platform
from openmm.app import PDBFile, Modeller, ForceField, Simulation, HBonds, NoCutoff

OUTDIR = '/content/PETU_Genesis_Protein_P5d_Robust_Preparation_MD'
PDB_DIR = '/content/PETU_PDB_P5D'
os.makedirs(OUTDIR, exist_ok=True)
os.makedirs(PDB_DIR, exist_ok=True)

# Incluye problemáticas + candidatas limpias. Móvil: corre hasta MAX_COMPLETED.
PDB_IDS = ['1FSD','1PGB','1UBQ','1CRN','1ENH','1VII','2CI2','1CSP','1R69','1BTA','1L2Y','1W4E','1BBL','1KDX']
MAX_COMPLETED = 6
MD_STEPS = 2000
EQUIL_STEPS = 500
REPORT_INTERVAL = 100
TEMPERATURE_K = 300
FRICTION = 1.0/unit.picosecond
TIMESTEP = 2.0*unit.femtoseconds
CONTACT_CUTOFF = 8.0
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

HYDROPATHY = {'ALA':1.8,'ARG':-4.5,'ASN':-3.5,'ASP':-3.5,'CYS':2.5,'CYX':2.5,'CYM':2.5,'GLN':-3.5,'GLU':-3.5,'GLY':-0.4,'HIS':-3.2,'ILE':4.5,'LEU':3.8,'LYS':-3.9,'MET':1.9,'PHE':2.8,'PRO':-1.6,'SER':-0.8,'THR':-0.7,'TRP':-0.9,'TYR':-1.3,'VAL':4.2}
MASS = {'ALA':89.09,'ARG':174.20,'ASN':132.12,'ASP':133.10,'CYS':121.16,'CYX':121.16,'CYM':121.16,'GLN':146.15,'GLU':147.13,'GLY':75.07,'HIS':155.16,'ILE':131.17,'LEU':131.17,'LYS':146.19,'MET':149.21,'PHE':165.19,'PRO':115.13,'SER':105.09,'THR':119.12,'TRP':204.23,'TYR':181.19,'VAL':117.15}
CHARGE = {'ARG':1,'LYS':1,'HIS':0.5,'ASP':-1,'GLU':-1,'ALA':0,'ASN':0,'CYS':0,'CYX':0,'CYM':-1,'GLN':0,'GLY':0,'ILE':0,'LEU':0,'MET':0,'PHE':0,'PRO':0,'SER':0,'THR':0,'TRP':0,'TYR':0,'VAL':0}
POLAR = {'ARG':1,'ASN':1,'ASP':1,'GLN':1,'GLU':1,'HIS':1,'LYS':1,'SER':1,'THR':1,'TYR':1,'ALA':0,'CYS':0,'CYX':0,'CYM':1,'GLY':0,'ILE':0,'LEU':0,'MET':0,'PHE':0,'PRO':0,'TRP':0,'VAL':0}

def normalize01(x):
    x=np.asarray(x,dtype=float)
    if len(x)==0: return x
    mn,mx=np.nanmin(x),np.nanmax(x)
    if mx-mn<1e-12: return np.zeros_like(x)
    return (x-mn)/(mx-mn)

def normalize01_groupwise(df, cols, group_col='pdb_id'):
    out=df.copy()
    for col in cols:
        out[col+'_local_norm']=out.groupby(group_col)[col].transform(lambda x: normalize01(x.values))
    return out

def safe_mean(x):
    x=[v for v in x if np.isfinite(v)]
    return float(np.mean(x)) if x else 0.0

def safe_std(x):
    x=[v for v in x if np.isfinite(v)]
    return float(np.std(x)) if x else 0.0

def safe_spearman(a,b):
    try:
        a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
        m=np.isfinite(a)&np.isfinite(b)
        if m.sum()<3: return None,None
        r,p=spearmanr(a[m],b[m]); return float(r),float(p)
    except Exception: return None,None

def pairwise_distances(coords):
    if len(coords)<2: return np.zeros((len(coords),len(coords)))
    return squareform(pdist(coords))

def contact_matrix(coords, cutoff=8.0):
    D=pairwise_distances(coords); C=(D<=cutoff).astype(int); np.fill_diagonal(C,0); return C,D

def radius_of_gyration(coords):
    coords=np.asarray(coords,dtype=float); c=np.mean(coords,axis=0)
    return float(np.sqrt(np.mean(np.sum((coords-c)**2,axis=1))))

def graph_from_C(C):
    G=nx.Graph(); n=C.shape[0]; G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i+1,n):
            if C[i,j]>0: G.add_edge(i,j)
    return G

def graph_efficiency(G):
    try: return float(nx.global_efficiency(G))
    except Exception: return 0.0

def graph_lcc_fraction(G):
    if G.number_of_nodes()==0: return 0.0
    comps=list(nx.connected_components(G))
    return float(max(len(c) for c in comps)/G.number_of_nodes()) if comps else 0.0

def graph_degree_entropy(G):
    deg=np.array([d for _,d in G.degree()],dtype=float)
    if len(deg)==0 or deg.sum()<=0: return 0.0
    p=deg/deg.sum(); ent=-np.sum(p*np.log(p+1e-12))
    return float(ent/np.log(len(p)+1e-12))

def rmsd_no_align(A,B):
    A,B=np.asarray(A,dtype=float),np.asarray(B,dtype=float); n=min(len(A),len(B))
    if n==0: return np.nan
    A=A[:n]-np.mean(A[:n],axis=0); B=B[:n]-np.mean(B[:n],axis=0)
    return float(np.sqrt(np.mean(np.sum((A-B)**2,axis=1))))

def native_contact_fraction(C,C_native):
    total=np.sum(C_native)/2
    if total<=0: return 0.0
    rec=np.sum((C>0)&(C_native>0))/2
    return float(rec/total)

def triadic_balance_from_cols(df, cols):
    return (1-df[cols].std(axis=1)).clip(lower=0)

pdbl=PDBList(); parser=PDBParser(QUIET=True)

def download_pdb(pdb_id):
    return pdbl.retrieve_pdb_file(pdb_id.lower(), pdir=PDB_DIR, file_format='pdb', overwrite=False)

def get_best_chain_id(pdb_path,pdb_id):
    structure=parser.get_structure(pdb_id,pdb_path); best=None; best_count=-1
    for model in structure:
        for chain in model:
            count=sum(1 for res in chain if is_aa(res,standard=True) and 'CA' in res)
            if count>best_count: best_count=count; best=chain.id
        break
    return best,best_count

class SingleProteinChainSelect(Select):
    def __init__(self, chain_id): self.chain_id=chain_id
    def accept_chain(self, chain): return 1 if chain.id==self.chain_id else 0
    def accept_residue(self, residue): return 1 if is_aa(residue, standard=True) else 0

def clean_to_single_chain(pdb_path,pdb_id):
    chain_id,nres=get_best_chain_id(pdb_path,pdb_id)
    if chain_id is None or nres<=0: raise ValueError(f'No valid protein chain found for {pdb_id}')
    structure=parser.get_structure(pdb_id,pdb_path); io=PDBIO(); io.set_structure(structure)
    clean_path=os.path.join(PDB_DIR,f'{pdb_id}_protein_chain_{chain_id}.pdb')
    io.save(clean_path, SingleProteinChainSelect(chain_id))
    return clean_path,chain_id,nres

def patch_disulfide_cys(input_pdb,pdb_id):
    lines=open(input_pdb).read().splitlines(); sg=[]
    for idx,line in enumerate(lines):
        if line.startswith(('ATOM  ','HETATM')) and line[12:16].strip()=='SG' and line[17:20].strip()=='CYS':
            try:
                x=float(line[30:38]); y=float(line[38:46]); z=float(line[46:54])
                sg.append((line[21].strip(), line[22:26].strip(), line[26].strip(), np.array([x,y,z])))
            except Exception: pass
    cyx=set()
    for i in range(len(sg)):
        for j in range(i+1,len(sg)):
            if np.linalg.norm(sg[i][3]-sg[j][3])<2.4:
                cyx.add(sg[i][:3]); cyx.add(sg[j][:3])
    patched=[]
    for line in lines:
        if line.startswith(('ATOM  ','HETATM')):
            key=(line[21].strip(), line[22:26].strip(), line[26].strip())
            if line[17:20].strip()=='CYS' and key in cyx:
                line=line[:17]+'CYX'+line[20:]
        patched.append(line)
    out=os.path.join(PDB_DIR,f'{pdb_id}_protein_chain_patched_cys.pdb')
    open(out,'w').write('\n'.join(patched)+'\n')
    return out,len(cyx)

def try_prepare_model(clean_path,pdb_id):
    ff=ForceField('amber14-all.xml','implicit/gbn2.xml')
    patched,ncyx=patch_disulfide_cys(clean_path,pdb_id)
    attempts=[('clean',clean_path),(f'patched_cys_CYX_{ncyx}',patched)]
    last=None
    for label,path in attempts:
        try:
            pdb=PDBFile(path); modeller=Modeller(pdb.topology,pdb.positions)
            modeller.addHydrogens(ff,pH=7.0)
            system=ff.createSystem(modeller.topology, nonbondedMethod=NoCutoff, constraints=HBonds, ignoreExternalBonds=True)
            return modeller,ff,system,label,path
        except Exception as e:
            last=str(e)
    raise RuntimeError(last)

def extract_ca(topology, positions):
    residues=[]; coords=[]; pos_nm=positions.value_in_unit(unit.nanometer)
    for atom in topology.atoms():
        if atom.name=='CA' and atom.residue.name in HYDROPATHY:
            residues.append(atom.residue.name); p=pos_nm[atom.index]; coords.append([p.x*10,p.y*10,p.z*10])
    return residues,np.array(coords,dtype=float)

def H_sequence_raw(residues, potential_energy_kj=None):
    hyd=[HYDROPATHY.get(r,0) for r in residues]; mass=[MASS.get(r,110) for r in residues]
    charge=[CHARGE.get(r,0) for r in residues]; polar=[POLAR.get(r,0) for r in residues]; n=len(residues)
    vals={'H_mass_mean':safe_mean(mass),'H_hydro_abs_mean':safe_mean([abs(x) for x in hyd]),'H_hydro_std':safe_std(hyd),'H_charge_abs_mean':safe_mean([abs(x) for x in charge]),'H_net_charge_abs':abs(float(np.sum(charge)))/max(n,1),'H_polar_fraction':safe_mean(polar),'H_energy_stability':0.0 if potential_energy_kj is None else -float(potential_energy_kj)/max(n,1)}
    vals['H_raw']=safe_mean(list(vals.values())); return vals

def S_structure_raw(coords,C,D,coords_native):
    n=len(coords)
    if n<2: return {k:0 for k in ['S_contact_density','S_compactness','S_local_contact_fraction','S_distance_regularity','S_native_similarity','S_raw']}
    rg=radius_of_gyration(coords); contact_density=float(np.sum(C)/(n*(n-1)+1e-12)); compactness=1/((rg/(n**(1/3)+1e-12))+1e-12)
    total=np.sum(C)/2; local=sum(1 for i in range(n) for j in range(i+1,n) if C[i,j]>0 and abs(i-j)<=6)
    local_frac=float(local/(total+1e-12)); cd=D[C>0]; dist_reg=1/(np.std(cd)+1e-12) if len(cd)>0 else 0.0
    r=rmsd_no_align(coords,coords_native); native_similarity=1/(1+r) if np.isfinite(r) else 0.0
    vals={'S_contact_density':contact_density,'S_compactness':compactness,'S_local_contact_fraction':local_frac,'S_distance_regularity':dist_reg,'S_native_similarity':native_similarity}
    vals['S_raw']=safe_mean(list(vals.values())); return vals

def L_network_raw(C,C_native):
    G=graph_from_C(C); n=G.number_of_nodes()
    if n==0: return {k:0 for k in ['L_avg_degree','L_efficiency','L_clustering','L_lcc_fraction','L_degree_entropy','L_native_contact_fraction','L_raw']}
    vals={'L_avg_degree':float(np.mean([d for _,d in G.degree()])) if n else 0.0,'L_efficiency':graph_efficiency(G),'L_clustering':float(nx.average_clustering(G)) if n else 0.0,'L_lcc_fraction':graph_lcc_fraction(G),'L_degree_entropy':graph_degree_entropy(G),'L_native_contact_fraction':native_contact_fraction(C,C_native)}
    vals['L_raw']=safe_mean(list(vals.values())); return vals

def run_md_for_pdb(pdb_id):
    print('\n============================================================'); print('Running P5d robust MD for:',pdb_id); print('============================================================')
    t0=time.time(); pdb_path=download_pdb(pdb_id); clean_path,chain_id,nres=clean_to_single_chain(pdb_path,pdb_id)
    print(f'  Cleaned to chain {chain_id} with approx {nres} CA residues')
    modeller,ff,system,prep_label,prep_path=try_prepare_model(clean_path,pdb_id); print('  Preparation mode:',prep_label)
    integrator=LangevinIntegrator(TEMPERATURE_K*unit.kelvin, FRICTION, TIMESTEP); integrator.setRandomNumberSeed(RANDOM_SEED)
    try: sim=Simulation(modeller.topology, system, integrator, Platform.getPlatformByName('CPU'))
    except Exception: sim=Simulation(modeller.topology, system, integrator)
    sim.context.setPositions(modeller.positions)
    residues_native, coords_native=extract_ca(modeller.topology, modeller.positions); C_native,D_native=contact_matrix(coords_native,CONTACT_CUTOFF)
    print('  Minimizing...'); sim.minimizeEnergy(maxIterations=400)
    print('  Equilibrating...'); sim.context.setVelocitiesToTemperature(TEMPERATURE_K*unit.kelvin,RANDOM_SEED); sim.step(EQUIL_STEPS)
    n_reports=MD_STEPS//REPORT_INTERVAL; print(f'  Production: {MD_STEPS} steps -> {n_reports+1} frames')
    frames=[]
    for rep in range(n_reports+1):
        state=sim.context.getState(getPositions=True,getEnergy=True); pos=state.getPositions(); energy=state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
        time_ps=rep*REPORT_INTERVAL*TIMESTEP.value_in_unit(unit.picoseconds)
        residues,coords=extract_ca(modeller.topology,pos); C,D=contact_matrix(coords,CONTACT_CUTOFF)
        frames.append({'pdb_id':pdb_id,'frame':rep,'time_ps':time_ps,'potential_energy_kj_mol':float(energy),'n_residues':len(residues),'rmsd_to_native':rmsd_no_align(coords,coords_native),'prep_label':prep_label,**H_sequence_raw(residues,energy),**S_structure_raw(coords,C,D,coords_native),**L_network_raw(C,C_native)})
        if rep<n_reports: sim.step(REPORT_INTERVAL)
    print(f'  OK: {pdb_id} elapsed_sec={time.time()-t0:.1f}')
    return pd.DataFrame(frames)

def postprocess_and_save(all_frames,failures):
    md_df=pd.concat(all_frames,ignore_index=True)
    H_BASE=['H_mass_mean','H_hydro_abs_mean','H_hydro_std','H_charge_abs_mean','H_net_charge_abs','H_polar_fraction','H_energy_stability']
    S_BASE=['S_contact_density','S_compactness','S_local_contact_fraction','S_distance_regularity','S_native_similarity']
    L_BASE=['L_avg_degree','L_efficiency','L_clustering','L_lcc_fraction','L_degree_entropy','L_native_contact_fraction']; RAW_BASE=H_BASE+S_BASE+L_BASE
    for col in RAW_BASE: md_df[col+'_global_norm']=normalize01(md_df[col].values)
    md_df['H_global']=md_df[[c+'_global_norm' for c in H_BASE]].mean(axis=1); md_df['S_global']=md_df[[c+'_global_norm' for c in S_BASE]].mean(axis=1); md_df['L_global']=md_df[[c+'_global_norm' for c in L_BASE]].mean(axis=1)
    md_df['Phi_global_epsilon']=(md_df['H_global']+EPSILON)*(md_df['S_global']+EPSILON)*(md_df['L_global']+EPSILON); md_df['Triadic_balance_global']=triadic_balance_from_cols(md_df,['H_global','S_global','L_global']); md_df['Functional_unity_global']=md_df['Phi_global_epsilon']*md_df['Triadic_balance_global']
    md_df=normalize01_groupwise(md_df,RAW_BASE,'pdb_id')
    md_df['H_local']=md_df[[c+'_local_norm' for c in H_BASE]].mean(axis=1); md_df['S_local']=md_df[[c+'_local_norm' for c in S_BASE]].mean(axis=1); md_df['L_local']=md_df[[c+'_local_norm' for c in L_BASE]].mean(axis=1)
    md_df['Phi_local_epsilon']=(md_df['H_local']+EPSILON)*(md_df['S_local']+EPSILON)*(md_df['L_local']+EPSILON); md_df['Triadic_balance_local']=triadic_balance_from_cols(md_df,['H_local','S_local','L_local']); md_df['Functional_unity_local']=md_df['Phi_local_epsilon']*md_df['Triadic_balance_local']
    md_df['H']=md_df['H_local']; md_df['S']=md_df['S_local']; md_df['L']=md_df['L_local']; md_df['Phi_epsilon']=md_df['Phi_local_epsilon']; md_df['Functional_unity_score']=md_df['Functional_unity_local']; md_df['Triadic_balance']=md_df['Triadic_balance_local']; md_df=md_df.sort_values(['pdb_id','frame']).reset_index(drop=True)
    def reg(df,X_cols,y_col,label):
        d=df[X_cols+[y_col]].dropna(); X=d[X_cols].values.astype(float); y=d[y_col].values.astype(float)
        if len(d)<20: return {'test':label,'n':int(len(d)),'r2':None,'mae':None,'spearman_true_pred':None,'p_value':None}
        pred=Ridge(alpha=1.0).fit(X,y).predict(X); r,p=safe_spearman(y,pred)
        return {'test':label,'n':int(len(d)),'r2':float(r2_score(y,pred)),'mae':float(mean_absolute_error(y,pred)),'spearman_true_pred':r,'p_value':p}
    genesis_summary=pd.DataFrame([reg(md_df,['H'],'S','LOCAL_MD_H_to_S'),reg(md_df,['H'],'L','LOCAL_MD_H_to_L'),reg(md_df,['S'],'L','LOCAL_MD_S_to_L'),reg(md_df,['H','S'],'L','LOCAL_MD_H_plus_S_to_L'),reg(md_df,['H','S','L'],'Phi_epsilon','LOCAL_MD_HSL_to_Phi_epsilon'),reg(md_df,['H','S','L'],'Functional_unity_score','LOCAL_MD_HSL_to_Functional_Unity'),reg(md_df,['H_global'],'S_global','GLOBAL_MD_H_to_S'),reg(md_df,['H_global'],'L_global','GLOBAL_MD_H_to_L'),reg(md_df,['S_global'],'L_global','GLOBAL_MD_S_to_L'),reg(md_df,['H_global','S_global'],'L_global','GLOBAL_MD_H_plus_S_to_L'),reg(md_df,['H_global','S_global','L_global'],'Phi_global_epsilon','GLOBAL_MD_HSL_to_Phi_epsilon'),reg(md_df,['H_global','S_global','L_global'],'Functional_unity_global','GLOBAL_MD_HSL_to_Functional_Unity'),reg(md_df,['time_ps'],'S','MD_TIME_to_S'),reg(md_df,['time_ps'],'L','MD_TIME_to_L'),reg(md_df,['time_ps'],'Phi_epsilon','MD_TIME_to_Phi_epsilon')])
    def mae(test):
        x=genesis_summary[genesis_summary['test']==test]; return None if len(x)==0 else x.iloc[0]['mae']
    def contrast(prefix):
        H_L=mae(f'{prefix}_MD_H_to_L'); S_L=mae(f'{prefix}_MD_S_to_L'); HS_L=mae(f'{prefix}_MD_H_plus_S_to_L')
        return {'level':prefix.lower(),'H_to_L_mae':H_L,'S_to_L_mae':S_L,'H_plus_S_to_L_mae':HS_L,'HS_improves_over_H':None if H_L is None or HS_L is None else H_L-HS_L,'HS_improves_over_S':None if S_L is None or HS_L is None else S_L-HS_L,'PETU_prediction_supported':H_L is not None and S_L is not None and HS_L is not None and HS_L<H_L and HS_L<S_L}
    emergence_contrast_summary=pd.DataFrame([contrast('LOCAL'),contrast('GLOBAL')])
    def phase(row):
        s,l,phi,bal=row['S'],row['L'],row['Phi_epsilon'],row['Triadic_balance']
        if s<0.25 and l<0.25: return 'low_structure_low_link'
        if s>=0.35 and l<0.35: return 'S_without_full_L'
        if l>=0.35 and phi<0.20: return 'L_cohesion_subPhi'
        if phi>=0.20 and bal>=0.65: return 'Phi_stable_co-inherence'
        return 'transitional'
    md_df['PETU_MD_phase']=md_df.apply(phase,axis=1); phase_totals=md_df.groupby('PETU_MD_phase').size().reset_index(name='n_frames_total').sort_values('n_frames_total',ascending=False); phase_summary=md_df.groupby(['pdb_id','PETU_MD_phase']).size().reset_index(name='n_frames')
    ev=[]
    for pdb_id,d in md_df.groupby('pdb_id'):
        rSL,pSL=safe_spearman(d['S'],d['L']); rSP,pSP=safe_spearman(d['S'],d['Phi_epsilon']); rLP,pLP=safe_spearman(d['L'],d['Phi_epsilon']); rEP,pEP=safe_spearman(d['H_energy_stability'],d['Phi_epsilon'])
        ev.append({'pdb_id':pdb_id,'n_frames':int(len(d)),'time_ps_max':float(d['time_ps'].max()),'mean_H':float(d['H'].mean()),'mean_S':float(d['S'].mean()),'mean_L':float(d['L'].mean()),'mean_Phi_epsilon':float(d['Phi_epsilon'].mean()),'mean_balance':float(d['Triadic_balance'].mean()),'mean_unity':float(d['Functional_unity_score'].mean()),'mean_rmsd_to_native':float(d['rmsd_to_native'].mean()),'spearman_S_L':rSL,'p_S_L':pSL,'spearman_S_Phi':rSP,'p_S_Phi':pSP,'spearman_L_Phi':rLP,'p_L_Phi':pLP,'spearman_energy_Phi':rEP,'p_energy_Phi':pEP,'final_H':float(d['H'].iloc[-1]),'final_S':float(d['S'].iloc[-1]),'final_L':float(d['L'].iloc[-1]),'final_Phi_epsilon':float(d['Phi_epsilon'].iloc[-1]),'final_balance':float(d['Triadic_balance'].iloc[-1]),'final_unity':float(d['Functional_unity_score'].iloc[-1]),'prep_label':str(d['prep_label'].iloc[0])})
    event_summary=pd.DataFrame(ev)
    paths={'md_features':f'{OUTDIR}/PETU_Genesis_Protein_P5d_MD_features.csv','genesis_summary':f'{OUTDIR}/PETU_Genesis_Protein_P5d_genesis_summary.csv','emergence_contrast':f'{OUTDIR}/PETU_Genesis_Protein_P5d_emergence_contrast_summary.csv','event_summary':f'{OUTDIR}/PETU_Genesis_Protein_P5d_event_summary.csv','phase_summary':f'{OUTDIR}/PETU_Genesis_Protein_P5d_phase_summary.csv','phase_totals':f'{OUTDIR}/PETU_Genesis_Protein_P5d_phase_totals.csv','failures':f'{OUTDIR}/PETU_Genesis_Protein_P5d_failures.csv','summary':f'{OUTDIR}/PETU_Genesis_Protein_P5d_summary.json'}
    md_df.to_csv(paths['md_features'],index=False); genesis_summary.to_csv(paths['genesis_summary'],index=False); emergence_contrast_summary.to_csv(paths['emergence_contrast'],index=False); event_summary.to_csv(paths['event_summary'],index=False); phase_summary.to_csv(paths['phase_summary'],index=False); phase_totals.to_csv(paths['phase_totals'],index=False); pd.DataFrame(failures).to_csv(paths['failures'],index=False)
    summary={'pipeline':'PETU-Genesis Protein P5d Robust Preparation MD','domain':'real-physics molecular dynamics of natural proteins','pdb_ids_requested':PDB_IDS,'pdb_ids_completed':sorted(list(md_df['pdb_id'].unique())),'n_proteins_completed':int(md_df['pdb_id'].nunique()),'total_frames':int(len(md_df)),'max_completed':MAX_COMPLETED,'md_steps':MD_STEPS,'equil_steps':EQUIL_STEPS,'report_interval':REPORT_INTERVAL,'temperature_K':TEMPERATURE_K,'timestep_fs':TIMESTEP.value_in_unit(unit.femtoseconds),'contact_cutoff_angstrom':CONTACT_CUTOFF,'forcefield':['amber14-all.xml','implicit/gbn2.xml'],'epsilon':EPSILON,'methodological_note':'Robust protein-only single-chain preparation, CYS disulfide CYX patch, OpenMM Amber14 implicit-solvent MD.','hypothesis':'H physical support/energy, S structure, and L contact-cohesion network co-inhere as Phi in real MD.','next_step':'P6 perturbative native vs perturbed/disrupted conditions.'}
    open(paths['summary'],'w').write(json.dumps(summary,indent=2))
    print('\n============================================================'); print('P5d MD GENESIS SUMMARY'); print('============================================================'); print(genesis_summary)
    print('\n============================================================'); print('P5d MD EMERGENCE CONTRAST SUMMARY'); print('============================================================'); print(emergence_contrast_summary)
    print('\n============================================================'); print('P5d MD EVENT / STABILITY SUMMARY'); print('============================================================'); print(event_summary)
    print('\n============================================================'); print('P5d MD PHASE TOTALS'); print('============================================================'); print(phase_totals)
    print('\n============================================================'); print('P5d MD FINAL SUMMARY'); print('============================================================'); print(json.dumps(summary,indent=2))
    if failures: print('\n============================================================\nFAILURES\n============================================================'); print(pd.DataFrame(failures))
    zip_base='/content/PETU_Genesis_Protein_P5d_Robust_Preparation_MD_results'; zip_path=zip_base+'.zip'
    if os.path.exists(zip_path): os.remove(zip_path)
    shutil.make_archive(zip_base,'zip',OUTDIR)
    print('\n============================================================'); print('PIPELINE COMPLETE')
    for k,v in paths.items(): print(k+':',v)
    print('ZIP:',zip_path); print('============================================================')

print('============================================================'); print('PETU-GENESIS PROTEIN P5d ROBUST PREPARATION MD'); print('============================================================')
all_frames=[]; failures=[]
for pdb_id in PDB_IDS:
    if len(all_frames)>=MAX_COMPLETED:
        print('\nMAX_COMPLETED reached. Stopping for mobile safety.'); break
    try:
        dfp=run_md_for_pdb(pdb_id.upper()); all_frames.append(dfp); pd.concat(all_frames,ignore_index=True).to_csv(f'{OUTDIR}/PARTIAL_P5d_frames.csv',index=False)
    except Exception as e:
        print('  FAIL:',pdb_id,e); failures.append({'pdb_id':pdb_id.upper(),'error':str(e)})
if not all_frames: raise RuntimeError('No MD simulations completed.')
postprocess_and_save(all_frames,failures)

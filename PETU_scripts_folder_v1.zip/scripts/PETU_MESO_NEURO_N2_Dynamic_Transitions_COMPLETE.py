# ============================================================
# PETU-MESO-NEURO N2 — Dynamic Transition Audit
# Natural neurodynamic derivative test after N1.
#
# Tests the process-level PETU sequence:
#   dH -> dS
#   dH + dS -> dL
#   dH + dS + dL -> dPhi
#
# Domain: Sleep-EDF EEG natural states Wake, REM, N1, N2, N3.
# H = neuroenergetic support; S = spectral form; L = functional cohesion;
# Phi = H-S-L functional unity.
# ============================================================

!pip -q install mne numpy scipy pandas scikit-learn matplotlib networkx

import os, json, shutil, warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx

from scipy.signal import welch
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.model_selection import GroupKFold

import mne
from mne.datasets.sleep_physionet.age import fetch_data

OUTDIR = '/content/PETU_MESO_NEURO_N2_Dynamic_Transitions'
os.makedirs(OUTDIR, exist_ok=True)

N_SUBJECTS = 6
WINDOW_SEC = 10
STEP_SEC = 10
MAX_EPOCHS_PER_STATE_PER_SUBJECT = 100
EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

BANDS = {
    'delta': (0.5, 4),
    'theta': (4, 8),
    'alpha': (8, 13),
    'sigma': (12, 16),
    'beta': (13, 30),
}
STATE_MAP = {
    'Sleep stage W': 'Wake',
    'Sleep stage R': 'REM',
    'Sleep stage 1': 'N1',
    'Sleep stage 2': 'N2',
    'Sleep stage 3': 'N3',
    'Sleep stage 4': 'N3',
}
TARGET_STATES = ['Wake', 'REM', 'N1', 'N2', 'N3']
CANONICAL_TRANSITIONS = ['Wake->N1','N1->N2','N2->N3','N3->N2','N2->REM','REM->Wake','Wake->REM','REM->N1','N2->Wake']

# ---------------- Utilities ----------------
def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0: return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12: return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def normalize01_groupwise(df, cols, group_col):
    out = df.copy()
    for col in cols:
        out[col + '_local_norm'] = out.groupby(group_col)[col].transform(lambda x: normalize01(x.values))
    return out

def safe_spearman(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3: return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def spectral_entropy(psd):
    psd = np.maximum(np.asarray(psd, dtype=float), 1e-12)
    p = psd / np.sum(psd)
    return float((-np.sum(p*np.log(p))) / np.log(len(p)))

def bandpower(freqs, psd, fmin, fmax):
    mask = (freqs >= fmin) & (freqs < fmax)
    if mask.sum() == 0: return 0.0
    return float(np.trapz(psd[mask], freqs[mask]))

def corr_network_features(X):
    n_ch = X.shape[0]
    if n_ch < 2:
        return dict(L_corr_mean_abs=0.0, L_corr_density_03=0.0, L_corr_efficiency=0.0, L_corr_clustering=0.0, L_corr_lcc_fraction=0.0)
    C = np.nan_to_num(np.corrcoef(X), nan=0.0)
    A = np.abs(C); np.fill_diagonal(A, 0)
    vals = A[np.triu_indices(n_ch, 1)]
    adj = (A >= 0.30).astype(int); np.fill_diagonal(adj, 0)
    G = nx.from_numpy_array(adj)
    density = float(np.sum(adj)/(n_ch*(n_ch-1)+1e-12))
    try: eff = float(nx.global_efficiency(G))
    except Exception: eff = 0.0
    try: clust = float(nx.average_clustering(G))
    except Exception: clust = 0.0
    if G.number_of_nodes() > 0 and G.number_of_edges() > 0:
        lcc = max(len(c) for c in nx.connected_components(G)) / G.number_of_nodes()
    else:
        lcc = 0.0
    return dict(L_corr_mean_abs=float(np.mean(vals)), L_corr_density_03=density, L_corr_efficiency=eff, L_corr_clustering=clust, L_corr_lcc_fraction=float(lcc))

def phase_locking_value_band(X, sfreq, band):
    if X.shape[0] < 2: return 0.0
    try:
        Xf = mne.filter.filter_data(X, sfreq, band[0], band[1], verbose=False)
        analytic = mne.filter.hilbert(Xf, envelope=False)
        phase = np.angle(analytic)
        vals = []
        for i in range(X.shape[0]):
            for j in range(i+1, X.shape[0]):
                vals.append(np.abs(np.mean(np.exp(1j*(phase[i]-phase[j])))))
        return float(np.mean(vals)) if vals else 0.0
    except Exception:
        return 0.0

def triadic_balance(h, s, l): return float(max(0.0, 1.0 - np.std([h, s, l])))
def dominance_index(h, s, l): return float(max(h, s, l) - min(h, s, l))

def classify_flow_phase(row):
    dh, ds, dl, dp, bal = row['dH'], row['dS'], row['dL'], row['dPhi'], row['Triadic_balance']
    if dp > 0 and dh > 0 and ds > 0 and dl > 0: return 'coherent_phi_gain'
    if dp < 0 and (ds < 0 or dl < 0): return 'phi_loss_via_form_link'
    if dh > 0 and ds < 0 and dl < 0: return 'H_active_S_L_drop'
    if ds > 0 and dl > 0 and dp > 0: return 'form_link_reintegration'
    if abs(dp) < 0.005: return 'quasi_stable'
    if bal < 0.55: return 'unbalanced_transition'
    return 'mixed_transition'

# ---------------- Feature extraction ----------------
def extract_features_window(X, sfreq):
    X = np.nan_to_num(np.asarray(X, dtype=float))
    X = X - np.mean(X, axis=1, keepdims=True)
    Xz = X / (np.std(X, axis=1, keepdims=True) + 1e-12)
    freqs, psd = welch(Xz, fs=sfreq, nperseg=min(int(sfreq*4), Xz.shape[1]), axis=1)
    psd_mean = np.mean(psd, axis=0)
    total_power = bandpower(freqs, psd_mean, 0.5, 30) + 1e-12
    bp = {}
    for name, band in BANDS.items():
        bp[name] = bandpower(freqs, psd_mean, band[0], band[1])
        bp[name + '_rel'] = bp[name]/total_power
    H_total_power = np.log1p(total_power)
    H_variance = float(np.mean(np.var(Xz, axis=1)))
    H_raw = np.mean([H_total_power, bp['delta_rel'], bp['theta_rel'], bp['alpha_rel'], bp['beta_rel'], H_variance])
    ent = spectral_entropy(psd_mean)
    spectral_order = 1-ent
    alpha_delta = np.log1p(bp['alpha']/(bp['delta']+1e-12))
    theta_delta = np.log1p(bp['theta']/(bp['delta']+1e-12))
    sigma_delta = np.log1p(bp['sigma']/(bp['delta']+1e-12))
    beta_delta = np.log1p(bp['beta']/(bp['delta']+1e-12))
    S_raw = np.mean([spectral_order, alpha_delta, theta_delta, sigma_delta, beta_delta])
    net = corr_network_features(Xz)
    plv_alpha = phase_locking_value_band(Xz, sfreq, BANDS['alpha'])
    plv_theta = phase_locking_value_band(Xz, sfreq, BANDS['theta'])
    L_raw = np.mean([net['L_corr_mean_abs'], net['L_corr_density_03'], net['L_corr_efficiency'], net['L_corr_clustering'], net['L_corr_lcc_fraction'], plv_alpha, plv_theta])
    return {
        'H_total_power': H_total_power, 'H_delta_rel': bp['delta_rel'], 'H_theta_rel': bp['theta_rel'], 'H_alpha_rel': bp['alpha_rel'], 'H_beta_rel': bp['beta_rel'], 'H_variance': H_variance, 'H_raw': H_raw,
        'S_spectral_entropy': ent, 'S_spectral_order': spectral_order, 'S_alpha_delta_ratio_log': alpha_delta, 'S_theta_delta_ratio_log': theta_delta, 'S_sigma_delta_ratio_log': sigma_delta, 'S_beta_delta_ratio_log': beta_delta, 'S_raw': S_raw,
        **net, 'L_plv_alpha': plv_alpha, 'L_plv_theta': plv_theta, 'L_raw': L_raw
    }

# ---------------- Load Sleep-EDF ----------------
print('='*60)
print('PETU-MESO-NEURO N2 DYNAMIC TRANSITIONS')
print('='*60)
print('Fetching Sleep-EDF data...')
files = fetch_data(subjects=list(range(N_SUBJECTS)), recording=[1]*N_SUBJECTS, on_missing='warn')
rows, failures = [], []
for si, pair in enumerate(files):
    subject_id = f'S{si:02d}'
    try:
        psg_path, hyp_path = pair
        print('\nSubject:', subject_id)
        raw = mne.io.read_raw_edf(psg_path, preload=True, verbose=False)
        ann = mne.read_annotations(hyp_path); raw.set_annotations(ann)
        picks = mne.pick_types(raw.info, eeg=True, eog=False, emg=False, misc=False)
        raw.pick(picks); raw.filter(0.5, 30, verbose=False)
        sfreq = raw.info['sfreq']
        events, event_id = mne.events_from_annotations(raw, verbose=False)
        inv_event_id = {v:k for k,v in event_id.items()}
        state_counts = {s:0 for s in TARGET_STATES}
        for ev in events:
            onset_sample, code = ev[0], ev[2]
            desc = inv_event_id.get(code, '')
            if desc not in STATE_MAP: continue
            state = STATE_MAP[desc]
            if state not in TARGET_STATES: continue
            if state_counts[state] >= MAX_EPOCHS_PER_STATE_PER_SUBJECT: continue
            start = onset_sample; epoch_len = int(30*sfreq); stop = start + epoch_len
            if stop > raw.n_times: continue
            win_len = int(WINDOW_SEC*sfreq); step_len = int(STEP_SEC*sfreq)
            for ws in range(start, stop-win_len+1, step_len):
                we = ws+win_len
                X = raw.get_data(start=ws, stop=we)
                if X.shape[1] < win_len*0.9: continue
                rows.append({'subject': subject_id, 'state': state, 'epoch_onset_sample': int(onset_sample), 'window_start_sample': int(ws), 'time_sec': float(ws/sfreq), 'sfreq': float(sfreq), 'n_channels': int(X.shape[0]), **extract_features_window(X, sfreq)})
            state_counts[state] += 1
        print('  State counts:', state_counts)
    except Exception as e:
        print('  FAIL:', subject_id, e)
        failures.append({'subject': subject_id, 'error': str(e)})

df = pd.DataFrame(rows)
if len(df) == 0: raise RuntimeError('No EEG windows extracted.')
df = df.sort_values(['subject','time_sec']).reset_index(drop=True)

# ---------------- PETU variables ----------------
H_COLS = ['H_total_power','H_delta_rel','H_theta_rel','H_alpha_rel','H_beta_rel','H_variance']
S_COLS = ['S_spectral_order','S_alpha_delta_ratio_log','S_theta_delta_ratio_log','S_sigma_delta_ratio_log','S_beta_delta_ratio_log']
L_COLS = ['L_corr_mean_abs','L_corr_density_03','L_corr_efficiency','L_corr_clustering','L_corr_lcc_fraction','L_plv_alpha','L_plv_theta']
RAW_BASE = H_COLS + S_COLS + L_COLS
for col in RAW_BASE: df[col + '_global_norm'] = normalize01(df[col].values)
df['H_global'] = df[[c+'_global_norm' for c in H_COLS]].mean(axis=1)
df['S_global'] = df[[c+'_global_norm' for c in S_COLS]].mean(axis=1)
df['L_global'] = df[[c+'_global_norm' for c in L_COLS]].mean(axis=1)
df['Phi_global_epsilon'] = (df['H_global']+EPSILON)*(df['S_global']+EPSILON)*(df['L_global']+EPSILON)
df['Triadic_balance_global'] = [triadic_balance(h,s,l) for h,s,l in zip(df['H_global'],df['S_global'],df['L_global'])]
df['Functional_unity_global'] = df['Phi_global_epsilon']*df['Triadic_balance_global']
df = normalize01_groupwise(df, RAW_BASE, 'subject')
df['H_local'] = df[[c+'_local_norm' for c in H_COLS]].mean(axis=1)
df['S_local'] = df[[c+'_local_norm' for c in S_COLS]].mean(axis=1)
df['L_local'] = df[[c+'_local_norm' for c in L_COLS]].mean(axis=1)
df['Phi_local_epsilon'] = (df['H_local']+EPSILON)*(df['S_local']+EPSILON)*(df['L_local']+EPSILON)
df['Triadic_balance_local'] = [triadic_balance(h,s,l) for h,s,l in zip(df['H_local'],df['S_local'],df['L_local'])]
df['Functional_unity_local'] = df['Phi_local_epsilon']*df['Triadic_balance_local']
df['H'], df['S'], df['L'] = df['H_local'], df['S_local'], df['L_local']
df['Phi_epsilon'], df['Functional_unity_score'], df['Triadic_balance'] = df['Phi_local_epsilon'], df['Functional_unity_local'], df['Triadic_balance_local']
df['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(df['H'],df['S'],df['L'])]

# ---------------- Derivatives ----------------
for col in ['H','S','L','Phi_epsilon','Functional_unity_score','Triadic_balance','H_global','S_global','L_global','Phi_global_epsilon','Functional_unity_global']:
    df['prev_'+col] = df.groupby('subject')[col].shift(1)

df['dH'] = df['H'] - df['prev_H']; df['dS'] = df['S'] - df['prev_S']; df['dL'] = df['L'] - df['prev_L']
df['dPhi'] = df['Phi_epsilon'] - df['prev_Phi_epsilon']; df['dUnity'] = df['Functional_unity_score'] - df['prev_Functional_unity_score']; df['dBalance'] = df['Triadic_balance'] - df['prev_Triadic_balance']
df['dH_global'] = df['H_global'] - df['prev_H_global']; df['dS_global'] = df['S_global'] - df['prev_S_global']; df['dL_global'] = df['L_global'] - df['prev_L_global']
df['dPhi_global'] = df['Phi_global_epsilon'] - df['prev_Phi_global_epsilon']; df['dUnity_global'] = df['Functional_unity_global'] - df['prev_Functional_unity_global']
df['prev_state'] = df.groupby('subject')['state'].shift(1)
df['transition'] = df['prev_state'].fillna('START') + '->' + df['state'].astype(str)
df['is_state_change'] = (df['prev_state'].notna()) & (df['prev_state'] != df['state'])
dyn = df.dropna(subset=['dH','dS','dL','dPhi','dUnity','dH_global','dS_global','dL_global','dPhi_global']).copy()
dyn['PETU_flow_phase'] = dyn.apply(classify_flow_phase, axis=1)
for col in ['dH','dS','dL','dPhi','dUnity','dH_global','dS_global','dL_global','dPhi_global']:
    dyn['lag1_'+col] = dyn.groupby('subject')[col].shift(1)
    dyn['lag2_'+col] = dyn.groupby('subject')[col].shift(2)
lagdyn = dyn.dropna(subset=['lag1_dH','lag1_dS','lag1_dL','lag1_dPhi']).copy()

# ---------------- Regression summaries ----------------
def regression_dynamic(data, X_cols, y_col, label):
    d = data[X_cols + [y_col, 'subject']].dropna().copy()
    if len(d) < 50:
        return {'test': label, 'n': int(len(d)), 'r2': None, 'mae': None, 'spearman_true_pred': None, 'p_value': None}
    X = d[X_cols].values.astype(float); y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0).fit(X, y); pred = model.predict(X)
    r,p = safe_spearman(y,pred)
    return {'test': label, 'n': int(len(d)), 'r2': float(r2_score(y,pred)), 'mae': float(mean_absolute_error(y,pred)), 'spearman_true_pred': r, 'p_value': p}

dynamic_genesis_summary = pd.DataFrame([
    regression_dynamic(dyn,['dH'],'dS','LOCAL_DYN_dH_to_dS'), regression_dynamic(dyn,['dH'],'dL','LOCAL_DYN_dH_to_dL'), regression_dynamic(dyn,['dS'],'dL','LOCAL_DYN_dS_to_dL'), regression_dynamic(dyn,['dH','dS'],'dL','LOCAL_DYN_dH_plus_dS_to_dL'), regression_dynamic(dyn,['dH','dS','dL'],'dPhi','LOCAL_DYN_dHSL_to_dPhi'), regression_dynamic(dyn,['dH','dS','dL'],'dUnity','LOCAL_DYN_dHSL_to_dUnity'),
    regression_dynamic(dyn,['dH_global'],'dS_global','GLOBAL_DYN_dH_to_dS'), regression_dynamic(dyn,['dH_global'],'dL_global','GLOBAL_DYN_dH_to_dL'), regression_dynamic(dyn,['dS_global'],'dL_global','GLOBAL_DYN_dS_to_dL'), regression_dynamic(dyn,['dH_global','dS_global'],'dL_global','GLOBAL_DYN_dH_plus_dS_to_dL'), regression_dynamic(dyn,['dH_global','dS_global','dL_global'],'dPhi_global','GLOBAL_DYN_dHSL_to_dPhi'), regression_dynamic(dyn,['dH_global','dS_global','dL_global'],'dUnity_global','GLOBAL_DYN_dHSL_to_dUnity')
])
lagged_precedence_summary = pd.DataFrame([
    regression_dynamic(lagdyn,['lag1_dH'],'dS','LAG1_LOCAL_dH_to_dS'), regression_dynamic(lagdyn,['lag1_dH'],'dL','LAG1_LOCAL_dH_to_dL'), regression_dynamic(lagdyn,['lag1_dS'],'dL','LAG1_LOCAL_dS_to_dL'), regression_dynamic(lagdyn,['lag1_dH','lag1_dS'],'dL','LAG1_LOCAL_dH_plus_dS_to_dL'), regression_dynamic(lagdyn,['lag1_dH','lag1_dS','lag1_dL'],'dPhi','LAG1_LOCAL_dHSL_to_dPhi'), regression_dynamic(lagdyn,['lag1_dH','lag1_dS','lag1_dL'],'dUnity','LAG1_LOCAL_dHSL_to_dUnity'),
    regression_dynamic(lagdyn,['lag2_dH'],'dS','LAG2_LOCAL_dH_to_dS'), regression_dynamic(lagdyn,['lag2_dH','lag2_dS'],'dL','LAG2_LOCAL_dH_plus_dS_to_dL'), regression_dynamic(lagdyn,['lag2_dH','lag2_dS','lag2_dL'],'dPhi','LAG2_LOCAL_dHSL_to_dPhi')
])

def get_mae(summary, test):
    x = summary[summary['test'] == test]
    return None if len(x)==0 else x.iloc[0]['mae']
def contrast_row(prefix):
    H_L = get_mae(dynamic_genesis_summary, f'{prefix}_DYN_dH_to_dL')
    S_L = get_mae(dynamic_genesis_summary, f'{prefix}_DYN_dS_to_dL')
    HS_L = get_mae(dynamic_genesis_summary, f'{prefix}_DYN_dH_plus_dS_to_dL')
    return {'level': prefix.lower(), 'dH_to_dL_mae': H_L, 'dS_to_dL_mae': S_L, 'dH_plus_dS_to_dL_mae': HS_L, 'dHS_improves_over_dH': None if H_L is None or HS_L is None else H_L-HS_L, 'dHS_improves_over_dS': None if S_L is None or HS_L is None else S_L-HS_L, 'PETU_dynamic_prediction_supported': H_L is not None and S_L is not None and HS_L is not None and HS_L < H_L and HS_L < S_L}
dynamic_emergence_contrast = pd.DataFrame([contrast_row('LOCAL'), contrast_row('GLOBAL')])

# ---------------- Transition summaries ----------------
transition_summary = dyn.groupby('transition').agg(n=('transition','count'), mean_dH=('dH','mean'), mean_dS=('dS','mean'), mean_dL=('dL','mean'), mean_dPhi=('dPhi','mean'), mean_dUnity=('dUnity','mean'), mean_dBalance=('dBalance','mean'), mean_abs_dPhi=('dPhi',lambda x: float(np.mean(np.abs(x)))), frac_phi_gain=('dPhi',lambda x: float(np.mean(np.asarray(x)>0))), frac_phi_loss=('dPhi',lambda x: float(np.mean(np.asarray(x)<0)))).reset_index().sort_values('n',ascending=False)
state_change_transition_summary = transition_summary[transition_summary['transition'].isin(CANONICAL_TRANSITIONS)].copy()
archetype_rows=[]
for tr,dtr in dyn.groupby('transition'):
    if len(dtr)<20: continue
    signature = ('H+' if dtr['dH'].mean()>0 else 'H-')+'_'+('S+' if dtr['dS'].mean()>0 else 'S-')+'_'+('L+' if dtr['dL'].mean()>0 else 'L-')+'_'+('Phi+' if dtr['dPhi'].mean()>0 else 'Phi-')
    archetype_rows.append({'transition':tr,'n':int(len(dtr)),'dominant_direction':'phi_gain' if dtr['dPhi'].mean()>0 else 'phi_loss' if dtr['dPhi'].mean()<0 else 'neutral','mean_dH':float(dtr['dH'].mean()),'mean_dS':float(dtr['dS'].mean()),'mean_dL':float(dtr['dL'].mean()),'mean_dPhi':float(dtr['dPhi'].mean()),'signature':signature})
transition_archetypes = pd.DataFrame(archetype_rows).sort_values('n',ascending=False)
flow_phase_summary = dyn.groupby(['state','PETU_flow_phase']).size().reset_index(name='n_windows')
flow_phase_totals = dyn.groupby('PETU_flow_phase').size().reset_index(name='n_windows_total').sort_values('n_windows_total',ascending=False)

# Phi-gain classification.
def auc_group_cv_phi_gain(data, feature_cols, label):
    d = data.dropna(subset=feature_cols+['dPhi','subject']).copy(); d = d[np.abs(d['dPhi'])>1e-6]
    if len(d)<100: return None
    y = (d['dPhi']>0).astype(int).values
    if len(np.unique(y))<2: return None
    X = d[feature_cols].values.astype(float); groups = d['subject'].values
    if len(np.unique(groups))<2: return None
    gkf = GroupKFold(n_splits=min(5,len(np.unique(groups)))); preds=np.zeros(len(y))
    for train,test in gkf.split(X,y,groups):
        try:
            clf=LogisticRegression(max_iter=1000,class_weight='balanced').fit(X[train],y[train])
            preds[test]=clf.predict_proba(X[test])[:,1]
        except Exception: preds[test]=0.5
    try: auc=roc_auc_score(y,preds)
    except Exception: auc=np.nan
    return {'feature_set':label,'n':int(len(d)),'auc_phi_gain_group_cv':float(auc)}
class_rows=[]
for cols,label in [(['dH'],'dH'),(['dS'],'dS'),(['dL'],'dL'),(['dH','dS'],'dH+dS'),(['dH','dS','dL'],'dH+dS+dL')]:
    r=auc_group_cv_phi_gain(dyn,cols,label)
    if r: class_rows.append(r)
phi_gain_classification = pd.DataFrame(class_rows)

# ---------------- Save ----------------
paths = {
 'features': f'{OUTDIR}/PETU_MESO_NEURO_N2_features.csv',
 'dynamic_features': f'{OUTDIR}/PETU_MESO_NEURO_N2_dynamic_features.csv',
 'dynamic_genesis_summary': f'{OUTDIR}/PETU_MESO_NEURO_N2_dynamic_genesis_summary.csv',
 'dynamic_emergence_contrast': f'{OUTDIR}/PETU_MESO_NEURO_N2_dynamic_emergence_contrast.csv',
 'lagged_precedence_summary': f'{OUTDIR}/PETU_MESO_NEURO_N2_lagged_precedence_summary.csv',
 'transition_summary': f'{OUTDIR}/PETU_MESO_NEURO_N2_transition_summary.csv',
 'state_change_transition_summary': f'{OUTDIR}/PETU_MESO_NEURO_N2_state_change_transition_summary.csv',
 'transition_archetypes': f'{OUTDIR}/PETU_MESO_NEURO_N2_transition_archetypes.csv',
 'flow_phase_summary': f'{OUTDIR}/PETU_MESO_NEURO_N2_flow_phase_summary.csv',
 'flow_phase_totals': f'{OUTDIR}/PETU_MESO_NEURO_N2_flow_phase_totals.csv',
 'phi_gain_classification': f'{OUTDIR}/PETU_MESO_NEURO_N2_phi_gain_classification.csv',
 'failures': f'{OUTDIR}/PETU_MESO_NEURO_N2_failures.csv',
 'summary': f'{OUTDIR}/PETU_MESO_NEURO_N2_summary.json'
}
df.to_csv(paths['features'], index=False); dyn.to_csv(paths['dynamic_features'], index=False)
dynamic_genesis_summary.to_csv(paths['dynamic_genesis_summary'], index=False); dynamic_emergence_contrast.to_csv(paths['dynamic_emergence_contrast'], index=False); lagged_precedence_summary.to_csv(paths['lagged_precedence_summary'], index=False)
transition_summary.to_csv(paths['transition_summary'], index=False); state_change_transition_summary.to_csv(paths['state_change_transition_summary'], index=False); transition_archetypes.to_csv(paths['transition_archetypes'], index=False)
flow_phase_summary.to_csv(paths['flow_phase_summary'], index=False); flow_phase_totals.to_csv(paths['flow_phase_totals'], index=False); phi_gain_classification.to_csv(paths['phi_gain_classification'], index=False); pd.DataFrame(failures).to_csv(paths['failures'], index=False)
summary = {'pipeline':'PETU-MESO-NEURO N2 Dynamic Transitions','domain':'natural neurodynamic transitions / Sleep-EDF EEG','n_subjects_requested':N_SUBJECTS,'n_subjects_completed':int(df['subject'].nunique()),'n_windows':int(len(df)),'n_dynamic_windows':int(len(dyn)),'states':sorted(df['state'].unique().tolist()),'window_sec':WINDOW_SEC,'step_sec':STEP_SEC,'epsilon':EPSILON,'hypothesis':'Natural neurodynamic transitions should display triadic derivative structure: dH -> dS, dH+dS -> dL, dH+dS+dL -> dPhi.','next_step':'N3 natural pathology/criticality contrast, or N2b expanded subjects with transition-focused sampling.'}
with open(paths['summary'],'w') as f: json.dump(summary,f,indent=2)

print('\n'+'='*60); print('PETU-MESO-NEURO N2 DYNAMIC GENESIS SUMMARY'); print('='*60); print(dynamic_genesis_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N2 DYNAMIC EMERGENCE CONTRAST'); print('='*60); print(dynamic_emergence_contrast)
print('\n'+'='*60); print('PETU-MESO-NEURO N2 LAGGED PRECEDENCE SUMMARY'); print('='*60); print(lagged_precedence_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N2 TRANSITION SUMMARY'); print('='*60); print(transition_summary.head(25))
print('\n'+'='*60); print('PETU-MESO-NEURO N2 STATE-CHANGE TRANSITION SUMMARY'); print('='*60); print(state_change_transition_summary)
print('\n'+'='*60); print('PETU-MESO-NEURO N2 TRANSITION ARCHETYPES'); print('='*60); print(transition_archetypes.head(25))
print('\n'+'='*60); print('PETU-MESO-NEURO N2 FLOW PHASE TOTALS'); print('='*60); print(flow_phase_totals)
print('\n'+'='*60); print('PETU-MESO-NEURO N2 PHI-GAIN CLASSIFICATION'); print('='*60); print(phi_gain_classification)
print('\n'+'='*60); print('PETU-MESO-NEURO N2 FINAL SUMMARY'); print('='*60); print(json.dumps(summary, indent=2))
if len(failures)>0: print('\nFAILURES'); print(pd.DataFrame(failures))

# Figures
plt.figure(figsize=(8,5)); plt.scatter(dyn['dS'], dyn['dL'], s=8, alpha=0.30); plt.xlabel('dS'); plt.ylabel('dL'); plt.title('PETU N2: dS vs dL'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_dS_dL.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(dyn['dH']+dyn['dS'], dyn['dL'], s=8, alpha=0.30); plt.xlabel('dH + dS'); plt.ylabel('dL'); plt.title('PETU N2: dH+dS vs dL'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_dHS_dL.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(dyn['dH']+dyn['dS']+dyn['dL'], dyn['dPhi'], s=8, alpha=0.30); plt.xlabel('dH + dS + dL'); plt.ylabel('dPhi'); plt.title('PETU N2: dH+dS+dL vs dPhi'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_dHSL_dPhi.png', dpi=220); plt.show()
if len(flow_phase_totals)>0:
    plt.figure(figsize=(10,5)); plt.bar(flow_phase_totals['PETU_flow_phase'], flow_phase_totals['n_windows_total']); plt.xticks(rotation=65); plt.ylabel('n windows'); plt.title('PETU N2: flow phases'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_flow_phase_totals.png', dpi=220); plt.show()
if len(phi_gain_classification)>0:
    plt.figure(figsize=(8,5)); plt.bar(phi_gain_classification['feature_set'], phi_gain_classification['auc_phi_gain_group_cv']); plt.ylim(0,1); plt.ylabel('AUC Phi-gain'); plt.title('PETU N2: predicting Phi gain'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_phi_gain_auc.png', dpi=220); plt.show()

zip_base='/content/PETU_MESO_NEURO_N2_Dynamic_Transitions_results'; zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

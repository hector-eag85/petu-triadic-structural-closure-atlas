# ============================================================
# PETU-MESO-NEURO N3
# Natural Epilepsy / Criticality Contrast Audit
#
# Objetivo:
#   Cerrar fase neuro-meso contrastando PETU en patología natural.
#
#   N1: H + S + L -> Phi en estados fisiológicos naturales.
#   N2: dH + dS + dL -> dPhi en transiciones naturales.
#   N3: crisis epiléptica como captura triádica patológica.
#
# Hipótesis PETU-N3:
#   La crisis epiléptica no es solo aumento de H.
#   Debe aparecer como reorganización/captura H-S-L:
#       H = soporte neuroenergético / potencia multibanda.
#       S = forma espectral / orden dinámico.
#       L = vínculo/coherencia funcional / sincronización.
#       Phi = unidad triádica del estado.
#
#   Predicción:
#       Ictal ≠ simple H alto.
#       Ictal = H, S, L reorganizados, con L especialmente decisivo.
#       H+S+L debe separar ictal/interictal mejor que H o H+S.
#       Phi ictal puede ser alto, pero como Phi capturada/patológica,
#       no como unidad funcional saludable.
#
# Dataset:
#   CHB-MIT Scalp EEG, PhysioNet, paciente chb01.
#   Descarga EDFs pequeños/subconjunto.
#
# Salidas:
#   - N3 genesis summary.
#   - N3 epilepsy state summary.
#   - N3 seizure contrast summary.
#   - N3 classification summary.
#   - N3 criticality/capture summary.
#   - N3 final summary.
# ============================================================

!pip -q install mne numpy scipy pandas scikit-learn matplotlib networkx requests

import os, json, shutil, warnings, requests
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx

from scipy.signal import welch
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.model_selection import GroupKFold, StratifiedKFold

import mne

# ============================================================
# CONFIG
# ============================================================

OUTDIR = "/content/PETU_MESO_NEURO_N3_Epilepsy_Criticality"
DATADIR = "/content/PETU_CHBMIT_chb01"
os.makedirs(OUTDIR, exist_ok=True)
os.makedirs(DATADIR, exist_ok=True)

EPSILON = 0.05
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

WINDOW_SEC = 5
STEP_SEC = 5
PREICTAL_SEC = 5 * 60
POSTICTAL_SEC = 5 * 60
MAX_INTERICTAL_WINDOWS_PER_FILE = 240

# CHB-MIT chb01 known seizure intervals in seconds.
# We include both seizure and non-seizure files.
CHB01_FILES = {
    "chb01_01.edf": [],
    "chb01_02.edf": [],
    "chb01_03.edf": [(2996, 3036)],
    "chb01_04.edf": [(1467, 1494)],
    "chb01_15.edf": [(1732, 1772)],
    "chb01_16.edf": [(1015, 1066)],
    "chb01_18.edf": [(1720, 1810)],
    "chb01_21.edf": [(327, 420)],
    "chb01_26.edf": [(1862, 1963)],
}

BASE_URL = "https://physionet.org/files/chbmit/1.0.0/chb01"

BANDS = {
    "delta": (0.5, 4),
    "theta": (4, 8),
    "alpha": (8, 13),
    "beta": (13, 30),
    "gamma_low": (30, 45),
}

# ============================================================
# UTILS
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mannwhitney(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        a, b = a[np.isfinite(a)], b[np.isfinite(b)]
        if len(a) < 5 or len(b) < 5:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None

def spectral_entropy(psd):
    psd = np.asarray(psd, dtype=float)
    psd = np.maximum(psd, 1e-12)
    p = psd / np.sum(psd)
    return float((-np.sum(p * np.log(p))) / np.log(len(p)))

def bandpower(freqs, psd, fmin, fmax):
    mask = (freqs >= fmin) & (freqs < fmax)
    if mask.sum() == 0:
        return 0.0
    return float(np.trapz(psd[mask], freqs[mask]))

def corr_network_features(X):
    n_ch = X.shape[0]
    if n_ch < 2:
        return {
            "L_corr_mean_abs": 0.0,
            "L_corr_density_03": 0.0,
            "L_corr_efficiency": 0.0,
            "L_corr_clustering": 0.0,
            "L_corr_lcc_fraction": 0.0,
            "L_corr_max_abs": 0.0,
        }
    C = np.corrcoef(X)
    C = np.nan_to_num(C, nan=0.0)
    A = np.abs(C)
    np.fill_diagonal(A, 0)
    vals = A[np.triu_indices(n_ch, 1)]
    adj = (A >= 0.30).astype(int)
    np.fill_diagonal(adj, 0)
    G = nx.from_numpy_array(adj)
    density = float(np.sum(adj) / (n_ch * (n_ch - 1) + 1e-12))
    try:
        eff = float(nx.global_efficiency(G))
    except Exception:
        eff = 0.0
    try:
        clust = float(nx.average_clustering(G))
    except Exception:
        clust = 0.0
    if G.number_of_nodes() > 0 and G.number_of_edges() > 0:
        comps = list(nx.connected_components(G))
        lcc = max(len(c) for c in comps) / G.number_of_nodes()
    else:
        lcc = 0.0
    return {
        "L_corr_mean_abs": float(np.mean(vals)),
        "L_corr_density_03": density,
        "L_corr_efficiency": eff,
        "L_corr_clustering": clust,
        "L_corr_lcc_fraction": float(lcc),
        "L_corr_max_abs": float(np.max(vals)) if len(vals) else 0.0,
    }

def phase_locking_value_band(X, sfreq, band):
    n_ch = X.shape[0]
    if n_ch < 2:
        return 0.0
    fmin, fmax = band
    try:
        Xf = mne.filter.filter_data(X, sfreq, fmin, fmax, verbose=False)
        analytic = mne.filter.hilbert(Xf, envelope=False)
        phase = np.angle(analytic)
        vals = []
        for i in range(n_ch):
            for j in range(i + 1, n_ch):
                vals.append(np.abs(np.mean(np.exp(1j * (phase[i] - phase[j])))))
        return float(np.mean(vals)) if vals else 0.0
    except Exception:
        return 0.0

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def state_for_window(t0, t1, seizures):
    for s0, s1 in seizures:
        if t1 > s0 and t0 < s1:
            return "ictal"
        if t1 > (s0 - PREICTAL_SEC) and t0 < s0:
            return "preictal"
        if t1 > s1 and t0 < (s1 + POSTICTAL_SEC):
            return "postictal"
    return "interictal"

def distance_to_nearest_seizure(tmid, seizures):
    if not seizures:
        return np.nan
    dists = []
    for s0, s1 in seizures:
        if s0 <= tmid <= s1:
            dists.append(0)
        else:
            dists.append(min(abs(tmid - s0), abs(tmid - s1)))
    return float(min(dists))

# ============================================================
# DOWNLOAD
# ============================================================

def download_file(url, dest):
    if os.path.exists(dest) and os.path.getsize(dest) > 1024 * 1024:
        return dest
    print("Downloading", url)
    with requests.get(url, stream=True, timeout=120) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
    return dest

# ============================================================
# FEATURE EXTRACTION
# ============================================================

def extract_features_window(X, sfreq):
    X = np.asarray(X, dtype=float)
    X = np.nan_to_num(X)
    X = X - np.mean(X, axis=1, keepdims=True)
    Xz = X / (np.std(X, axis=1, keepdims=True) + 1e-12)

    freqs, psd = welch(Xz, fs=sfreq, nperseg=min(int(sfreq * 2), Xz.shape[1]), axis=1)
    psd_mean = np.mean(psd, axis=0)

    total_power = bandpower(freqs, psd_mean, 0.5, 45) + 1e-12
    bp = {}
    for name, band in BANDS.items():
        bp[name] = bandpower(freqs, psd_mean, band[0], band[1])
        bp[name + "_rel"] = bp[name] / total_power

    # H: neuroenergetic support / activation.
    H_total_power = np.log1p(total_power)
    H_variance = float(np.mean(np.var(Xz, axis=1)))
    H_high_freq = bp["beta_rel"] + bp["gamma_low_rel"]
    H_low_freq = bp["delta_rel"] + bp["theta_rel"]
    H_raw = np.mean([
        H_total_power,
        H_variance,
        H_low_freq,
        H_high_freq,
        bp["alpha_rel"],
        bp["beta_rel"],
        bp["gamma_low_rel"],
    ])

    # S: spectral form / order.
    ent = spectral_entropy(psd_mean)
    spectral_order = 1 - ent
    delta_theta_ratio = np.log1p(bp["delta"] / (bp["theta"] + 1e-12))
    beta_delta_ratio = np.log1p(bp["beta"] / (bp["delta"] + 1e-12))
    gamma_delta_ratio = np.log1p(bp["gamma_low"] / (bp["delta"] + 1e-12))
    alpha_delta_ratio = np.log1p(bp["alpha"] / (bp["delta"] + 1e-12))
    S_raw = np.mean([
        spectral_order,
        delta_theta_ratio,
        beta_delta_ratio,
        gamma_delta_ratio,
        alpha_delta_ratio,
    ])

    # L: functional link / synchronization.
    net = corr_network_features(Xz)
    plv_delta = phase_locking_value_band(Xz, sfreq, BANDS["delta"])
    plv_theta = phase_locking_value_band(Xz, sfreq, BANDS["theta"])
    plv_alpha = phase_locking_value_band(Xz, sfreq, BANDS["alpha"])
    plv_beta = phase_locking_value_band(Xz, sfreq, BANDS["beta"])
    L_raw = np.mean([
        net["L_corr_mean_abs"],
        net["L_corr_density_03"],
        net["L_corr_efficiency"],
        net["L_corr_clustering"],
        net["L_corr_lcc_fraction"],
        net["L_corr_max_abs"],
        plv_delta, plv_theta, plv_alpha, plv_beta,
    ])

    return {
        "H_total_power": H_total_power,
        "H_variance": H_variance,
        "H_low_freq": H_low_freq,
        "H_high_freq": H_high_freq,
        "H_delta_rel": bp["delta_rel"],
        "H_theta_rel": bp["theta_rel"],
        "H_alpha_rel": bp["alpha_rel"],
        "H_beta_rel": bp["beta_rel"],
        "H_gamma_low_rel": bp["gamma_low_rel"],
        "H_raw": H_raw,

        "S_spectral_entropy": ent,
        "S_spectral_order": spectral_order,
        "S_delta_theta_ratio_log": delta_theta_ratio,
        "S_beta_delta_ratio_log": beta_delta_ratio,
        "S_gamma_delta_ratio_log": gamma_delta_ratio,
        "S_alpha_delta_ratio_log": alpha_delta_ratio,
        "S_raw": S_raw,

        **net,
        "L_plv_delta": plv_delta,
        "L_plv_theta": plv_theta,
        "L_plv_alpha": plv_alpha,
        "L_plv_beta": plv_beta,
        "L_raw": L_raw,
    }

# ============================================================
# LOAD + EXTRACT
# ============================================================

print("============================================================")
print("PETU-MESO-NEURO N3 EPILEPSY / CRITICALITY")
print("============================================================")

rows, failures = [], []

for fname, seizures in CHB01_FILES.items():
    try:
        url = f"{BASE_URL}/{fname}"
        fpath = os.path.join(DATADIR, fname)
        download_file(url, fpath)
        print("\nFile:", fname, "seizures:", seizures)

        raw = mne.io.read_raw_edf(fpath, preload=True, verbose=False)
        raw.pick_types(eeg=True, verbose=False)
        raw.filter(0.5, 45, verbose=False)
        sfreq = raw.info["sfreq"]
        duration = raw.n_times / sfreq

        win = int(WINDOW_SEC * sfreq)
        step = int(STEP_SEC * sfreq)

        interictal_kept = 0

        for start in range(0, raw.n_times - win + 1, step):
            stop = start + win
            t0 = start / sfreq
            t1 = stop / sfreq
            tm = 0.5 * (t0 + t1)
            state = state_for_window(t0, t1, seizures)

            # Balance file size: keep all non-interictal, subsample interictal.
            if state == "interictal":
                if interictal_kept >= MAX_INTERICTAL_WINDOWS_PER_FILE:
                    continue
                # Keep regularly spaced windows.
                if start % (step * 3) != 0:
                    continue
                interictal_kept += 1

            X = raw.get_data(start=start, stop=stop)
            if X.shape[1] < win * 0.9:
                continue

            feats = extract_features_window(X, sfreq)
            rows.append({
                "patient": "chb01",
                "file": fname,
                "time_sec": float(tm),
                "window_start_sec": float(t0),
                "window_end_sec": float(t1),
                "state": state,
                "is_ictal": int(state == "ictal"),
                "is_preictal": int(state == "preictal"),
                "is_postictal": int(state == "postictal"),
                "distance_to_seizure_sec": distance_to_nearest_seizure(tm, seizures),
                "n_channels": int(X.shape[0]),
                "sfreq": float(sfreq),
                **feats
            })

        print("  windows total so far:", len(rows))

    except Exception as e:
        print("  FAIL:", fname, e)
        failures.append({"file": fname, "error": str(e)})

df = pd.DataFrame(rows)
if len(df) == 0:
    raise RuntimeError("No windows extracted.")

# ============================================================
# NORMALIZE + PHI
# ============================================================

H_COLS = [
    "H_total_power", "H_variance", "H_low_freq", "H_high_freq",
    "H_delta_rel", "H_theta_rel", "H_alpha_rel", "H_beta_rel", "H_gamma_low_rel"
]
S_COLS = [
    "S_spectral_order", "S_delta_theta_ratio_log", "S_beta_delta_ratio_log",
    "S_gamma_delta_ratio_log", "S_alpha_delta_ratio_log"
]
L_COLS = [
    "L_corr_mean_abs", "L_corr_density_03", "L_corr_efficiency",
    "L_corr_clustering", "L_corr_lcc_fraction", "L_corr_max_abs",
    "L_plv_delta", "L_plv_theta", "L_plv_alpha", "L_plv_beta"
]
RAW_BASE = H_COLS + S_COLS + L_COLS

for col in RAW_BASE:
    df[col + "_global_norm"] = normalize01(df[col].values)

df["H"] = df[[c + "_global_norm" for c in H_COLS]].mean(axis=1)
df["S"] = df[[c + "_global_norm" for c in S_COLS]].mean(axis=1)
df["L"] = df[[c + "_global_norm" for c in L_COLS]].mean(axis=1)

df["Phi_epsilon"] = (df["H"] + EPSILON) * (df["S"] + EPSILON) * (df["L"] + EPSILON)
df["Triadic_balance"] = [triadic_balance(h, s, l) for h, s, l in zip(df["H"], df["S"], df["L"])]
df["Functional_unity_score"] = df["Phi_epsilon"] * df["Triadic_balance"]
df["Dominance_index"] = [dominance_index(h, s, l) for h, s, l in zip(df["H"], df["S"], df["L"])]

# Pathological capture index:
# High Phi + high L + dominance/spectral order, marked ictal-like.
# This is not "healthy unity" but captured/critical unity.
df["Pathological_capture_index"] = (
    df["Phi_epsilon"] *
    (df["L"] + EPSILON) *
    (df["S"] + EPSILON) *
    (1 + df["Dominance_index"])
)

# Dynamic derivatives inside each file.
df = df.sort_values(["file", "time_sec"]).reset_index(drop=True)
for col in ["H", "S", "L", "Phi_epsilon", "Functional_unity_score", "Pathological_capture_index"]:
    df["d" + col.replace("_epsilon", "").replace("_score", "")] = df[col] - df.groupby("file")[col].shift(1)

# ============================================================
# REGRESSION TESTS
# ============================================================

def regression_dynamic(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna().copy()
    if len(d) < 50:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {
        "test": label,
        "n": int(len(d)),
        "r2": float(r2_score(y, pred)),
        "mae": float(mean_absolute_error(y, pred)),
        "spearman_true_pred": r,
        "p_value": p
    }

genesis_summary = pd.DataFrame([
    regression_dynamic(df, ["H"], "S", "N3_H_to_S"),
    regression_dynamic(df, ["H"], "L", "N3_H_to_L"),
    regression_dynamic(df, ["S"], "L", "N3_S_to_L"),
    regression_dynamic(df, ["H", "S"], "L", "N3_H_plus_S_to_L"),
    regression_dynamic(df, ["H", "S", "L"], "Phi_epsilon", "N3_HSL_to_Phi"),
    regression_dynamic(df, ["H", "S", "L"], "Functional_unity_score", "N3_HSL_to_Functional_Unity"),
    regression_dynamic(df, ["H", "S", "L"], "Pathological_capture_index", "N3_HSL_to_Pathological_Capture"),
])

# Dynamic crisis derivatives.
dyn = df.dropna(subset=["dH", "dS", "dL", "dPhi", "dFunctional_unity", "dPathological_capture_index"]).copy()

dynamic_summary = pd.DataFrame([
    regression_dynamic(dyn, ["dH"], "dS", "N3_DYN_dH_to_dS"),
    regression_dynamic(dyn, ["dH"], "dL", "N3_DYN_dH_to_dL"),
    regression_dynamic(dyn, ["dS"], "dL", "N3_DYN_dS_to_dL"),
    regression_dynamic(dyn, ["dH", "dS"], "dL", "N3_DYN_dH_plus_dS_to_dL"),
    regression_dynamic(dyn, ["dH", "dS", "dL"], "dPhi", "N3_DYN_dHSL_to_dPhi"),
    regression_dynamic(dyn, ["dH", "dS", "dL"], "dPathological_capture_index", "N3_DYN_dHSL_to_dCapture"),
])

def get_mae(summary, test):
    x = summary[summary["test"] == test]
    return None if len(x) == 0 else x.iloc[0]["mae"]

H_L = get_mae(genesis_summary, "N3_H_to_L")
S_L = get_mae(genesis_summary, "N3_S_to_L")
HS_L = get_mae(genesis_summary, "N3_H_plus_S_to_L")
emergence_contrast = pd.DataFrame([{
    "level": "epilepsy_state",
    "H_to_L_mae": H_L,
    "S_to_L_mae": S_L,
    "H_plus_S_to_L_mae": HS_L,
    "HS_improves_over_H": None if H_L is None or HS_L is None else H_L - HS_L,
    "HS_improves_over_S": None if S_L is None or HS_L is None else S_L - HS_L,
    "PETU_prediction_supported": H_L is not None and S_L is not None and HS_L is not None and HS_L < H_L and HS_L < S_L
}])

DH_L = get_mae(dynamic_summary, "N3_DYN_dH_to_dL")
DS_L = get_mae(dynamic_summary, "N3_DYN_dS_to_dL")
DHS_L = get_mae(dynamic_summary, "N3_DYN_dH_plus_dS_to_dL")
dynamic_emergence_contrast = pd.DataFrame([{
    "level": "epilepsy_dynamic",
    "dH_to_dL_mae": DH_L,
    "dS_to_dL_mae": DS_L,
    "dH_plus_dS_to_dL_mae": DHS_L,
    "dHS_improves_over_dH": None if DH_L is None or DHS_L is None else DH_L - DHS_L,
    "dHS_improves_over_dS": None if DS_L is None or DHS_L is None else DS_L - DHS_L,
    "PETU_dynamic_prediction_supported": DH_L is not None and DS_L is not None and DHS_L is not None and DHS_L < DH_L and DHS_L < DS_L
}])

# ============================================================
# STATE / SEIZURE CONTRASTS
# ============================================================

state_summary = (
    df.groupby("state")
    .agg(
        n_windows=("state", "count"),
        mean_H=("H", "mean"),
        mean_S=("S", "mean"),
        mean_L=("L", "mean"),
        mean_Phi=("Phi_epsilon", "mean"),
        mean_unity=("Functional_unity_score", "mean"),
        mean_balance=("Triadic_balance", "mean"),
        mean_dominance=("Dominance_index", "mean"),
        mean_capture=("Pathological_capture_index", "mean")
    )
    .reset_index()
)

# Ictal vs interictal effect sizes + p-values.
contrast_rows = []
for metric in ["H", "S", "L", "Phi_epsilon", "Functional_unity_score", "Triadic_balance", "Dominance_index", "Pathological_capture_index"]:
    ictal = df[df["state"] == "ictal"][metric].values
    inter = df[df["state"] == "interictal"][metric].values
    stat, p = safe_mannwhitney(ictal, inter)
    contrast_rows.append({
        "metric": metric,
        "ictal_mean": float(np.mean(ictal)) if len(ictal) else np.nan,
        "interictal_mean": float(np.mean(inter)) if len(inter) else np.nan,
        "delta_ictal_minus_interictal": float(np.mean(ictal) - np.mean(inter)) if len(ictal) and len(inter) else np.nan,
        "pct_delta": float(100 * (np.mean(ictal) - np.mean(inter)) / (abs(np.mean(inter)) + 1e-12)) if len(ictal) and len(inter) else np.nan,
        "mannwhitney_stat": stat,
        "p_value": p,
    })
seizure_contrast_summary = pd.DataFrame(contrast_rows)

# File-level seizure summary.
file_summary = (
    df.groupby(["file", "state"])
    .agg(
        n=("state", "count"),
        mean_H=("H", "mean"),
        mean_S=("S", "mean"),
        mean_L=("L", "mean"),
        mean_Phi=("Phi_epsilon", "mean"),
        mean_capture=("Pathological_capture_index", "mean"),
        mean_unity=("Functional_unity_score", "mean")
    )
    .reset_index()
)

# ============================================================
# CLASSIFICATION: H vs HS vs HSL vs HSLPhiCapture
# ============================================================

def auc_cv(data, feature_cols, label, target_col="is_ictal"):
    d = data.dropna(subset=feature_cols + [target_col, "file"]).copy()
    # Ictal vs interictal only for clean contrast.
    d = d[d["state"].isin(["ictal", "interictal"])]
    if len(d) < 50 or d[target_col].nunique() < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target_col].values.astype(int)

    # If enough files, group CV by file; otherwise stratified.
    groups = d["file"].values
    preds = np.zeros(len(y), dtype=float)
    unique_groups = np.unique(groups)
    try:
        if len(unique_groups) >= 3:
            splitter = GroupKFold(n_splits=min(5, len(unique_groups)))
            iterator = splitter.split(X, y, groups)
        else:
            splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)
            iterator = splitter.split(X, y)

        for train, test in iterator:
            clf = LogisticRegression(max_iter=1000, class_weight="balanced")
            clf.fit(X[train], y[train])
            preds[test] = clf.predict_proba(X[test])[:, 1]
        auc = roc_auc_score(y, preds)
    except Exception:
        auc = np.nan

    return {
        "feature_set": label,
        "target": "ictal_vs_interictal",
        "n": int(len(d)),
        "auc": float(auc)
    }

class_rows = []
for cols, label in [
    (["H"], "H"),
    (["S"], "S"),
    (["L"], "L"),
    (["H", "S"], "H+S"),
    (["H", "S", "L"], "H+S+L"),
    (["H", "S", "L", "Phi_epsilon"], "H+S+L+Phi"),
    (["H", "S", "L", "Phi_epsilon", "Pathological_capture_index"], "H+S+L+Phi+Capture"),
]:
    r = auc_cv(df, cols, label)
    if r:
        class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

# Gains.
if len(classification_summary) > 0:
    def auc_of(label):
        x = classification_summary[classification_summary["feature_set"] == label]
        return None if len(x) == 0 else float(x.iloc[0]["auc"])
    auc_H = auc_of("H")
    auc_HS = auc_of("H+S")
    auc_HSL = auc_of("H+S+L")
    auc_full = auc_of("H+S+L+Phi+Capture")
    classification_gain_summary = pd.DataFrame([{
        "auc_H": auc_H,
        "auc_HS": auc_HS,
        "auc_HSL": auc_HSL,
        "auc_full": auc_full,
        "gain_HSL_over_H": None if auc_H is None or auc_HSL is None else auc_HSL - auc_H,
        "gain_HSL_over_HS": None if auc_HS is None or auc_HSL is None else auc_HSL - auc_HS,
        "gain_full_over_HSL": None if auc_full is None or auc_HSL is None else auc_full - auc_HSL,
    }])
else:
    classification_gain_summary = pd.DataFrame()

# ============================================================
# PHASES
# ============================================================

def classify_epilepsy_phase(row):
    h, s, l = row["H"], row["S"], row["L"]
    phi = row["Phi_epsilon"]
    cap = row["Pathological_capture_index"]
    bal = row["Triadic_balance"]

    if row["state"] == "ictal" and l >= 0.45 and cap >= df["Pathological_capture_index"].quantile(0.75):
        return "pathological_phi_capture"
    if row["state"] == "ictal" and l >= 0.40:
        return "ictal_link_synchrony"
    if phi >= df["Phi_epsilon"].quantile(0.75) and bal >= 0.70:
        return "high_phi_integrated"
    if h >= 0.55 and l < 0.35:
        return "H_active_low_link"
    if l >= 0.45 and phi < df["Phi_epsilon"].median():
        return "L_cohesion_subPhi"
    if bal < 0.60:
        return "unbalanced_transition"
    return "transitional"

df["PETU_epilepsy_phase"] = df.apply(classify_epilepsy_phase, axis=1)

phase_summary = (
    df.groupby(["state", "PETU_epilepsy_phase"])
    .size()
    .reset_index(name="n_windows")
)
phase_totals = (
    df.groupby("PETU_epilepsy_phase")
    .size()
    .reset_index(name="n_windows_total")
    .sort_values("n_windows_total", ascending=False)
)

# ============================================================
# SAVE
# ============================================================

paths = {
    "features": f"{OUTDIR}/PETU_MESO_NEURO_N3_features.csv",
    "dynamic_features": f"{OUTDIR}/PETU_MESO_NEURO_N3_dynamic_features.csv",
    "genesis_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_genesis_summary.csv",
    "dynamic_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_dynamic_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_MESO_NEURO_N3_emergence_contrast.csv",
    "dynamic_emergence_contrast": f"{OUTDIR}/PETU_MESO_NEURO_N3_dynamic_emergence_contrast.csv",
    "state_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_state_summary.csv",
    "seizure_contrast_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_seizure_contrast_summary.csv",
    "file_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_file_summary.csv",
    "classification_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_classification_summary.csv",
    "classification_gain_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_classification_gain_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_phase_summary.csv",
    "phase_totals": f"{OUTDIR}/PETU_MESO_NEURO_N3_phase_totals.csv",
    "failures": f"{OUTDIR}/PETU_MESO_NEURO_N3_failures.csv",
    "summary": f"{OUTDIR}/PETU_MESO_NEURO_N3_summary.json",
}

df.to_csv(paths["features"], index=False)
dyn.to_csv(paths["dynamic_features"], index=False)
genesis_summary.to_csv(paths["genesis_summary"], index=False)
dynamic_summary.to_csv(paths["dynamic_summary"], index=False)
emergence_contrast.to_csv(paths["emergence_contrast"], index=False)
dynamic_emergence_contrast.to_csv(paths["dynamic_emergence_contrast"], index=False)
state_summary.to_csv(paths["state_summary"], index=False)
seizure_contrast_summary.to_csv(paths["seizure_contrast_summary"], index=False)
file_summary.to_csv(paths["file_summary"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
phase_totals.to_csv(paths["phase_totals"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-MESO-NEURO N3 Epilepsy Criticality",
    "domain": "natural pathology / CHB-MIT scalp EEG / epilepsy",
    "patient": "chb01",
    "files_requested": list(CHB01_FILES.keys()),
    "files_completed": sorted(df["file"].unique().tolist()),
    "n_windows": int(len(df)),
    "n_dynamic_windows": int(len(dyn)),
    "states": sorted(df["state"].unique().tolist()),
    "window_sec": WINDOW_SEC,
    "step_sec": STEP_SEC,
    "epsilon": EPSILON,
    "hypothesis": "Epileptic seizure is a pathological triadic capture, not mere H activation: H/S/L jointly reconstruct Phi and classify ictal state, with L/capture expected to be decisive.",
    "next_step": "N3b multi-patient CHB-MIT expansion; N4 macro-domain transition."
}
with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

# ============================================================
# PRINT
# ============================================================

print("\n============================================================")
print("PETU-MESO-NEURO N3 GENESIS SUMMARY")
print("============================================================")
print(genesis_summary)

print("\n============================================================")
print("PETU-MESO-NEURO N3 DYNAMIC SUMMARY")
print("============================================================")
print(dynamic_summary)

print("\n============================================================")
print("PETU-MESO-NEURO N3 EMERGENCE CONTRAST")
print("============================================================")
print(emergence_contrast)

print("\n============================================================")
print("PETU-MESO-NEURO N3 DYNAMIC EMERGENCE CONTRAST")
print("============================================================")
print(dynamic_emergence_contrast)

print("\n============================================================")
print("PETU-MESO-NEURO N3 STATE SUMMARY")
print("============================================================")
print(state_summary)

print("\n============================================================")
print("PETU-MESO-NEURO N3 SEIZURE CONTRAST SUMMARY")
print("============================================================")
print(seizure_contrast_summary)

print("\n============================================================")
print("PETU-MESO-NEURO N3 CLASSIFICATION SUMMARY")
print("============================================================")
print(classification_summary)

print("\n============================================================")
print("PETU-MESO-NEURO N3 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MESO-NEURO N3 PHASE TOTALS")
print("============================================================")
print(phase_totals)

print("\n============================================================")
print("PETU-MESO-NEURO N3 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

if len(failures) > 0:
    print("\n============================================================")
    print("FAILURES")
    print("============================================================")
    print(pd.DataFrame(failures))

# ============================================================
# FIGURES
# ============================================================

plt.figure(figsize=(9, 5))
order = [s for s in ["interictal", "preictal", "ictal", "postictal"] if s in state_summary["state"].values]
for metric in ["mean_H", "mean_S", "mean_L", "mean_Phi", "mean_capture"]:
    vals = []
    for st in order:
        vals.append(float(state_summary[state_summary["state"] == st][metric].iloc[0]))
    plt.plot(order, vals, marker="o", label=metric)
plt.xlabel("Epilepsy state")
plt.ylabel("Mean PETU score")
plt.title("PETU-MESO-NEURO N3: H-S-L-Phi-Capture by epilepsy state")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_N3_HSLPhiCapture_by_state.png", dpi=220)
plt.show()

plt.figure(figsize=(8, 5))
for st in order:
    d = df[df["state"] == st]
    plt.scatter(d["L"], d["Phi_epsilon"], s=8, alpha=0.35, label=st)
plt.xlabel("L")
plt.ylabel("Phi epsilon")
plt.title("PETU-MESO-NEURO N3: L vs Phi")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_N3_L_vs_Phi.png", dpi=220)
plt.show()

if len(classification_summary) > 0:
    plt.figure(figsize=(9, 5))
    plt.bar(classification_summary["feature_set"], classification_summary["auc"])
    plt.xticks(rotation=45)
    plt.ylim(0, 1)
    plt.ylabel("AUC ictal vs interictal")
    plt.title("PETU-MESO-NEURO N3: ictal classification")
    plt.tight_layout()
    plt.savefig(f"{OUTDIR}/figure_N3_classification_auc.png", dpi=220)
    plt.show()

plt.figure(figsize=(10, 5))
plt.bar(phase_totals["PETU_epilepsy_phase"], phase_totals["n_windows_total"])
plt.xticks(rotation=65)
plt.ylabel("n windows")
plt.title("PETU-MESO-NEURO N3: epilepsy phases")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_N3_phase_totals.png", dpi=220)
plt.show()

zip_base = "/content/PETU_MESO_NEURO_N3_Epilepsy_Criticality_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path):
    os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k, v in paths.items():
    print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

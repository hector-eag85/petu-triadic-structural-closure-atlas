# ============================================================
# PETU-MACRO-HYDRO H2
# Hydroclimatic Stress / Extreme Event Perturbative Audit
#
# Sistema: USGS NWIS daily discharge (00060)
# H = soporte hídrico/material
# S = estructura del régimen hidrológico
# L = vínculo/continuidad temporal del flujo
# Phi = resiliencia hidrofuncional
# ============================================================

!pip -q install requests numpy pandas scipy scikit-learn matplotlib tqdm

import os, json, warnings, shutil
warnings.filterwarnings('ignore')

import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

OUTDIR = '/content/PETU_MACRO_HYDRO_H2_Hydroclimatic_Stress_Audit'
os.makedirs(OUTDIR, exist_ok=True)

START_DATE = '2000-01-01'
END_DATE = '2023-12-31'
PARAMETER_CODE = '00060'
WINDOW_DAYS = 365
STEP_DAYS = 90
MIN_DAYS_PER_SITE = 1500
MIN_VALID_IN_WINDOW = 250
EPSILON = 0.05

USGS_SITES = {
    'Colorado_River_Lees_Ferry_AZ': '09380000',
    'Mississippi_St_Louis_MO': '07010000',
    'Hudson_River_Green_Island_NY': '01358000',
    'Potomac_River_Washington_DC': '01646500',
    'Delaware_River_Trenton_NJ': '01463500',
    'Susquehanna_River_Harrisburg_PA': '01570500',
    'Columbia_River_Dalles_OR': '14105700',
    'Snake_River_Weiser_ID': '13269000',
    'Yampa_River_Deerlodge_CO': '09260050',
    'Rio_Grande_Embudo_NM': '08279500',
    'Gila_River_Clifton_AZ': '09442000',
    'Tennessee_River_Chattanooga_TN': '03568000',
    'Allegheny_River_Natrona_PA': '03049500',
    'Willamette_River_Portland_OR': '14211720',
    'Truckee_River_Reno_NV': '10348000',
    'Yellowstone_River_Billings_MT': '06214500',
    'James_River_Scotland_SD': '06478500',
    'Wabash_River_Mount_Carmel_IL': '03377500',
    'Neuse_River_Kinston_NC': '02089500',
    'San_Joaquin_River_Vernalis_CA': '11303500',
    'Klamath_River_Keno_OR': '11509500',
    'Deschutes_River_Moody_OR': '14103000',
    'Connecticut_River_Thompsonville_CT': '01184000',
    'St_Croix_River_St_Croix_Falls_WI': '05340500',
    'Sabine_River_Ruliff_TX': '08030500',
    'Sacramento_River_Freeport_CA': '11447650',
    'Red_River_Alexandria_LA': '07355500',
    'Arkansas_River_Little_Rock_AR': '07263620',
    'Chattahoochee_River_Atlanta_GA': '02336000',
    'Pecos_River_Red_Bluff_NM': '08410000'
}

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0: return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12: return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3: return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        a, b = a[np.isfinite(a)], b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3: return None, None
        stat, p = mannwhitneyu(a, b, alternative='two-sided')
        return float(stat), float(p)
    except Exception:
        return None, None

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def entropy_norm(values, bins=20):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 5: return 0.0
    hist, _ = np.histogram(values, bins=bins, density=False)
    p = hist.astype(float)
    if p.sum() <= 0: return 0.0
    p = p / p.sum()
    ent = -np.sum(p * np.log(p + 1e-12))
    return float(ent / np.log(len(p) + 1e-12))

def autocorr(x, lag=1):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) <= lag + 3: return 0.0
    a, b = x[:-lag], x[lag:]
    if np.std(a) < 1e-12 or np.std(b) < 1e-12: return 0.0
    return float(np.corrcoef(a, b)[0, 1])

def fetch_usgs_daily(site_id):
    url = 'https://waterservices.usgs.gov/nwis/dv/'
    params = {'format': 'json', 'sites': site_id, 'startDT': START_DATE, 'endDT': END_DATE, 'parameterCd': PARAMETER_CODE, 'siteStatus': 'all'}
    r = requests.get(url, params=params, timeout=60)
    r.raise_for_status()
    data = r.json()
    ts = data.get('value', {}).get('timeSeries', [])
    if not ts: return pd.DataFrame(columns=['date', 'q'])
    vals = ts[0].get('values', [])
    records = []
    for block in vals:
        for v in block.get('value', []):
            try:
                dt = pd.to_datetime(v.get('dateTime')).date()
                q = float(v.get('value'))
                if q >= 0 and np.isfinite(q): records.append((dt, q))
            except Exception:
                pass
    df = pd.DataFrame(records, columns=['date', 'q'])
    if len(df) == 0: return df
    df['date'] = pd.to_datetime(df['date'])
    return df.drop_duplicates('date').sort_values('date')

def window_features(site_name, site_id, df, start_idx, gs):
    w = df.iloc[start_idx:start_idx+WINDOW_DAYS].copy()
    if len(w) < MIN_VALID_IN_WINDOW: return None
    q = w['q'].values.astype(float)
    q = q[np.isfinite(q)]
    if len(q) < MIN_VALID_IN_WINDOW or np.mean(q) <= 0: return None

    logq = np.log1p(q)
    mean_q, med_q = float(np.mean(q)), float(np.median(q))
    q05, q10, q25, q75, q90, q95 = [float(np.percentile(q, p)) for p in [5,10,25,75,90,95]]
    std_q = float(np.std(q))
    cv = std_q / (mean_q + 1e-12)
    iqr_ratio = (q75 - q25) / (med_q + 1e-12)
    diffs = np.diff(q)
    flashiness = float(np.sum(np.abs(diffs)) / (np.sum(q[:-1]) + 1e-12)) if len(q) > 3 else 0.0
    rise_rate = float(np.mean(np.maximum(diffs, 0)) / (mean_q + 1e-12)) if len(diffs) else 0.0
    fall_rate = float(np.mean(np.maximum(-diffs, 0)) / (mean_q + 1e-12)) if len(diffs) else 0.0
    ac1, ac7, ac30 = autocorr(q, 1), autocorr(q, 7), autocorr(q, 30)
    baseflow_proxy = q10 / (mean_q + 1e-12)
    lowflow_days = float(np.mean(q <= gs['q10_site']))
    highflow_days = float(np.mean(q >= gs['q90_site']))
    extreme_low_days = float(np.mean(q <= gs['q05_site']))
    extreme_high_days = float(np.mean(q >= gs['q95_site']))

    low_mask = q <= gs['q10_site']
    recoveries, i = [], 0
    while i < len(q):
        if low_mask[i]:
            j = i
            while j < len(q) and low_mask[j]: j += 1
            after = q[j:min(len(q), j+30)]
            if len(after) >= 5:
                rec = (np.median(after) - np.median(q[i:j])) / (gs['median_site'] + 1e-12)
                recoveries.append(rec)
            i = j
        else:
            i += 1
    recovery_after_lowflow = float(np.nanmean(recoveries)) if recoveries else 0.0
    recovery_after_lowflow = max(0.0, recovery_after_lowflow)

    variability_penalty = 1.0 / (1.0 + cv)
    flash_penalty = 1.0 / (1.0 + flashiness * 10.0)
    drought_penalty = 1.0 - min(1.0, lowflow_days + extreme_low_days)
    flood_penalty = 1.0 - min(1.0, highflow_days + extreme_high_days)
    recovery_score_raw = recovery_after_lowflow / (1.0 + recovery_after_lowflow)

    H_raw = np.mean([mean_q/(gs['mean_site']+1e-12), med_q/(gs['median_site']+1e-12), baseflow_proxy, q10/(gs['q10_site']+1e-12), 1.0-extreme_low_days])
    S_raw = np.mean([entropy_norm(logq), variability_penalty, 1.0/(1.0+iqr_ratio), drought_penalty, flood_penalty, 1.0/(1.0+abs(rise_rate-fall_rate))])
    L_raw = np.mean([max(0.0, ac1), max(0.0, ac7), max(0.0, ac30), baseflow_proxy, flash_penalty, 1.0-min(1.0, abs(fall_rate-rise_rate)*10.0)])
    Phi_resilience_raw = np.mean([variability_penalty, flash_penalty, drought_penalty, flood_penalty, recovery_score_raw, max(0.0, ac7)])
    Hydro_pathology_raw = np.mean([lowflow_days, extreme_low_days, highflow_days, extreme_high_days, min(1.0, cv), min(1.0, flashiness*5.0), 1.0-max(0.0, ac7)])
    Drought_index_raw = np.mean([lowflow_days, extreme_low_days, 1.0/(1.0+baseflow_proxy), 1.0/(1.0+mean_q/(gs['mean_site']+1e-12))])
    Flash_index_raw = np.mean([min(1.0, flashiness*5.0), min(1.0, cv), highflow_days+extreme_high_days, min(1.0, abs(rise_rate-fall_rate)*5.0)])

    return {
        'site_name': site_name, 'site_id': site_id, 'window_start': str(w['date'].iloc[0].date()), 'window_end': str(w['date'].iloc[-1].date()), 'n_days': int(len(q)),
        'mean_q': mean_q, 'median_q': med_q, 'min_q': float(np.min(q)), 'max_q': float(np.max(q)), 'q05': q05, 'q10': q10, 'q90': q90, 'q95': q95,
        'cv': cv, 'iqr_ratio': iqr_ratio, 'flashiness': flashiness, 'rise_rate': rise_rate, 'fall_rate': fall_rate, 'baseflow_proxy': baseflow_proxy,
        'autocorr_lag1': ac1, 'autocorr_lag7': ac7, 'autocorr_lag30': ac30, 'lowflow_days': lowflow_days, 'highflow_days': highflow_days,
        'extreme_low_days': extreme_low_days, 'extreme_high_days': extreme_high_days, 'recovery_after_lowflow': recovery_after_lowflow,
        'H_raw': H_raw, 'S_raw': S_raw, 'L_raw': L_raw, 'Phi_resilience_raw': Phi_resilience_raw, 'Hydro_pathology_raw': Hydro_pathology_raw,
        'Drought_index_raw': Drought_index_raw, 'Flash_index_raw': Flash_index_raw
    }

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20: return {'test': label, 'n': int(len(d)), 'r2': None, 'mae': None, 'spearman_true_pred': None, 'p_value': None}
    X, y = d[X_cols].values.astype(float), d[y_col].values.astype(float)
    model = Ridge(alpha=1.0).fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {'test': label, 'n': int(len(d)), 'r2': float(r2_score(y, pred)), 'mae': float(mean_absolute_error(y, pred)), 'spearman_true_pred': r, 'p_value': p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2: return None
    X, y = d[feature_cols].values.astype(float), d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight='balanced').fit(X, y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception:
        auc = np.nan
    return {'feature_set': label, 'target': target, 'n': int(len(d)), 'auc': float(auc)}

print('='*60)
print('PETU-MACRO-HYDRO H2 HYDROCLIMATIC STRESS AUDIT')
print('='*60)
print('Fetching USGS NWIS daily discharge records...')

features, site_summary_rows, failures = [], [], []
for site_name, site_id in tqdm(USGS_SITES.items(), desc='USGS sites'):
    try:
        df = fetch_usgs_daily(site_id)
        if len(df) < MIN_DAYS_PER_SITE:
            failures.append({'site_name': site_name, 'site_id': site_id, 'error': f'too few days: {len(df)}'})
            continue
        q = df['q'].values.astype(float)
        gs = {'mean_site': float(np.mean(q)), 'median_site': float(np.median(q)), 'q05_site': float(np.percentile(q,5)), 'q10_site': float(np.percentile(q,10)), 'q90_site': float(np.percentile(q,90)), 'q95_site': float(np.percentile(q,95))}
        nwin = 0
        for start_idx in range(0, len(df)-WINDOW_DAYS+1, STEP_DAYS):
            row = window_features(site_name, site_id, df, start_idx, gs)
            if row is not None:
                features.append(row); nwin += 1
        site_summary_rows.append({'site_name': site_name, 'site_id': site_id, 'n_days': int(len(df)), 'start_date': str(df['date'].min().date()), 'end_date': str(df['date'].max().date()), 'n_windows': int(nwin), 'mean_q_all': float(np.mean(q)), 'median_q_all': float(np.median(q)), 'q10_all': float(np.percentile(q,10)), 'q90_all': float(np.percentile(q,90))})
        print(f'  OK {site_name} windows: {nwin}')
    except Exception as e:
        failures.append({'site_name': site_name, 'site_id': site_id, 'error': str(e)})

features = pd.DataFrame(features)
site_summary = pd.DataFrame(site_summary_rows)
if len(features) < 50: raise RuntimeError('Too few hydrological windows.')

for col in ['H_raw','S_raw','L_raw','Phi_resilience_raw','Hydro_pathology_raw','Drought_index_raw','Flash_index_raw']:
    features[col.replace('_raw','')] = normalize01(features[col].values)
features['Phi_HSL_epsilon'] = (features['H']+EPSILON)*(features['S']+EPSILON)*(features['L']+EPSILON)
features['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(features['H'], features['S'], features['L'])]
features['Functional_unity'] = features['Phi_HSL_epsilon'] * features['Triadic_balance']
features['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(features['H'], features['S'], features['L'])]

features['resilient_high_flag'] = features['Phi_resilience'] >= features['Phi_resilience'].median()
features['pathology_high_flag'] = features['Hydro_pathology'] >= features['Hydro_pathology'].median()
features['drought_high_flag'] = features['Drought_index'] >= features['Drought_index'].quantile(0.75)
features['flash_high_flag'] = features['Flash_index'] >= features['Flash_index'].quantile(0.75)
features['recovery_high_flag'] = features['recovery_after_lowflow'] >= features['recovery_after_lowflow'].median()
features['triadic_disproportion_flag'] = (features['Triadic_balance'] <= features['Triadic_balance'].quantile(0.25)) | (features['Dominance_index'] >= features['Dominance_index'].quantile(0.75))
features['L_hyperdynamic_flag'] = (features['L'] >= features['L'].quantile(0.75)) & (features['Flash_index'] >= features['Flash_index'].quantile(0.75))
features['window_mid'] = pd.to_datetime(features['window_start']) + (pd.to_datetime(features['window_end']) - pd.to_datetime(features['window_start'])) / 2
features = features.sort_values(['site_id','window_mid']).reset_index(drop=True)

dyn_rows = []
for site_id, g in features.groupby('site_id'):
    g = g.sort_values('window_mid').reset_index(drop=True)
    for i in range(1, len(g)):
        prev, cur = g.iloc[i-1], g.iloc[i]
        dyn_rows.append({'site_name': cur['site_name'], 'site_id': site_id, 'window_start': cur['window_start'], 'window_end': cur['window_end'], 'dH': cur['H']-prev['H'], 'dS': cur['S']-prev['S'], 'dL': cur['L']-prev['L'], 'dPhi_resilience': cur['Phi_resilience']-prev['Phi_resilience'], 'dFunctional_unity': cur['Functional_unity']-prev['Functional_unity'], 'dHydro_pathology': cur['Hydro_pathology']-prev['Hydro_pathology'], 'dDrought_index': cur['Drought_index']-prev['Drought_index'], 'dFlash_index': cur['Flash_index']-prev['Flash_index'], 'dBalance': cur['Triadic_balance']-prev['Triadic_balance'], 'dDominance': cur['Dominance_index']-prev['Dominance_index']})
dynamic_features = pd.DataFrame(dyn_rows)

genesis_summary = pd.DataFrame([
    regression(features, ['H'], 'S', 'H2_H_to_S'), regression(features, ['H'], 'L', 'H2_H_to_L'), regression(features, ['S'], 'L', 'H2_S_to_L'), regression(features, ['H','S'], 'L', 'H2_H_plus_S_to_L'),
    regression(features, ['H','S','L'], 'Phi_resilience', 'H2_HSL_to_Phi_resilience'), regression(features, ['H','S','L'], 'Functional_unity', 'H2_HSL_to_Functional_Unity'),
    regression(features, ['H','S','L'], 'Hydro_pathology', 'H2_HSL_to_Hydro_Pathology'), regression(features, ['H','S','L','Triadic_balance','Dominance_index'], 'Hydro_pathology', 'H2_Full_to_Hydro_Pathology'),
    regression(features, ['H','S','L','Triadic_balance','Dominance_index'], 'Phi_resilience', 'H2_Full_to_Phi_resilience'), regression(features, ['H','S','L'], 'Drought_index', 'H2_HSL_to_Drought_Index'),
    regression(features, ['H','S','L'], 'Flash_index', 'H2_HSL_to_Flash_Index'), regression(features, ['H','S','L'], 'recovery_after_lowflow', 'H2_HSL_to_Recovery_After_Lowflow')])

def get_mae(summary, test):
    x = summary[summary['test']==test]
    return None if len(x)==0 else x.iloc[0]['mae']
H_L, S_L, HS_L = get_mae(genesis_summary,'H2_H_to_L'), get_mae(genesis_summary,'H2_S_to_L'), get_mae(genesis_summary,'H2_H_plus_S_to_L')
emergence_contrast = pd.DataFrame([{'level': 'macro_hydro_stress', 'H_to_L_mae': H_L, 'S_to_L_mae': S_L, 'H_plus_S_to_L_mae': HS_L, 'HS_improves_over_H': H_L-HS_L if H_L is not None and HS_L is not None else None, 'HS_improves_over_S': S_L-HS_L if S_L is not None and HS_L is not None else None, 'PETU_prediction_supported': (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None}])

dynamic_summary = pd.DataFrame([
    regression(dynamic_features, ['dH'], 'dS', 'H2_DYN_dH_to_dS'), regression(dynamic_features, ['dH'], 'dL', 'H2_DYN_dH_to_dL'), regression(dynamic_features, ['dS'], 'dL', 'H2_DYN_dS_to_dL'), regression(dynamic_features, ['dH','dS'], 'dL', 'H2_DYN_dH_plus_dS_to_dL'),
    regression(dynamic_features, ['dH','dS','dL'], 'dPhi_resilience', 'H2_DYN_dHSL_to_dPhi_resilience'), regression(dynamic_features, ['dH','dS','dL'], 'dFunctional_unity', 'H2_DYN_dHSL_to_dFunctional_Unity'),
    regression(dynamic_features, ['dH','dS','dL'], 'dHydro_pathology', 'H2_DYN_dHSL_to_dHydro_Pathology'), regression(dynamic_features, ['dH','dS','dL'], 'dDrought_index', 'H2_DYN_dHSL_to_dDrought'), regression(dynamic_features, ['dH','dS','dL'], 'dFlash_index', 'H2_DYN_dHSL_to_dFlash')])

contrast_defs = [('resilient_vs_fragile','resilient_high_flag',True,False),('pathology_high_vs_low','pathology_high_flag',True,False),('drought_high_vs_other','drought_high_flag',True,False),('flash_high_vs_other','flash_high_flag',True,False),('recovery_high_vs_low','recovery_high_flag',True,False),('disproportion_vs_proportion','triadic_disproportion_flag',True,False),('L_hyperdynamic_vs_other','L_hyperdynamic_flag',True,False)]
contrast_metrics = ['H','S','L','Phi_HSL_epsilon','Triadic_balance','Functional_unity','Dominance_index','Phi_resilience','Hydro_pathology','Drought_index','Flash_index','cv','flashiness','baseflow_proxy','autocorr_lag1','autocorr_lag7','recovery_after_lowflow','lowflow_days','highflow_days','extreme_low_days','extreme_high_days']
contrast_rows = []
for cname, flag, aval, bval in contrast_defs:
    A, B = features[features[flag]==aval], features[features[flag]==bval]
    for col in contrast_metrics:
        stat, p = safe_mw(A[col], B[col])
        contrast_rows.append({'contrast': cname, 'metric': col, 'groupA_mean': float(A[col].mean()) if len(A) else np.nan, 'groupB_mean': float(B[col].mean()) if len(B) else np.nan, 'delta_A_minus_B': float(A[col].mean()-B[col].mean()) if len(A) and len(B) else np.nan, 'pct_delta': float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan, 'mannwhitney_stat': stat, 'p_value': p})
contrast_summary = pd.DataFrame(contrast_rows)

class_rows = []
targets = ['resilient_high_flag','pathology_high_flag','drought_high_flag','flash_high_flag','recovery_high_flag','triadic_disproportion_flag','L_hyperdynamic_flag']
feature_sets = [(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
for target in targets:
    for cols, label in feature_sets:
        r = auc_model(features, cols, target, label)
        if r: class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows = []
for target, d in classification_summary.groupby('target'):
    def auc(fs):
        x = d[d['feature_set']==fs]
        return None if len(x)==0 else float(x.iloc[0]['auc'])
    aH, aHS, aHSL, aFull = auc('H'), auc('H+S'), auc('H+S+L'), auc('H+S+L+PhiBalanceDominance')
    gain_rows.append({'target': target, 'auc_H': aH, 'auc_HS': aHS, 'auc_HSL': aHSL, 'auc_full': aFull, 'gain_HSL_over_H': None if aH is None or aHSL is None else aHSL-aH, 'gain_HSL_over_HS': None if aHS is None or aHSL is None else aHSL-aHS, 'gain_full_over_HSL': None if aFull is None or aHSL is None else aFull-aHSL})
classification_gain_summary = pd.DataFrame(gain_rows)

def classify_phase(r):
    if r['Drought_index'] >= features['Drought_index'].quantile(0.75) and r['H'] <= features['H'].median(): return 'low_H_drought_pathology'
    if r['Flash_index'] >= features['Flash_index'].quantile(0.75) and r['L'] >= features['L'].quantile(0.75): return 'flash_L_hyperdynamic_pathology'
    if r['triadic_disproportion_flag']: return 'triadic_disproportion'
    if r['Phi_resilience'] >= features['Phi_resilience'].median() and r['Triadic_balance'] >= features['Triadic_balance'].median(): return 'resilient_phi_integrated'
    if r['S'] >= features['S'].median() and r['L'] <= features['L'].quantile(0.25): return 'S_regime_low_link'
    if r['H'] <= features['H'].quantile(0.25): return 'low_support_H'
    return 'transitional'
features['PETU_H2_phase'] = features.apply(classify_phase, axis=1)
phase_summary = features.groupby('PETU_H2_phase').agg(n_windows=('site_id','count'), n_sites=('site_id','nunique'), mean_H=('H','mean'), mean_S=('S','mean'), mean_L=('L','mean'), mean_Phi_HSL=('Phi_HSL_epsilon','mean'), mean_resilience=('Phi_resilience','mean'), mean_balance=('Triadic_balance','mean'), mean_dominance=('Dominance_index','mean'), mean_pathology=('Hydro_pathology','mean'), mean_drought=('Drought_index','mean'), mean_flash=('Flash_index','mean'), mean_recovery=('recovery_after_lowflow','mean')).reset_index().sort_values('n_windows', ascending=False)

traj_rows = []
for flag in ['drought_high_flag','flash_high_flag','pathology_high_flag','resilient_high_flag']:
    for site_id, g in features.groupby('site_id'):
        g = g.sort_values('window_mid').reset_index(drop=True)
        for i in range(1, len(g)):
            prev, cur = g.iloc[i-1], g.iloc[i]
            traj_rows.append({'flag': flag, 'transition': f"{int(prev[flag])}->{int(cur[flag])}", 'site_id': site_id, 'dH': cur['H']-prev['H'], 'dS': cur['S']-prev['S'], 'dL': cur['L']-prev['L'], 'dPhi': cur['Phi_resilience']-prev['Phi_resilience'], 'dUnity': cur['Functional_unity']-prev['Functional_unity'], 'dPathology': cur['Hydro_pathology']-prev['Hydro_pathology'], 'dBalance': cur['Triadic_balance']-prev['Triadic_balance'], 'dDominance': cur['Dominance_index']-prev['Dominance_index']})
trajectory = pd.DataFrame(traj_rows)
trajectory_summary = trajectory.groupby(['flag','transition']).agg(n=('site_id','count'), mean_dH=('dH','mean'), mean_dS=('dS','mean'), mean_dL=('dL','mean'), mean_dPhi=('dPhi','mean'), mean_dUnity=('dUnity','mean'), mean_dPathology=('dPathology','mean'), mean_dBalance=('dBalance','mean'), mean_dDominance=('dDominance','mean')).reset_index()

paths = {
    'features': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_features.csv', 'dynamic_features': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_dynamic_features.csv', 'site_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_site_summary.csv', 'genesis_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_genesis_summary.csv', 'dynamic_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_dynamic_summary.csv', 'emergence_contrast': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_emergence_contrast.csv', 'contrast_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_contrast_summary.csv', 'classification_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_classification_summary.csv', 'classification_gain_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_classification_gain_summary.csv', 'phase_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_phase_summary.csv', 'trajectory_summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_trajectory_summary.csv', 'failures': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_failures.csv', 'summary': f'{OUTDIR}/PETU_MACRO_HYDRO_H2_summary.json'}
for name, df in [('features',features),('dynamic_features',dynamic_features),('site_summary',site_summary),('genesis_summary',genesis_summary),('dynamic_summary',dynamic_summary),('emergence_contrast',emergence_contrast),('contrast_summary',contrast_summary),('classification_summary',classification_summary),('classification_gain_summary',classification_gain_summary),('phase_summary',phase_summary),('trajectory_summary',trajectory_summary)]:
    df.to_csv(paths[name], index=False)
pd.DataFrame(failures).to_csv(paths['failures'], index=False)
summary = {'pipeline':'PETU-MACRO-HYDRO H2 Hydroclimatic Stress Audit','domain':'macro natural hydrology / USGS NWIS daily river discharge / stress events','n_sites_requested':int(len(USGS_SITES)),'n_sites_completed':int(site_summary['site_id'].nunique()),'n_windows':int(len(features)),'n_dynamic_windows':int(len(dynamic_features)),'start_date':START_DATE,'end_date':END_DATE,'parameter_code':PARAMETER_CODE,'window_days':WINDOW_DAYS,'step_days':STEP_DAYS,'epsilon':EPSILON,'hypothesis':'Hydroclimatic stress and recovery arise from triadic proportion/disproportion of H water support, S regime structure, and L flow continuity.','next_step':'C1: climate teleconnection audit; H2b: add precipitation/temperature forcing; K1: cosmological large-scale structure audit.'}
with open(paths['summary'],'w') as f: json.dump(summary, f, indent=2)

print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 SITE SUMMARY'); print('='*60); print(site_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 GENESIS SUMMARY'); print('='*60); print(genesis_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 EMERGENCE CONTRAST'); print('='*60); print(emergence_contrast)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 DYNAMIC SUMMARY'); print('='*60); print(dynamic_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 CONTRAST SUMMARY'); print('='*60); print(contrast_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 CLASSIFICATION GAIN SUMMARY'); print('='*60); print(classification_gain_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 PHASE SUMMARY'); print('='*60); print(phase_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 TRAJECTORY SUMMARY'); print('='*60); print(trajectory_summary)
print('\n'+'='*60); print('PETU-MACRO-HYDRO H2 FINAL SUMMARY'); print('='*60); print(json.dumps(summary, indent=2))
if len(failures) > 0:
    print('\n'+'='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

plt.figure(figsize=(8,5)); plt.scatter(features['H']+features['S'], features['L'], s=18, alpha=0.5); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-HYDRO H2: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_H2_HS_to_L.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Phi_HSL_epsilon'], features['Phi_resilience'], s=18, alpha=0.5); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_resilience'); plt.title('PETU-HYDRO H2: HSL unity vs hydrological resilience'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_H2_PhiHSL_resilience.png', dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features['Dominance_index'], features['Hydro_pathology'], s=18, alpha=0.5); plt.xlabel('Dominance index'); plt.ylabel('Hydro pathology'); plt.title('PETU-HYDRO H2: dominance and hydro pathology'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_H2_Dominance_Pathology.png', dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(phase_summary['PETU_H2_phase'], phase_summary['n_windows']); plt.xticks(rotation=60); plt.ylabel('Windows'); plt.title('PETU-HYDRO H2: phase counts'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_H2_phase_counts.png', dpi=220); plt.show()
zip_base = '/content/PETU_MACRO_HYDRO_H2_Hydroclimatic_Stress_Audit_results'; zip_path = zip_base + '.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base, 'zip', OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k + ':', v)
print('ZIP:', zip_path); print('='*60)

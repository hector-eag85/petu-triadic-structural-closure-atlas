# ============================================================
# PETU-MACRO-ECO M1
# Ecosystem Food-Web Perichoretic Triad Audit
#
# Objetivo:
#   Replicar en MACRO-ECO la firma observada en micro-proteínas
#   y meso-neuro:
#       H -> S
#       H + S -> L
#       H + S + L -> Phi
#
# Dominio:
#   Redes ecológicas reales de Mangal.io / food webs / species interactions.
#
# Tesis macro-ecológica PETU:
#   H = soporte ecoenergético/material:
#       riqueza de especies, base trófica, disponibilidad de presas/recursos.
#   S = forma/estructura ecosistémica:
#       modularidad, jerarquía trófica, diversidad de grados, profundidad trófica.
#   L = vínculo/cohesión ecológica:
#       conectancia, eficiencia, cohesión de red, redundancia de interacciones.
#   Phi = unidad funcional/resiliencia ecosistémica:
#       robustez frente a extinciones primarias y cascadas secundarias.
#
# Nota clave:
#   Phi_resilience NO es simplemente el producto H*S*L.
#   Se calcula como robustez simulada frente a perturbaciones.
# ============================================================

!pip -q install requests numpy scipy pandas scikit-learn matplotlib networkx tqdm

import os, json, math, shutil, random, warnings
warnings.filterwarnings("ignore")

import requests
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from tqdm.auto import tqdm

from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score
from sklearn.model_selection import KFold

# ============================================================
# CONFIG
# ============================================================

OUTDIR = "/content/PETU_MACRO_ECO_M1_Ecosystem_FoodWeb_Perichoresis"
os.makedirs(OUTDIR, exist_ok=True)

API = "https://mangal.io/api/v2"
MAX_NETWORKS = 120
NETWORK_PAGE_COUNT = 1000
MIN_NODES = 8
MAX_NODES = 250
MIN_EDGES = 8
ROBUSTNESS_REPS = 20
REMOVAL_FRACTION_GRID = np.linspace(0.0, 1.0, 21)
EPSILON = 0.05
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

TROPHIC_TYPES = set(["predation", "herbivory", "parasitism", "scavenger", "detritivore", "consumption"])

# ============================================================
# UTILS
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        mask = np.isfinite(a) & np.isfinite(b)
        if mask.sum() < 3:
            return None, None
        r, p = spearmanr(a[mask], b[mask])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mannwhitney(a, b):
    try:
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        a, b = a[np.isfinite(a)], b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None

def api_get(endpoint, params=None, timeout=60):
    url = f"{API}/{endpoint}"
    r = requests.get(url, params=params or {}, timeout=timeout)
    r.raise_for_status()
    return r.json()

def parse_nodes(nodes_json):
    out = {}
    for n in nodes_json:
        nid = int(n["id"])
        tax = n.get("taxonomy") or {}
        name = tax.get("name") or n.get("original_name") or str(nid)
        rank = tax.get("rank") or "unknown"
        out[nid] = {"name": name, "rank": rank, "original_name": n.get("original_name")}
    return out

def graph_from_interactions(nodes, interactions):
    """
    Directed graph convention:
       consumer/predator -> resource/prey.
    """
    G = nx.DiGraph()
    for nid, meta in nodes.items():
        G.add_node(nid, **meta)
    for e in interactions:
        try:
            u, v = int(e["node_from"]), int(e["node_to"])
            if u not in G or v not in G or u == v:
                continue
            val = e.get("value")
            weight = float(val) if val is not None and np.isfinite(float(val)) else 1.0
            G.add_edge(u, v, type=e.get("type") or "unspecified", weight=weight)
        except Exception:
            continue
    return G

def largest_weak_component(G):
    if G.number_of_nodes() == 0:
        return G.copy()
    comps = list(nx.weakly_connected_components(G))
    if not comps:
        return G.copy()
    return G.subgraph(max(comps, key=len)).copy()

def shannon_entropy(values):
    values = np.asarray(values, dtype=float)
    values = values[values > 0]
    if len(values) == 0:
        return 0.0
    p = values / np.sum(values)
    return float(-np.sum(p * np.log(p)) / np.log(len(p) + 1e-12))

def safe_modularity(G_und):
    try:
        if G_und.number_of_nodes() < 3 or G_und.number_of_edges() == 0:
            return 0.0
        comms = list(nx.algorithms.community.greedy_modularity_communities(G_und))
        return float(nx.algorithms.community.modularity(G_und, comms))
    except Exception:
        return 0.0

def safe_efficiency(G_und):
    try:
        if G_und.number_of_nodes() < 2:
            return 0.0
        return float(nx.global_efficiency(G_und))
    except Exception:
        return 0.0

def safe_clustering(G_und):
    try:
        if G_und.number_of_nodes() < 2:
            return 0.0
        return float(nx.average_clustering(G_und))
    except Exception:
        return 0.0

def trophic_levels_iterative(G, max_iter=200, tol=1e-6):
    nodes = list(G.nodes())
    tl = {n: 1.0 for n in nodes}
    for _ in range(max_iter):
        old = tl.copy()
        for n in nodes:
            prey = list(G.successors(n))
            if len(prey) == 0:
                tl[n] = 1.0
            else:
                tl[n] = 0.5 * old[n] + 0.5 * (1.0 + float(np.mean([old[p] for p in prey])))
        if nodes and max(abs(tl[n] - old[n]) for n in nodes) < tol:
            break
    vals = np.array([tl[n] for n in nodes], dtype=float)
    return tl, vals

# ============================================================
# NETWORK METRICS: H/S/L
# ============================================================

def compute_network_metrics(G):
    G = largest_weak_component(G)
    n, e = G.number_of_nodes(), G.number_of_edges()
    Gu = G.to_undirected()
    if n < 2:
        return None

    out_deg = dict(G.out_degree())
    in_deg = dict(G.in_degree())
    total_deg = dict(Gu.degree())
    basal_nodes = [x for x in G.nodes() if out_deg[x] == 0]
    top_nodes = [x for x in G.nodes() if in_deg[x] == 0]
    consumer_nodes = [x for x in G.nodes() if out_deg[x] > 0]

    connectance = e / (n * (n - 1) + 1e-12)
    basal_fraction = len(basal_nodes) / n
    top_fraction = len(top_nodes) / n
    consumer_fraction = len(consumer_nodes) / n
    mean_resources_per_consumer = float(np.mean([out_deg[x] for x in consumer_nodes])) if consumer_nodes else 0.0
    resource_redundancy = float(np.mean([in_deg[x] for x in basal_nodes])) if basal_nodes else 0.0

    _, tl_vals = trophic_levels_iterative(G)
    trophic_mean = float(np.mean(tl_vals)) if len(tl_vals) else 0.0
    trophic_std = float(np.std(tl_vals)) if len(tl_vals) else 0.0
    trophic_span = float(np.max(tl_vals) - np.min(tl_vals)) if len(tl_vals) else 0.0

    degree_vals = np.array(list(total_deg.values()), dtype=float)
    in_vals = np.array(list(in_deg.values()), dtype=float)
    out_vals = np.array(list(out_deg.values()), dtype=float)

    modularity = safe_modularity(Gu)
    efficiency = safe_efficiency(Gu)
    clustering = safe_clustering(Gu)
    comps = list(nx.connected_components(Gu)) if n else []
    lcc_fraction = max([len(c) for c in comps]) / n if comps else 0.0

    degree_entropy = shannon_entropy(degree_vals)
    in_entropy = shannon_entropy(in_vals)
    out_entropy = shannon_entropy(out_vals)

    try:
        reciprocity = nx.reciprocity(G)
        reciprocity = 0.0 if reciprocity is None else float(reciprocity)
    except Exception:
        reciprocity = 0.0

    H_features = {
        "H_log_species_richness": math.log1p(n),
        "H_basal_fraction": basal_fraction,
        "H_consumer_fraction": consumer_fraction,
        "H_mean_resources_per_consumer": mean_resources_per_consumer,
        "H_resource_redundancy": resource_redundancy,
        "H_trophic_base_width": len(basal_nodes) / math.sqrt(n + 1e-12),
    }

    S_features = {
        "S_modularity": modularity,
        "S_trophic_mean": trophic_mean,
        "S_trophic_std": trophic_std,
        "S_trophic_span": trophic_span,
        "S_trophic_hierarchy_proxy": trophic_span / (1.0 + trophic_std + 1e-12),
        "S_degree_entropy": degree_entropy,
        "S_in_out_entropy_balance": 1.0 - abs(in_entropy - out_entropy),
    }

    L_features = {
        "L_connectance": connectance,
        "L_efficiency": efficiency,
        "L_clustering": clustering,
        "L_lcc_fraction": lcc_fraction,
        "L_mean_degree": float(np.mean(degree_vals)) if len(degree_vals) else 0.0,
        "L_reciprocity": reciprocity,
        "L_link_density_log": math.log1p(e) / math.log1p(n * n),
    }

    return {
        "n_species": n,
        "n_interactions": e,
        "basal_count": len(basal_nodes),
        "top_count": len(top_nodes),
        "top_fraction": top_fraction,
        "connectance_raw": connectance,
        **H_features, **S_features, **L_features,
    }

# ============================================================
# ROBUSTNESS / INDEPENDENT PHI
# ============================================================

def cascade_after_removal(G, removed_initial):
    alive = set(G.nodes()) - set(removed_initial)
    changed = True
    while changed:
        changed = False
        for node in list(alive):
            prey = [p for p in G.successors(node) if p in alive]
            original_prey_count = G.out_degree(node)
            if original_prey_count > 0 and len(prey) == 0:
                alive.remove(node)
                changed = True
    return alive

def robustness_curve(G, mode="random", reps=20):
    G = largest_weak_component(G)
    nodes = list(G.nodes())
    n = len(nodes)
    if n == 0:
        return 0.0, []
    degrees = dict(G.to_undirected().degree())
    basal = [x for x in nodes if G.out_degree(x) == 0]
    curves = []
    for _ in range(reps):
        if mode == "random":
            order = nodes.copy(); random.shuffle(order)
        elif mode == "hub":
            order = sorted(nodes, key=lambda x: degrees.get(x, 0), reverse=True)
        elif mode == "basal":
            b = basal.copy(); random.shuffle(b)
            rest = [x for x in nodes if x not in set(b)]; random.shuffle(rest)
            order = b + rest
        else:
            order = nodes.copy(); random.shuffle(order)
        surv = []
        for frac in REMOVAL_FRACTION_GRID:
            k = int(round(frac * n))
            alive = cascade_after_removal(G, order[:k])
            surv.append(len(alive) / n)
        curves.append(surv)
    curve = np.mean(np.asarray(curves), axis=0)
    auc = float(np.trapz(curve, REMOVAL_FRACTION_GRID))
    return auc, curve.tolist()

def compute_robustness_metrics(G):
    random_auc, random_curve = robustness_curve(G, "random", ROBUSTNESS_REPS)
    hub_auc, hub_curve = robustness_curve(G, "hub", max(3, ROBUSTNESS_REPS // 3))
    basal_auc, basal_curve = robustness_curve(G, "basal", max(3, ROBUSTNESS_REPS // 3))
    phi_resilience = float(np.mean([random_auc, hub_auc, basal_auc]))
    fragility = 1.0 - phi_resilience
    targeted_sensitivity = float(max(random_auc - hub_auc, random_auc - basal_auc, 0.0))
    pathological_fragility = fragility * (1.0 + targeted_sensitivity)
    return {
        "Phi_resilience_random": random_auc,
        "Phi_resilience_hub_attack": hub_auc,
        "Phi_resilience_basal_attack": basal_auc,
        "Phi_resilience": phi_resilience,
        "Macro_fragility": fragility,
        "Targeted_sensitivity": targeted_sensitivity,
        "Pathological_fragility_index": pathological_fragility,
        "curve_random": random_curve,
        "curve_hub": hub_curve,
        "curve_basal": basal_curve,
    }

# ============================================================
# DOWNLOAD MANGAL NETWORKS
# ============================================================

print("============================================================")
print("PETU-MACRO-ECO M1 ECOSYSTEM FOOD-WEB PERICHORESIS")
print("============================================================")
print("Fetching public Mangal networks...")

all_networks = []
for page in range(0, 5):
    try:
        batch = api_get("network", params={"public": "true", "all_interactions": "true", "count": NETWORK_PAGE_COUNT, "page": page})
        if not batch:
            break
        all_networks.extend(batch)
        if len(batch) < NETWORK_PAGE_COUNT:
            break
    except Exception as e:
        print("Network listing failed on page", page, e)
        break

all_networks = sorted(all_networks, key=lambda x: int(x.get("id", 0)))
print("Networks discovered:", len(all_networks))

rows, curves, failures = [], [], []
processed = 0

for net in tqdm(all_networks, desc="Processing ecological networks"):
    if processed >= MAX_NETWORKS:
        break
    net_id = int(net["id"])
    net_name = net.get("name", f"network_{net_id}")
    try:
        nodes_json = api_get("node", params={"network_id": net_id, "count": 1000})
        interactions_json = api_get("interaction", params={"network_id": net_id, "count": 1000})
        if not nodes_json or not interactions_json:
            continue
        trophic_interactions = [e for e in interactions_json if (e.get("type") in TROPHIC_TYPES)]
        if len(trophic_interactions) < MIN_EDGES:
            continue
        nodes = parse_nodes(nodes_json)
        G = largest_weak_component(graph_from_interactions(nodes, trophic_interactions))
        n, e = G.number_of_nodes(), G.number_of_edges()
        if n < MIN_NODES or n > MAX_NODES or e < MIN_EDGES:
            continue
        metrics = compute_network_metrics(G)
        if metrics is None:
            continue
        robust = compute_robustness_metrics(G)
        row = {
            "network_id": net_id,
            "network_name": net_name,
            "dataset_id": net.get("dataset_id"),
            "date": net.get("date"),
            "description": (net.get("description") or "")[:250],
            **metrics,
            **{k: v for k, v in robust.items() if not k.startswith("curve_")}
        }
        rows.append(row)
        curves.append({
            "network_id": net_id,
            "network_name": net_name,
            "curve_random": robust["curve_random"],
            "curve_hub": robust["curve_hub"],
            "curve_basal": robust["curve_basal"]
        })
        processed += 1
        if processed % 10 == 0:
            print(f"  OK networks: {processed}")
            pd.DataFrame(rows).to_csv(f"{OUTDIR}/PARTIAL_M1_network_metrics.csv", index=False)
    except Exception as e:
        failures.append({"network_id": net_id, "network_name": net_name, "error": str(e)[:300]})
        continue

if len(rows) < 10:
    raise RuntimeError(f"Only {len(rows)} empirical trophic networks processed. Check Mangal API availability or relax filters.")

m1 = pd.DataFrame(rows)
curves_df = pd.DataFrame(curves)

# ============================================================
# NORMALIZE H/S/L AND DEFINE PHI_HSL
# ============================================================

H_COLS = [c for c in m1.columns if c.startswith("H_")]
S_COLS = [c for c in m1.columns if c.startswith("S_")]
L_COLS = [c for c in m1.columns if c.startswith("L_")]

for col in H_COLS + S_COLS + L_COLS:
    m1[col + "_norm"] = normalize01(m1[col].values)

m1["H"] = m1[[c + "_norm" for c in H_COLS]].mean(axis=1)
m1["S"] = m1[[c + "_norm" for c in S_COLS]].mean(axis=1)
m1["L"] = m1[[c + "_norm" for c in L_COLS]].mean(axis=1)

m1["Phi_HSL_epsilon"] = (m1["H"] + EPSILON) * (m1["S"] + EPSILON) * (m1["L"] + EPSILON)
m1["Triadic_balance"] = (1.0 - m1[["H", "S", "L"]].std(axis=1)).clip(lower=0)
m1["Functional_unity_HSL"] = m1["Phi_HSL_epsilon"] * m1["Triadic_balance"]
m1["Dominance_index"] = m1[["H", "S", "L"]].max(axis=1) - m1[["H", "S", "L"]].min(axis=1)
m1["Phi_resilience_norm"] = normalize01(m1["Phi_resilience"].values)
m1["Fragility_norm"] = normalize01(m1["Pathological_fragility_index"].values)

frag_q = m1["Pathological_fragility_index"].quantile(0.70)
dom_q = m1["Dominance_index"].quantile(0.70)
bal_q = m1["Triadic_balance"].quantile(0.30)
m1["macro_pathology_flag"] = ((m1["Pathological_fragility_index"] >= frag_q) & ((m1["Dominance_index"] >= dom_q) | (m1["Triadic_balance"] <= bal_q))).astype(int)
rob_q = m1["Phi_resilience"].quantile(0.70)
frag_low_q = m1["Phi_resilience"].quantile(0.30)
m1["robust_high_flag"] = (m1["Phi_resilience"] >= rob_q).astype(int)
m1["fragile_low_flag"] = (m1["Phi_resilience"] <= frag_low_q).astype(int)

# ============================================================
# REGRESSION TESTS
# ============================================================

def regression_test(df, X_cols, y_col, label):
    d = df[X_cols + [y_col]].dropna().copy()
    if len(d) < 10:
        return {"test": label, "n": len(d), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    X = d[X_cols].values.astype(float)
    y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X, y)
    pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {"test": label, "n": int(len(d)), "r2": float(r2_score(y, pred)), "mae": float(mean_absolute_error(y, pred)), "spearman_true_pred": r, "p_value": p}

m1_summary = pd.DataFrame([
    regression_test(m1, ["H"], "S", "M1_H_to_S"),
    regression_test(m1, ["H"], "L", "M1_H_to_L"),
    regression_test(m1, ["S"], "L", "M1_S_to_L"),
    regression_test(m1, ["H", "S"], "L", "M1_H_plus_S_to_L"),
    regression_test(m1, ["H", "S", "L"], "Phi_resilience_norm", "M1_HSL_to_Phi_resilience"),
    regression_test(m1, ["H", "S", "L"], "Functional_unity_HSL", "M1_HSL_to_Functional_Unity_HSL"),
    regression_test(m1, ["H", "S", "L"], "Fragility_norm", "M1_HSL_to_Pathological_Fragility"),
    regression_test(m1, ["Phi_HSL_epsilon", "Triadic_balance", "Dominance_index"], "Phi_resilience_norm", "M1_PhiBalanceDominance_to_Resilience"),
])

def get_mae(summary, test):
    x = summary[summary["test"] == test]
    return None if len(x) == 0 else x.iloc[0]["mae"]
H_L = get_mae(m1_summary, "M1_H_to_L")
S_L = get_mae(m1_summary, "M1_S_to_L")
HS_L = get_mae(m1_summary, "M1_H_plus_S_to_L")
emergence_contrast = pd.DataFrame([{
    "level": "macro_eco_foodweb",
    "H_to_L_mae": H_L,
    "S_to_L_mae": S_L,
    "H_plus_S_to_L_mae": HS_L,
    "HS_improves_over_H": None if H_L is None or HS_L is None else H_L - HS_L,
    "HS_improves_over_S": None if S_L is None or HS_L is None else S_L - HS_L,
    "PETU_prediction_supported": bool(HS_L is not None and H_L is not None and S_L is not None and HS_L < H_L and HS_L < S_L)
}])

# ============================================================
# ROBUST VS FRAGILE CONTRASTS
# ============================================================

robust = m1[m1["robust_high_flag"] == 1]
fragile = m1[m1["fragile_low_flag"] == 1]
contrast_rows = []
for metric in ["H", "S", "L", "Phi_HSL_epsilon", "Triadic_balance", "Functional_unity_HSL", "Dominance_index", "Phi_resilience", "Pathological_fragility_index", "connectance_raw", "n_species", "n_interactions"]:
    stat, p = safe_mannwhitney(robust[metric].values, fragile[metric].values)
    contrast_rows.append({
        "metric": metric,
        "robust_mean": float(robust[metric].mean()) if len(robust) else None,
        "fragile_mean": float(fragile[metric].mean()) if len(fragile) else None,
        "delta_robust_minus_fragile": float(robust[metric].mean() - fragile[metric].mean()) if len(robust) and len(fragile) else None,
        "pct_delta": float(100 * (robust[metric].mean() - fragile[metric].mean()) / (abs(fragile[metric].mean()) + 1e-12)) if len(robust) and len(fragile) else None,
        "mannwhitney_stat": stat,
        "p_value": p
    })
robust_fragile_contrast = pd.DataFrame(contrast_rows)

# ============================================================
# CLASSIFICATION
# ============================================================

class_rows = []
def auc_cv(df, feature_cols, target_col, label):
    d = df[feature_cols + [target_col]].dropna().copy()
    if len(d) < 20 or d[target_col].nunique() < 2:
        return None
    X = d[feature_cols].values.astype(float)
    y = d[target_col].values.astype(int)
    kf = KFold(n_splits=min(5, len(d)), shuffle=True, random_state=RANDOM_SEED)
    preds = np.zeros(len(d), dtype=float)
    for train, test in kf.split(X):
        try:
            clf = LogisticRegression(max_iter=1000, class_weight="balanced")
            clf.fit(X[train], y[train])
            preds[test] = clf.predict_proba(X[test])[:, 1]
        except Exception:
            preds[test] = 0.5
    try:
        auc = roc_auc_score(y, preds)
    except Exception:
        auc = np.nan
    return {"feature_set": label, "target": target_col, "n": int(len(d)), "auc": float(auc)}

for target in ["robust_high_flag", "macro_pathology_flag"]:
    for cols, label in [
        (["H"], "H"), (["S"], "S"), (["L"], "L"), (["H", "S"], "H+S"),
        (["H", "S", "L"], "H+S+L"), (["H", "S", "L", "Phi_HSL_epsilon"], "H+S+L+Phi"),
        (["H", "S", "L", "Phi_HSL_epsilon", "Triadic_balance", "Dominance_index"], "H+S+L+PhiBalanceDominance"),
    ]:
        r = auc_cv(m1, cols, target, label)
        if r: class_rows.append(r)
classification_summary = pd.DataFrame(class_rows)

gain_rows = []
for target, dd in classification_summary.groupby("target"):
    def auc_of(label):
        x = dd[dd["feature_set"] == label]
        return None if len(x) == 0 else float(x.iloc[0]["auc"])
    auc_H, auc_HS, auc_HSL, auc_full = auc_of("H"), auc_of("H+S"), auc_of("H+S+L"), auc_of("H+S+L+PhiBalanceDominance")
    gain_rows.append({
        "target": target, "auc_H": auc_H, "auc_HS": auc_HS, "auc_HSL": auc_HSL, "auc_full": auc_full,
        "gain_HSL_over_H": None if auc_H is None or auc_HSL is None else auc_HSL - auc_H,
        "gain_HSL_over_HS": None if auc_HS is None or auc_HSL is None else auc_HSL - auc_HS,
        "gain_full_over_HSL": None if auc_full is None or auc_HSL is None else auc_full - auc_HSL,
    })
classification_gain_summary = pd.DataFrame(gain_rows)

# ============================================================
# PHASES
# ============================================================

def classify_macro_phase(row):
    H, S, L = row["H"], row["S"], row["L"]
    resil, bal, dom, frag = row["Phi_resilience_norm"], row["Triadic_balance"], row["Dominance_index"], row["Fragility_norm"]
    if resil >= 0.70 and bal >= 0.70:
        return "resilient_phi_integrated"
    if frag >= 0.70 and dom >= 0.55:
        return "macro_pathological_desproportion"
    if H >= 0.55 and S < 0.40:
        return "H_support_low_form"
    if L >= 0.55 and resil < 0.45:
        return "L_hyperlinked_fragile"
    if S >= 0.55 and L < 0.40:
        return "S_structure_low_link"
    if bal < 0.55:
        return "triadic_imbalance"
    return "transitional"

m1["PETU_macro_phase"] = m1.apply(classify_macro_phase, axis=1)
phase_summary = (m1.groupby("PETU_macro_phase").agg(
    n_networks=("network_id", "count"), mean_H=("H", "mean"), mean_S=("S", "mean"), mean_L=("L", "mean"),
    mean_Phi_HSL=("Phi_HSL_epsilon", "mean"), mean_resilience=("Phi_resilience", "mean"),
    mean_balance=("Triadic_balance", "mean"), mean_dominance=("Dominance_index", "mean"),
    mean_fragility=("Pathological_fragility_index", "mean")
).reset_index().sort_values("n_networks", ascending=False))

# ============================================================
# SAVE / PRINT
# ============================================================

paths = {
    "network_metrics": f"{OUTDIR}/PETU_MACRO_ECO_M1_network_metrics.csv",
    "robustness_curves": f"{OUTDIR}/PETU_MACRO_ECO_M1_robustness_curves.csv",
    "genesis_summary": f"{OUTDIR}/PETU_MACRO_ECO_M1_genesis_summary.csv",
    "emergence_contrast": f"{OUTDIR}/PETU_MACRO_ECO_M1_emergence_contrast.csv",
    "robust_fragile_contrast": f"{OUTDIR}/PETU_MACRO_ECO_M1_robust_fragile_contrast.csv",
    "classification_summary": f"{OUTDIR}/PETU_MACRO_ECO_M1_classification_summary.csv",
    "classification_gain_summary": f"{OUTDIR}/PETU_MACRO_ECO_M1_classification_gain_summary.csv",
    "phase_summary": f"{OUTDIR}/PETU_MACRO_ECO_M1_phase_summary.csv",
    "failures": f"{OUTDIR}/PETU_MACRO_ECO_M1_failures.csv",
    "summary": f"{OUTDIR}/PETU_MACRO_ECO_M1_summary.json"
}

m1.to_csv(paths["network_metrics"], index=False)
curves_df.to_csv(paths["robustness_curves"], index=False)
m1_summary.to_csv(paths["genesis_summary"], index=False)
emergence_contrast.to_csv(paths["emergence_contrast"], index=False)
robust_fragile_contrast.to_csv(paths["robust_fragile_contrast"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)

summary = {
    "pipeline": "PETU-MACRO-ECO M1 Ecosystem Food-Web Perichoresis",
    "domain": "macro natural ecosystems / empirical food-web networks / Mangal API",
    "n_networks_processed": int(len(m1)),
    "max_networks_requested": MAX_NETWORKS,
    "min_nodes": MIN_NODES,
    "max_nodes": MAX_NODES,
    "min_edges": MIN_EDGES,
    "robustness_reps": ROBUSTNESS_REPS,
    "epsilon": EPSILON,
    "data_source": "Mangal ecological interactions database REST API v2",
    "hypothesis": "In empirical macro-ecosystem food webs, H ecoenergetic support, S ecological structure, and L interaction cohesion co-inhere as ecosystem resilience Phi; pathology is triadic disproportionality/fragility.",
    "next_step": "M2: temporal or perturbative ecosystem datasets, or M1b: expanded Mangal/Web-of-Life multi-network run."
}
with open(paths["summary"], "w") as f:
    json.dump(summary, f, indent=2)

print("\n============================================================")
print("PETU-MACRO-ECO M1 GENESIS SUMMARY")
print("============================================================")
print(m1_summary)

print("\n============================================================")
print("PETU-MACRO-ECO M1 EMERGENCE CONTRAST")
print("============================================================")
print(emergence_contrast)

print("\n============================================================")
print("PETU-MACRO-ECO M1 ROBUST VS FRAGILE CONTRAST")
print("============================================================")
print(robust_fragile_contrast)

print("\n============================================================")
print("PETU-MACRO-ECO M1 CLASSIFICATION SUMMARY")
print("============================================================")
print(classification_summary)

print("\n============================================================")
print("PETU-MACRO-ECO M1 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MACRO-ECO M1 PHASE SUMMARY")
print("============================================================")
print(phase_summary)

print("\n============================================================")
print("PETU-MACRO-ECO M1 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary, indent=2))

if len(failures) > 0:
    print("\n============================================================")
    print("FAILURES / SKIPPED ERRORS")
    print("============================================================")
    print(pd.DataFrame(failures).head(20))

# FIGURES
plt.figure(figsize=(8, 5)); plt.scatter(m1["S"], m1["L"], s=25, alpha=0.65); plt.xlabel("S ecological structure"); plt.ylabel("L interaction cohesion"); plt.title("PETU-MACRO-ECO M1: S-L relation"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_M1_S_L_relation.png", dpi=220); plt.show()
plt.figure(figsize=(8, 5)); plt.scatter(m1["Phi_HSL_epsilon"], m1["Phi_resilience"], s=25, alpha=0.65); plt.xlabel("Phi HSL epsilon"); plt.ylabel("Independent Phi resilience"); plt.title("PETU-MACRO-ECO M1: HSL Phi vs simulated resilience"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_M1_PhiHSL_resilience.png", dpi=220); plt.show()
plt.figure(figsize=(8, 5)); plt.scatter(m1["Triadic_balance"], m1["Phi_resilience"], s=25, alpha=0.65); plt.xlabel("Triadic balance"); plt.ylabel("Phi resilience"); plt.title("PETU-MACRO-ECO M1: balance vs resilience"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_M1_balance_resilience.png", dpi=220); plt.show()
plt.figure(figsize=(8, 5)); plt.scatter(m1["Dominance_index"], m1["Pathological_fragility_index"], s=25, alpha=0.65); plt.xlabel("Dominance index"); plt.ylabel("Pathological fragility"); plt.title("PETU-MACRO-ECO M1: disproportionality and fragility"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_M1_dominance_fragility.png", dpi=220); plt.show()
if len(phase_summary) > 0:
    plt.figure(figsize=(10, 5)); plt.bar(phase_summary["PETU_macro_phase"], phase_summary["n_networks"]); plt.xticks(rotation=60); plt.ylabel("n networks"); plt.title("PETU-MACRO-ECO M1: macro phases"); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_M1_phase_summary.png", dpi=220); plt.show()

zip_base = "/content/PETU_MACRO_ECO_M1_Ecosystem_FoodWeb_Perichoresis_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k, v in paths.items(): print(k + ":", v)
print("ZIP:", zip_path)
print("============================================================")

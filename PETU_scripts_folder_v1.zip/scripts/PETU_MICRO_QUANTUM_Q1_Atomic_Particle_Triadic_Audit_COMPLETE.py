# ============================================================
# PETU-MICRO-QUANTUM Q1
# Atomic / Subatomic Microphysics Triadic Audit
# ============================================================
# Objetivo:
#   Cuarto dominio micro-natural de PETU/LETU: microfísica atómica
#   y, cuando sea posible, partículas subatómicas reales.
#
# Base primaria:
#   1) Átomos naturales / tabla periódica / isotopía natural.
#   2) Rama opcional de partículas PDG mediante paquete `particle`.
#
# Traducción PETU:
#   H = soporte físico-material:
#       número atómico, masa nuclear, soporte nucleónico, radio/masa,
#       energía de enlace nuclear aproximada.
#
#   S = estructura formal cuántica:
#       configuración de capas, periodo/grupo, valencia, cercanía a capa cerrada,
#       organización electrónica.
#
#   L = vínculo/interacción:
#       electronegatividad, ionización, afinidad, radio/capacidad de enlace,
#       acoplamiento químico-cuántico.
#
#   Φ = coherencia atómica:
#       estabilidad isotópica, coherencia nuclear-electrónica, baja fragilidad,
#       integración H-S-L.
#
# Nota epistemológica:
#   En microfísica no se pretende reducir la mecánica cuántica real a un
#   modelo clásico simple. Se hace una auditoría de proxies físicos reales
#   y estables para observar si la organización atómica muestra firma H-S-L.
#
# Diseño:
#   - Usa mendeleev si está disponible para datos ricos.
#   - Si mendeleev falla, usa un fallback interno aproximado con constantes
#     y estructura periódica básica.
#   - Rama de partículas opcional con paquete particle. Si falla, se omite.
#
# Diseñado para Google Colab desde móvil.
# ============================================================

!pip -q install numpy pandas scipy scikit-learn matplotlib tqdm mendeleev periodictable particle

import os, re, json, math, random, warnings, shutil
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

OUTDIR = "/content/PETU_MICRO_QUANTUM_Q1_Atomic_Particle_Triadic_Audit"
os.makedirs(OUTDIR, exist_ok=True)

EPSILON = 0.05
Z_MAX_PRIMARY = 92   # H-U: prioriza átomos naturales o geoquímicamente relevantes.
INCLUDE_TRANSURANICS = True

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0:
        return x
    mn, mx = np.nanmin(x), np.nanmax(x)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a,b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        m = np.isfinite(a) & np.isfinite(b)
        if m.sum() < 3: return None, None
        r,p = spearmanr(a[m], b[m])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a,b):
    try:
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        a = a[np.isfinite(a)]; b = b[np.isfinite(b)]
        if len(a)<3 or len(b)<3: return None, None
        stat,p = mannwhitneyu(a,b,alternative='two-sided')
        return float(stat), float(p)
    except Exception:
        return None, None

def entropy_norm(vals):
    vals = np.asarray(vals, dtype=float)
    vals = vals[vals > 0]
    if vals.sum() <= 0 or len(vals) <= 1:
        return 0.0
    p = vals / vals.sum()
    ent = -np.sum(p*np.log(p+1e-12))
    return float(ent / np.log(len(vals)+1e-12))

def triadic_balance(h,s,l):
    return float(max(0.0, 1.0 - np.std([h,s,l])))

def dominance_index(h,s,l):
    return float(max(h,s,l) - min(h,s,l))

# ------------------------------------------------------------
# Periodic structure helpers
# ------------------------------------------------------------

NOBLE_GAS_Z = np.array([2,10,18,36,54,86,118])
MAGIC_NUCLEAR = np.array([2,8,20,28,50,82,126])

# Approximate periodic group/period/block fallback.
# mendeleev normally supplies better group_id/period/block.

def shell_closure_score_Z(Z):
    d = np.min(np.abs(NOBLE_GAS_Z - Z))
    return float(1.0 / (1.0 + d/8.0))

def nuclear_magic_score(N, Z):
    dN = np.min(np.abs(MAGIC_NUCLEAR - N)) if np.isfinite(N) else 20
    dZ = np.min(np.abs(MAGIC_NUCLEAR - Z))
    return float(0.5/(1.0+dN/10.0) + 0.5/(1.0+dZ/10.0))

def infer_period(Z):
    if Z <= 2: return 1
    if Z <= 10: return 2
    if Z <= 18: return 3
    if Z <= 36: return 4
    if Z <= 54: return 5
    if Z <= 86: return 6
    return 7

def infer_group_rough(Z):
    # Rough group based on periodic ranges; used only as fallback.
    period = infer_period(Z)
    starts = {1:1,2:3,3:11,4:19,5:37,6:55,7:87}
    local = Z - starts[period] + 1
    if period == 1:
        return 1 if Z == 1 else 18
    if period in [2,3]:
        if local <= 2: return local
        return local + 10
    if period in [4,5]:
        return min(18, local)
    if period in [6,7]:
        # lanthanide/actinide zone collapsed as group 3 formal block
        if 3 <= local <= 16: return 3
        return min(18, local-14 if local>16 else local)
    return np.nan

def valence_proxy_from_group(group):
    if not np.isfinite(group): return 0.5
    g = int(group)
    if g == 18: return 0.0
    if g <= 2: return g/8.0
    if 13 <= g <= 17: return (g-10)/8.0
    if 3 <= g <= 12: return min(1.0, g/12.0)
    return 0.5

def semi_empirical_binding_per_nucleon(Z, A):
    # Weizsäcker semi-empirical mass formula proxy in MeV/nucleon.
    if A <= 1 or Z < 1 or Z > A:
        return 0.0
    av, as_, ac, aa, ap = 15.8, 18.3, 0.714, 23.2, 12.0
    volume = av*A
    surface = as_*(A**(2/3))
    coulomb = ac*Z*(Z-1)/(A**(1/3))
    asym = aa*((A-2*Z)**2)/A
    if A % 2 == 1:
        pairing = 0.0
    elif Z % 2 == 0:
        pairing = ap/(A**0.5)
    else:
        pairing = -ap/(A**0.5)
    B = volume - surface - coulomb - asym + pairing
    return float(max(0.0, B/A))

# ------------------------------------------------------------
# Atomic data loading
# ------------------------------------------------------------

def load_atomic_data():
    failures = []
    rows = []
    source = "mendeleev"
    try:
        from mendeleev import element
        maxZ = 118 if INCLUDE_TRANSURANICS else Z_MAX_PRIMARY
        for Z in range(1, maxZ+1):
            try:
                e = element(Z)
                mass = float(e.atomic_weight) if e.atomic_weight is not None else float(Z*2)
                period = float(e.period) if e.period is not None else infer_period(Z)
                group = float(e.group_id) if e.group_id is not None else infer_group_rough(Z)
                en = float(e.en_pauling) if e.en_pauling is not None else np.nan
                covrad = float(e.covalent_radius_pyykko) if e.covalent_radius_pyykko is not None else np.nan
                atomic_radius = float(e.atomic_radius) if e.atomic_radius is not None else np.nan
                electron_affinity = float(e.electron_affinity) if e.electron_affinity is not None else np.nan
                try:
                    ion1 = float(e.ionenergies.get(1, np.nan))
                    ion2 = float(e.ionenergies.get(2, np.nan))
                except Exception:
                    ion1, ion2 = np.nan, np.nan
                block = str(e.block) if e.block is not None else "?"
                is_radioactive = bool(e.is_radioactive) if e.is_radioactive is not None else False

                # Stable isotope proxy from mendeleev isotope abundance.
                stable_iso_count = 0
                abundance_sum = 0.0
                try:
                    for iso in e.isotopes:
                        ab = iso.abundance
                        if ab is not None and ab > 0:
                            stable_iso_count += 1
                            abundance_sum += float(ab)
                except Exception:
                    pass

                A = int(round(mass)) if np.isfinite(mass) else int(round(2*Z))
                N = max(0, A - Z)
                rows.append({
                    "entity_type": "atom",
                    "Z": Z,
                    "symbol": e.symbol,
                    "name": e.name,
                    "mass": mass,
                    "A_proxy": A,
                    "N_proxy": N,
                    "period": period,
                    "group": group,
                    "block": block,
                    "en_pauling": en,
                    "covalent_radius": covrad,
                    "atomic_radius": atomic_radius,
                    "electron_affinity": electron_affinity,
                    "ionization_1": ion1,
                    "ionization_2": ion2,
                    "stable_iso_count": stable_iso_count,
                    "natural_abundance_sum": abundance_sum,
                    "is_radioactive": is_radioactive,
                    "source": source
                })
            except Exception as ex:
                failures.append({"Z":Z,"stage":"mendeleev_element","error":str(ex)})
    except Exception as ex:
        source = "internal_fallback"
        failures.append({"Z":None,"stage":"mendeleev_import","error":str(ex)})
        # Fallback minimal periodic table values for Z 1-92.
        symbols = "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U".split()
        names = symbols
        for Z, sym in enumerate(symbols, start=1):
            period = infer_period(Z); group = infer_group_rough(Z)
            mass = float(2*Z + (0.015*Z*Z)/(1+0.01*Z))
            A = int(round(mass)); N = A-Z
            rows.append({
                "entity_type":"atom", "Z":Z, "symbol":sym, "name":names[Z-1], "mass":mass,
                "A_proxy":A, "N_proxy":N, "period":period, "group":group, "block":"?",
                "en_pauling":np.nan, "covalent_radius":np.nan, "atomic_radius":np.nan,
                "electron_affinity":np.nan, "ionization_1":np.nan, "ionization_2":np.nan,
                "stable_iso_count": 0 if Z>83 or Z in [43,61] else 1,
                "natural_abundance_sum": 0.0,
                "is_radioactive": bool(Z>83 or Z in [43,61]),
                "source":source
            })
    return pd.DataFrame(rows), failures

def impute_atomic_trends(df):
    df = df.copy()
    # Trend proxies for missing values.
    # Electronegativity rough: higher toward top-right, lower in metals.
    g = df["group"].fillna(df["Z"].apply(infer_group_rough)).astype(float)
    p = df["period"].fillna(df["Z"].apply(infer_period)).astype(float)
    en_proxy = 0.7 + 3.3*((g-1)/17.0)*(1.0/(p**0.35))
    en_proxy = np.clip(en_proxy, 0.5, 4.2)
    df["en_used"] = df["en_pauling"].where(np.isfinite(df["en_pauling"]), en_proxy)

    radius_proxy = 35 + 22*p + 4*(18-g)
    df["radius_used"] = df["covalent_radius"].where(np.isfinite(df["covalent_radius"]), df["atomic_radius"])
    df["radius_used"] = df["radius_used"].where(np.isfinite(df["radius_used"]), radius_proxy)

    ion_proxy = 4.0 + 16.0*((g-1)/17.0)*(1.0/(p**0.45))
    df["ion1_used"] = df["ionization_1"].where(np.isfinite(df["ionization_1"]), ion_proxy)
    df["ea_used"] = df["electron_affinity"].where(np.isfinite(df["electron_affinity"]), 0.2*df["en_used"])
    return df

# ------------------------------------------------------------
# PETU atomic features
# ------------------------------------------------------------

def atomic_petu_features(row, variant="natural"):
    Z = float(row["Z"]); A = float(row["A_proxy"]); N = float(row["N_proxy"])
    period = float(row["period"]); group = float(row["group"])
    mass = float(row["mass"])
    en = float(row["en_used"]); radius = float(row["radius_used"])
    ion1 = float(row["ion1_used"]); ea = float(row["ea_used"])
    stable_iso = float(row.get("stable_iso_count",0))
    radioactive = bool(row.get("is_radioactive",False))

    bpN = semi_empirical_binding_per_nucleon(int(Z), int(max(A,Z)))
    n_p_balance = 1.0 - min(1.0, abs((N/(Z+1e-12)) - 1.25)/1.25)
    nuclear_magic = nuclear_magic_score(N, Z)
    shell_closure = shell_closure_score_Z(Z)
    valence = valence_proxy_from_group(group)
    noble_inertness = 1.0 if int(group)==18 else 0.0
    period_norm = period/7.0
    group_norm = group/18.0

    # Natural baseline raw values.
    H_raw = np.mean([
        np.log1p(Z)/np.log1p(118),
        np.log1p(mass)/np.log1p(294),
        n_p_balance,
        min(1.0, bpN/8.8),
        nuclear_magic
    ])

    S_raw = np.mean([
        shell_closure,
        1.0 - min(1.0, abs(valence-0.5)/0.5),
        1.0 - min(1.0, abs(group_norm-0.5)/0.5),
        1.0 - min(1.0, period_norm),
        nuclear_magic
    ])

    L_raw = np.mean([
        normalize_scalar(en, 0.5, 4.2),
        1.0 - normalize_scalar(radius, 25, 260),
        normalize_scalar(ion1, 3, 25),
        normalize_scalar(ea, -1, 4),
        valence if int(group)!=18 else 0.15
    ])

    # Independent coherence / stability proxy.
    isotope_stability = min(1.0, stable_iso/6.0)
    radio_penalty = 0.25 if radioactive else 1.0
    Phi_atomic_raw = np.mean([
        min(1.0, bpN/8.8),
        n_p_balance,
        nuclear_magic,
        shell_closure,
        isotope_stability,
        radio_penalty,
        1.0 - min(1.0, abs(valence - 0.25)/0.85)
    ])

    Fragility_raw = np.mean([
        1.0 - min(1.0, bpN/8.8),
        1.0 - n_p_balance,
        1.0 - nuclear_magic,
        1.0 - isotope_stability,
        1.0 if radioactive else 0.0,
        min(1.0, abs(valence - 0.5)/0.8)
    ])

    # Auxiliary perturbations: not primary, only contrasts.
    if variant == "ionized_stress":
        L_raw *= 0.82
        S_raw *= 0.95
        Phi_atomic_raw *= 0.88
        Fragility_raw = min(1.0, Fragility_raw + 0.10)
    elif variant == "neutron_imbalance_stress":
        H_raw *= 0.82
        Phi_atomic_raw *= 0.75
        Fragility_raw = min(1.0, Fragility_raw + 0.20)
    elif variant == "shell_disruption_stress":
        S_raw *= 0.70
        L_raw *= 0.92
        Phi_atomic_raw *= 0.78
        Fragility_raw = min(1.0, Fragility_raw + 0.18)
    elif variant == "interaction_suppression":
        L_raw *= 0.55
        Phi_atomic_raw *= 0.82
        Fragility_raw = min(1.0, Fragility_raw + 0.15)

    return {
        "entity_type":"atom",
        "variant":variant,
        "Z": int(Z),
        "symbol": row["symbol"],
        "name": row["name"],
        "period": period,
        "group": group,
        "mass": mass,
        "A_proxy": A,
        "N_proxy": N,
        "binding_per_nucleon_proxy": bpN,
        "n_p_balance": n_p_balance,
        "nuclear_magic_score": nuclear_magic,
        "shell_closure_score": shell_closure,
        "valence_proxy": valence,
        "en_used": en,
        "radius_used": radius,
        "ion1_used": ion1,
        "stable_iso_count": stable_iso,
        "is_radioactive": radioactive,
        "H_raw": H_raw,
        "S_raw": S_raw,
        "L_raw": L_raw,
        "Phi_atomic_raw": Phi_atomic_raw,
        "Fragility_raw": Fragility_raw,
        "source": row.get("source", "unknown")
    }

def normalize_scalar(x, mn, mx):
    try:
        x = float(x)
        if not np.isfinite(x): return 0.5
        return float(np.clip((x-mn)/(mx-mn), 0, 1))
    except Exception:
        return 0.5

# ------------------------------------------------------------
# Optional particle branch
# ------------------------------------------------------------

def load_particle_data_optional():
    rows = []
    failures = []
    try:
        from particle import Particle
        particles = []
        # Use a controlled list of common particles/hadrons/leptons/gauge bosons.
        names = [
            "e-", "e+", "mu-", "mu+", "tau-", "tau+",
            "nu(e)", "nu(mu)", "nu(tau)", "gamma", "g", "W+", "W-", "Z0",
            "p", "p~", "n", "n~", "pi+", "pi-", "pi0", "K+", "K-", "K0", "K(S)0", "K(L)0",
            "D+", "D-", "D0", "B+", "B-", "B0", "J/psi(1S)", "Upsilon(1S)", "Lambda0", "Sigma+", "Sigma-", "Xi-", "Omega-"
        ]
        for nm in names:
            try:
                p = Particle.from_evtgen_name(nm)
                particles.append(p)
            except Exception:
                try:
                    p = Particle.from_name(nm)
                    particles.append(p)
                except Exception as e:
                    failures.append({"particle":nm,"error":str(e)})
        seen = set()
        for p in particles:
            if p.pdgid in seen: continue
            seen.add(p.pdgid)
            mass = float(p.mass) if p.mass is not None else 0.0
            charge = float(p.charge) if p.charge is not None else 0.0
            spin = float(p.J) if p.J is not None else 0.0
            width = float(p.width) if p.width is not None else 0.0
            tau = float(p.lifetime) if p.lifetime is not None else 0.0
            # basic class proxies
            pdg_abs = abs(int(p.pdgid))
            is_lepton = 11 <= pdg_abs <= 18
            is_boson = pdg_abs in [21,22,23,24,25]
            is_baryon = pdg_abs > 1000 and pdg_abs < 10000
            is_meson = pdg_abs > 100 and pdg_abs < 1000
            class_complexity = 0.2 + 0.2*is_lepton + 0.25*is_boson + 0.55*is_meson + 0.75*is_baryon
            H_raw = np.mean([normalize_scalar(np.log1p(mass), 0, np.log1p(10000)), min(1,abs(charge)), normalize_scalar(pdg_abs, 0, 6000)])
            S_raw = np.mean([normalize_scalar(spin,0,3), class_complexity, 1.0 if charge==0 else 0.6])
            # Width high = strong decay coupling; stable width low but interaction still if charged.
            decay_link = normalize_scalar(np.log1p(width), 0, np.log1p(2500)) if width>0 else 0.15
            L_raw = np.mean([decay_link, min(1,abs(charge)), 0.8 if is_boson else 0.4 if is_lepton else 0.6])
            stability = 1.0 if width == 0 else 1.0/(1.0+np.log1p(width)/8.0)
            Phi_particle_raw = np.mean([stability, 1.0 - min(1.0, abs(charge)/3.0), 1.0 - abs(spin-round(spin)) if spin else 0.5, 1.0-class_complexity/1.2])
            Fragility_raw = 1.0 - Phi_particle_raw
            rows.append({
                "entity_type":"particle", "variant":"natural_particle", "particle_name":p.name,
                "pdgid":int(p.pdgid), "mass_MeV":mass, "charge":charge, "spin":spin,
                "width_MeV":width, "lifetime_s":tau, "is_lepton":is_lepton, "is_boson":is_boson,
                "is_meson":is_meson, "is_baryon":is_baryon,
                "H_raw":H_raw, "S_raw":S_raw, "L_raw":L_raw,
                "Phi_particle_raw":Phi_particle_raw, "Fragility_particle_raw":Fragility_raw,
                "source":"particle_PDG_package"
            })
    except Exception as ex:
        failures.append({"particle":"ALL","error":str(ex)})
    return pd.DataFrame(rows), failures

# ------------------------------------------------------------
# Models
# ------------------------------------------------------------

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {"test":label,"n":int(len(d)),"r2":None,"mae":None,"spearman_true_pred":None,"p_value":None}
    X = d[X_cols].values.astype(float); y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0)
    model.fit(X,y)
    pred = model.predict(X)
    r,p = safe_spearman(y,pred)
    return {"test":label,"n":int(len(d)),"r2":float(r2_score(y,pred)),"mae":float(mean_absolute_error(y,pred)),"spearman_true_pred":r,"p_value":p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2:
        return None
    X = d[feature_cols].values.astype(float); y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight='balanced')
        clf.fit(X,y)
        pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y,pred)
    except Exception:
        auc = np.nan
    return {"feature_set":label,"target":target,"n":int(len(d)),"auc":float(auc)}

# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

print("============================================================")
print("PETU-MICRO-QUANTUM Q1 ATOMIC / SUBATOMIC TRIADIC AUDIT")
print("============================================================")

atomic_base, atomic_failures = load_atomic_data()
atomic_base = impute_atomic_trends(atomic_base)
print(f"Atomic rows loaded: {len(atomic_base)} | sources: {sorted(atomic_base['source'].unique())}")

atomic_rows = []
variants = ["natural", "ionized_stress", "neutron_imbalance_stress", "shell_disruption_stress", "interaction_suppression"]
for _, row in atomic_base.iterrows():
    for v in variants:
        atomic_rows.append(atomic_petu_features(row, variant=v))

atomic = pd.DataFrame(atomic_rows)
for col in ["H_raw", "S_raw", "L_raw", "Phi_atomic_raw", "Fragility_raw"]:
    atomic[col.replace("_raw","")] = normalize01(atomic[col].values)

atomic["Phi_HSL_epsilon"] = (atomic["H"]+EPSILON)*(atomic["S"]+EPSILON)*(atomic["L"]+EPSILON)
atomic["Triadic_balance"] = [triadic_balance(h,s,l) for h,s,l in zip(atomic["H"],atomic["S"],atomic["L"])]
atomic["Functional_unity"] = atomic["Phi_HSL_epsilon"] * atomic["Triadic_balance"]
atomic["Dominance_index"] = [dominance_index(h,s,l) for h,s,l in zip(atomic["H"],atomic["S"],atomic["L"])]
atomic["is_natural"] = atomic["variant"].eq("natural")
atomic["is_perturbed"] = ~atomic["is_natural"]
atomic["primary_natural_range"] = atomic["Z"] <= Z_MAX_PRIMARY
atomic["coherence_high_flag"] = atomic["Phi_atomic"] >= atomic["Phi_atomic"].median()
atomic["fragility_high_flag"] = atomic["Fragility" ] >= atomic["Fragility"].median()
atomic["triadic_disproportion_flag"] = (atomic["Triadic_balance"] <= atomic["Triadic_balance"].quantile(0.25)) | (atomic["Dominance_index"] >= atomic["Dominance_index"].quantile(0.75))
atomic["stable_natural_flag"] = (atomic["stable_iso_count"] > 0) & (~atomic["is_radioactive"])

natural = atomic[(atomic["is_natural"]) & (atomic["primary_natural_range"])].copy()
all_atomic = atomic[atomic["primary_natural_range"]].copy()

# Optional particle branch
particle_df, particle_failures = load_particle_data_optional()
if len(particle_df) > 0:
    for col in ["H_raw","S_raw","L_raw","Phi_particle_raw","Fragility_particle_raw"]:
        particle_df[col.replace("_raw","").replace("_particle","")] = normalize01(particle_df[col].values)
    particle_df["Phi_HSL_epsilon"] = (particle_df["H"]+EPSILON)*(particle_df["S"]+EPSILON)*(particle_df["L"]+EPSILON)
    particle_df["Triadic_balance"] = [triadic_balance(h,s,l) for h,s,l in zip(particle_df["H"],particle_df["S"],particle_df["L"])]
    particle_df["Functional_unity"] = particle_df["Phi_HSL_epsilon"] * particle_df["Triadic_balance"]
    particle_df["Dominance_index"] = [dominance_index(h,s,l) for h,s,l in zip(particle_df["H"],particle_df["S"],particle_df["L"])]

# Summaries
atomic_data_summary = pd.DataFrame([{
    "n_atomic_rows_total": int(len(atomic)),
    "n_natural_primary_atoms": int(len(natural)),
    "n_perturbed_primary_rows": int(all_atomic["is_perturbed"].sum()),
    "Z_max_primary": Z_MAX_PRIMARY,
    "include_transuranics_loaded": INCLUDE_TRANSURANICS,
    "sources": ",".join(sorted(atomic["source"].unique())),
    "variants": ",".join(sorted(atomic["variant"].unique())),
    "particle_rows_optional": int(len(particle_df)),
    "epsilon": EPSILON
}])

atomic_genesis_summary = pd.DataFrame([
    regression(natural, ["H"], "S", "Q1_ATOM_NAT_H_to_S"),
    regression(natural, ["H"], "L", "Q1_ATOM_NAT_H_to_L"),
    regression(natural, ["S"], "L", "Q1_ATOM_NAT_S_to_L"),
    regression(natural, ["H","S"], "L", "Q1_ATOM_NAT_H_plus_S_to_L"),
    regression(natural, ["H","S","L"], "Phi_atomic", "Q1_ATOM_NAT_HSL_to_Phi_atomic"),
    regression(natural, ["H","S","L"], "Functional_unity", "Q1_ATOM_NAT_HSL_to_Functional_Unity"),
    regression(natural, ["H","S","L"], "Fragility", "Q1_ATOM_NAT_HSL_to_Atomic_Fragility"),
    regression(natural, ["H","S","L","Triadic_balance","Dominance_index"], "Fragility", "Q1_ATOM_NAT_Full_to_Atomic_Fragility"),
])

atomic_perturbative_summary = pd.DataFrame([
    regression(all_atomic, ["H"], "S", "Q1_ATOM_ALL_H_to_S"),
    regression(all_atomic, ["H"], "L", "Q1_ATOM_ALL_H_to_L"),
    regression(all_atomic, ["S"], "L", "Q1_ATOM_ALL_S_to_L"),
    regression(all_atomic, ["H","S"], "L", "Q1_ATOM_ALL_H_plus_S_to_L"),
    regression(all_atomic, ["H","S","L"], "Phi_atomic", "Q1_ATOM_ALL_HSL_to_Phi_atomic"),
    regression(all_atomic, ["H","S","L"], "Functional_unity", "Q1_ATOM_ALL_HSL_to_Functional_Unity"),
    regression(all_atomic, ["H","S","L"], "Fragility", "Q1_ATOM_ALL_HSL_to_Atomic_Fragility"),
    regression(all_atomic, ["H","S","L","Triadic_balance","Dominance_index"], "Fragility", "Q1_ATOM_ALL_Full_to_Atomic_Fragility"),
])

def get_mae(summary, test):
    x = summary[summary["test"]==test]
    return None if len(x)==0 else x.iloc[0]["mae"]
H_L = get_mae(atomic_genesis_summary,"Q1_ATOM_NAT_H_to_L")
S_L = get_mae(atomic_genesis_summary,"Q1_ATOM_NAT_S_to_L")
HS_L = get_mae(atomic_genesis_summary,"Q1_ATOM_NAT_H_plus_S_to_L")
atomic_emergence_contrast = pd.DataFrame([{
    "level":"micro_atomic_quantum_natural",
    "H_to_L_mae":H_L,
    "S_to_L_mae":S_L,
    "H_plus_S_to_L_mae":HS_L,
    "HS_improves_over_H": H_L-HS_L if H_L is not None and HS_L is not None else None,
    "HS_improves_over_S": S_L-HS_L if S_L is not None and HS_L is not None else None,
    "PETU_prediction_supported": (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None
}])

variant_summary = (all_atomic.groupby("variant")
    .agg(n=("symbol","count"), mean_H=("H","mean"), mean_S=("S","mean"), mean_L=("L","mean"),
         mean_Phi=("Phi_atomic","mean"), mean_Phi_HSL=("Phi_HSL_epsilon","mean"), mean_unity=("Functional_unity","mean"),
         mean_balance=("Triadic_balance","mean"), mean_dominance=("Dominance_index","mean"), mean_fragility=("Fragility","mean"),
         mean_binding=("binding_per_nucleon_proxy","mean"), mean_shell_closure=("shell_closure_score","mean"))
    .reset_index().sort_values("mean_Phi", ascending=False))

# Contrasts
contrast_defs = [
    ("natural_vs_perturbed", "is_natural", True, False),
    ("coherent_vs_low", "coherence_high_flag", True, False),
    ("fragility_high_vs_low", "fragility_high_flag", True, False),
    ("disproportion_vs_proportion", "triadic_disproportion_flag", True, False),
    ("stable_vs_unstable", "stable_natural_flag", True, False),
]
contrast_metrics = ["H","S","L","Phi_atomic","Phi_HSL_epsilon","Functional_unity","Triadic_balance","Dominance_index","Fragility","binding_per_nucleon_proxy","n_p_balance","nuclear_magic_score","shell_closure_score","valence_proxy","en_used","ion1_used"]
contrast_rows=[]
for cname, flag, aval, bval in contrast_defs:
    A=all_atomic[all_atomic[flag]==aval]; B=all_atomic[all_atomic[flag]==bval]
    for col in contrast_metrics:
        stat,p=safe_mw(A[col],B[col])
        contrast_rows.append({"contrast":cname,"metric":col,"groupA_mean":float(A[col].mean()) if len(A) else np.nan,"groupB_mean":float(B[col].mean()) if len(B) else np.nan,"delta_A_minus_B":float(A[col].mean()-B[col].mean()) if len(A) and len(B) else np.nan,"pct_delta":float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,"mannwhitney_stat":stat,"p_value":p})
contrast_summary = pd.DataFrame(contrast_rows)

# Classification
class_rows=[]
targets=["is_natural","coherence_high_flag","fragility_high_flag","triadic_disproportion_flag","stable_natural_flag"]
feature_sets=[(["H"],"H"),(["S"],"S"),(["L"],"L"),(["H","S"],"H+S"),(["H","S","L"],"H+S+L"),(["H","S","L","Phi_HSL_epsilon"],"H+S+L+Phi"),(["H","S","L","Phi_HSL_epsilon","Triadic_balance","Dominance_index"],"H+S+L+PhiBalanceDominance")]
for target in targets:
    for cols,label in feature_sets:
        r=auc_model(all_atomic,cols,target,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)

gain_rows=[]
for target,d in classification_summary.groupby("target"):
    def auc(fs):
        x=d[d["feature_set"]==fs]
        return None if len(x)==0 else float(x.iloc[0]["auc"])
    aH,aHS,aHSL,aFull=auc("H"),auc("H+S"),auc("H+S+L"),auc("H+S+L+PhiBalanceDominance")
    gain_rows.append({"target":target,"auc_H":aH,"auc_HS":aHS,"auc_HSL":aHSL,"auc_full":aFull,"gain_HSL_over_H":None if aH is None or aHSL is None else aHSL-aH,"gain_HSL_over_HS":None if aHS is None or aHSL is None else aHSL-aHS,"gain_full_over_HSL":None if aFull is None or aHSL is None else aFull-aHSL})
classification_gain_summary=pd.DataFrame(gain_rows)

# Phase classification

def classify_phase(r):
    if r["is_natural"] and r["Phi_atomic"] >= all_atomic["Phi_atomic"].median() and r["Triadic_balance"] >= all_atomic["Triadic_balance"].median():
        return "natural_atomic_phi_integrated"
    if r["variant"] == "neutron_imbalance_stress": return "nuclear_H_imbalance_pathology"
    if r["variant"] == "shell_disruption_stress": return "shell_S_disruption_pathology"
    if r["variant"] == "interaction_suppression": return "interaction_L_suppression_pathology"
    if r["variant"] == "ionized_stress": return "ionized_transition"
    if r["triadic_disproportion_flag"]: return "triadic_disproportion"
    if r["is_natural"] and r["stable_natural_flag"]: return "natural_stable_transitional"
    if r["is_natural"]: return "natural_fragile_or_radioactive"
    return "perturbed_transitional"
all_atomic["PETU_Q1_phase"] = all_atomic.apply(classify_phase, axis=1)
phase_summary=(all_atomic.groupby("PETU_Q1_phase")
    .agg(n=("symbol","count"), mean_Z=("Z","mean"), mean_H=("H","mean"), mean_S=("S","mean"), mean_L=("L","mean"), mean_Phi=("Phi_atomic","mean"), mean_Phi_HSL=("Phi_HSL_epsilon","mean"), mean_unity=("Functional_unity","mean"), mean_balance=("Triadic_balance","mean"), mean_dominance=("Dominance_index","mean"), mean_fragility=("Fragility","mean"), mean_binding=("binding_per_nucleon_proxy","mean"), mean_shell=("shell_closure_score","mean"))
    .reset_index().sort_values("n", ascending=False))

# Particle summaries optional
particle_summary = pd.DataFrame()
particle_genesis_summary = pd.DataFrame()
if len(particle_df) >= 20:
    particle_summary = pd.DataFrame([{
        "n_particles": int(len(particle_df)),
        "source":"particle_PDG_package",
        "note":"Optional subatomic branch; interpret separately from atomic branch."
    }])
    particle_genesis_summary = pd.DataFrame([
        regression(particle_df, ["H"], "S", "Q1_PARTICLE_H_to_S"),
        regression(particle_df, ["H"], "L", "Q1_PARTICLE_H_to_L"),
        regression(particle_df, ["S"], "L", "Q1_PARTICLE_S_to_L"),
        regression(particle_df, ["H","S"], "L", "Q1_PARTICLE_H_plus_S_to_L"),
        regression(particle_df, ["H","S","L"], "Phi", "Q1_PARTICLE_HSL_to_Phi_particle"),
        regression(particle_df, ["H","S","L"], "Functional_unity", "Q1_PARTICLE_HSL_to_Functional_Unity"),
    ])

# Save files
paths={
    "atomic_features":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_atomic_features.csv",
    "atomic_base":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_atomic_base.csv",
    "data_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_data_summary.csv",
    "atomic_genesis_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_atomic_genesis_summary.csv",
    "atomic_perturbative_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_atomic_perturbative_summary.csv",
    "atomic_emergence_contrast":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_atomic_emergence_contrast.csv",
    "variant_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_variant_summary.csv",
    "contrast_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_contrast_summary.csv",
    "classification_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_classification_summary.csv",
    "classification_gain_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_classification_gain_summary.csv",
    "phase_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_phase_summary.csv",
    "particle_features":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_particle_features.csv",
    "particle_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_particle_summary.csv",
    "particle_genesis_summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_particle_genesis_summary.csv",
    "failures":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_failures.csv",
    "summary":f"{OUTDIR}/PETU_MICRO_QUANTUM_Q1_summary.json"
}

atomic.to_csv(paths["atomic_features"], index=False)
atomic_base.to_csv(paths["atomic_base"], index=False)
atomic_data_summary.to_csv(paths["data_summary"], index=False)
atomic_genesis_summary.to_csv(paths["atomic_genesis_summary"], index=False)
atomic_perturbative_summary.to_csv(paths["atomic_perturbative_summary"], index=False)
atomic_emergence_contrast.to_csv(paths["atomic_emergence_contrast"], index=False)
variant_summary.to_csv(paths["variant_summary"], index=False)
contrast_summary.to_csv(paths["contrast_summary"], index=False)
classification_summary.to_csv(paths["classification_summary"], index=False)
classification_gain_summary.to_csv(paths["classification_gain_summary"], index=False)
phase_summary.to_csv(paths["phase_summary"], index=False)
particle_df.to_csv(paths["particle_features"], index=False)
particle_summary.to_csv(paths["particle_summary"], index=False)
particle_genesis_summary.to_csv(paths["particle_genesis_summary"], index=False)
pd.DataFrame(atomic_failures + particle_failures).to_csv(paths["failures"], index=False)

summary={
    "pipeline":"PETU-MICRO-QUANTUM Q1 Atomic/Subatomic Triadic Audit",
    "domain":"microphysics / atoms / optional subatomic particles",
    "primary_branch":"atomic periodic microphysics",
    "n_primary_natural_atoms": int(len(natural)),
    "n_atomic_rows_primary_with_perturbations": int(len(all_atomic)),
    "optional_particle_rows": int(len(particle_df)),
    "epsilon": EPSILON,
    "hypothesis":"Atomic coherence arises from triadic proportion/co-inherence of H nuclear-material support, S quantum shell structure, and L interaction/linkage properties.",
    "epistemic_note":"This is a proxy-based physical audit, not a replacement for quantum mechanics or QFT. Perturbations are auxiliary contrasts; natural atoms are the primary basis.",
    "next_step":"MESO cardiorespiratory natural dynamics, unless a deeper dedicated PDG/QFT particle audit Q2 is desired."
}
with open(paths["summary"],"w") as f: json.dump(summary,f,indent=2)

# Print output blocks
print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 DATA SUMMARY")
print("============================================================")
print(atomic_data_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 ATOMIC NATURAL GENESIS SUMMARY")
print("============================================================")
print(atomic_genesis_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 ATOMIC EMERGENCE CONTRAST")
print("============================================================")
print(atomic_emergence_contrast)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 ATOMIC PERTURBATIVE SUMMARY")
print("============================================================")
print(atomic_perturbative_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 VARIANT SUMMARY")
print("============================================================")
print(variant_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 CONTRAST SUMMARY")
print("============================================================")
print(contrast_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 CLASSIFICATION GAIN SUMMARY")
print("============================================================")
print(classification_gain_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 PHASE SUMMARY")
print("============================================================")
print(phase_summary)

if len(particle_summary)>0:
    print("\n============================================================")
    print("PETU-MICRO-QUANTUM Q1 OPTIONAL PARTICLE SUMMARY")
    print("============================================================")
    print(particle_summary)
    print("\n============================================================")
    print("PETU-MICRO-QUANTUM Q1 OPTIONAL PARTICLE GENESIS SUMMARY")
    print("============================================================")
    print(particle_genesis_summary)

print("\n============================================================")
print("PETU-MICRO-QUANTUM Q1 FINAL SUMMARY")
print("============================================================")
print(json.dumps(summary,indent=2))

fails = pd.DataFrame(atomic_failures + particle_failures)
if len(fails)>0:
    print("\n============================================================")
    print("FAILURES / SKIPPED")
    print("============================================================")
    print(fails)

# Figures
plt.figure(figsize=(8,5))
plt.scatter(natural["H"]+natural["S"], natural["L"], s=25, alpha=0.7)
plt.xlabel("H + S")
plt.ylabel("L")
plt.title("PETU-QUANTUM Q1 natural atoms: H+S -> L")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_Q1_atoms_HS_to_L.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(all_atomic["Phi_HSL_epsilon"], all_atomic["Phi_atomic"], s=18, alpha=0.5)
plt.xlabel("Phi_HSL_epsilon")
plt.ylabel("Phi_atomic")
plt.title("PETU-QUANTUM Q1: HSL unity vs atomic coherence")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_Q1_atoms_PhiHSL_PhiAtomic.png", dpi=220)
plt.show()

plt.figure(figsize=(8,5))
plt.scatter(all_atomic["Dominance_index"], all_atomic["Fragility"], s=18, alpha=0.5)
plt.xlabel("Dominance index")
plt.ylabel("Atomic fragility")
plt.title("PETU-QUANTUM Q1: dominance and atomic fragility")
plt.grid(True)
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_Q1_atoms_Dominance_Fragility.png", dpi=220)
plt.show()

plt.figure(figsize=(10,5))
plt.bar(variant_summary["variant"], variant_summary["mean_Phi"])
plt.xticks(rotation=45)
plt.ylabel("Mean atomic Phi")
plt.title("PETU-QUANTUM Q1: natural vs microphysical stress variants")
plt.tight_layout()
plt.savefig(f"{OUTDIR}/figure_Q1_atoms_variant_phi.png", dpi=220)
plt.show()

zip_base = "/content/PETU_MICRO_QUANTUM_Q1_Atomic_Particle_Triadic_Audit_results"
zip_path = zip_base + ".zip"
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base, "zip", OUTDIR)

print("\n============================================================")
print("PIPELINE COMPLETE")
for k,v in paths.items(): print(k+":",v)
print("ZIP:",zip_path)
print("============================================================")

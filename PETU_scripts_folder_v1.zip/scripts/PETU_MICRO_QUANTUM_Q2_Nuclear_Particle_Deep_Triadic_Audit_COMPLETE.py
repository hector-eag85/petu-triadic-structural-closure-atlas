# ============================================================
# PETU-MICRO-QUANTUM Q2
# Nuclear / Isotopic / Particle Deep Triadic Audit
#
# Objetivo:
#   Robustecer Q1 dentro de un único dominio ampliado de microfísica.
#   Q1 = átomo/periodicidad; Q2 = núcleo/isótopos/partículas.
#
# Base primaria natural:
#   Rama nuclear-isotópica: datos atómicos/isotópicos disponibles en mendeleev.
#   Rama subatómica: paquete particle/PDG si está disponible.
#
# Traducción PETU:
#   H = soporte físico-material:
#       Z, A, N, masa nuclear/isotópica, energía de enlace aproximada,
#       soporte bariónico/nucleónico o masa/carga de partícula.
#
#   S = estructura formal cuántica:
#       números mágicos, paridad par-impar, shell nuclear, spin, familia,
#       estructura de clasificación cuántica.
#
#   L = vínculo/interacción:
#       estabilidad/decaimiento, semivida, anchura, carga acoplante,
#       modo de interacción/decay, posibilidad de enlace/acoplamiento.
#
#   Φ = coherencia microfísica:
#       estabilidad nuclear/particular, baja fragilidad, proporción H-S-L.
#
# Nota epistemológica:
#   Q2 es una auditoría por proxies físico-reales. No sustituye QFT ni física
#   nuclear; mide si la organización microfísica muestra firma H-S-L.
# ============================================================

!pip -q install numpy pandas scipy scikit-learn matplotlib tqdm mendeleev particle

import os, re, json, math, random, warnings, shutil
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

OUTDIR = '/content/PETU_MICRO_QUANTUM_Q2_Nuclear_Particle_Deep_Triadic_Audit'
os.makedirs(OUTDIR, exist_ok=True)
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)
EPSILON = 0.05
MAGIC_NUMBERS = np.array([2, 8, 20, 28, 50, 82, 126, 184], dtype=float)

# ============================================================
# UTILITIES
# ============================================================

def normalize01(x):
    x = np.asarray(x, dtype=float)
    if len(x) == 0: return x
    finite = np.isfinite(x)
    if finite.sum() == 0: return np.zeros_like(x)
    mn, mx = np.nanmin(x[finite]), np.nanmax(x[finite])
    if mx - mn < 1e-12: return np.zeros_like(x)
    y = (x - mn)/(mx-mn)
    y[~np.isfinite(y)] = 0
    return y

def safe_spearman(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        m=np.isfinite(a)&np.isfinite(b)
        if m.sum()<3: return None,None
        r,p=spearmanr(a[m],b[m])
        return float(r), float(p)
    except Exception:
        return None,None

def safe_mw(a,b):
    try:
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        a=a[np.isfinite(a)]; b=b[np.isfinite(b)]
        if len(a)<3 or len(b)<3: return None,None
        s,p=mannwhitneyu(a,b,alternative='two-sided')
        return float(s), float(p)
    except Exception:
        return None,None

def triadic_balance(h,s,l):
    return float(max(0.0, 1.0 - np.std([h,s,l])))

def dominance_index(h,s,l):
    return float(max(h,s,l)-min(h,s,l))

def magic_score(x):
    if not np.isfinite(x): return 0.0
    d = np.min(np.abs(MAGIC_NUMBERS - x))
    return float(np.exp(-d/8.0))

def even_odd_score(z,n):
    if int(z)%2==0 and int(n)%2==0: return 1.0
    if int(z)%2==0 or int(n)%2==0: return 0.55
    return 0.15

def semi_empirical_binding_energy(Z,A):
    # Bethe-Weizsäcker approximate binding energy in MeV.
    if A <= 1 or Z <= 0 or Z > A: return np.nan
    av, ass, ac, aa, ap = 15.8, 18.3, 0.714, 23.2, 12.0
    N = A - Z
    volume = av*A
    surface = ass*(A**(2/3))
    coulomb = ac*Z*(Z-1)/(A**(1/3))
    asym = aa*((A-2*Z)**2)/A
    if A%2==1: pairing = 0.0
    elif Z%2==0 and N%2==0: pairing = ap/(A**0.5)
    else: pairing = -ap/(A**0.5)
    return float(volume - surface - coulomb - asym + pairing)

def stable_band_score(Z,A):
    # valley-of-stability proxy using empirical beta-stability estimate.
    if A <= 1: return 0.0
    Z_stable = A/(2 + 0.015*(A**(2/3)))
    d = abs(Z - Z_stable)
    return float(np.exp(-d/3.0))

def half_life_to_score(hl):
    # mendeleev may supply seconds or None. If none, assume unknown not stable.
    try:
        if hl is None or not np.isfinite(float(hl)) or float(hl) <= 0:
            return 0.0
        # log scale; > age-of-universe-ish saturates
        return float(np.clip(np.log10(float(hl)+1)/17.0, 0, 1))
    except Exception:
        return 0.0

def parse_stability(isotope):
    # mendeleev isotope fields vary; use is_stable if present and half_life fallback.
    stable = False
    hl = None
    abundance = 0.0
    try:
        stable = bool(getattr(isotope, 'is_stable', False))
    except Exception:
        stable = False
    for attr in ['half_life', 'halflife', 'half_life_sec']:
        try:
            val=getattr(isotope, attr)
            if val is not None:
                hl=float(val); break
        except Exception:
            pass
    for attr in ['abundance', 'abundance_crust', 'isotopic_abundance']:
        try:
            val=getattr(isotope, attr)
            if val is not None:
                abundance=float(val); break
        except Exception:
            pass
    return stable, hl, abundance

# ============================================================
# NUCLEAR / ISOTOPE BRANCH
# ============================================================

print('='*60)
print('PETU-MICRO-QUANTUM Q2 NUCLEAR / PARTICLE DEEP TRIADIC AUDIT')
print('='*60)

failures=[]
iso_rows=[]

try:
    from mendeleev import element
    print('Loading isotope data from mendeleev...')
    for Z in tqdm(range(1, 93), desc='Elements H-U'):
        try:
            el = element(Z)
            isotopes = getattr(el, 'isotopes', [])
            if not isotopes:
                failures.append({'branch':'isotope','Z':Z,'stage':'load','error':'no isotopes'})
                continue
            for iso in isotopes:
                try:
                    A = getattr(iso, 'mass_number', None)
                    if A is None: continue
                    A = int(A)
                    if A < Z: continue
                    N = A - Z
                    mass = None
                    for attr in ['mass','isotope_mass','atomic_mass']:
                        try:
                            val = getattr(iso, attr)
                            if val is not None:
                                mass = float(val); break
                        except Exception: pass
                    stable, hl, abundance = parse_stability(iso)
                    BE = semi_empirical_binding_energy(Z,A)
                    BEA = BE/A if np.isfinite(BE) and A>0 else np.nan
                    nz_ratio = N/(Z+1e-12)
                    n_magic = magic_score(N)
                    z_magic = magic_score(Z)
                    shell = max(n_magic, z_magic)
                    double_magic = n_magic*z_magic
                    evenodd = even_odd_score(Z,N)
                    stable_band = stable_band_score(Z,A)
                    hl_score = 1.0 if stable else half_life_to_score(hl)
                    abundance_score = float(np.clip(np.log10(abundance+1)/2.0,0,1)) if abundance and abundance>0 else 0.0
                    # H/S/L raw proxies.
                    H_raw = np.nanmean([
                        np.log1p(A)/np.log1p(238),
                        np.log1p(Z)/np.log1p(92),
                        np.log1p(N+1)/np.log1p(146),
                        np.clip(BEA/9.0,0,1) if np.isfinite(BEA) else 0,
                        np.exp(-abs(nz_ratio-1.35)/0.9)
                    ])
                    S_raw = np.nanmean([
                        shell,
                        double_magic,
                        evenodd,
                        stable_band,
                        np.exp(-abs(nz_ratio-1.35)/0.7)
                    ])
                    L_raw = np.nanmean([
                        hl_score,
                        abundance_score,
                        stable_band,
                        np.clip(BEA/9.0,0,1) if np.isfinite(BEA) else 0,
                        1.0 - np.clip(abs(nz_ratio-1.35)/2.0,0,1)
                    ])
                    Phi_nuclear_raw = np.nanmean([
                        1.0 if stable else 0.0,
                        hl_score,
                        abundance_score,
                        stable_band,
                        np.clip(BEA/9.0,0,1) if np.isfinite(BEA) else 0,
                        evenodd,
                        shell
                    ])
                    Fragility_raw = np.nanmean([
                        0.0 if stable else 1.0,
                        1.0 - hl_score,
                        1.0 - stable_band,
                        1.0 - (np.clip(BEA/9.0,0,1) if np.isfinite(BEA) else 0),
                        np.clip(abs(nz_ratio-1.35)/2.0,0,1),
                        1.0 - evenodd
                    ])
                    iso_rows.append({
                        'Z':Z,'symbol':el.symbol,'element':el.name,'A':A,'N':N,
                        'mass':mass,'stable':stable,'half_life':hl,'abundance':abundance,
                        'binding_energy_SEMF':BE,'binding_per_A':BEA,'N_Z_ratio':nz_ratio,
                        'n_magic_score':n_magic,'z_magic_score':z_magic,'shell_score':shell,
                        'double_magic_score':double_magic,'evenodd_score':evenodd,
                        'stable_band_score':stable_band,'half_life_score':hl_score,
                        'abundance_score':abundance_score,
                        'H_raw':H_raw,'S_raw':S_raw,'L_raw':L_raw,
                        'Phi_nuclear_raw':Phi_nuclear_raw,'Fragility_raw':Fragility_raw,
                        'variant':'natural_isotope'
                    })
                except Exception as e:
                    failures.append({'branch':'isotope','Z':Z,'stage':'parse_iso','error':str(e)})
        except Exception as e:
            failures.append({'branch':'isotope','Z':Z,'stage':'element','error':str(e)})
except Exception as e:
    failures.append({'branch':'isotope','stage':'import','error':str(e)})

isotopes = pd.DataFrame(iso_rows)
if len(isotopes) < 100:
    raise RuntimeError('Too few isotope rows loaded. mendeleev isotope data unavailable.')

# Perturbative variants: nuclear imbalance, shell disruption, decay destabilization.
pert_rows=[]
for _,r in isotopes.iterrows():
    base = r.to_dict()
    # Natural primary already included.
    for variant in ['neutron_imbalance_stress','shell_structure_disruption','decay_linkage_suppression','binding_support_stress']:
        x=base.copy(); x['variant']=variant
        if variant=='neutron_imbalance_stress':
            x['H_raw'] = max(0, x['H_raw']*0.72)
            x['Phi_nuclear_raw'] = max(0, x['Phi_nuclear_raw']*0.66)
            x['Fragility_raw'] = min(1, x['Fragility_raw']*1.32 + 0.08)
        elif variant=='shell_structure_disruption':
            x['S_raw'] = max(0, x['S_raw']*0.45)
            x['Phi_nuclear_raw'] = max(0, x['Phi_nuclear_raw']*0.72)
            x['Fragility_raw'] = min(1, x['Fragility_raw']*1.25 + 0.06)
        elif variant=='decay_linkage_suppression':
            x['L_raw'] = max(0, x['L_raw']*0.42)
            x['Phi_nuclear_raw'] = max(0, x['Phi_nuclear_raw']*0.70)
            x['Fragility_raw'] = min(1, x['Fragility_raw']*1.28 + 0.07)
        elif variant=='binding_support_stress':
            x['H_raw'] = max(0, x['H_raw']*0.82)
            x['S_raw'] = max(0, x['S_raw']*0.86)
            x['Phi_nuclear_raw'] = max(0, x['Phi_nuclear_raw']*0.78)
            x['Fragility_raw'] = min(1, x['Fragility_raw']*1.20 + 0.04)
        pert_rows.append(x)

nuclear_all = pd.concat([isotopes, pd.DataFrame(pert_rows)], ignore_index=True)
for col in ['H_raw','S_raw','L_raw','Phi_nuclear_raw','Fragility_raw']:
    nuclear_all[col.replace('_raw','')] = normalize01(nuclear_all[col].values)

nuclear_all['Phi_HSL_epsilon'] = (nuclear_all['H']+EPSILON)*(nuclear_all['S']+EPSILON)*(nuclear_all['L']+EPSILON)
nuclear_all['Triadic_balance'] = [triadic_balance(h,s,l) for h,s,l in zip(nuclear_all.H,nuclear_all.S,nuclear_all.L)]
nuclear_all['Functional_unity'] = nuclear_all['Phi_HSL_epsilon']*nuclear_all['Triadic_balance']
nuclear_all['Dominance_index'] = [dominance_index(h,s,l) for h,s,l in zip(nuclear_all.H,nuclear_all.S,nuclear_all.L)]
nuclear_all['is_natural'] = nuclear_all['variant'].eq('natural_isotope')
nuclear_all['stable_flag'] = nuclear_all['stable'].astype(bool)
nuclear_all['coherence_high_flag'] = nuclear_all['Phi_nuclear'] >= nuclear_all['Phi_nuclear'].median()
nuclear_all['fragility_high_flag'] = nuclear_all['Fragility'] >= nuclear_all['Fragility'].median()
nuclear_all['triadic_disproportion_flag'] = ((nuclear_all['Triadic_balance'] <= nuclear_all['Triadic_balance'].quantile(.25)) | (nuclear_all['Dominance_index'] >= nuclear_all['Dominance_index'].quantile(.75)))

nuclear_nat = nuclear_all[nuclear_all.is_natural].copy()

# ============================================================
# PARTICLE BRANCH
# ============================================================
particle_rows=[]
try:
    from particle import Particle
    plist = list(Particle.findall())
    # Focus on common/known particles; avoid huge nuclear pseudoentries by filtering pdgid abs.
    for p in plist:
        try:
            name = str(p.name)
            mass = float(p.mass) if p.mass is not None else np.nan
            charge = float(p.charge) if p.charge is not None else 0.0
            width = float(p.width) if p.width is not None else np.nan
            tau = float(p.ctau) if getattr(p,'ctau',None) is not None else np.nan
            spin = float(p.J) if getattr(p,'J',None) is not None else np.nan
            pdgid = int(p.pdgid) if p.pdgid is not None else 0
            if not np.isfinite(mass) or mass < 0: continue
            if abs(pdgid) > 10000000: continue
            # Keep a manageable but diverse subset: elementary and common hadrons/leptons/gauge bosons.
            if len(particle_rows) >= 220: break
            stable_like = (not np.isfinite(width) or width == 0) and (not np.isfinite(tau) or tau > 1e3)
            mass_score = np.clip(np.log1p(mass)/np.log1p(200000),0,1)
            charge_score = min(1.0, abs(charge)/3.0)
            spin_score = 0.4 if not np.isfinite(spin) else np.clip(spin/3.0,0,1)
            width_score = 1.0 if not np.isfinite(width) or width<=0 else 1.0/(1.0+np.log10(width+1))
            lifetime_score = 1.0 if stable_like else (0.0 if not np.isfinite(tau) else np.clip(np.log10(tau+1)/6.0,0,1))
            family_score = 0.5
            lower=name.lower()
            if any(x in lower for x in ['electron','muon','tau','neutrino']): family_score=0.75
            elif any(x in lower for x in ['photon','gluon','boson','higgs']): family_score=0.85
            elif any(x in lower for x in ['proton','neutron','pion','kaon','lambda','sigma','delta']): family_score=0.65
            H_raw = np.nanmean([mass_score, charge_score, 1.0 if mass>0 else 0.3])
            S_raw = np.nanmean([spin_score, family_score, 1.0-charge_score*0.15])
            L_raw = np.nanmean([lifetime_score, width_score, charge_score, family_score])
            Phi_particle_raw = np.nanmean([lifetime_score, width_score, family_score, spin_score, 1.0 if stable_like else 0.35])
            Fragility_raw = np.nanmean([1-lifetime_score, 1-width_score, abs(charge_score-0.33), 0.0 if stable_like else 0.65])
            particle_rows.append({'name':name,'pdgid':pdgid,'mass':mass,'charge':charge,'spin':spin,'width':width,'ctau':tau,
                                  'H_raw':H_raw,'S_raw':S_raw,'L_raw':L_raw,'Phi_particle_raw':Phi_particle_raw,'Fragility_raw':Fragility_raw,
                                  'stable_like':stable_like})
        except Exception:
            pass
except Exception as e:
    failures.append({'branch':'particle','stage':'import_parse','error':str(e)})

particles = pd.DataFrame(particle_rows)
if len(particles)>10:
    for col in ['H_raw','S_raw','L_raw','Phi_particle_raw','Fragility_raw']:
        particles[col.replace('_raw','')] = normalize01(particles[col].values)
    particles['Phi_HSL_epsilon']=(particles.H+EPSILON)*(particles.S+EPSILON)*(particles.L+EPSILON)
    particles['Triadic_balance']=[triadic_balance(h,s,l) for h,s,l in zip(particles.H,particles.S,particles.L)]
    particles['Functional_unity']=particles.Phi_HSL_epsilon*particles.Triadic_balance
    particles['Dominance_index']=[dominance_index(h,s,l) for h,s,l in zip(particles.H,particles.S,particles.L)]
    particles['coherence_high_flag']=particles.Phi_particle>=particles.Phi_particle.median()
    particles['fragility_high_flag']=particles.Fragility>=particles.Fragility.median()
    particles['triadic_disproportion_flag']=((particles.Triadic_balance<=particles.Triadic_balance.quantile(.25)) | (particles.Dominance_index>=particles.Dominance_index.quantile(.75)))

# ============================================================
# MODELS
# ============================================================

def regression(data, X_cols, y_col, label):
    d=data[X_cols+[y_col]].dropna()
    if len(d)<20: return {'test':label,'n':int(len(d)),'r2':None,'mae':None,'spearman_true_pred':None,'p_value':None}
    X=d[X_cols].values.astype(float); y=d[y_col].values.astype(float)
    model=Ridge(alpha=1.0).fit(X,y); pred=model.predict(X)
    r,p=safe_spearman(y,pred)
    return {'test':label,'n':int(len(d)),'r2':float(r2_score(y,pred)),'mae':float(mean_absolute_error(y,pred)),'spearman_true_pred':r,'p_value':p}

def auc_model(data, cols, target, label):
    d=data[cols+[target]].dropna()
    if len(d)<30 or len(d[target].unique())<2: return None
    X=d[cols].values.astype(float); y=d[target].astype(int).values
    try:
        clf=LogisticRegression(max_iter=1000,class_weight='balanced').fit(X,y)
        pred=clf.predict_proba(X)[:,1]
        auc=float(roc_auc_score(y,pred))
    except Exception: auc=np.nan
    return {'feature_set':label,'target':target,'n':int(len(d)),'auc':auc}

def gain_summary(classification_summary):
    rows=[]
    for target,d in classification_summary.groupby('target'):
        def auc(fs):
            x=d[d.feature_set==fs]
            return None if len(x)==0 else float(x.iloc[0].auc)
        aH,aHS,aHSL,aFull=auc('H'),auc('H+S'),auc('H+S+L'),auc('H+S+L+PhiBalanceDominance')
        rows.append({'target':target,'auc_H':aH,'auc_HS':aHS,'auc_HSL':aHSL,'auc_full':aFull,
                     'gain_HSL_over_H':None if aH is None or aHSL is None else aHSL-aH,
                     'gain_HSL_over_HS':None if aHS is None or aHSL is None else aHSL-aHS,
                     'gain_full_over_HSL':None if aFull is None or aHSL is None else aFull-aHSL})
    return pd.DataFrame(rows)

nuclear_genesis_summary=pd.DataFrame([
    regression(nuclear_nat,['H'],'S','Q2_NUC_NAT_H_to_S'),
    regression(nuclear_nat,['H'],'L','Q2_NUC_NAT_H_to_L'),
    regression(nuclear_nat,['S'],'L','Q2_NUC_NAT_S_to_L'),
    regression(nuclear_nat,['H','S'],'L','Q2_NUC_NAT_H_plus_S_to_L'),
    regression(nuclear_nat,['H','S','L'],'Phi_nuclear','Q2_NUC_NAT_HSL_to_Phi_nuclear'),
    regression(nuclear_nat,['H','S','L'],'Functional_unity','Q2_NUC_NAT_HSL_to_Functional_Unity'),
    regression(nuclear_nat,['H','S','L'],'Fragility','Q2_NUC_NAT_HSL_to_Nuclear_Fragility'),
    regression(nuclear_nat,['H','S','L','Triadic_balance','Dominance_index'],'Fragility','Q2_NUC_NAT_Full_to_Nuclear_Fragility'),
])

nuclear_all_summary=pd.DataFrame([
    regression(nuclear_all,['H'],'S','Q2_NUC_ALL_H_to_S'),
    regression(nuclear_all,['H'],'L','Q2_NUC_ALL_H_to_L'),
    regression(nuclear_all,['S'],'L','Q2_NUC_ALL_S_to_L'),
    regression(nuclear_all,['H','S'],'L','Q2_NUC_ALL_H_plus_S_to_L'),
    regression(nuclear_all,['H','S','L'],'Phi_nuclear','Q2_NUC_ALL_HSL_to_Phi_nuclear'),
    regression(nuclear_all,['H','S','L'],'Functional_unity','Q2_NUC_ALL_HSL_to_Functional_Unity'),
    regression(nuclear_all,['H','S','L'],'Fragility','Q2_NUC_ALL_HSL_to_Nuclear_Fragility'),
    regression(nuclear_all,['H','S','L','Triadic_balance','Dominance_index'],'Fragility','Q2_NUC_ALL_Full_to_Nuclear_Fragility'),
])

# Emergence contrast
H_L=nuclear_genesis_summary[nuclear_genesis_summary.test=='Q2_NUC_NAT_H_to_L'].iloc[0].mae
S_L=nuclear_genesis_summary[nuclear_genesis_summary.test=='Q2_NUC_NAT_S_to_L'].iloc[0].mae
HS_L=nuclear_genesis_summary[nuclear_genesis_summary.test=='Q2_NUC_NAT_H_plus_S_to_L'].iloc[0].mae
nuclear_emergence_contrast=pd.DataFrame([{'level':'micro_nuclear_isotopic_natural','H_to_L_mae':H_L,'S_to_L_mae':S_L,'H_plus_S_to_L_mae':HS_L,'HS_improves_over_H':H_L-HS_L,'HS_improves_over_S':S_L-HS_L,'PETU_prediction_supported':bool(HS_L<H_L and HS_L<S_L)}])

variant_summary=nuclear_all.groupby('variant').agg(n=('Z','count'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi=('Phi_nuclear','mean'),mean_Phi_HSL=('Phi_HSL_epsilon','mean'),mean_unity=('Functional_unity','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_fragility=('Fragility','mean'),stable_fraction=('stable_flag','mean'),mean_binding=('binding_per_A','mean'),mean_shell=('shell_score','mean')).reset_index().sort_values('mean_Phi',ascending=False)

# Contrasts
contrast_defs=[('natural_vs_perturbed','is_natural',True,False),('stable_vs_unstable','stable_flag',True,False),('coherent_vs_low','coherence_high_flag',True,False),('fragility_high_vs_low','fragility_high_flag',True,False),('disproportion_vs_proportion','triadic_disproportion_flag',True,False)]
metrics=['H','S','L','Phi_nuclear','Phi_HSL_epsilon','Functional_unity','Triadic_balance','Dominance_index','Fragility','binding_per_A','N_Z_ratio','shell_score','double_magic_score','evenodd_score','stable_band_score','half_life_score','abundance_score']
contrast_rows=[]
for cname,flag,a,b in contrast_defs:
    A=nuclear_all[nuclear_all[flag]==a]; B=nuclear_all[nuclear_all[flag]==b]
    for col in metrics:
        stat,p=safe_mw(A[col],B[col])
        contrast_rows.append({'contrast':cname,'metric':col,'groupA_mean':float(A[col].mean()),'groupB_mean':float(B[col].mean()),'delta_A_minus_B':float(A[col].mean()-B[col].mean()),'pct_delta':float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)),'mannwhitney_stat':stat,'p_value':p})
contrast_summary=pd.DataFrame(contrast_rows)

# Classification nuclear
class_rows=[]
feature_sets=[(['H'],'H'),(['S'],'S'),(['L'],'L'),(['H','S'],'H+S'),(['H','S','L'],'H+S+L'),(['H','S','L','Phi_HSL_epsilon'],'H+S+L+Phi'),(['H','S','L','Phi_HSL_epsilon','Triadic_balance','Dominance_index'],'H+S+L+PhiBalanceDominance')]
for target in ['is_natural','stable_flag','coherence_high_flag','fragility_high_flag','triadic_disproportion_flag']:
    for cols,label in feature_sets:
        r=auc_model(nuclear_all,cols,target,label)
        if r: class_rows.append(r)
nuclear_classification_summary=pd.DataFrame(class_rows)
nuclear_classification_gain_summary=gain_summary(nuclear_classification_summary)

# Particle summaries
particle_summary=pd.DataFrame([{'n_particles':int(len(particles)),'source':'particle_PDG_package','note':'Dedicated Q2 particle branch; proxy audit, not full QFT.'}])
if len(particles)>10:
    particle_genesis_summary=pd.DataFrame([
        regression(particles,['H'],'S','Q2_PARTICLE_H_to_S'),
        regression(particles,['H'],'L','Q2_PARTICLE_H_to_L'),
        regression(particles,['S'],'L','Q2_PARTICLE_S_to_L'),
        regression(particles,['H','S'],'L','Q2_PARTICLE_H_plus_S_to_L'),
        regression(particles,['H','S','L'],'Phi_particle','Q2_PARTICLE_HSL_to_Phi_particle'),
        regression(particles,['H','S','L'],'Functional_unity','Q2_PARTICLE_HSL_to_Functional_Unity'),
        regression(particles,['H','S','L'],'Fragility','Q2_PARTICLE_HSL_to_Particle_Fragility'),
    ])
    pclass=[]
    for target in ['coherence_high_flag','fragility_high_flag','triadic_disproportion_flag']:
        for cols,label in feature_sets:
            r=auc_model(particles,cols,target,label)
            if r: pclass.append(r)
    particle_classification_summary=pd.DataFrame(pclass)
    particle_classification_gain_summary=gain_summary(particle_classification_summary) if len(pclass)>0 else pd.DataFrame()
else:
    particle_genesis_summary=pd.DataFrame()
    particle_classification_summary=pd.DataFrame()
    particle_classification_gain_summary=pd.DataFrame()

# Phase classification
def phase(r):
    if r['is_natural'] and r['stable_flag'] and r['Phi_nuclear']>=nuclear_all.Phi_nuclear.median() and r['Triadic_balance']>=nuclear_all.Triadic_balance.median(): return 'stable_nuclear_phi_integrated'
    if r['variant']=='neutron_imbalance_stress': return 'H_neutron_imbalance_pathology'
    if r['variant']=='shell_structure_disruption': return 'S_shell_disruption_pathology'
    if r['variant']=='decay_linkage_suppression': return 'L_decay_linkage_pathology'
    if r['variant']=='binding_support_stress': return 'binding_support_stress'
    if r['is_natural'] and not r['stable_flag']: return 'natural_radioactive_fragile'
    if r['triadic_disproportion_flag']: return 'triadic_disproportion'
    return 'natural_transitional'
nuclear_all['PETU_Q2_phase']=nuclear_all.apply(phase,axis=1)
phase_summary=nuclear_all.groupby('PETU_Q2_phase').agg(n=('Z','count'),mean_Z=('Z','mean'),mean_A=('A','mean'),mean_H=('H','mean'),mean_S=('S','mean'),mean_L=('L','mean'),mean_Phi=('Phi_nuclear','mean'),mean_Phi_HSL=('Phi_HSL_epsilon','mean'),mean_unity=('Functional_unity','mean'),mean_balance=('Triadic_balance','mean'),mean_dominance=('Dominance_index','mean'),mean_fragility=('Fragility','mean'),stable_fraction=('stable_flag','mean'),mean_binding=('binding_per_A','mean'),mean_shell=('shell_score','mean')).reset_index().sort_values('n',ascending=False)

# Data summary
summary_data=pd.DataFrame([{'n_isotope_rows_natural':int(len(nuclear_nat)),'n_nuclear_rows_total':int(len(nuclear_all)),'n_elements_H_to_U':int(nuclear_nat.Z.nunique()),'n_stable_isotopes':int(nuclear_nat.stable_flag.sum()),'n_particle_rows':int(len(particles)),'epsilon':EPSILON,'sources':'mendeleev_isotopes,particle_PDG_package'}])

# Save
paths={
 'nuclear_features':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_features.csv',
 'nuclear_natural':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_natural.csv',
 'data_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_data_summary.csv',
 'nuclear_genesis_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_genesis_summary.csv',
 'nuclear_all_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_all_summary.csv',
 'nuclear_emergence_contrast':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_emergence_contrast.csv',
 'variant_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_variant_summary.csv',
 'contrast_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_contrast_summary.csv',
 'nuclear_classification_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_classification_summary.csv',
 'nuclear_classification_gain_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_nuclear_classification_gain_summary.csv',
 'phase_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_phase_summary.csv',
 'particle_features':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_particle_features.csv',
 'particle_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_particle_summary.csv',
 'particle_genesis_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_particle_genesis_summary.csv',
 'particle_classification_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_particle_classification_summary.csv',
 'particle_classification_gain_summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_particle_classification_gain_summary.csv',
 'failures':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_failures.csv',
 'summary':f'{OUTDIR}/PETU_MICRO_QUANTUM_Q2_summary.json'
}
nuclear_all.to_csv(paths['nuclear_features'],index=False); nuclear_nat.to_csv(paths['nuclear_natural'],index=False)
summary_data.to_csv(paths['data_summary'],index=False); nuclear_genesis_summary.to_csv(paths['nuclear_genesis_summary'],index=False); nuclear_all_summary.to_csv(paths['nuclear_all_summary'],index=False); nuclear_emergence_contrast.to_csv(paths['nuclear_emergence_contrast'],index=False); variant_summary.to_csv(paths['variant_summary'],index=False); contrast_summary.to_csv(paths['contrast_summary'],index=False); nuclear_classification_summary.to_csv(paths['nuclear_classification_summary'],index=False); nuclear_classification_gain_summary.to_csv(paths['nuclear_classification_gain_summary'],index=False); phase_summary.to_csv(paths['phase_summary'],index=False); particles.to_csv(paths['particle_features'],index=False); particle_summary.to_csv(paths['particle_summary'],index=False); particle_genesis_summary.to_csv(paths['particle_genesis_summary'],index=False); particle_classification_summary.to_csv(paths['particle_classification_summary'],index=False); particle_classification_gain_summary.to_csv(paths['particle_classification_gain_summary'],index=False); pd.DataFrame(failures).to_csv(paths['failures'],index=False)

final_summary={'pipeline':'PETU-MICRO-QUANTUM Q2 Nuclear/Particle Deep Triadic Audit','domain':'microphysics / nuclear isotopes / subatomic particles','primary_branch':'nuclear isotopic stability','n_isotope_rows_natural':int(len(nuclear_nat)),'n_nuclear_rows_total':int(len(nuclear_all)),'n_stable_isotopes':int(nuclear_nat.stable_flag.sum()),'n_particle_rows':int(len(particles)),'epsilon':EPSILON,'hypothesis':'Microphysical coherence arises from triadic proportion/co-inherence of H material/nucleonic support, S quantum/nuclear structure, and L interaction/decay linkage.','epistemic_note':'Proxy-based physical audit; Q1+Q2 count as one expanded microphysics domain in PETU atlas.','next_step':'Proceed to MESO-CARDIORESP C1 after evaluating Q2.'}
with open(paths['summary'],'w') as f: json.dump(final_summary,f,indent=2)

# Print blocks
for title,df in [
('PETU-MICRO-QUANTUM Q2 DATA SUMMARY',summary_data),
('PETU-MICRO-QUANTUM Q2 NUCLEAR NATURAL GENESIS SUMMARY',nuclear_genesis_summary),
('PETU-MICRO-QUANTUM Q2 NUCLEAR EMERGENCE CONTRAST',nuclear_emergence_contrast),
('PETU-MICRO-QUANTUM Q2 NUCLEAR ALL / PERTURBATIVE SUMMARY',nuclear_all_summary),
('PETU-MICRO-QUANTUM Q2 VARIANT SUMMARY',variant_summary),
('PETU-MICRO-QUANTUM Q2 CONTRAST SUMMARY',contrast_summary),
('PETU-MICRO-QUANTUM Q2 CLASSIFICATION GAIN SUMMARY',nuclear_classification_gain_summary),
('PETU-MICRO-QUANTUM Q2 PHASE SUMMARY',phase_summary),
('PETU-MICRO-QUANTUM Q2 PARTICLE SUMMARY',particle_summary),
('PETU-MICRO-QUANTUM Q2 PARTICLE GENESIS SUMMARY',particle_genesis_summary),
('PETU-MICRO-QUANTUM Q2 PARTICLE CLASSIFICATION GAIN SUMMARY',particle_classification_gain_summary)]:
    print('\n'+'='*60); print(title); print('='*60); print(df)

print('\n'+'='*60); print('PETU-MICRO-QUANTUM Q2 FINAL SUMMARY'); print('='*60); print(json.dumps(final_summary,indent=2))
if failures:
    print('\n'+'='*60); print('FAILURES / SKIPPED'); print('='*60); print(pd.DataFrame(failures))

# Figures
plt.figure(figsize=(8,5)); plt.scatter(nuclear_nat.H+nuclear_nat.S,nuclear_nat.L,s=12,alpha=.45); plt.xlabel('H + S'); plt.ylabel('L'); plt.title('PETU-Q2 nuclear natural: H+S -> L'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_Q2_NUC_HS_to_L.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(nuclear_all.Phi_HSL_epsilon,nuclear_all.Phi_nuclear,s=10,alpha=.35); plt.xlabel('Phi_HSL_epsilon'); plt.ylabel('Phi_nuclear'); plt.title('PETU-Q2: HSL unity vs nuclear coherence'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_Q2_PhiHSL_NuclearPhi.png',dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(nuclear_all.Dominance_index,nuclear_all.Fragility,s=10,alpha=.35); plt.xlabel('Dominance index'); plt.ylabel('Nuclear fragility'); plt.title('PETU-Q2: dominance and nuclear fragility'); plt.grid(True); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_Q2_Dominance_Fragility.png',dpi=220); plt.show()
plt.figure(figsize=(10,5)); plt.bar(variant_summary.variant,variant_summary.mean_Phi); plt.xticks(rotation=45,ha='right'); plt.ylabel('Mean nuclear Phi'); plt.title('PETU-Q2 nuclear variants'); plt.tight_layout(); plt.savefig(f'{OUTDIR}/figure_Q2_variant_phi.png',dpi=220); plt.show()

zip_base='/content/PETU_MICRO_QUANTUM_Q2_Nuclear_Particle_Deep_Triadic_Audit_results'
zip_path=zip_base+'.zip'
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,'zip',OUTDIR)
print('\n'+'='*60); print('PIPELINE COMPLETE')
for k,v in paths.items(): print(k+':',v)
print('ZIP:',zip_path); print('='*60)

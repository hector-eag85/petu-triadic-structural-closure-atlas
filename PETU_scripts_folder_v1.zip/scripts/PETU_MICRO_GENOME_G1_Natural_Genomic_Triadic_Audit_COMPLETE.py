# ============================================================
# PETU-MICRO-GENOME G1
# Natural Genomic / Codon-Structure Triadic Audit
# ============================================================
# Google Colab / mobile-ready pipeline.
# H = nucleotide/material support
# S = codon/ORF/formal genomic structure
# L = sequential linkage/memory/dependence
# Phi = genomic coherence / coding-sequence unity
# ============================================================

!pip -q install requests numpy pandas scipy scikit-learn matplotlib tqdm

import os, re, json, random, warnings, shutil
warnings.filterwarnings("ignore")
import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr, mannwhitneyu
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score

OUTDIR = "/content/PETU_MICRO_GENOME_G1_Natural_Genomic_Triadic_Audit"
os.makedirs(OUTDIR, exist_ok=True)
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)
EPSILON = 0.05
WINDOW_BP = 9000
STEP_BP = 4500
MIN_WINDOW_BP = 3000
MAX_WINDOWS_PER_GENOME = 45

GENOMES = {
    "E_coli_K12": "NC_000913.3",
    "B_subtilis_168": "NC_000964.3",
    "Mycoplasma_genitalium": "NC_000908.2",
    "Synechocystis_PCC6803": "NC_000911.1",
    "Human_mitochondrion": "NC_012920.1",
    "Arabidopsis_chloroplast": "NC_000932.1",
    "SARS_CoV_2_reference": "NC_045512.2",
    "Lambda_phage": "NC_001416.1"
}
BASES = "ACGT"
STOP_CODONS = {"TAA", "TAG", "TGA"}

def normalize01(x):
    x = np.asarray(x, dtype=float)
    mn, mx = np.nanmin(x), np.nanmax(x)
    if mx - mn < 1e-12:
        return np.zeros_like(x)
    return (x - mn) / (mx - mn)

def safe_spearman(a, b):
    try:
        a, b = np.asarray(a, float), np.asarray(b, float)
        m = np.isfinite(a) & np.isfinite(b)
        if m.sum() < 3:
            return None, None
        r, p = spearmanr(a[m], b[m])
        return float(r), float(p)
    except Exception:
        return None, None

def safe_mw(a, b):
    try:
        a, b = np.asarray(a, float), np.asarray(b, float)
        a, b = a[np.isfinite(a)], b[np.isfinite(b)]
        if len(a) < 3 or len(b) < 3:
            return None, None
        stat, p = mannwhitneyu(a, b, alternative="two-sided")
        return float(stat), float(p)
    except Exception:
        return None, None

def entropy_norm_from_counts(counts):
    counts = np.asarray(counts, dtype=float)
    counts = counts[counts > 0]
    if counts.sum() <= 0 or len(counts) <= 1:
        return 0.0
    p = counts / counts.sum()
    return float(-np.sum(p * np.log(p + 1e-12)) / np.log(len(counts) + 1e-12))

def triadic_balance(h, s, l):
    return float(max(0.0, 1.0 - np.std([h, s, l])))

def dominance_index(h, s, l):
    return float(max(h, s, l) - min(h, s, l))

def clean_seq(seq):
    return re.sub("[^ACGT]", "", seq.upper())

def fetch_fasta_ncbi(accession):
    url = "https://www.ncbi.nlm.nih.gov/sviewer/viewer.cgi"
    params = {"id": accession, "db": "nuccore", "report": "fasta", "retmode": "text"}
    r = requests.get(url, params=params, timeout=90)
    r.raise_for_status()
    text = r.text
    if not text.startswith(">"):
        raise RuntimeError("FASTA not returned")
    seq = clean_seq("".join([ln.strip() for ln in text.splitlines() if not ln.startswith(">")]))
    if len(seq) < MIN_WINDOW_BP:
        raise RuntimeError(f"Sequence too short: {len(seq)}")
    return seq

def counts_for_kmers(seq, k):
    d = {}
    for i in range(len(seq)-k+1):
        kmer = seq[i:i+k]
        if len(kmer) == k and all(c in BASES for c in kmer):
            d[kmer] = d.get(kmer, 0) + 1
    return d

def autocorr_numeric(x, lag=1):
    x = np.asarray(x, dtype=float)
    if len(x) <= lag + 3:
        return 0.0
    a, b = x[:-lag], x[lag:]
    if np.std(a) < 1e-12 or np.std(b) < 1e-12:
        return 0.0
    return float(np.corrcoef(a,b)[0,1])

def mutual_info_adjacent(seq):
    if len(seq) < 10:
        return 0.0
    idx = {b:i for i,b in enumerate(BASES)}
    joint = np.zeros((4,4), dtype=float)
    for a,b in zip(seq[:-1], seq[1:]):
        if a in idx and b in idx:
            joint[idx[a], idx[b]] += 1
    if joint.sum() <= 0:
        return 0.0
    pxy = joint / joint.sum(); px = pxy.sum(axis=1); py = pxy.sum(axis=0)
    mi = 0.0
    for i in range(4):
        for j in range(4):
            if pxy[i,j] > 0 and px[i] > 0 and py[j] > 0:
                mi += pxy[i,j] * np.log(pxy[i,j] / (px[i]*py[j] + 1e-12))
    return float(max(0.0, mi / np.log(4)))

def triplet_periodicity(seq):
    if len(seq) < 300:
        return 0.0
    x = np.array([1.0 if c in "GC" else 0.0 for c in seq], dtype=float)
    x = x - x.mean()
    fft = np.abs(np.fft.rfft(x))**2
    if fft.sum() <= 1e-12:
        return 0.0
    n = len(x)
    idx = int(round(n/3))
    idx = min(max(idx, 1), len(fft)-1)
    local = fft[max(1, idx-2):min(len(fft), idx+3)].sum()
    return float(local / (fft[1:].sum() + 1e-12))

def best_frame_orf_metrics(seq):
    best = None
    for frame in range(3):
        codons = [seq[i:i+3] for i in range(frame, len(seq)-2, 3)]
        if len(codons) < 20:
            continue
        stop_flags = np.array([c in STOP_CODONS for c in codons], dtype=int)
        stop_fraction = float(stop_flags.mean())
        longest = cur = 0
        for f in stop_flags:
            if f == 0:
                cur += 1; longest = max(longest, cur)
            else:
                cur = 0
        longest_frac = longest / (len(codons) + 1e-12)
        codon_counts = {}
        for c in codons:
            codon_counts[c] = codon_counts.get(c,0)+1
        codon_entropy = entropy_norm_from_counts(list(codon_counts.values()))
        score = (1.0 - stop_fraction) * 0.45 + longest_frac * 0.35 + codon_entropy * 0.20
        cand = {"best_frame": frame, "stop_fraction": stop_fraction, "longest_orf_frac": float(longest_frac), "codon_entropy": float(codon_entropy), "orf_integrity": float(score)}
        if best is None or cand["orf_integrity"] > best["orf_integrity"]:
            best = cand
    return best or {"best_frame": 0, "stop_fraction": 1.0, "longest_orf_frac": 0.0, "codon_entropy": 0.0, "orf_integrity": 0.0}

def mono_shuffle(seq):
    chars = list(seq); random.shuffle(chars); return "".join(chars)

def codon_shuffle(seq):
    usable = len(seq) - (len(seq) % 3)
    codons = [seq[i:i+3] for i in range(0, usable, 3)]
    random.shuffle(codons)
    return "".join(codons) + seq[usable:]

def frame_disrupt(seq):
    if len(seq) < 100: return seq
    s = list(seq); pos1 = len(s)//3; s.pop(pos1); pos2 = (2*len(s))//3; s.insert(pos2, random.choice(BASES)); return "".join(s)

def block_shuffle(seq, block=90):
    blocks = [seq[i:i+block] for i in range(0, len(seq), block)]
    random.shuffle(blocks)
    return "".join(blocks)

def features_for_sequence(seq, genome_name, accession, start, end, variant):
    seq = clean_seq(seq); n = len(seq)
    if n < MIN_WINDOW_BP: return None
    base_counts = np.array([seq.count(b) for b in BASES], dtype=float)
    freqs = base_counts / (base_counts.sum() + 1e-12)
    gc = (seq.count("G") + seq.count("C")) / (n + 1e-12)
    gc_balance = 1.0 - abs(gc - 0.5)*2.0
    base_entropy = entropy_norm_from_counts(base_counts)
    purine = (seq.count("A") + seq.count("G")) / (n + 1e-12)
    pyrimidine_balance = 1.0 - abs(purine - 0.5)*2.0
    g, c = seq.count("G"), seq.count("C")
    gc_skew = abs((g-c)/(g+c+1e-12))
    skew_stability = 1.0 - min(1.0, gc_skew)
    H_raw = np.mean([gc_balance, base_entropy, pyrimidine_balance, skew_stability, 1.0 - min(1.0, abs(gc - 0.42))])
    k2 = counts_for_kmers(seq, 2); k3 = counts_for_kmers(seq, 3); k4 = counts_for_kmers(seq, 4)
    k2_entropy = entropy_norm_from_counts(list(k2.values()))
    k3_entropy = entropy_norm_from_counts(list(k3.values()))
    k4_entropy = entropy_norm_from_counts(list(k4.values()))
    orf = best_frame_orf_metrics(seq)
    period3 = triplet_periodicity(seq)
    S_raw = np.mean([orf["orf_integrity"], 1.0 - orf["stop_fraction"], orf["longest_orf_frac"], orf["codon_entropy"], period3, k3_entropy])
    gc_signal = np.array([1.0 if b in "GC" else 0.0 for b in seq], dtype=float)
    pur_signal = np.array([1.0 if b in "AG" else 0.0 for b in seq], dtype=float)
    ac1 = max(0.0, autocorr_numeric(gc_signal, 1)); ac3 = max(0.0, autocorr_numeric(gc_signal, 3)); ac10 = max(0.0, autocorr_numeric(gc_signal, 10)); ac30 = max(0.0, autocorr_numeric(gc_signal, 30))
    pur_ac3 = max(0.0, autocorr_numeric(pur_signal, 3)); mi_adj = mutual_info_adjacent(seq)
    dinuc = counts_for_kmers(seq, 2); dinuc_dev = []
    for a in BASES:
        for b in BASES:
            obs = dinuc.get(a+b,0) / max(1, n-1)
            exp = freqs[BASES.index(a)] * freqs[BASES.index(b)]
            dinuc_dev.append(abs(obs-exp))
    dinuc_linkage = min(1.0, np.sum(dinuc_dev) * 4.0)
    L_raw = np.mean([ac1, ac3, ac10, ac30, pur_ac3, mi_adj, dinuc_linkage])
    Phi_genomic_raw = np.mean([orf["orf_integrity"], 1.0 - orf["stop_fraction"], min(1.0, orf["longest_orf_frac"]*4.0), period3, k3_entropy, 1.0 - min(1.0, abs(k2_entropy-k4_entropy)), 0.7 + min(0.3, mi_adj)])
    Genomic_pathology_raw = np.mean([orf["stop_fraction"], 1.0 - min(1.0, orf["longest_orf_frac"]*4.0), 1.0 - orf["orf_integrity"], 1.0 - k3_entropy, 1.0 - period3, min(1.0, gc_skew)])
    return {"genome": genome_name, "accession": accession, "variant": variant, "window_start": int(start), "window_end": int(end), "n_bp": int(n), "gc": float(gc), "base_entropy": float(base_entropy), "gc_balance": float(gc_balance), "pyrimidine_balance": float(pyrimidine_balance), "skew_stability": float(skew_stability), "best_frame": int(orf["best_frame"]), "stop_fraction": float(orf["stop_fraction"]), "longest_orf_frac": float(orf["longest_orf_frac"]), "codon_entropy": float(orf["codon_entropy"]), "orf_integrity": float(orf["orf_integrity"]), "period3": float(period3), "k2_entropy": float(k2_entropy), "k3_entropy": float(k3_entropy), "k4_entropy": float(k4_entropy), "ac1": float(ac1), "ac3": float(ac3), "ac10": float(ac10), "ac30": float(ac30), "pur_ac3": float(pur_ac3), "mi_adjacent": float(mi_adj), "dinuc_linkage": float(dinuc_linkage), "H_raw": float(H_raw), "S_raw": float(S_raw), "L_raw": float(L_raw), "Phi_genomic_raw": float(Phi_genomic_raw), "Genomic_pathology_raw": float(Genomic_pathology_raw)}

def regression(data, X_cols, y_col, label):
    d = data[X_cols + [y_col]].dropna()
    if len(d) < 20:
        return {"test": label, "n": int(len(d)), "r2": None, "mae": None, "spearman_true_pred": None, "p_value": None}
    X = d[X_cols].values.astype(float); y = d[y_col].values.astype(float)
    model = Ridge(alpha=1.0); model.fit(X, y); pred = model.predict(X)
    r, p = safe_spearman(y, pred)
    return {"test": label, "n": int(len(d)), "r2": float(r2_score(y, pred)), "mae": float(mean_absolute_error(y, pred)), "spearman_true_pred": r, "p_value": p}

def auc_model(data, feature_cols, target, label):
    d = data[feature_cols + [target]].dropna()
    if len(d) < 30 or len(d[target].unique()) < 2: return None
    X = d[feature_cols].values.astype(float); y = d[target].astype(int).values
    try:
        clf = LogisticRegression(max_iter=1000, class_weight="balanced"); clf.fit(X,y); pred = clf.predict_proba(X)[:,1]
        auc = roc_auc_score(y, pred)
    except Exception: auc = np.nan
    return {"feature_set": label, "target": target, "n": int(len(d)), "auc": float(auc)}

print("============================================================")
print("PETU-MICRO-GENOME G1 NATURAL GENOMIC TRIADIC AUDIT")
print("============================================================")
print("Fetching natural RefSeq genomes...")
raw_genomes, failures = {}, []
for name, acc in tqdm(GENOMES.items(), desc="RefSeq genomes"):
    try:
        seq = fetch_fasta_ncbi(acc)
        raw_genomes[name] = {"accession": acc, "sequence": seq}
        print(f"  OK {name} {acc} length: {len(seq)}")
    except Exception as e:
        failures.append({"genome": name, "accession": acc, "error": str(e)})
        print("  FAIL", name, acc, str(e))
if len(raw_genomes) < 4: raise RuntimeError("Too few genomes loaded. Check NCBI connection.")

rows, genome_summary_rows = [], []
for genome_name, item in tqdm(raw_genomes.items(), desc="Genomic windows"):
    acc, seq = item["accession"], item["sequence"]; n = len(seq)
    starts = list(range(0, max(1, n - MIN_WINDOW_BP + 1), STEP_BP))
    if len(starts) > MAX_WINDOWS_PER_GENOME:
        idxs = np.linspace(0, len(starts)-1, MAX_WINDOWS_PER_GENOME).astype(int)
        starts = [starts[i] for i in idxs]
    natural_count = 0
    for st in starts:
        en = min(st + WINDOW_BP, n)
        if en - st < MIN_WINDOW_BP: continue
        wseq = seq[st:en]
        variants = {"natural": wseq, "mono_shuffle": mono_shuffle(wseq), "codon_shuffle": codon_shuffle(wseq), "block_shuffle": block_shuffle(wseq, 90), "frame_disrupt": frame_disrupt(wseq)}
        for variant, vseq in variants.items():
            feat = features_for_sequence(vseq, genome_name, acc, st, en, variant)
            if feat: rows.append(feat)
        natural_count += 1
    genome_summary_rows.append({"genome": genome_name, "accession": acc, "length_bp": int(n), "n_natural_windows": int(natural_count)})
features = pd.DataFrame(rows); genome_summary = pd.DataFrame(genome_summary_rows)
if len(features) < 100: raise RuntimeError("Too few windows/features.")
for col in ["H_raw","S_raw","L_raw","Phi_genomic_raw","Genomic_pathology_raw"]:
    features[col.replace("_raw","")] = normalize01(features[col].values)
features["Phi_HSL_epsilon"] = (features["H"]+EPSILON)*(features["S"]+EPSILON)*(features["L"]+EPSILON)
features["Triadic_balance"] = [triadic_balance(h,s,l) for h,s,l in zip(features.H, features.S, features.L)]
features["Functional_unity"] = features["Phi_HSL_epsilon"] * features["Triadic_balance"]
features["Dominance_index"] = [dominance_index(h,s,l) for h,s,l in zip(features.H, features.S, features.L)]
features["is_natural"] = features["variant"].eq("natural")
features["is_perturbed"] = ~features["is_natural"]
features["pathology_high_flag"] = features["Genomic_pathology"] >= features["Genomic_pathology"].median()
features["coherence_high_flag"] = features["Phi_genomic"] >= features["Phi_genomic"].median()
features["triadic_disproportion_flag"] = ((features["Triadic_balance"] <= features["Triadic_balance"].quantile(0.25)) | (features["Dominance_index"] >= features["Dominance_index"].quantile(0.75)))
features["L_disrupted_flag"] = features["variant"].isin(["mono_shuffle", "block_shuffle", "frame_disrupt"])
natural = features[features.is_natural].copy(); all_data = features.copy()

data_summary = pd.DataFrame([{"n_genomes_loaded": int(len(raw_genomes)), "n_total_rows": int(len(features)), "n_natural_windows": int(len(natural)), "n_perturbed_windows": int(features.is_perturbed.sum()), "window_bp": WINDOW_BP, "step_bp": STEP_BP, "variants": ",".join(sorted(features.variant.unique()))}])
genesis_summary = pd.DataFrame([regression(natural,["H"],"S","G1_NAT_H_to_S"), regression(natural,["H"],"L","G1_NAT_H_to_L"), regression(natural,["S"],"L","G1_NAT_S_to_L"), regression(natural,["H","S"],"L","G1_NAT_H_plus_S_to_L"), regression(natural,["H","S","L"],"Phi_genomic","G1_NAT_HSL_to_Phi_genomic"), regression(natural,["H","S","L"],"Functional_unity","G1_NAT_HSL_to_Functional_Unity"), regression(natural,["H","S","L"],"Genomic_pathology","G1_NAT_HSL_to_Genomic_Pathology"), regression(natural,["H","S","L","Triadic_balance","Dominance_index"],"Genomic_pathology","G1_NAT_Full_to_Genomic_Pathology")])
perturbative_summary = pd.DataFrame([regression(all_data,["H"],"S","G1_ALL_H_to_S"), regression(all_data,["H"],"L","G1_ALL_H_to_L"), regression(all_data,["S"],"L","G1_ALL_S_to_L"), regression(all_data,["H","S"],"L","G1_ALL_H_plus_S_to_L"), regression(all_data,["H","S","L"],"Phi_genomic","G1_ALL_HSL_to_Phi_genomic"), regression(all_data,["H","S","L"],"Functional_unity","G1_ALL_HSL_to_Functional_Unity"), regression(all_data,["H","S","L"],"Genomic_pathology","G1_ALL_HSL_to_Genomic_Pathology"), regression(all_data,["H","S","L","Triadic_balance","Dominance_index"],"Genomic_pathology","G1_ALL_Full_to_Genomic_Pathology")])
def get_mae(summary, test):
    x = summary[summary.test == test]
    return None if len(x)==0 else x.iloc[0].mae
H_L=get_mae(genesis_summary,"G1_NAT_H_to_L"); S_L=get_mae(genesis_summary,"G1_NAT_S_to_L"); HS_L=get_mae(genesis_summary,"G1_NAT_H_plus_S_to_L")
emergence_contrast = pd.DataFrame([{"level":"micro_genome_natural", "H_to_L_mae":H_L, "S_to_L_mae":S_L, "H_plus_S_to_L_mae":HS_L, "HS_improves_over_H": H_L-HS_L if H_L is not None and HS_L is not None else None, "HS_improves_over_S": S_L-HS_L if S_L is not None and HS_L is not None else None, "PETU_prediction_supported": (HS_L < H_L and HS_L < S_L) if H_L is not None and S_L is not None and HS_L is not None else None}])
variant_summary = features.groupby("variant").agg(n=("genome","count"), n_genomes=("genome","nunique"), mean_H=("H","mean"), mean_S=("S","mean"), mean_L=("L","mean"), mean_Phi=("Phi_genomic","mean"), mean_Phi_HSL=("Phi_HSL_epsilon","mean"), mean_unity=("Functional_unity","mean"), mean_balance=("Triadic_balance","mean"), mean_dominance=("Dominance_index","mean"), mean_pathology=("Genomic_pathology","mean"), mean_orf_integrity=("orf_integrity","mean"), mean_period3=("period3","mean"), mean_mi=("mi_adjacent","mean")).reset_index().sort_values("mean_Phi", ascending=False)
contrast_defs = [("natural_vs_perturbed","is_natural",True,False),("coherent_vs_low","coherence_high_flag",True,False),("pathology_high_vs_low","pathology_high_flag",True,False),("disproportion_vs_proportion","triadic_disproportion_flag",True,False),("L_disrupted_vs_other","L_disrupted_flag",True,False)]
contrast_metrics = ["H","S","L","Phi_genomic","Phi_HSL_epsilon","Functional_unity","Triadic_balance","Dominance_index","Genomic_pathology","orf_integrity","stop_fraction","longest_orf_frac","codon_entropy","period3","k3_entropy","mi_adjacent","dinuc_linkage","ac3","ac10"]
contrast_rows=[]
for cname,flag,aval,bval in contrast_defs:
    A=features[features[flag]==aval]; B=features[features[flag]==bval]
    for col in contrast_metrics:
        stat,p=safe_mw(A[col],B[col])
        contrast_rows.append({"contrast":cname,"metric":col,"groupA_mean":float(A[col].mean()) if len(A) else np.nan,"groupB_mean":float(B[col].mean()) if len(B) else np.nan,"delta_A_minus_B":float(A[col].mean()-B[col].mean()) if len(A) and len(B) else np.nan,"pct_delta":float(100*(A[col].mean()-B[col].mean())/(abs(B[col].mean())+1e-12)) if len(A) and len(B) else np.nan,"mannwhitney_stat":stat,"p_value":p})
contrast_summary = pd.DataFrame(contrast_rows)
class_rows=[]; targets=["is_natural","coherence_high_flag","pathology_high_flag","triadic_disproportion_flag","L_disrupted_flag"]
feature_sets=[(["H"],"H"),(["S"],"S"),(["L"],"L"),(["H","S"],"H+S"),(["H","S","L"],"H+S+L"),(["H","S","L","Phi_HSL_epsilon"],"H+S+L+Phi"),(["H","S","L","Phi_HSL_epsilon","Triadic_balance","Dominance_index"],"H+S+L+PhiBalanceDominance")]
for target in targets:
    for cols,label in feature_sets:
        r=auc_model(features,cols,target,label)
        if r: class_rows.append(r)
classification_summary=pd.DataFrame(class_rows)
gain_rows=[]
for target,d in classification_summary.groupby("target"):
    def auc(fs):
        x=d[d.feature_set==fs]
        return None if len(x)==0 else float(x.iloc[0].auc)
    aH,aHS,aHSL,aFull=auc("H"),auc("H+S"),auc("H+S+L"),auc("H+S+L+PhiBalanceDominance")
    gain_rows.append({"target":target,"auc_H":aH,"auc_HS":aHS,"auc_HSL":aHSL,"auc_full":aFull,"gain_HSL_over_H":None if aH is None or aHSL is None else aHSL-aH,"gain_HSL_over_HS":None if aHS is None or aHSL is None else aHSL-aHS,"gain_full_over_HSL":None if aFull is None or aHSL is None else aFull-aHSL})
classification_gain_summary=pd.DataFrame(gain_rows)
def classify_phase(r):
    if r.is_natural and r.Phi_genomic >= features.Phi_genomic.median() and r.Triadic_balance >= features.Triadic_balance.median(): return "natural_phi_integrated"
    if r.variant == "mono_shuffle": return "mono_shuffle_support_only"
    if r.variant == "codon_shuffle": return "codon_structure_without_link"
    if r.variant == "frame_disrupt": return "frame_disrupted_pathology"
    if r.triadic_disproportion_flag: return "triadic_disproportion"
    if r.variant == "block_shuffle": return "block_linkage_disrupted"
    if r.is_natural: return "natural_transitional"
    return "perturbed_transitional"
features["PETU_G1_phase"] = features.apply(classify_phase, axis=1)
phase_summary = features.groupby("PETU_G1_phase").agg(n=("genome","count"), n_genomes=("genome","nunique"), mean_H=("H","mean"), mean_S=("S","mean"), mean_L=("L","mean"), mean_Phi=("Phi_genomic","mean"), mean_Phi_HSL=("Phi_HSL_epsilon","mean"), mean_unity=("Functional_unity","mean"), mean_balance=("Triadic_balance","mean"), mean_dominance=("Dominance_index","mean"), mean_pathology=("Genomic_pathology","mean"), mean_orf_integrity=("orf_integrity","mean"), mean_period3=("period3","mean"), mean_mi=("mi_adjacent","mean")).reset_index().sort_values("n", ascending=False)
paths={"features":f"{OUTDIR}/PETU_MICRO_GENOME_G1_features.csv","genome_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_genome_summary.csv","data_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_data_summary.csv","genesis_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_genesis_summary.csv","perturbative_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_perturbative_summary.csv","emergence_contrast":f"{OUTDIR}/PETU_MICRO_GENOME_G1_emergence_contrast.csv","variant_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_variant_summary.csv","contrast_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_contrast_summary.csv","classification_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_classification_summary.csv","classification_gain_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_classification_gain_summary.csv","phase_summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_phase_summary.csv","failures":f"{OUTDIR}/PETU_MICRO_GENOME_G1_failures.csv","summary":f"{OUTDIR}/PETU_MICRO_GENOME_G1_summary.json"}
for name,df in [("features",features),("genome_summary",genome_summary),("data_summary",data_summary),("genesis_summary",genesis_summary),("perturbative_summary",perturbative_summary),("emergence_contrast",emergence_contrast),("variant_summary",variant_summary),("contrast_summary",contrast_summary),("classification_summary",classification_summary),("classification_gain_summary",classification_gain_summary),("phase_summary",phase_summary)]: df.to_csv(paths[name], index=False)
pd.DataFrame(failures).to_csv(paths["failures"], index=False)
summary={"pipeline":"PETU-MICRO-GENOME G1 Natural Genomic Triadic Audit","domain":"micro natural genomics / RefSeq complete genomes / codon and sequence organization","n_genomes_loaded":int(len(raw_genomes)),"n_total_rows":int(len(features)),"n_natural_windows":int(len(natural)),"n_perturbed_windows":int(features.is_perturbed.sum()),"window_bp":WINDOW_BP,"step_bp":STEP_BP,"epsilon":EPSILON,"hypothesis":"Genomic coherence arises from triadic proportion/co-inherence of H nucleotide support, S codon-formal structure, and L sequential linkage.","theological_note":"Operationalizes the H-in-S / S-in-H co-inherence criterion: genomic structure S is nucleotide support H conformed into codon/ORF order.","next_step":"MICRO-METAB M1 metabolic network triadic audit; then MESO cardiorespiratory and embryogenesis domains."}
with open(paths["summary"],"w") as f: json.dump(summary,f,indent=2)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 DATA SUMMARY"); print("============================================================"); print(data_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 GENOME SUMMARY"); print("============================================================"); print(genome_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 NATURAL GENESIS SUMMARY"); print("============================================================"); print(genesis_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 EMERGENCE CONTRAST"); print("============================================================"); print(emergence_contrast)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 PERTURBATIVE SUMMARY"); print("============================================================"); print(perturbative_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 VARIANT SUMMARY"); print("============================================================"); print(variant_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 CONTRAST SUMMARY"); print("============================================================"); print(contrast_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 CLASSIFICATION GAIN SUMMARY"); print("============================================================"); print(classification_gain_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 PHASE SUMMARY"); print("============================================================"); print(phase_summary)
print("\n============================================================"); print("PETU-MICRO-GENOME G1 FINAL SUMMARY"); print("============================================================"); print(json.dumps(summary, indent=2))
if len(failures)>0:
    print("\n============================================================"); print("FAILURES / SKIPPED"); print("============================================================"); print(pd.DataFrame(failures))
plt.figure(figsize=(8,5)); plt.scatter(natural["H"]+natural["S"], natural["L"], s=22, alpha=0.65); plt.xlabel("H + S"); plt.ylabel("L"); plt.title("PETU-GENOME G1 natural: H+S -> L"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_G1_NAT_HS_to_L.png", dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features["Phi_HSL_epsilon"], features["Phi_genomic"], s=18, alpha=0.45); plt.xlabel("Phi_HSL_epsilon"); plt.ylabel("Phi_genomic"); plt.title("PETU-GENOME G1: HSL unity vs genomic coherence"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_G1_PhiHSL_GenomicPhi.png", dpi=220); plt.show()
plt.figure(figsize=(8,5)); plt.scatter(features["Dominance_index"], features["Genomic_pathology"], s=18, alpha=0.45); plt.xlabel("Dominance index"); plt.ylabel("Genomic pathology"); plt.title("PETU-GENOME G1: dominance and genomic pathology"); plt.grid(True); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_G1_Dominance_Pathology.png", dpi=220); plt.show()
plt.figure(figsize=(9,5)); plt.bar(variant_summary["variant"], variant_summary["mean_Phi"]); plt.xticks(rotation=45); plt.ylabel("Mean genomic Phi"); plt.title("PETU-GENOME G1: natural vs perturbative variants"); plt.tight_layout(); plt.savefig(f"{OUTDIR}/figure_G1_variant_phi.png", dpi=220); plt.show()
zip_base="/content/PETU_MICRO_GENOME_G1_Natural_Genomic_Triadic_Audit_results"; zip_path=zip_base+".zip"
if os.path.exists(zip_path): os.remove(zip_path)
shutil.make_archive(zip_base,"zip",OUTDIR)
print("\n============================================================"); print("PIPELINE COMPLETE")
for k,v in paths.items(): print(k+":",v)
print("ZIP:", zip_path); print("============================================================")

# PETU Main Figures Final v1

This folder contains the regenerated main figures for:

**Triadic structural closure across twelve natural domains**

## Contents

- Figure 1: Atlas and framework
- Figure 2: HSL reconstructs Phi and Unity
- Figure 3: Linkage from raw and structured support
- Figure 4: Perturbative loss of coherence
- Figure 5: Fragility as triadic disproportion
- Figure 6: Cross-scale evidence map

## Source-backed status

Figures were regenerated from Supplementary Tables Final v1 CSV sources and figure-source tables.

Final status:
- PASS_STRUCTURAL for file creation and source linkage.
- PENDING_FINAL_LOG_AUDIT for final reconciliation against raw logs/source outputs before public preprint or journal submission.

## AI compliance

These regenerated figures were produced programmatically from tabular sources using Matplotlib. They are not generative-AI image outputs.

## Generated files

- Individual PNG and PDF files for each figure
- PETU_Main_Figures_Final_v1.pdf: combined multipage PDF
- PETU_Main_Figures_Final_Audit_v1.csv
- PETU_Main_Figures_Source_Numeric_Checks_v1.csv
- Source CSVs for Figures 1-6

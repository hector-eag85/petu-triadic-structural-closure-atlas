# PETU Extended Data Figures Final v1 - Captions

**Extended Data Fig. 1 | Operational definitions of H, S, L and Phi.** Role-equivalent definitions used across the empirical atlas.

**Extended Data Fig. 2 | HSL -> Phi and HSL -> Unity robustness.** Cross-domain R2 and rank-association support for coherence and unity reconstruction.

**Extended Data Fig. 3 | H_raw, H_structured and linkage emergence.** Diagnostic comparison of raw support, structure, H+S and structured support in linkage prediction.

**Extended Data Fig. 4 | Perturbative and null contrasts.** Natural-versus-perturbed differences in Phi and Phi_HSL where such auxiliary stress tests are available.

**Extended Data Fig. 5 | Independent tier-1 validation.** Immune, metabolism, hydrology and climate validation block using preserved operational architecture and independent data or validation substrates.

**Extended Data Fig. 6 | Fragility archetypes and disproportion.** Fragility as relational imbalance, rupture, dominance or capture in H-S-L organization.

**Extended Data Fig. 7 | Robustness, controls and evidence grading.** Domain-level evidence grades summarizing performance, validation, perturbative support and replication priority.

**Extended Data Fig. 8 | Preregistered replication roadmap.** Future replication sequence and the rule that the H/S/L/Phi architecture must be preserved while datasets change.

Status: PASS_STRUCTURAL / PENDING_FINAL_LOG_AUDIT.

# PETU Extended Data Figures Final v1

This folder contains Extended Data Figures 1-8 for:

**Triadic structural closure across twelve natural domains**

## Status

- PASS_STRUCTURAL for file creation and source linkage.
- PENDING_FINAL_LOG_AUDIT for final reconciliation against raw logs/source outputs before public preprint or journal submission.

## AI compliance

These figures were produced programmatically from Supplementary Tables and source CSVs using Matplotlib. They are not generative-AI image outputs.

## Contents

- Individual PNG and PDF files for EDF1-EDF8
- PETU_Extended_Data_Figures_Final_v1.pdf: combined 8-page PDF
- source CSVs for EDF1-EDF8
- PETU_Extended_Data_Figures_Final_Audit_v1.csv
- PETU_Extended_Data_Figures_Source_Numeric_Checks_v1.csv

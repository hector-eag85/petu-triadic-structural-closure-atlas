# PETU Theory and Strong Predictions Public Package v1

This package contains a cleaned, modularized, public-ready edition of the PETU mathematical theory materials.

## Contents

1. `01_mathematical_theory_formal_companion/`
   - Formal mathematical companion.
   - Clean notation, claim boundary, operators, falsification, categorical/tensorial/variational extensions and law-candidate criteria.

2. `02_strong_predictions_preregistered_tests/`
   - Separated strong prediction and preregistration document.
   - Prediction classes, null models, thresholds, domain templates and failure matrix.

3. `03_admin_audit/`
   - Manifest, render audit, phrase scan and summary.

## Public records

Preprint DOI: https://doi.org/10.5281/zenodo.20821557  
Data/Code DOI: https://doi.org/10.5281/zenodo.20820252  
Repository: https://github.com/hector-eag85/petu-triadic-structural-closure-atlas

## Status

Prepared as a public mathematical companion package, not as a replacement for empirical validation.

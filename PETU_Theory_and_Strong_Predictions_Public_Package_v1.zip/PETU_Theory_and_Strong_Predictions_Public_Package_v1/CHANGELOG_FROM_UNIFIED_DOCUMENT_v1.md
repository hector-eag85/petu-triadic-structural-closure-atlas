# Changelog from unified mathematical document v1

This package edits the earlier unified PETU mathematical text into two public-facing modules:

1. PETU Mathematical Theory Formal Companion v1
2. PETU Strong Predictions and Preregistered Tests v1

## Main editorial operations

- Added explicit claim-boundary section.
- Added notation table.
- Defined admissible systems as N*.
- Standardized H_raw / H_structured notation.
- Corrected balance operator.
- Split dominance into D_gap and D_share.
- Standardized triadic gain as a difference-form metric with optional ratio-form report.
- Added non-circularity and endpoint-independence section.
- Reframed category-theoretic material as structural comparison, not proof.
- Added measurable commutativity error E_Theta.
- Reframed tensorial and variational extensions as research horizons.
- Renamed universal-law language into law-candidate criteria.
- Separated preregistered predictions and domain templates into their own document.
